# Custom FastMCP Server

This repository contains a template for deploying a **FastMCP** server
integrated with **FastAPI**.  It exposes a simple `fetch_tasks` tool
and demonstrates how to mount the MCP server under a custom path
within a FastAPI application.  The project is configurable via
environment variables and supports separate settings for development,
testing and production.

## Project layout

```
project_root/
│
├── config.py        ← Centralised configuration management
├── run.py           ← Entry point that starts the ASGI server
├── main.py          ← Assembles the FastAPI app and mounts the MCP server
├── app/
│   ├── __init__.py  ← Exposes create_mcp_server for convenience
│   └── mcp_server.py← Defines the MCP server and its tools
├── requirements.txt ← Python dependencies
├── .env.dev         ← Environment variables for development
├── .env.test        ← Environment variables for testing
├── .env.prod        ← Environment variables for production
└── README.md        ← Project documentation
```

## How it works

### MCP server and tools

The MCP server is created in `app/mcp_server.py` using the
[`FastMCP` class](https://gofastmcp.com/getting-started/welcome).  A
`fetch_tasks` tool is registered using the `@mcp.tool` decorator.
You can add additional tools here following the same pattern.

### FastAPI integration

`main.py` constructs a FastAPI application and mounts the MCP ASGI
application returned by `FastMCP.http_app()`.  The mounting process
uses a helper function to split your desired MCP endpoint into a
**mount prefix** and an **internal MCP subpath**.  For example,
requesting `mcp.http_app(path='/mcp')` and mounting it at
`/analytics` will expose the MCP server at `/analytics/mcp/`【881929937029725†L438-L474】.  By
splitting your configured path (e.g. `/vagas/apps/mcp`) into
`mount_prefix='/vagas/apps'` and `mcp_subpath='/mcp'`, the final
endpoint becomes `/vagas/apps/mcp` in your deployment.

The MCP documentation notes that you can customise the HTTP path by
passing the `path` argument when building the HTTP app【123095618924159†L232-L247】; this
project uses that feature under the hood.

### Configuration

`config.py` defines a `Settings` dataclass that reads its values
from environment variables.  These settings include:

- `MCP_NAME` – a human‑readable name for your server (default
  `Custom MCP Server`).
- `MCP_PATH` – the URL path where the MCP routes should live (default
  `/vagas/apps/mcp`).
- `MCP_HOST` – host interface for Uvicorn to bind (default `0.0.0.0`).
- `MCP_PORT` – TCP port (default `8000`).
- `MCP_DEBUG` – enables auto‑reload in development when set to `true`.

Use the provided `.env.*` files as templates.  The
[`python-dotenv`](https://pypi.org/project/python-dotenv/) package
listed in `requirements.txt` will load the appropriate file if you
choose to integrate it into your workflow.

### Running the server

1. **Install dependencies**:

   ```bash
   pip install -r requirements.txt
   ```

2. **Choose or create an environment file** (`.env.dev`, `.env.test`
   or `.env.prod`) and export its variables.  For example:

   ```bash
   export $(grep -v '^#' .env.dev | xargs)
   ```

3. **Start the server**:

   ```bash
   python run.py
   ```

The server will listen on the configured host and port.  The MCP
endpoint will be available at the path defined in `MCP_PATH`.  A
health check is also available at `/health`.

### Extending the server

- **Add new tools** by decorating functions in `app/mcp_server.py` with
  `@mcp.tool`.  Be sure to provide type hints and a docstring;
  FastMCP automatically generates input schemas and descriptions.
- **Add other FastAPI routes** by defining them in `main.py` before
  mounting the MCP app.
- **Enable authentication** by following the FastMCP
  authentication guide; you can pass authentication headers when
  creating the MCP server or mount it behind your own auth layer.

Feel free to tailor this template to your infrastructure and
deployment platform.  See the FastMCP documentation for more
advanced features such as resources, prompts and client libraries.
