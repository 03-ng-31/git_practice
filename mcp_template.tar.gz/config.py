"""
Configuration settings for the custom MCP server.

This module centralizes configuration values used throughout the
project.  Keeping configuration in one place makes it easy to
change runtime behaviour without editing business logic.  When
deploying to your cloud infrastructure, you can override these
values via environment variables or by modifying this file.
"""

from dataclasses import dataclass
import os


@dataclass
class Settings:
    """Application configuration values.

    Attributes:
        mcp_name: Human‑readable name for the MCP server.  This
            appears in the MCP metadata and in OpenAPI docs.
        mcp_path: URL path where the MCP server should be exposed.
            This path is relative to the domain root; your cloud
            gateway may prepend additional prefixes (e.g. `/domain`).
            For example, if you set ``mcp_path`` to ``/vagas/apps/mcp``
            and your gateway inserts ``/domain`` in front of every
            route, the final MCP endpoint will be
            ``/domain/vagas/apps/mcp``.
        host: Host interface on which to run the ASGI server.  Set
            this to ``0.0.0.0`` to listen on all network interfaces.
        port: TCP port on which to serve HTTP traffic.
        debug: Enable debug mode for FastAPI/uvicorn.  Do not enable
            this in production.
    """

    mcp_name: str = os.getenv("MCP_NAME", "Custom MCP Server")
    mcp_path: str = os.getenv("MCP_PATH", "/vagas/apps/mcp")
    host: str = os.getenv("MCP_HOST", "0.0.0.0")
    port: int = int(os.getenv("MCP_PORT", "8000"))
    debug: bool = os.getenv("MCP_DEBUG", "false").lower() == "true"


# Instantiate a global settings object so other modules can import
# configuration values without instantiating Settings themselves.
settings = Settings()
