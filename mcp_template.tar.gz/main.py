"""
Application bootstrap for the MCP FastAPI service.

This module brings together the configuration settings and the
MCP server logic defined in :mod:`app.mcp_server` to build a
FastAPI application.  The resulting ASGI app can be served by
Uvicorn or any other ASGI server.  A health check endpoint is
included for monitoring purposes.
"""

from __future__ import annotations

from typing import Dict, Tuple

from fastapi import FastAPI

from config import settings
from app import create_mcp_server


def split_path(path: str) -> Tuple[str, str]:
    """Split a URL path into a mount prefix and a subpath for MCP.

    The MCP server's HTTP app attaches its routes under a given
    subpath. When mounting that app into FastAPI, separating the
    path into a mount prefix and subpath ensures the final URL
    structure is correct. See the FastMCP documentation for
    mounting details【881929937029725†L438-L474】.

    Parameters
    ----------
    path: str
        The full URL path where the MCP server should be exposed.

    Returns
    -------
    tuple[str, str]
        A tuple ``(mount_prefix, mcp_subpath)``.  ``mount_prefix`` is
        everything before the last segment, and ``mcp_subpath`` is
        that last segment with a leading slash.  If there is only
        one segment, ``mount_prefix`` will be empty.
    """
    normalized = path.strip()
    if not normalized.startswith("/"):
        normalized = "/" + normalized
    normalized = normalized.rstrip("/")
    parts = normalized.split("/")[1:]
    if len(parts) <= 1:
        return "", f"/{parts[0]}" if parts else "/"
    mount_prefix = "/" + "/".join(parts[:-1])
    mcp_subpath = f"/{parts[-1]}"
    return mount_prefix, mcp_subpath


def create_fastapi_app() -> FastAPI:
    """Assemble and return the FastAPI application.

    Creates a FastMCP server instance using :func:`app.create_mcp_server`,
    constructs its ASGI application at the configured subpath, and
    mounts it within a FastAPI application.  A `/health` route is
    added for Kubernetes or load balancer health checks.  The MCP
    lifespan context is forwarded to FastAPI to ensure proper
    initialization and cleanup【881929937029725†L438-L474】.
    """
    mcp = create_mcp_server()
    mount_prefix, mcp_subpath = split_path(settings.mcp_path)
    mcp_app = mcp.http_app(path=mcp_subpath)
    app = FastAPI(title=settings.mcp_name, lifespan=mcp_app.lifespan)
    # When mount_prefix is empty, mount at root.  Otherwise mount
    # under the specified prefix.
    app.mount(mount_prefix or "/", mcp_app)

    @app.get("/health", tags=["Health"])
    async def health_check() -> Dict[str, str]:
        """Return basic service health information."""
        return {"status": "ok", "service": settings.mcp_name}

    return app


# Expose a module-level ASGI app for Uvicorn autodiscovery
app = create_fastapi_app()
