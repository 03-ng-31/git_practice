"""
Top level package for the MCP application.

This package exposes the :func:`create_mcp_server` function which
constructs and configures the FastMCP server.  It can also be used
to group additional modules (e.g. database models, API clients) in
the future.
"""

from .mcp_server import create_mcp_server  # noqa: F401
