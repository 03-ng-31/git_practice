"""
MCP server tools and business logic.

This module defines the tasks exposed by the MCP server and
provides a factory function to construct and configure a
:class:`fastmcp.FastMCP` instance.  Separating the server logic
from the application entry point promotes modularity and makes it
easier to write unit tests against individual tools without
bootstrapping the entire HTTP layer.
"""

from __future__ import annotations

from typing import List, Optional, Dict

from fastmcp import FastMCP
from config import settings


def create_mcp_server() -> FastMCP:
    """Create and configure the FastMCP server.

    Returns
    -------
    fastmcp.FastMCP
        A configured MCP server with registered tools.
    """
    mcp = FastMCP(name=settings.mcp_name)

    # Example in‑memory tasks for demonstration. In a real project,
    # replace this with database or API calls to fetch tasks.
    tasks_db: List[Dict[str, str]] = [
        {"id": "1", "title": "Prepare project proposal", "status": "pending"},
        {"id": "2", "title": "Review design document", "status": "completed"},
        {"id": "3", "title": "Implement MCP server", "status": "in_progress"},
    ]

    @mcp.tool(
        name="fetch_tasks",
        description=(
            "Retrieve tasks from the internal task list. Optionally filter "
            "by status and limit the number of results returned."
        ),
    )
    def fetch_tasks(
        status: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[Dict[str, str]]:
        """Fetch a list of tasks.

        Parameters
        ----------
        status: Optional[str], optional
            If provided, return only tasks whose ``status`` field matches
            this value.  Accepted statuses in the demonstration data are
            ``"pending"``, ``"in_progress"`` and ``"completed"``.
        limit: Optional[int], optional
            If provided, return at most this many tasks.  If omitted,
            all matching tasks are returned.

        Returns
        -------
        list of dict
            A list of tasks represented as dictionaries.  Each task
            includes an ``id``, ``title`` and ``status``.  If no
            tasks match the criteria, an empty list is returned.
        """
        filtered = (
            [task for task in tasks_db if task["status"] == status]
            if status is not None
            else list(tasks_db)
        )
        if limit is not None and limit > 0:
            filtered = filtered[: limit]
        return filtered

    return mcp
