"""
Entry point for launching the custom MCP server.

Running this module will start a Uvicorn HTTP server exposing the
FastAPI application defined in :mod:`main`.  The server listens on
the host and port specified in :mod:`config` and serves the MCP
endpoint at the configured path.  To run in a different
environment, adjust the values in `config.py` or set the
``MCP_HOST`` and ``MCP_PORT`` environment variables before
starting the process.

Example
-------
.. code-block:: bash

   # Start the MCP server on localhost:8000
   python run.py

   # Override the port using an environment variable
   MCP_PORT=9000 python run.py
"""

from __future__ import annotations

import uvicorn

from config import settings
from main import app


def main() -> None:
    """Boot the Uvicorn server.

    This function delegates to :func:`uvicorn.run` with the
    configured host and port.  Passing ``reload=True`` would enable
    auto‑reloading during development, but is disabled by default to
    avoid unnecessary overhead in production environments.
    """
    uvicorn.run(
        app,
        host=settings.host,
        port=settings.port,
        reload=settings.debug,
        log_level="info",
    )


if __name__ == "__main__":
    main()
