import cv2
import logging

def preprocess_image(image, use_adaptive_threshold=True):
    """
    Preprocess the image by converting it to grayscale, applying Gaussian blur,
    and then thresholding.
    :param image: Input BGR image.
    :param use_adaptive_threshold: Flag to use adaptive thresholding.
    :return: Binary (thresholded) image.
    """
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    logging.info("Converted image to grayscale.")
    
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    logging.info("Applied Gaussian blur for noise reduction.")
    
    if use_adaptive_threshold:
        thresh = cv2.adaptiveThreshold(blurred, 255, 
                                       cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                       cv2.THRESH_BINARY, 11, 2)
        logging.info("Applied adaptive thresholding.")
    else:
        eq = cv2.equalizeHist(blurred)
        _, thresh = cv2.threshold(eq, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        logging.info("Applied histogram equalization and Otsu thresholding.")
    return thresh

def preprocess_image(image):
    """
    Converts an image (PIL format) to OpenCV format, then applies preprocessing:
    grayscale, denoising, and thresholding.
    """
    # Convert PIL image to NumPy array (OpenCV uses BGR)
    image_cv = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
    gray = cv2.cvtColor(image_cv, cv2.COLOR_BGR2GRAY)
    # Denoise
    gray = cv2.fastNlMeansDenoising(gray, None, 30, 7, 21)
    # Threshold using Otsu's method
    _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return image_cv, thresh
