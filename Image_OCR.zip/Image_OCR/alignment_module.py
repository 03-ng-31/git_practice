import cv2
import numpy as np
import logging

def warp_image(scanned, H, ref_shape):
    """
    Warp the scanned image using the homography matrix to align it with the reference.
    :param scanned: The scanned image.
    :param H: Homography matrix.
    :param ref_shape: Shape of the reference template image.
    :return: Warped (aligned) image.
    """
    height, width = ref_shape[:2]
    warped = cv2.warpPerspective(scanned, H, (width, height))
    logging.info("Warped scanned image to align with reference template.")
    return warped
