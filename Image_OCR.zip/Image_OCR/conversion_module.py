import cv2
import numpy as np
import logging
from pdf2image import convert_from_path

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def pdf_to_images(pdf_path, dpi=300):
    """
    Convert each page of a PDF into high-resolution images.
    :param pdf_path: Path to the PDF file.
    :param dpi: DPI for conversion.
    :return: List of images in BGR format.
    """
    logging.info(f"Converting PDF {pdf_path} to images at {dpi} DPI.")
    pil_images = convert_from_path(pdf_path, dpi=dpi)
    images = []
    for i, pil_img in enumerate(pil_images):
        open_cv_image = np.array(pil_img)
        open_cv_image = cv2.cvtColor(open_cv_image, cv2.COLOR_RGB2BGR)
        images.append(open_cv_image)
    return images
