import cv2
import numpy as np
import logging

def match_template(reference, scanned, min_match_count=30):
    """
    Use ORB to verify that the scanned image matches the reference template.
    If enough matches are found, compute the homography.
    :param reference: Reference template image.
    :param scanned: Scanned page image.
    :param min_match_count: Minimum number of matches required.
    :return: (Homography matrix, matches, success flag)
    """
    orb = cv2.ORB_create(500)
    kp_ref, des_ref = orb.detectAndCompute(reference, None)
    kp_scan, des_scan = orb.detectAndCompute(scanned, None)

    if des_ref is None or des_scan is None:
        logging.warning("Could not compute descriptors; skipping this page.")
        return None, None, False

    bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    matches = bf.match(des_ref, des_scan)
    matches = sorted(matches, key=lambda x: x.distance)
    logging.info(f"Found {len(matches)} total matches.")

    if len(matches) < min_match_count:
        logging.warning("Not enough matches; page does not match the template.")
        return None, matches, False

    pts_ref = np.float32([kp_ref[m.queryIdx].pt for m in matches]).reshape(-1, 1, 2)
    pts_scan = np.float32([kp_scan[m.trainIdx].pt for m in matches]).reshape(-1, 1, 2)
    H, mask = cv2.findHomography(pts_scan, pts_ref, cv2.RANSAC, 5.0)

    if H is not None:
        logging.info("Homography computed successfully; page matches template.")
        return H, matches, True
    else:
        logging.warning("Homography computation failed.")
        return None, matches, False
