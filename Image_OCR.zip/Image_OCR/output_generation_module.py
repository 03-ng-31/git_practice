import cv2
import os
import tempfile
import logging
from fpdf import FPDF

def save_image(output_path, image):
    """
    Save a single image to disk.
    :param output_path: File path for the image.
    :param image: Image to save.
    """
    cv2.imwrite(output_path, image)
    logging.info(f"Saved redacted image to {output_path}")

def save_images_as_pdf(output_path, images):
    """
    Compile multiple images into a single PDF.
    :param output_path: File path for the PDF.
    :param images: List of images.
    """
    pdf = FPDF()
    for idx, img in enumerate(images):
        temp_path = os.path.join(tempfile.gettempdir(), f"page_{idx}.jpg")
        cv2.imwrite(temp_path, img)
        pdf.add_page()
        pdf.image(temp_path, x=10, y=10, w=pdf.w - 20)
    pdf.output(output_path, "F")
    logging.info(f"Saved redacted PDF to {output_path}")
