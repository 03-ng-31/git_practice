import cv2
import os
import logging
import argparse

from conversion_module import pdf_to_images
from preprocessing_module import preprocess_image
from template_verification_module import match_template
from alignment_module import warp_image
from redaction_module import redact_image
from output_generation_module import save_image, save_images_as_pdf

roi_definitions = {
    "name": (100, 150, 400, 200),
    "address": (100, 210, 400, 260),
    "bank_account": (100, 270, 400, 320),
    "routing_number": (100, 330, 400, 380),
    "ein": (100, 390, 400, 440),
    "ssn": (100, 450, 400, 500)
}

def main():
    parser = argparse.ArgumentParser(description="Module-wise Redaction Pipeline")
    parser.add_argument("input_file", help="Path to input PDF or image file")
    parser.add_argument("output_file", help="Path to save the redacted output")
    parser.add_argument("template_file", help="Path to reference template image")
    args = parser.parse_args()

    ref_template = cv2.imread(args.template_file)
    if ref_template is None:
        logging.error("Could not load the reference template image.")
        return

    input_path = args.input_file
    ext = os.path.splitext(input_path)[1].lower()
    if ext == ".pdf":
        images = pdf_to_images(input_path, dpi=300)
    else:
        img = cv2.imread(input_path)
        if img is None:
            logging.error("Could not load the input image.")
            return
        images = [img]

    processed_images = []
    for idx, scanned in enumerate(images):
        logging.info(f"Processing page {idx+1}/{len(images)}")
        
        preprocessed = preprocess_image(scanned)
        
        H, matches, match_success = match_template(ref_template, scanned, min_match_count=30)
        if not match_success:
            logging.warning(f"Page {idx+1}: Template verification failed. Skipping redaction.")
            continue
        
        aligned = warp_image(scanned, H, ref_template.shape)
        
        redacted = redact_image(aligned, ref_template, roi_definitions, blur_strength=(51, 51))
        processed_images.append(redacted)

    if len(processed_images) == 0:
        logging.error("No pages processed successfully.")
    elif len(processed_images) == 1:
        save_image(args.output_file, processed_images[0])
    else:
        save_images_as_pdf(args.output_file, processed_images)

if __name__ == '__main__':
    main()
