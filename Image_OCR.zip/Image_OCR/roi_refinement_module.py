import cv2
import logging

def refine_roi_position(aligned_img, ref_template, roi_box):
    """
    Refine the ROI location using template matching.
    :param aligned_img: The aligned scanned image.
    :param ref_template: The reference template image.
    :param roi_box: Predefined ROI coordinates (x1, y1, x2, y2) in the reference.
    :return: Refined ROI coordinates (x1, y1, x2, y2) in the aligned image.
    """
    x1, y1, x2, y2 = roi_box
    roi_template = ref_template[y1:y2, x1:x2]
    
    result = cv2.matchTemplate(aligned_img, roi_template, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, max_loc = cv2.minMaxLoc(result)
    logging.info(f"Template matching confidence for ROI: {max_val:.2f}")

    refined_box = (max_loc[0], max_loc[1], max_loc[0] + (x2 - x1), max_loc[1] + (y2 - y1))
    return refined_box
