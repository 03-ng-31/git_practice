import cv2
import logging
from roi_refinement_module import refine_roi_position

def redact_image(aligned_img, ref_template, roi_defs, blur_strength=(51, 51)):
    """
    Redact sensitive regions in the aligned image.
    For each predefined ROI, refine its location using template matching and apply a Gaussian blur.
    :param aligned_img: Aligned scanned image.
    :param ref_template: Reference template image.
    :param roi_defs: Dictionary of ROI definitions.
    :param blur_strength: Gaussian blur kernel size.
    :return: Redacted image.
    """
    redacted = aligned_img.copy()
    for label, roi_box in roi_defs.items():
        refined_box = refine_roi_position(aligned_img, ref_template, roi_box)
        x1, y1, x2, y2 = refined_box
        logging.info(f"Redacting {label} at refined coordinates: {(x1, y1, x2, y2)}")
        roi = redacted[y1:y2, x1:x2]
        redacted[y1:y2, x1:x2] = cv2.GaussianBlur(roi, blur_strength, 0)
    return redacted
