from flask import Flask, render_template, request, jsonify, send_from_directory
import cv2
import numpy as np
from werkzeug.utils import secure_filename
import os
import json
from document_matcher import DocumentMatcher
import base64
import fitz  # PyMuPDF
import tempfile

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Ensure upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'pdf'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def convert_pdf_to_image(pdf_path):
    """Convert first page of PDF to image using PyMuPDF"""
    try:
        # Open PDF document
        pdf_document = fitz.open(pdf_path)
        
        if len(pdf_document) == 0:
            raise ValueError("PDF file is empty")
            
        # Get first page
        first_page = pdf_document[0]
        
        # Set a higher zoom factor for better quality (2 = 200% zoom)
        zoom = 2.0
        mat = fitz.Matrix(zoom, zoom)
        
        # Get the page's pixmap (image)
        pix = first_page.get_pixmap(matrix=mat)
        
        # Convert to numpy array
        img_array = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)
        
        # Convert to BGR format for OpenCV if needed
        if pix.n == 4:  # RGBA
            img_array = cv2.cvtColor(img_array, cv2.COLOR_RGBA2BGR)
        elif pix.n == 3:  # RGB
            img_array = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
            
        # Resize if image is too large
        max_dimension = 2000  # Maximum width or height
        height, width = img_array.shape[:2]
        if height > max_dimension or width > max_dimension:
            scale = max_dimension / max(height, width)
            new_width = int(width * scale)
            new_height = int(height * scale)
            img_array = cv2.resize(img_array, (new_width, new_height))
            
        pdf_document.close()
        return img_array
        
    except Exception as e:
        raise RuntimeError(f"Error converting PDF to image: {str(e)}")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_files():
    if 'template' not in request.files or 'input' not in request.files:
        return jsonify({'error': 'Both template and input files are required'}), 400
    
    template_file = request.files['template']
    input_file = request.files['input']
    
    if template_file.filename == '' or input_file.filename == '':
        return jsonify({'error': 'No selected files'}), 400
    
    if not (allowed_file(template_file.filename) and allowed_file(input_file.filename)):
        return jsonify({'error': 'Invalid file type'}), 400
    
    try:
        # Create temporary directory for PDF processing
        with tempfile.TemporaryDirectory() as temp_dir:
            # Save files with Windows-safe paths
            template_temp_path = os.path.join(temp_dir, 'template' + os.path.splitext(template_file.filename)[1])
            input_temp_path = os.path.join(temp_dir, 'input' + os.path.splitext(input_file.filename)[1])
            
            template_file.save(template_temp_path)
            input_file.save(input_temp_path)
            
            # Process template file
            if template_file.filename.lower().endswith('.pdf'):
                try:
                    template_image = convert_pdf_to_image(template_temp_path)
                    template_save_path = os.path.join(app.config['UPLOAD_FOLDER'], 'template.jpg')
                    cv2.imwrite(template_save_path, template_image)
                except Exception as e:
                    return jsonify({'error': f'Error processing template PDF: {str(e)}. Make sure poppler is installed correctly.'}), 400
            else:
                template_save_path = os.path.join(app.config['UPLOAD_FOLDER'], 'template.jpg')
                template_file.seek(0)
                template_file.save(template_save_path)
            
            # Process input file
            if input_file.filename.lower().endswith('.pdf'):
                try:
                    input_image = convert_pdf_to_image(input_temp_path)
                    input_save_path = os.path.join(app.config['UPLOAD_FOLDER'], 'input.jpg')
                    cv2.imwrite(input_save_path, input_image)
                except Exception as e:
                    return jsonify({'error': f'Error processing input PDF: {str(e)}. Make sure poppler is installed correctly.'}), 400
            else:
                input_save_path = os.path.join(app.config['UPLOAD_FOLDER'], 'input.jpg')
                input_file.seek(0)
                input_file.save(input_save_path)
        
        return jsonify({
            'template': 'static/uploads/template.jpg',
            'input': 'static/uploads/input.jpg'
        })
        
    except Exception as e:
        return jsonify({'error': f'Error processing files: {str(e)}'}), 400

@app.route('/align', methods=['POST'])
def align_images():
    try:
        template_path = os.path.join(app.config['UPLOAD_FOLDER'], 'template.jpg')
        input_path = os.path.join(app.config['UPLOAD_FOLDER'], 'input.jpg')
        
        template = cv2.imread(template_path)
        input_img = cv2.imread(input_path)
        
        if template is None or input_img is None:
            return jsonify({'error': 'Could not read images'}), 400
        
        # Perform alignment
        matcher = DocumentMatcher()
        aligned_image, match_scores = matcher.align_images(template, input_img)
        
        # Save aligned image
        aligned_path = os.path.join(app.config['UPLOAD_FOLDER'], 'aligned.jpg')
        cv2.imwrite(aligned_path, aligned_image)
        
        return jsonify({
            'aligned': 'static/uploads/aligned.jpg',
            'scores': match_scores
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/process', methods=['POST'])
def process_images():
    try:
        steps = json.loads(request.form.get('steps', '[]'))
        params = json.loads(request.form.get('params', '{}'))
        target_image = request.form.get('target_image', 'both')
        
        template_path = os.path.join(app.config['UPLOAD_FOLDER'], 'template.jpg')
        input_path = os.path.join(app.config['UPLOAD_FOLDER'], 'input.jpg')
        
        result = {}
        matcher = DocumentMatcher()
        
        if target_image in ['template', 'both']:
            template = cv2.imread(template_path)
            if template is None:
                return jsonify({'error': 'Could not read template image'}), 400
            
            processed_template = template.copy()
            for step in steps:
                step_params = params.get(step, {})
                processed_template = matcher.preprocess_image(processed_template, step, step_params)
            
            cv2.imwrite(os.path.join(app.config['UPLOAD_FOLDER'], 'processed_template.jpg'), processed_template)
            result['processed_template'] = 'static/uploads/processed_template.jpg'
            
        if target_image in ['input', 'both']:
            input_img = cv2.imread(input_path)
            if input_img is None:
                return jsonify({'error': 'Could not read input image'}), 400
            
            processed_input = input_img.copy()
            for step in steps:
                step_params = params.get(step, {})
                processed_input = matcher.preprocess_image(processed_input, step, step_params)
            
            cv2.imwrite(os.path.join(app.config['UPLOAD_FOLDER'], 'processed_input.jpg'), processed_input)
            result['processed_input'] = 'static/uploads/processed_input.jpg'
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/download/<filename>')
def download_file(filename):
    try:
        return send_from_directory(app.config['UPLOAD_FOLDER'],
                                 filename,
                                 as_attachment=True)
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/ocr', methods=['POST'])
def perform_ocr():
    try:
        data = request.json
        roi = data.get('roi')  # Get region coordinates
        
        # Read aligned image
        aligned_path = os.path.join(app.config['UPLOAD_FOLDER'], 'aligned.jpg')
        aligned_image = cv2.imread(aligned_path)
        
        if aligned_image is None:
            return jsonify({'error': 'Could not read aligned image'}), 400
            
        # Perform OCR
        matcher = DocumentMatcher()
        result = matcher.perform_ocr(aligned_image, roi)
        
        # Save annotated image
        annotated_path = os.path.join(app.config['UPLOAD_FOLDER'], 'annotated.jpg')
        cv2.imwrite(annotated_path, result['annotated_image'])
        
        # Return results
        return jsonify({
            'text': result['text'],
            'confidence': result['confidence'],
            'metrics': result['detailed_metrics'],
            'annotated_image': 'static/uploads/annotated.jpg'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/preprocess_ocr', methods=['POST'])
def preprocess_ocr():
    try:
        # Read aligned image
        aligned_path = os.path.join(app.config['UPLOAD_FOLDER'], 'aligned.jpg')
        aligned_image = cv2.imread(aligned_path)
        
        if aligned_image is None:
            return jsonify({'error': 'Could not read aligned image'}), 400
            
        # Preprocess image
        matcher = DocumentMatcher()
        preprocessed = matcher.preprocess_for_ocr(aligned_image)
        
        # Save preprocessed image
        preprocessed_path = os.path.join(app.config['UPLOAD_FOLDER'], 'preprocessed.jpg')
        cv2.imwrite(preprocessed_path, preprocessed)
        
        return jsonify({
            'preprocessed': 'static/uploads/preprocessed.jpg'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/preprocess_text', methods=['POST'])
def preprocess_text():
    try:
        data = request.json
        options = data.get('options', {})
        
        # Read aligned image
        aligned_path = os.path.join(app.config['UPLOAD_FOLDER'], 'aligned.jpg')
        image = cv2.imread(aligned_path)
        
        if image is None:
            return jsonify({'error': 'Could not read image'}), 400
        
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Apply selected preprocessing steps
        if options.get('enhance_contrast'):
            clahe = cv2.createCLAHE(
                clipLimit=options['enhance_contrast']['level'],
                tileGridSize=(8,8)
            )
            gray = clahe.apply(gray)
            
        if options.get('denoise'):
            gray = cv2.fastNlMeansDenoising(
                gray,
                None,
                options['denoise']['strength'],
                7,
                21
            )
            
        if options.get('sharpen'):
            kernel = np.array([[-1,-1,-1],
                             [-1, 9,-1],
                             [-1,-1,-1]]) * options['sharpen']['intensity']
            gray = cv2.filter2D(gray, -1, kernel)
            
        if options.get('threshold'):
            gray = cv2.adaptiveThreshold(
                gray,
                255,
                cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                cv2.THRESH_BINARY,
                options['threshold']['block_size'],
                11
            )
        
        # Save preprocessed image
        preprocessed_path = os.path.join(app.config['UPLOAD_FOLDER'], 'text_preprocessed.jpg')
        cv2.imwrite(preprocessed_path, gray)
        
        return jsonify({
            'preprocessed': 'static/uploads/text_preprocessed.jpg'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True) 