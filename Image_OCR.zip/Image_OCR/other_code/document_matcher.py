import cv2
import numpy as np
import pytesseract
from PIL import Image
import os

# Add Tesseract path for Windows
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
os.environ['TESSDATA_PREFIX'] = r'C:\Program Files\Tesseract-OCR\tessdata'

class DocumentMatcher:
    @staticmethod
    def align_images(template, input_image):
        """
        Align input image to template using feature matching and homography,
        optimized for W9 and EFT forms. Returns aligned image and match quality.
        """
        try:
            # Convert images to grayscale
            template_gray = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)
            input_gray = cv2.cvtColor(input_image, cv2.COLOR_BGR2GRAY)
            
            # Apply adaptive thresholding to better handle form backgrounds
            template_thresh = cv2.adaptiveThreshold(template_gray, 255, 
                                                  cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                                  cv2.THRESH_BINARY, 11, 2)
            input_thresh = cv2.adaptiveThreshold(input_gray, 255, 
                                               cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                               cv2.THRESH_BINARY, 11, 2)
            
            # Initialize ORB detector
            orb = cv2.ORB_create(nfeatures=2000)
            
            # Detect keypoints and compute descriptors
            kp1, des1 = orb.detectAndCompute(template_thresh, None)
            kp2, des2 = orb.detectAndCompute(input_thresh, None)
            
            if des1 is None or des2 is None:
                raise ValueError("Could not detect features in one or both images")
            
            # Use Brute Force Matcher
            bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
            matches = bf.match(des1, des2)
            
            # Sort matches by distance
            matches = sorted(matches, key=lambda x: x.distance)
            
            # Calculate match quality
            total_matches = len(matches)
            good_matches = [m for m in matches if m.distance < 50]  # Adjust threshold as needed
            match_quality = (len(good_matches) / total_matches * 100) if total_matches > 0 else 0
            
            # Take only good matches for alignment
            good_matches = matches[:min(len(matches), 50)]
            
            if len(good_matches) < 4:
                raise ValueError("Not enough good matches found for alignment")
            
            # Extract location of good matches
            src_pts = np.float32([kp1[m.queryIdx].pt for m in good_matches]).reshape(-1, 1, 2)
            dst_pts = np.float32([kp2[m.trainIdx].pt for m in good_matches]).reshape(-1, 1, 2)
            
            # Find homography
            H, mask = cv2.findHomography(dst_pts, src_pts, cv2.RANSAC, 3.0)
            
            if H is None:
                raise ValueError("Could not find homography matrix")
            
            # Calculate additional alignment metrics
            inliers = np.sum(mask)
            alignment_score = (inliers / len(good_matches) * 100) if len(good_matches) > 0 else 0
            
            # Warp input image
            height, width = template.shape[:2]
            aligned_image = cv2.warpPerspective(input_image, H, (width, height))
            
            # Calculate structural similarity after alignment
            aligned_gray = cv2.cvtColor(aligned_image, cv2.COLOR_BGR2GRAY)
            ssim = cv2.matchTemplate(template_gray, aligned_gray, cv2.TM_CCOEFF_NORMED)[0][0]
            ssim_score = max(0, min(100, ssim * 100))
            
            # Convert numpy values to regular Python floats for JSON serialization
            match_quality = float(match_quality)
            alignment_score = float(alignment_score)
            ssim_score = float(ssim_score)
            final_score = float(match_quality * 0.4 + alignment_score * 0.3 + ssim_score * 0.3)
            
            return aligned_image, {
                'match_quality': round(match_quality, 2),
                'alignment_score': round(alignment_score, 2),
                'similarity_score': round(ssim_score, 2),
                'final_score': round(final_score, 2)
            }
        except Exception as e:
            raise ValueError(f"Error in alignment process: {str(e)}")

    @staticmethod
    def preprocess_image(image, process_type, params=None):
        """
        Apply various preprocessing techniques optimized for W9 and EFT forms
        """
        if params is None:
            params = {}
            
        try:
            # Convert to BGR if image is grayscale
            if len(image.shape) == 2:
                image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
            
            if process_type == 'grayscale':
                return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
            elif process_type == 'blur':
                kernel_size = params.get('kernel_size', 3)
                # Ensure kernel size is odd
                kernel_size = max(1, kernel_size if kernel_size % 2 == 1 else kernel_size + 1)
                if len(image.shape) == 2:  # If image is already grayscale
                    return cv2.GaussianBlur(image, (kernel_size, kernel_size), 0)
                else:
                    return cv2.GaussianBlur(image, (kernel_size, kernel_size), 0)
            
            elif process_type == 'threshold':
                # Convert to grayscale if needed
                if len(image.shape) == 3:
                    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
                else:
                    gray = image
                thresh = params.get('thresh', 127)
                _, binary = cv2.threshold(gray, thresh, 255, cv2.THRESH_BINARY)
                return binary
            
            elif process_type == 'adaptive_threshold':
                # Convert to grayscale if needed
                if len(image.shape) == 3:
                    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
                else:
                    gray = image
                block_size = params.get('block_size', 11)
                C = params.get('C', 2)
                # Ensure block_size is odd
                block_size = max(3, block_size if block_size % 2 == 1 else block_size + 1)
                return cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                          cv2.THRESH_BINARY, block_size, C)
            
            elif process_type == 'form_enhance':
                # Convert to grayscale if needed
                if len(image.shape) == 3:
                    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
                else:
                    gray = image
                contrast_limit = params.get('contrast_limit', 2.0)
                clahe = cv2.createCLAHE(clipLimit=contrast_limit, tileGridSize=(8,8))
                enhanced = clahe.apply(gray)
                denoised = cv2.fastNlMeansDenoising(enhanced)
                binary = cv2.adaptiveThreshold(denoised, 255, 
                                             cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                             cv2.THRESH_BINARY, 11, 2)
                return binary
            
            elif process_type == 'denoise':
                if len(image.shape) == 3:
                    return cv2.fastNlMeansDenoisingColored(image, None, 
                                                         params.get('strength', 10), 
                                                         params.get('strength', 10), 7, 21)
                else:
                    return cv2.fastNlMeansDenoising(image, None, 
                                                  params.get('strength', 10), 7, 21)
            
            else:
                raise ValueError(f"Unknown process type: {process_type}")
                
        except Exception as e:
            raise RuntimeError(f"Error processing image: {str(e)}")

    @staticmethod
    def detect_form_fields(image):
        """
        Detect and extract form fields from W9 or EFT forms
        """
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Apply adaptive threshold
        binary = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                     cv2.THRESH_BINARY_INV, 11, 2)
        
        # Find contours
        contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Filter contours based on area and aspect ratio
        form_fields = []
        for contour in contours:
            area = cv2.contourArea(contour)
            if area < 100:  # Skip small contours
                continue
                
            x, y, w, h = cv2.boundingRect(contour)
            aspect_ratio = w / float(h)
            
            # Check if contour could be a form field
            if 0.1 < aspect_ratio < 20:  # Adjust these values based on your forms
                form_fields.append((x, y, w, h))
        
        return form_fields 

    @staticmethod
    def perform_ocr(image, roi):
        """
        Perform OCR optimized for handwritten digits with enhanced accuracy
        """
        try:
            # Convert ROI coordinates to integers
            x, y, w, h = map(int, [roi['x'], roi['y'], roi['width'], roi['height']])
            
            # Extract ROI from image
            roi_image = image[y:y+h, x:x+w]
            
            # Enhanced preprocessing for handwritten digits
            # 1. Convert to grayscale
            gray = cv2.cvtColor(roi_image, cv2.COLOR_BGR2GRAY)
            
            # 2. Resize image to much larger size for better recognition
            scale = 4  # Increased scale factor
            enlarged = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
            
            # 3. Apply advanced noise reduction
            denoised = cv2.fastNlMeansDenoising(enlarged, None, h=10, templateWindowSize=7, searchWindowSize=21)
            
            # 4. Enhance contrast with multiple methods
            clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8,8))
            enhanced = clahe.apply(denoised)
            
            # Normalize the image
            enhanced = cv2.normalize(enhanced, None, 0, 255, cv2.NORM_MINMAX)
            
            # 5. Sharpen the image
            kernel = np.array([[-1,-1,-1],
                             [-1, 9,-1],
                             [-1,-1,-1]])
            sharpened = cv2.filter2D(enhanced, -1, kernel)
            
            # 6. Apply local adaptive thresholding
            binary = cv2.adaptiveThreshold(
                sharpened,
                255,
                cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                cv2.THRESH_BINARY_INV,
                25,  # Larger block size
                15   # Higher C value
            )
            
            # 7. Clean up noise and enhance digits
            # Remove small noise
            kernel_open = np.ones((3,3), np.uint8)
            cleaned = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel_open)
            
            # Connect broken parts
            kernel_close = np.ones((5,5), np.uint8)
            connected = cv2.morphologyEx(cleaned, cv2.MORPH_CLOSE, kernel_close)
            
            # Dilate slightly to make digits more prominent
            kernel_dilate = np.ones((3,3), np.uint8)
            dilated = cv2.dilate(connected, kernel_dilate, iterations=1)
            
            # 8. Invert for OCR
            processed = cv2.bitwise_not(dilated)
            
            # Try multiple OCR configurations
            configs = [
                '--psm 10 -c tessedit_char_whitelist=0123456789 --oem 3',  # Single character
                '--psm 8 -c tessedit_char_whitelist=0123456789 --oem 3',   # Single word
                '--psm 7 -c tessedit_char_whitelist=0123456789 --oem 3',   # Single line
                '--psm 6 -c tessedit_char_whitelist=0123456789 --oem 3'    # Uniform block
            ]
            
            best_result = None
            best_confidence = -1
            
            # Try each configuration multiple times with slightly different preprocessing
            for config in configs:
                # Try original processed image
                result = pytesseract.image_to_data(
                    processed,
                    output_type=pytesseract.Output.DICT,
                    config=config
                )
                
                # Try with additional preprocessing variations
                variations = [
                    cv2.GaussianBlur(processed, (3,3), 0),
                    cv2.medianBlur(processed, 3),
                    cv2.bilateralFilter(processed, 9, 75, 75)
                ]
                
                for variant in variations:
                    result = pytesseract.image_to_data(
                        variant,
                        output_type=pytesseract.Output.DICT,
                        config=config
                    )
                    
                    for i, conf in enumerate(result['conf']):
                        if conf > -1:  # Valid detection
                            text = result['text'][i].strip()
                            if text and text.isdigit():
                                conf = float(conf)
                                if conf > best_confidence:
                                    best_confidence = conf
                                    best_result = {
                                        'text': text,
                                        'confidence': conf,
                                        'bbox': (
                                            result['left'][i] // scale,
                                            result['top'][i] // scale,
                                            result['width'][i] // scale,
                                            result['height'][i] // scale
                                        )
                                    }
            
            # Create annotated image
            annotated_image = image.copy()
            
            # Draw ROI rectangle
            cv2.rectangle(annotated_image, (x, y), (x+w, y+h), (0, 255, 0), 2)
            
            if best_result:
                # Draw digit box and confidence
                digit_x = x + best_result['bbox'][0]
                digit_y = y + best_result['bbox'][1]
                digit_w = best_result['bbox'][2]
                digit_h = best_result['bbox'][3]
                
                # Color based on confidence
                if best_result['confidence'] >= 90:
                    color = (255, 215, 0)  # Gold
                elif best_result['confidence'] >= 60:
                    color = (255, 165, 0)  # Orange
                else:
                    color = (255, 0, 0)    # Red
                
                # Draw digit box
                cv2.rectangle(
                    annotated_image,
                    (digit_x, digit_y),
                    (digit_x + digit_w, digit_y + digit_h),
                    color,
                    2
                )
                
                # Add digit and confidence
                label = f"{best_result['text']} ({best_result['confidence']:.0f}%)"
                cv2.putText(
                    annotated_image,
                    label,
                    (digit_x, digit_y - 5),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.6,
                    color,
                    2
                )
            
            # Compile metrics
            metrics = {
                'text': best_result['text'] if best_result else '',
                'confidence': round(best_result['confidence'], 2) if best_result else 0,
                'detailed_metrics': {
                    'digit_found': best_result is not None,
                    'confidence': round(best_result['confidence'], 2) if best_result else 0,
                },
                'annotated_image': annotated_image
            }
            
            return metrics
            
        except Exception as e:
            raise ValueError(f"Error performing OCR: {str(e)}")

    @staticmethod
    def preprocess_for_ocr(image):
        """
        Preprocess image specifically for OCR
        """
        try:
            # Convert to grayscale
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
            # Enhance contrast
            clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
            enhanced = clahe.apply(gray)
            
            # Denoise
            denoised = cv2.fastNlMeansDenoising(enhanced)
            
            # Adaptive threshold
            binary = cv2.adaptiveThreshold(
                denoised, 255, 
                cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                cv2.THRESH_BINARY, 11, 2
            )
            
            return binary
            
        except Exception as e:
            raise ValueError(f"Error preprocessing image for OCR: {str(e)}") 