import streamlit as st
import cv2
import numpy as np
from document_matcher import DocumentMatcher
import tempfile
import os
from PIL import Image
import io
from streamlit_drawable_canvas import st_canvas
import base64

# Initialize DocumentMatcher
matcher = DocumentMatcher()

def save_uploaded_file(uploaded_file):
    """Save uploaded file and return the path"""
    if uploaded_file is not None:
        # Read the file into bytes
        bytes_data = uploaded_file.getvalue()
        
        # Convert to numpy array
        nparr = np.frombuffer(bytes_data, np.uint8)
        
        # Decode image
        image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        # Save to temporary file
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.jpg')
        cv2.imwrite(temp_file.name, image)
        return temp_file.name, image
    return None, None

def main():
    st.set_page_config(page_title="Document Matcher and OCR", layout="wide")
    st.title("Document Matcher and OCR")
    
    # Initialize session state
    if 'template_image' not in st.session_state:
        st.session_state.template_image = None
    if 'input_image' not in st.session_state:
        st.session_state.input_image = None
    if 'aligned_image' not in st.session_state:
        st.session_state.aligned_image = None
    if 'processed_template' not in st.session_state:
        st.session_state.processed_template = None
    if 'processed_input' not in st.session_state:
        st.session_state.processed_input = None
    
    # Create tabs
    tab1, tab2, tab3 = st.tabs(["Preprocessing", "Alignment", "OCR"])
    
    # Preprocessing Tab
    with tab1:
        st.header("Upload and Preprocess Documents")
        
        # File uploaders
        col1, col2 = st.columns(2)
        with col1:
            template_file = st.file_uploader("Upload Template Image", type=['jpg', 'jpeg', 'png'])
            if template_file:
                template_path, template_image = save_uploaded_file(template_file)
                if template_image is not None:
                    st.session_state.template_image = template_image
                    st.image(template_image, caption="Template Image", channels="BGR", use_container_width=True)
        
        with col2:
            input_file = st.file_uploader("Upload Input Image", type=['jpg', 'jpeg', 'png'])
            if input_file:
                input_path, input_image = save_uploaded_file(input_file)
                if input_image is not None:
                    st.session_state.input_image = input_image
                    st.image(input_image, caption="Input Image", channels="BGR", use_container_width=True)

        if st.session_state.template_image is not None or st.session_state.input_image is not None:
            # Preprocessing options
            st.subheader("Preprocessing Options")
            target_image = st.radio("Select Image to Process:", 
                                  ["Template Only", "Input Only", "Both Images"])
            
            with st.expander("Preprocessing Steps"):
                col1, col2 = st.columns(2)
                with col1:
                    use_grayscale = st.checkbox("Grayscale")
                    use_blur = st.checkbox("Blur")
                    if use_blur:
                        blur_kernel = st.slider("Blur Kernel Size", 1, 15, 3, 2)
                    
                    use_threshold = st.checkbox("Threshold")
                    if use_threshold:
                        thresh_value = st.slider("Threshold Value", 0, 255, 127)
                
                with col2:
                    use_adaptive = st.checkbox("Adaptive Threshold")
                    if use_adaptive:
                        block_size = st.slider("Block Size", 3, 21, 11, 2)
                        c_value = st.slider("C Value", 0, 10, 2)
                    
                    use_denoise = st.checkbox("Denoise")
                    if use_denoise:
                        denoise_strength = st.slider("Denoise Strength", 1, 20, 10)
            
            if st.button("Apply Preprocessing"):
                with st.spinner("Applying preprocessing..."):
                    if target_image in ["Template Only", "Both Images"] and st.session_state.template_image is not None:
                        processed = st.session_state.template_image.copy()
                        if use_grayscale:
                            processed = matcher.preprocess_image(processed, 'grayscale')
                            channels = "GRAY"
                        else:
                            channels = "BGR"
                        if use_blur:
                            processed = matcher.preprocess_image(processed, 'blur', {'kernel_size': blur_kernel})
                        if use_threshold:
                            processed = matcher.preprocess_image(processed, 'threshold', {'thresh': thresh_value})
                            channels = "GRAY"
                        if use_adaptive:
                            processed = matcher.preprocess_image(processed, 'adaptive_threshold', 
                                                              {'block_size': block_size, 'C': c_value})
                            channels = "GRAY"
                        if use_denoise:
                            processed = matcher.preprocess_image(processed, 'denoise', {'strength': denoise_strength})
                        st.session_state.processed_template = processed
                        st.image(processed, caption="Processed Template", channels=channels, use_container_width=True)
                    
                    if target_image in ["Input Only", "Both Images"] and st.session_state.input_image is not None:
                        processed = st.session_state.input_image.copy()
                        if use_grayscale:
                            processed = matcher.preprocess_image(processed, 'grayscale')
                            channels = "GRAY"
                        else:
                            channels = "BGR"
                        if use_blur:
                            processed = matcher.preprocess_image(processed, 'blur', {'kernel_size': blur_kernel})
                        if use_threshold:
                            processed = matcher.preprocess_image(processed, 'threshold', {'thresh': thresh_value})
                            channels = "GRAY"
                        if use_adaptive:
                            processed = matcher.preprocess_image(processed, 'adaptive_threshold', 
                                                              {'block_size': block_size, 'C': c_value})
                            channels = "GRAY"
                        if use_denoise:
                            processed = matcher.preprocess_image(processed, 'denoise', {'strength': denoise_strength})
                        st.session_state.processed_input = processed
                        st.image(processed, caption="Processed Input", channels=channels, use_container_width=True)
    
    # Alignment Tab
    with tab2:
        st.header("Document Alignment")
        if st.button("Align Images"):
            template_to_align = st.session_state.processed_template if st.session_state.processed_template is not None else st.session_state.template_image
            input_to_align = st.session_state.processed_input if st.session_state.processed_input is not None else st.session_state.input_image
            
            if template_to_align is not None and input_to_align is not None:
                with st.spinner("Aligning images..."):
                    try:
                        # Convert to BGR if images are grayscale
                        if len(template_to_align.shape) == 2:
                            template_to_align = cv2.cvtColor(template_to_align, cv2.COLOR_GRAY2BGR)
                        if len(input_to_align.shape) == 2:
                            input_to_align = cv2.cvtColor(input_to_align, cv2.COLOR_GRAY2BGR)
                        
                        aligned_image, scores = matcher.align_images(template_to_align, input_to_align)
                        st.session_state.aligned_image = aligned_image
                        
                        # Display results
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.image(template_to_align, caption="Template", channels="BGR", use_container_width=True)
                        with col2:
                            st.image(input_to_align, caption="Input", channels="BGR", use_container_width=True)
                        with col3:
                            st.image(aligned_image, caption="Aligned Result", channels="BGR", use_container_width=True)
                        
                        # Display scores
                        st.subheader("Alignment Scores")
                        col1, col2, col3, col4 = st.columns(4)
                        with col1:
                            st.metric("Match Quality", f"{scores['match_quality']:.1f}%")
                        with col2:
                            st.metric("Alignment Score", f"{scores['alignment_score']:.1f}%")
                        with col3:
                            st.metric("Similarity Score", f"{scores['similarity_score']:.1f}%")
                        with col4:
                            st.metric("Final Score", f"{scores['final_score']:.1f}%")
                    except Exception as e:
                        st.error(f"Error during alignment: {str(e)}")
            else:
                st.error("Please upload both template and input images first")
    
    # OCR Tab
    with tab3:
        st.header("OCR Processing")
        if st.session_state.aligned_image is None:
            st.warning("Please align images first")
        else:
            # Display the aligned image
            st.subheader("Select region for OCR")
            img_height, img_width = st.session_state.aligned_image.shape[:2]
            
            # Display image with current dimensions
            st.image(st.session_state.aligned_image, caption=f"Image dimensions: {img_width}x{img_height}", 
                    channels="BGR", use_container_width=True)
            
            # ROI selection using number inputs
            col1, col2 = st.columns(2)
            with col1:
                x = st.number_input("X coordinate", 0, img_width-1, 0)
                y = st.number_input("Y coordinate", 0, img_height-1, 0)
            with col2:
                w = st.number_input("Width", 1, img_width-x, min(100, img_width-x))
                h = st.number_input("Height", 1, img_height-y, min(100, img_height-y))
            
            if st.button("Perform OCR"):
                roi = {'x': x, 'y': y, 'width': w, 'height': h}
                try:
                    result = matcher.perform_ocr(st.session_state.aligned_image, roi)
                    
                    # Display results
                    st.subheader("OCR Results")
                    st.text(f"Extracted Text: {result['text']}")
                    st.progress(float(result['confidence']) / 100)
                    st.text(f"Confidence: {result['confidence']:.1f}%")
                    
                    # Display annotated image
                    st.image(result['annotated_image'], caption="Annotated Result", 
                           channels="BGR", use_container_width=True)
                except Exception as e:
                    st.error(f"Error during OCR: {str(e)}")

if __name__ == "__main__":
    main() 