# Metadata Enrichment Pipeline — Enhanced v3 Proposal

## Current v2 Architecture

```mermaid
flowchart TD
    subgraph ingest [1. Ingest]
        PDF[PDF Documents] --> Docling[Docling Parser]
        Docling --> Markdown[Markdown Text]
    end

    subgraph chunk [2. Chunk]
        Markdown --> Parent[Parent Chunks ~2000 chars]
        Parent --> Child[Child Chunks ~512 chars]
    end

    subgraph embed [3. Embed]
        Child --> Arctic["Snowflake Arctic Embed M (768d)"]
        Arctic --> Vectors[Normalized Vectors]
    end

    subgraph index [4. Index]
        Parent --> ES[(Elasticsearch)]
        Vectors --> ES
        Child --> ES
    end

    subgraph enrich [5. Enrich per Document]
        ES --> PerField["Per-field ES Hybrid Search (KNN + BM25 + RRF)"]
        PerField --> Dedup[Deduplicate Chunks Across Fields]
        Dedup --> ParentFetch["Fetch Parent Texts (on-demand)"]
        ParentFetch --> LLM["1 LLM Call (Gemini) — Full Schema"]
        LLM --> DocMeta[Document-Level Metadata]
        DocMeta --> BulkUpdate["Bulk-Update All Chunks in ES"]
    end
```

### v2 Flow Summary

| Step | What Happens | Key Detail |
|------|-------------|------------|
| **Ingest** | PDFs converted to markdown via Docling | Handles scanned + native PDFs |
| **Chunk** | Parent-child splitting (character-based) | Parents: 2000 chars, Children: 512 chars |
| **Embed** | Child chunks embedded with Snowflake Arctic | 768-dim, cosine similarity, normalized |
| **Index** | Parents + children stored in Elasticsearch | `dense_vector` for KNN, `text` for BM25 |
| **Retrieve** | Per-field hybrid search (KNN + BM25 + RRF) | 9 fields = 9 ES queries, deduplicated |
| **Extract** | One Gemini call with full Pydantic schema | Batch extraction, structured JSON output |
| **Enrich** | Bulk-update all chunk_ids with metadata | Document-level metadata on every chunk |

### v2 Strengths

- ES-native hybrid search (no Python-side vector math)
- Pydantic schema drives both extraction and ES mapping
- Batch LLM extraction (1 call per document, not per field)
- Parent-child chunking gives retrieval precision + extraction context

---

## Proposed v3 Enhancements

### Architecture Diagram

```mermaid
flowchart TD
    subgraph ingest_v3 [1. Structured Ingest]
        PDF_v3[PDF Documents] --> Docling_v3[Docling Parser]
        Docling_v3 --> StructuredMD["Structured Markdown (with headers)"]
    end

    subgraph chunk_v3 [2. Structure-Aware Chunking]
        StructuredMD --> SectionParse["Parse Section Headers (Parties, Term, Rent...)"]
        SectionParse --> SectionChunk["Section-Based Parent Chunks"]
        SectionChunk --> SubSection["Sub-Section Child Chunks"]
    end

    subgraph embed_v3 [3. Embed]
        SubSection --> Arctic_v3["Embedding Model (768d)"]
        Arctic_v3 --> Vectors_v3[Normalized Vectors]
    end

    subgraph index_v3 [4. Index]
        SectionChunk --> ES_v3[(Elasticsearch)]
        Vectors_v3 --> ES_v3
        SubSection --> ES_v3
    end

    subgraph extract_v3 [5. Two-Pass Extraction]
        ES_v3 --> SingleQuery["Single Multi-Intent ES Hybrid Search"]
        SingleQuery --> RetrievedCtx[Retrieved Context]
        RetrievedCtx --> Pass1["Pass 1: Deterministic (Regex/Patterns)"]
        Pass1 --> Resolved[Resolved Fields]
        Pass1 --> Unresolved[Unresolved Fields]
        Unresolved --> Pass2["Pass 2: LLM (Gemini) — Remaining Fields Only"]
        Pass2 --> AllFields[Complete Metadata]
        Resolved --> AllFields
    end

    subgraph validate_v3 [6. Validate and Score]
        AllFields --> SchemaVal[Schema Validation]
        SchemaVal --> Confidence[Confidence Scoring]
        Confidence --> Flag{"Below Threshold?"}
        Flag -->|Yes| Review[Flag for Human Review]
        Flag -->|No| Accept[Accept Metadata]
    end

    subgraph enrich_v3 [7. Enrich with Provenance]
        Accept --> BulkUpdate_v3["Bulk-Update ES with Versioned Metadata"]
        Review --> BulkUpdate_v3
        BulkUpdate_v3 --> ES_v3
    end
```

---

### Enhancement 1: Structure-Aware Chunking

**Problem**: Current chunking splits text at fixed character boundaries (2000/512), which cuts mid-sentence and mid-paragraph. A legal clause like "Rent Escalation" might be split across two chunks.

**Solution**: Docling already outputs structured markdown with section headers. Parse those headers and chunk by logical document sections.

```
Current (v2):                        Proposed (v3):
┌──────────────────────┐             ┌──────────────────────┐
│ chars 0-2000         │             │ § Parties            │
│ (arbitrary split)    │             │ (complete section)   │
├──────────────────────┤             ├──────────────────────┤
│ chars 2000-4000      │             │ § Term of Lease      │
│ (arbitrary split)    │             │ (complete section)   │
├──────────────────────┤             ├──────────────────────┤
│ chars 4000-6000      │             │ § Rent               │
│ (arbitrary split)    │             │ (complete section)   │
├──────────────────────┤             ├──────────────────────┤
│ ...                  │             │ § Security Deposit   │
│                      │             │ (complete section)   │
└──────────────────────┘             └──────────────────────┘
```

**Impact**: Chunks align with legal document structure. Retrieval for "monthly rent" returns the complete Rent section, not a fragment that starts mid-paragraph.

**Implementation**:
- Parse markdown headers (`## Section Title`) from Docling output
- Each header-to-next-header block becomes a parent chunk
- If a section exceeds max size, split at paragraph boundaries (not character boundaries)
- Child chunks are sub-paragraphs within each section

---

### Enhancement 2: Single Multi-Intent Query

**Problem**: Currently we run 9 separate ES hybrid searches (one per metadata field). For a 10-page lease, most queries return overlapping chunks — the "Parties" section is retrieved by both "tenant name" and "landlord" queries.

**Solution**: Construct one rich query that captures all field intents, run one ES search.

```python
# v2: 9 separate queries
for field_name in fields:
    retrieve_chunks_for_field(es, index, doc_id, field_name, ...)  # 9 ES round-trips

# v3: 1 combined query
combined_query = "; ".join(
    field_info.description for field_info in schema.model_fields.values()
)
# "Name of the tenant; Name of the landlord; Date the lease was signed; ..."
chunks = es_hybrid_search(es, index, doc_id, combined_query, top_k=20)  # 1 ES round-trip
```

**Impact**: 9x fewer ES round-trips. For short documents (5-15 pages), a single top-20 retrieval covers all relevant sections.

**When to keep per-field**: For very long documents (100+ pages) where fields are in distant sections, per-field retrieval may still be needed. Use document length as a heuristic to switch strategies.

---

### Enhancement 3: Two-Pass Extraction (Deterministic + LLM)

**Problem**: Every field goes through the LLM, including fields with highly structured values (dates, dollar amounts, addresses) that could be extracted with simple patterns.

**Solution**: Two-pass extraction pipeline.

**Pass 1 — Deterministic (free, fast, reliable)**:
| Field | Pattern | Example |
|-------|---------|---------|
| `signing_date` | Date regex (`MM/DD/YYYY`, `Month DD, YYYY`) | "signed on 01/15/2024" |
| `expiry_date` | Date regex near "expir/terminat" keywords | "expires December 31, 2025" |
| `monthly_rent` | Currency regex (`$X,XXX`) near "rent/month" | "$1,200 per month" |
| `property_address` | Address pattern (number + street + city + state + zip) | "123 Main St, Austin, TX 78701" |

**Pass 2 — LLM (only for remaining fields)**:
| Field | Why LLM is needed |
|-------|------------------|
| `escalation_clause` | Requires summarization of complex legal language |
| `document_type` | Requires reasoning ("is this a lease or amendment?") |
| `amendment_number` | Context-dependent ("Third Amendment" vs no amendment) |
| Fields that Pass 1 missed | Fallback for unusual formatting |

**Impact**: 40-60% fewer tokens sent to the LLM. Deterministic fields are extracted instantly with 100% consistency (no LLM hallucination risk for dates/amounts).

---

### Enhancement 4: Confidence Scoring and Validation

**Problem**: The pipeline trusts LLM output unconditionally. If Gemini hallucinates a date or misreads a rent amount, it goes straight into the index.

**Solution**: Multi-layer validation.

```mermaid
flowchart LR
    Extracted[Extracted Value] --> TypeCheck[Type Validation]
    TypeCheck --> RangeCheck[Range/Format Check]
    RangeCheck --> CrossRef[Cross-Chunk Verification]
    CrossRef --> ConfScore[Confidence Score]
    ConfScore --> Decision{"score >= 0.7?"}
    Decision -->|Yes| Accept[Store in ES]
    Decision -->|No| Flag[Flag for Review]
```

**Validation rules**:
- **Type check**: Does the value match the Pydantic field type?
- **Range check**: Is the date in a reasonable range (not year 1900)? Is rent > 0?
- **Format check**: Does the address parse into components? Is the date parseable?
- **Cross-chunk verification**: If 3 out of 5 retrieved chunks independently confirm the same value, high confidence
- **Confidence score**: Combine the above into a 0-1 score per field

**Storage**: Store both the value and its confidence in ES:
```json
{
  "metadata": {
    "monthly_rent": "$1,200",
    "monthly_rent_confidence": 0.95,
    "escalation_clause": "3% annual increase",
    "escalation_clause_confidence": 0.72
  }
}
```

---

### Enhancement 5: Enrichment Provenance and Versioning

**Problem**: No record of which chunks contributed to each extraction, which model was used, or when enrichment happened. Makes debugging and auditing impossible.

**Solution**: Store provenance alongside metadata.

```json
{
  "metadata": {
    "monthly_rent": "$1,200",
    "landlord": "John Smith"
  },
  "metadata_provenance": {
    "enrichment_version": "v3.1",
    "enriched_at": "2026-03-17T10:30:00Z",
    "model": "gemini-2.0-flash",
    "embedding_model": "snowflake-arctic-embed-m",
    "source_chunks": ["chunk_abc123", "chunk_def456"],
    "extraction_method": {
      "monthly_rent": "regex",
      "landlord": "llm"
    },
    "confidence": {
      "monthly_rent": 0.98,
      "landlord": 0.85
    }
  }
}
```

**Benefits**:
- **Debugging**: "Why was rent extracted as $1,500?" — look at which chunks were used
- **Re-enrichment**: When you upgrade the LLM model, only re-extract fields where `extraction_method == "llm"`
- **Auditing**: Full traceability for compliance-sensitive documents

---

### Enhancement 6: Evaluation Framework

**Problem**: No way to measure extraction quality. You can't improve what you can't measure.

**Solution**: Build a ground truth dataset and automated evaluation.

```
ground_truth/
├── doc_001.json    # manually verified metadata
├── doc_002.json
├── ...
└── doc_030.json    # 20-30 documents is enough to start
```

**Metrics per field**:
| Metric | Definition |
|--------|-----------|
| **Exact match** | Extracted value == ground truth (for categorical fields) |
| **Fuzzy match** | Levenshtein distance < threshold (for names, addresses) |
| **Date accuracy** | Parsed date matches within +/- 0 days |
| **Numeric accuracy** | Rent amount within +/- 1% |
| **Null precision** | When pipeline returns null, was the field truly absent? |
| **Null recall** | When field exists in document, did pipeline find it? |

**Use cases**:
- Compare retrieval strategies (single-query vs per-field)
- Compare chunking strategies (character vs structure-aware)
- Compare models (Gemini Flash vs Pro vs other)
- Regression testing after pipeline changes

---

### Enhancement 7: Composable Pipeline Stages

**Problem**: Monolithic notebook — if embedding fails, you re-run everything. No parallelism across documents.

**Solution**: Design as independent, idempotent stages.

```mermaid
flowchart LR
    subgraph stages [Pipeline Stages]
        S1[Ingest] --> S2[Chunk]
        S2 --> S3[Embed]
        S3 --> S4[Index]
        S4 --> S5[Retrieve]
        S5 --> S6[Extract]
        S6 --> S7[Validate]
        S7 --> S8[Enrich]
    end

    subgraph storage [Shared State]
        ES_store[(Elasticsearch)]
    end

    S1 -.-> ES_store
    S2 -.-> ES_store
    S3 -.-> ES_store
    S4 -.-> ES_store
    S5 -.-> ES_store
    S6 -.-> ES_store
    S7 -.-> ES_store
    S8 -.-> ES_store
```

Each stage:
- **Reads from ES** (or filesystem for ingest)
- **Writes to ES** (updating document state)
- **Is idempotent**: Re-running a stage on the same document produces the same result
- **Is independent**: Can swap embedding model without re-chunking, change LLM without re-embedding
- **Tracks state**: Each document has a `pipeline_state` field showing which stages have completed

**Parallelism**: Process multiple documents concurrently at each stage using Python `concurrent.futures` or task queues.

---

## Priority Roadmap

| Priority | Enhancement | Impact | Effort |
|----------|------------|--------|--------|
| **P0** | Structure-aware chunking | High — biggest retrieval quality improvement | Medium |
| **P1** | Single multi-intent query | High — 9x fewer ES round-trips | Low |
| **P2** | Two-pass extraction | Medium — cost reduction + reliability for structured fields | Medium |
| **P3** | Evaluation framework | High — enables all future improvements to be measured | Medium |
| **P4** | Confidence scoring | Medium — prevents bad data from entering the index | Medium |
| **P5** | Provenance and versioning | Medium — essential for production and auditing | Low |
| **P6** | Composable pipeline stages | Medium — operational improvement for production | High |

---

## Current v2 vs Proposed v3

| Aspect | v2 (Current) | v3 (Proposed) |
|--------|-------------|---------------|
| **Chunking** | Character-based (2000/512) | Structure-aware (section headers) |
| **ES queries per doc** | 9 (one per field) | 1 (multi-intent) |
| **LLM calls per doc** | 1 (batch) | 0-1 (regex first, LLM for remainder) |
| **Validation** | None (trust LLM output) | Type + range + cross-chunk + confidence |
| **Provenance** | None | Full (chunks, method, model, timestamp) |
| **Evaluation** | Manual inspection | Automated metrics against ground truth |
| **Pipeline** | Monolithic notebook | Composable, idempotent stages |
| **Error handling** | Silent `except: return None` | Confidence scores + human review flags |
