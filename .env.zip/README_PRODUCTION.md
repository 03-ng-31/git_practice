# RAG Metadata Pipeline — Production

Production-grade metadata-aware RAG for lease and amendment documents.

## Quick Start

### With Docker Compose

```bash
# Set your Gemini API key
export GEMINI_API_KEY=your_key_here

# Start Elasticsearch + API
docker-compose up -d

# API at http://localhost:8000
# Docs at http://localhost:8000/docs
```

### Local Development

```bash
# Install
pip install -r requirements.txt
# or: pip install -e .  (if using a package layout)

# Start Elasticsearch (required for notebooks and API)
docker compose up -d elasticsearch
# Wait until healthy (~30s), then check: curl -u elastic:changeme http://localhost:9200

# Set GEMINI_API_KEY in .env or environment

# Run API (optional)
uvicorn rag_metadata.api.main:app --reload --port 8000
```

### Activating the virtual environment on Windows (PowerShell)

If you see **"running scripts is disabled on this system"** when running `.\agentic_rag\Scripts\Activate.ps1`:

**Option A — Allow scripts for your user (one-time):**
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```
Then run `.\agentic_rag\Scripts\Activate.ps1` again.

**Option B — Use Command Prompt instead:**  
Open **cmd** (not PowerShell) and run:
```cmd
agentic_rag\Scripts\activate.bat
```

### Installing Docker (Windows)

Use Docker to run Elasticsearch in one command. On Windows you need **Docker Desktop**.

1. **Enable WSL 2** (required for Docker Desktop on Windows):
   - Open **PowerShell as Administrator** (right‑click Start → Windows Terminal (Admin) or PowerShell (Admin)).
   - Run: `wsl --install`
   - Restart your PC when prompted. After restart, WSL may finish installing; reboot again if it asks.

2. **Download Docker Desktop**  
   - Go to **[docs.docker.com/desktop/install/windows-install](https://docs.docker.com/desktop/install/windows-install)**  
   - Or direct download: **[Docker Desktop for Windows](https://desktop.docker.com/win/main/amd64/Docker%20Desktop%20Installer.exe)**

3. **Install**
   - Run the installer. Use default options; ensure **“Use WSL 2 instead of Hyper-V”** is selected if shown.
   - Restart when the installer asks.

4. **Start Docker**
   - Start **Docker Desktop** from the Start menu. Wait until the whale icon in the system tray is steady (Docker is running).

5. **Verify** (PowerShell or Command Prompt):
   ```powershell
   docker --version
   docker compose version
   docker run hello-world
   ```
   If all three work, you can use **Option A** below to run Elasticsearch.

**Requirements:** Windows 10/11 64‑bit (Pro, Enterprise, or Education recommended); 4 GB RAM; virtualization enabled in BIOS. On **Windows Home**, WSL 2 + Docker Desktop work for Linux containers (which is what we use).

---

### Running Elasticsearch only (for Jupyter notebooks)

The notebooks (`01_metadata_enrichment_pipeline_v2.ipynb`, `02_metadata_retrieval_pipeline.ipynb`) expect Elasticsearch at **http://localhost:9200** with user `elastic` and password `changeme`.

**No Docker?** Use **Option C** below (download the .zip and run `bin\elasticsearch.bat` on Windows).

**Option A — Docker Compose (recommended)**

```bash
# From the project root
docker compose up -d elasticsearch
```

**Option B — Docker run (no compose)**

```bash
docker run -d --name elasticsearch \
  -p 9200:9200 -p 9300:9300 \
  -e discovery.type=single-node \
  -e xpack.security.enabled=true \
  -e ELASTIC_PASSWORD=changeme \
  -e "ES_JAVA_OPTS=-Xms512m -Xmx512m" \
  docker.elastic.co/elasticsearch/elasticsearch:8.12.0
```

**Verify**

```bash
curl -u elastic:changeme http://localhost:9200
# Or in browser: http://localhost:9200 (use elastic / changeme when prompted)
```

**Stop**

```bash
docker compose down          # if you used compose
docker stop elasticsearch    # if you used docker run
```

**Option C — No Docker (run Elasticsearch from a .zip)**

Use this if you don’t have Docker. Elasticsearch runs as a normal process and includes a bundled JVM.

1. **Download** the Windows `.zip` from **[Elasticsearch downloads](https://www.elastic.co/downloads/elasticsearch)** (e.g. `elasticsearch-8.15.0-windows-x86_64.zip`).

2. **Unzip** to a folder, e.g. `C:\elasticsearch-8.15.0`. This folder is `%ES_HOME%`.

3. **Set the password** so the notebooks can use `elastic` / `changeme` without changes. In the same terminal you’ll use to start Elasticsearch, set:
   - **PowerShell:** `$env:ELASTIC_PASSWORD="changeme"`
   - **CMD:** `set ELASTIC_PASSWORD=changeme`
   Do this *before* the first time you start Elasticsearch.

4. **Start Elasticsearch** from `%ES_HOME%`:
   ```powershell
   cd C:\elasticsearch-8.15.0
   .\bin\elasticsearch.bat
   ```
   Keep this window open. Wait until you see a line like “started” (can take a minute).

5. **Verify:** In a browser open **https://localhost:9200**. Accept the self-signed certificate if prompted, then log in with user `elastic` and password `changeme`.  
   Or in PowerShell:
   ```powershell
   # Ignore cert for a quick check (first run uses HTTPS)
   Invoke-WebRequest -Uri https://localhost:9200 -SkipCertificateCheck -Credential (Get-Credential -UserName elastic -Message "Password")
   ```

6. **Notebooks and HTTP:** The notebooks use `http://localhost:9200`. By default the .zip install uses **HTTPS**. Either:
   - **Easiest:** In `%ES_HOME%\config\elasticsearch.yml` add:
     ```yaml
     xpack.security.enabled: true
     xpack.security.http.ssl.enabled: false
     ```
     Restart Elasticsearch; then the cluster will listen on HTTP and the notebooks will work with `http://localhost:9200`.
   - **Or** change the notebook config to use `https://localhost:9200` and disable SSL verification in the Elasticsearch client (see notebook config cell).

**If you already started Elasticsearch once** and it printed a random `elastic` password: either run `bin\elasticsearch-reset-password -u elastic` (it will prompt for the new password — use `changeme`), or set `ES_PASSWORD` in the notebook config to the printed password.

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Health check (ES + embedding model) |
| `/upload` | POST | Upload PDF for ingest + enrichment |
| `/ingest` | POST | Alias for `/upload` |
| `/query` | POST | Natural language RAG query |
| `/enrich` | POST | Run metadata enrichment on all docs |

### Example: Upload PDF

```bash
curl -X POST -F "file=@lease.pdf" http://localhost:8000/upload
```

### Example: Query

```bash
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"query": "What is the escalation clause?"}'
```

## Configuration

Environment variables (see `.env.example`):

- `GEMINI_API_KEY` — Required for LLM extraction and RAG
- `RAG_ES_HOST` — Elasticsearch URL (default: http://localhost:9200)
- `RAG_ES_INDEX` — Index name (default: lease_documents)
- `RAG_ES_USER` / `RAG_ES_PASSWORD` — ES credentials

## Architecture

1. **Ingest**: PDF → parse → chunk (parent-child or flat) → embed → index to ES
2. **Enrichment**: Per-field retrieval-augmented extraction → bulk update metadata
3. **Retrieval**: Query → document selector → metadata extractor → RRF hybrid search → parent expansion → RAG generation
