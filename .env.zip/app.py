import os
import time
from typing import Optional, List, Dict, Any, Type

import streamlit as st
import pandas as pd
from pydantic import BaseModel, Field, create_model
from elasticsearch import Elasticsearch

from pipeline.config import PipelineSettings, EnrichmentConfig, LLMConfig

# ─── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="RAG Metadata Pipeline",
    page_icon="📄",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Custom CSS ───────────────────────────────────────────────────────────────
st.markdown("""
<style>
    .block-container { padding-top: 1.5rem; }
    .stMetric > div { background: #f8f9fa; padding: 0.8rem; border-radius: 8px; border-left: 4px solid #4e8cff; }
    div[data-testid="stExpander"] { border: 1px solid #e0e0e0; border-radius: 8px; margin-bottom: 0.5rem; }
    .chunk-box { background: #f0f2f6; padding: 10px; border-radius: 6px; margin: 4px 0;
                 font-size: 0.85em; border-left: 3px solid #4e8cff; }
    .parent-box { background: #eef6ff; padding: 12px; border-radius: 8px; margin: 6px 0;
                  font-size: 0.85em; border-left: 4px solid #1a73e8; }
    .prompt-box { background: #1e1e1e; color: #d4d4d4; padding: 16px; border-radius: 8px;
                  font-family: 'Consolas', 'Courier New', monospace; font-size: 0.82em;
                  white-space: pre-wrap; word-wrap: break-word; max-height: 600px; overflow-y: auto; }
    .success-box { background: #d4edda; padding: 12px; border-radius: 8px; border-left: 4px solid #28a745; }
</style>
""", unsafe_allow_html=True)


# ─── Cached resource loaders ─────────────────────────────────────────────────
@st.cache_resource
def load_embedding_model(model_name: str):
    from sentence_transformers import SentenceTransformer
    return SentenceTransformer(model_name, trust_remote_code=True)


@st.cache_resource
def get_es_client(host: str, user: str, password: str) -> Elasticsearch:
    return Elasticsearch(
        hosts=[host],
        basic_auth=(user, password) if user and password else None,
        verify_certs=False,
    )


def get_llm_config(s: PipelineSettings) -> LLMConfig:
    return LLMConfig(agent_name=s.llm_agent_name, user_id=s.llm_user_id, vegas_api_url=s.llm_vegas_api_url)


# ─── Session state defaults ──────────────────────────────────────────────────
defaults = {
    "documents": [],
    "index_created": False,
    "index_name": "",
    "doc_url_map": {},
    "metadata_fields": [{"name": "", "description": ""}],
    "child_chunks_no_mmr_map": {},
    "child_chunks_mmr_map": {},
    "parent_chunks_map": {},
    "context_map": {},
    "retrieval_done": False,
    "retrieval_timing": {},
    "_use_mmr": False,
    "chunks_accepted": False,
    "prompt_map": {},
    "extraction_results": [],
    "_dynamic_schema_fields": [],
}
for k, v in defaults.items():
    if k not in st.session_state:
        st.session_state[k] = v


# ─── Sidebar ──────────────────────────────────────────────────────────────────
with st.sidebar:
    st.header("Infrastructure")
    es_host = st.text_input("Elasticsearch Host", value="http://localhost:9200")
    es_user = st.text_input("ES Username", value="elastic")
    es_password = st.text_input("ES Password", value="changeme", type="password")
    es_index_name = st.text_input("Index Name", value="rag_documents")

    st.divider()
    embedding_model_name = st.text_input("Embedding Model", value="Snowflake/snowflake-arctic-embed-m")
    embedding_dim = st.number_input("Embedding Dimension", value=768, min_value=64)

    st.divider()
    st.subheader("LLM Gateway")
    _env = LLMConfig.from_env()
    llm_agent_name = st.text_input("LLM_AGENT_NAME", value=_env.agent_name, placeholder="my-rag-agent")
    llm_user_id = st.text_input("LLM_USER_ID", value=_env.user_id, placeholder="user-123")
    llm_vegas_api_url = st.text_input("LLM_VEGAS_API_URL", value=_env.vegas_api_url, placeholder="https://vegas.example.com/v1/chat")
    if llm_agent_name and llm_user_id and llm_vegas_api_url:
        st.success("LLM gateway configured", icon="✅")
    else:
        st.warning("Fill all three fields (or set env vars)", icon="⚠️")

    st.divider()
    st.subheader("Chunking")
    parent_chunk_size = st.number_input("Parent Chunk Size", value=2000, min_value=200, step=100)
    parent_chunk_overlap = st.number_input("Parent Overlap", value=200, min_value=0, step=50)
    child_chunk_size = st.number_input("Child Chunk Size", value=512, min_value=64, step=64)
    child_chunk_overlap = st.number_input("Child Overlap", value=50, min_value=0, step=10)

settings = PipelineSettings(
    es_host=es_host, es_index=es_index_name, es_user=es_user, es_password=es_password,
    embedding_model_name=embedding_model_name, embedding_dim=embedding_dim,
    llm_agent_name=llm_agent_name, llm_user_id=llm_user_id, llm_vegas_api_url=llm_vegas_api_url,
    parent_chunk_size=parent_chunk_size, parent_chunk_overlap=parent_chunk_overlap,
    child_chunk_size=child_chunk_size, child_chunk_overlap=child_chunk_overlap,
)


# ─── Helper: rebuild dynamic schema from session state field defs ─────────────
def _rebuild_schema():
    field_defs = st.session_state.get("_dynamic_schema_fields", [])
    if not field_defs:
        return None
    defns = {}
    for f in field_defs:
        defns[f["name"]] = (Optional[str], Field(None, description=f["description"]))
    return create_model("DynamicSchema", **defns)


# ═══════════════════════════════════════════════════════════════════════════════
st.title("RAG Metadata Enrichment Pipeline")

tab1, tab2, tab3, tab4 = st.tabs([
    "1. Upload & Vectorize",
    "2. Retrieve Chunks",
    "3. Review Prompt",
    "4. Extraction Results",
])


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 1: Upload & Vectorize
# ═══════════════════════════════════════════════════════════════════════════════
with tab1:
    st.header("Upload PDF URLs & Vectorize")
    st.markdown("Paste PDF URLs (one per line). Documents will be downloaded, chunked, embedded, and indexed.")

    url_input = st.text_area(
        "PDF URLs (one per line)", height=200,
        placeholder="https://example.com/document1.pdf\nhttps://example.com/document2.pdf",
    )

    if st.button("Submit & Process", type="primary", key="btn_upload"):
        urls = [u.strip() for u in url_input.strip().split("\n") if u.strip()] if url_input.strip() else []
        if not urls:
            st.warning("No valid URLs found.")
        else:
            from pipeline.pdf_ingestion import download_and_load_pdfs
            from pipeline.chunking import create_parent_child_chunks, deterministic_id
            from pipeline.embedding import embed_child_chunks
            from pipeline.es_indexing import create_es_index, index_documents

            progress_bar = st.progress(0.0)
            status_text = st.empty()

            try:
                es = get_es_client(settings.es_host, settings.es_user, settings.es_password)
                es_info = es.info().body.get("version", {}).get("number", "?")
                status_text.info(f"Connected to Elasticsearch {es_info}")
            except Exception as e:
                st.error(f"Cannot connect to Elasticsearch: {e}")
                st.stop()

            status_text.info("Downloading and extracting text from PDFs...")
            progress_bar.progress(0.1)
            documents = download_and_load_pdfs(urls, data_dir=settings.data_dir)
            st.session_state["documents"] = documents

            doc_url_map = {}
            for url, doc in zip(urls, documents):
                doc_url_map[deterministic_id(doc["file_name"], prefix="doc_")] = url
            st.session_state["doc_url_map"] = doc_url_map

            if not documents:
                st.error("No documents were successfully downloaded/processed.")
                st.stop()

            progress_bar.progress(0.3)
            status_text.info(f"Downloaded {len(documents)}/{len(urls)} PDFs. Chunking...")

            GenericMeta = create_model("GenericMeta", document_type=(Optional[str], None), source_file=(Optional[str], None))
            for doc in documents:
                create_parent_child_chunks(
                    doc, metadata_schema=GenericMeta,
                    parent_chunk_size=settings.parent_chunk_size, parent_chunk_overlap=settings.parent_chunk_overlap,
                    child_chunk_size=settings.child_chunk_size, child_chunk_overlap=settings.child_chunk_overlap,
                )

            total_parents = sum(len(d.get("parent_chunks", [])) for d in documents)
            total_children = sum(len(d.get("child_chunks", [])) for d in documents)
            progress_bar.progress(0.5)
            status_text.info(f"Chunked: {total_parents} parents, {total_children} children. Embedding...")

            emb_model = load_embedding_model(settings.embedding_model_name)
            n_embedded = embed_child_chunks(documents, emb_model)
            progress_bar.progress(0.7)
            status_text.info(f"Embedded {n_embedded} child chunks. Indexing...")

            create_es_index(es, settings.es_index, GenericMeta, settings.embedding_dim)
            index_documents(es, documents, settings.es_index)
            progress_bar.progress(1.0)

            st.session_state["index_created"] = True
            st.session_state["index_name"] = settings.es_index
            # Reset downstream state
            st.session_state["retrieval_done"] = False
            st.session_state["chunks_accepted"] = False
            st.session_state["prompt_map"] = {}
            st.session_state["extraction_results"] = []

            status_text.empty()
            st.markdown('<div class="success-box">Pipeline complete!</div>', unsafe_allow_html=True)

            m1, m2, m3, m4 = st.columns(4)
            m1.metric("URLs Submitted", len(urls))
            m2.metric("Docs Downloaded", len(documents))
            m3.metric("Parent Chunks", total_parents)
            m4.metric("Child Chunks (Vectorized)", total_children)

            st.subheader("Document Details")
            rows = [{
                "File": d["file_name"],
                "Doc ID": d.get("doc_id", "")[:16] + "...",
                "Text Length": f"{len(d.get('full_text', '')):,} chars",
                "Parents": len(d.get("parent_chunks", [])),
                "Children": len(d.get("child_chunks", [])),
                "Source URL": d.get("source_url", ""),
            } for d in documents]
            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

    elif st.session_state["index_created"]:
        st.success(f"Index **{st.session_state['index_name']}** ready with {len(st.session_state['documents'])} documents.")


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 2: Define Fields, Retrieve Chunks, Show Compiled Parent Chunks
# ═══════════════════════════════════════════════════════════════════════════════
with tab2:
    st.header("Define Metadata Fields & Retrieve Chunks")

    if not st.session_state["index_created"]:
        st.info("Complete Step 1 first — upload and vectorize your documents.")
        st.stop()

    # ── Metadata Field Editor ──
    st.subheader("Metadata Fields")
    st.markdown("Each field needs a **name** and a **description** (used as the retrieval query).")

    with st.expander("Metadata Fields", expanded=True):
        fields = st.session_state["metadata_fields"]
        for i, field in enumerate(fields):
            c1, c2, c3 = st.columns([2, 5, 1])
            with c1:
                fields[i]["name"] = st.text_input(
                    "Field Name", value=field["name"], key=f"fname_{i}",
                    placeholder="e.g. owner_name",
                    label_visibility="collapsed" if i > 0 else "visible",
                )
            with c2:
                fields[i]["description"] = st.text_input(
                    "Description (retrieval query)", value=field["description"], key=f"fdesc_{i}",
                    placeholder="e.g. Name of the tenant or lessee who rents the property",
                    label_visibility="collapsed" if i > 0 else "visible",
                )
            with c3:
                if i > 0 and st.button("✕", key=f"fdel_{i}", help="Remove"):
                    fields.pop(i)
                    st.rerun()

        if st.button("+ Add Field"):
            fields.append({"name": "", "description": ""})
            st.rerun()

    # ── Retrieval Parameters ──
    st.subheader("Retrieval Parameters")
    p1, p2 = st.columns(2)
    with p1:
        use_mmr = st.toggle("Use MMR (Maximal Marginal Relevance)", value=False)
        top_k_per_field = st.slider("Top-K chunks per field", 1, 20, 5)
    with p2:
        rrf_k = st.slider("RRF K parameter", 1, 200, 60, help="Higher = more weight to lower-ranked results")
        mmr_lambda = st.slider("MMR Lambda", 0.0, 1.0, 0.7, 0.05,
                               help="1.0 = pure relevance, 0.0 = pure diversity", disabled=not use_mmr)

    # ── Retrieve Chunks Button ──
    st.divider()
    if st.button("Retrieve Chunks", type="primary", use_container_width=True, key="btn_retrieve"):
        valid_fields = [f for f in fields if f["name"].strip() and f["description"].strip()]
        if not valid_fields:
            st.error("Add at least one field with both name and description.")
            st.stop()

        from pipeline.chunking import create_parent_child_chunks
        from pipeline.embedding import embed_child_chunks
        from pipeline.es_indexing import create_es_index, index_documents, get_unique_doc_ids
        from pipeline.retrieval import retrieve_all_fields_chunks, fetch_parent_texts
        from pipeline.enrichment import assemble_context

        field_definitions = {}
        for f in valid_fields:
            field_definitions[f["name"].strip()] = (Optional[str], Field(None, description=f["description"].strip()))
        DynamicSchema = create_model("DynamicSchema", **field_definitions)

        st.session_state["_dynamic_schema_fields"] = [
            {"name": f["name"].strip(), "description": f["description"].strip()} for f in valid_fields
        ]

        es = get_es_client(settings.es_host, settings.es_user, settings.es_password)
        emb_model = load_embedding_model(settings.embedding_model_name)

        st.info("Rebuilding index with new metadata schema...")
        docs = st.session_state["documents"]
        for doc in docs:
            create_parent_child_chunks(
                doc, metadata_schema=DynamicSchema,
                parent_chunk_size=settings.parent_chunk_size, parent_chunk_overlap=settings.parent_chunk_overlap,
                child_chunk_size=settings.child_chunk_size, child_chunk_overlap=settings.child_chunk_overlap,
            )
        create_es_index(es, settings.es_index, DynamicSchema, settings.embedding_dim)
        embed_child_chunks(docs, emb_model)
        index_documents(es, docs, settings.es_index)

        doc_ids = get_unique_doc_ids(es, settings.es_index)
        child_chunks_no_mmr_map = {}
        child_chunks_mmr_map = {}
        parent_chunks_map = {}
        context_map = {}
        total_elapsed_no_mmr = 0.0
        total_elapsed_mmr = 0.0

        progress = st.progress(0.0)

        for idx, doc_id in enumerate(doc_ids):
            progress.progress((idx + 1) / len(doc_ids))

            # Always run without MMR
            chunks_no_mmr, t_no_mmr = retrieve_all_fields_chunks(
                es, settings.es_index, doc_id, schema=DynamicSchema,
                embedding_model=emb_model, top_k_per_field=top_k_per_field,
                chunking_mode="parent_child", use_mmr=False, mmr_lambda=mmr_lambda, rrf_k=rrf_k,
            )
            total_elapsed_no_mmr += t_no_mmr
            child_chunks_no_mmr_map[doc_id] = chunks_no_mmr

            # Always run with MMR for comparison
            chunks_mmr, t_mmr = retrieve_all_fields_chunks(
                es, settings.es_index, doc_id, schema=DynamicSchema,
                embedding_model=emb_model, top_k_per_field=top_k_per_field,
                chunking_mode="parent_child", use_mmr=True, mmr_lambda=mmr_lambda, rrf_k=rrf_k,
            )
            total_elapsed_mmr += t_mmr
            child_chunks_mmr_map[doc_id] = chunks_mmr

            final_chunks = chunks_mmr if use_mmr else chunks_no_mmr

            # Resolve to unique parent chunks
            parent_ids = list(dict.fromkeys(
                c["parent_id"] for c in final_chunks if c.get("parent_id")
            ))
            parent_text_map = fetch_parent_texts(es, settings.es_index, parent_ids) if parent_ids else {}

            parent_list = [{"chunk_id": pid, "text": parent_text_map.get(pid, "")} for pid in parent_ids if pid in parent_text_map]
            parent_chunks_map[doc_id] = parent_list

            context = "\n\n".join(p["text"] for p in parent_list) if parent_list else "\n\n".join(c["text"] for c in final_chunks)
            context_map[doc_id] = context

        progress.progress(1.0)

        timing_cols = st.columns(2)
        with timing_cols[0]:
            st.metric("Time (without MMR)", f"{total_elapsed_no_mmr:.2f}s")
        with timing_cols[1]:
            st.metric("Time (with MMR)", f"{total_elapsed_mmr:.2f}s")

        st.session_state["child_chunks_no_mmr_map"] = child_chunks_no_mmr_map
        st.session_state["child_chunks_mmr_map"] = child_chunks_mmr_map
        st.session_state["parent_chunks_map"] = parent_chunks_map
        st.session_state["context_map"] = context_map
        st.session_state["retrieval_done"] = True
        st.session_state["chunks_accepted"] = False
        st.session_state["prompt_map"] = {}
        st.session_state["extraction_results"] = []
        st.session_state["retrieval_timing"] = {
            "no_mmr": total_elapsed_no_mmr,
            "mmr": total_elapsed_mmr,
        }
        st.session_state["_use_mmr"] = use_mmr

    # ── Display Retrieved Child Chunks (with vs without MMR) ──
    if st.session_state["retrieval_done"]:
        docs_list = st.session_state["documents"]
        no_mmr_map = st.session_state.get("child_chunks_no_mmr_map", {})
        mmr_map = st.session_state.get("child_chunks_mmr_map", {})
        parent_map = st.session_state["parent_chunks_map"]
        used_mmr = st.session_state.get("_use_mmr", False)
        timing = st.session_state.get("retrieval_timing", {})

        st.subheader("Retrieved Child Chunks — Without MMR vs With MMR")

        for doc_id in no_mmr_map:
            file_name = next((d["file_name"] for d in docs_list if d.get("doc_id") == doc_id), doc_id)
            children_no = no_mmr_map.get(doc_id, [])
            children_mmr = mmr_map.get(doc_id, [])

            no_mmr_ids = {c["chunk_id"] for c in children_no}
            mmr_ids = {c["chunk_id"] for c in children_mmr}
            common = no_mmr_ids & mmr_ids
            only_no_mmr = no_mmr_ids - mmr_ids
            only_mmr = mmr_ids - no_mmr_ids

            with st.expander(
                f"📄 {file_name} — {len(children_no)} children (no MMR) vs {len(children_mmr)} children (MMR) "
                f"| {len(common)} shared, {len(only_no_mmr)} only-RRF, {len(only_mmr)} only-MMR",
                expanded=False,
            ):
                col_no, col_mmr = st.columns(2)

                with col_no:
                    st.markdown(f"**Without MMR** ({len(children_no)} chunks, {timing.get('no_mmr', 0):.2f}s)")
                    for i, c in enumerate(children_no):
                        pid = c.get("parent_id", "N/A")
                        tag = "🟢" if c["chunk_id"] in common else "🔵"
                        text_preview = c["text"][:200] + ("..." if len(c["text"]) > 200 else "")
                        st.markdown(
                            f'<div class="chunk-box">{tag} <b>Child {i+1}</b> '
                            f'<code>{c["chunk_id"][:20]}...</code> → parent: <code>{pid[:20]}...</code>'
                            f'<br/>{text_preview}</div>',
                            unsafe_allow_html=True,
                        )

                with col_mmr:
                    st.markdown(f"**With MMR** ({len(children_mmr)} chunks, {timing.get('mmr', 0):.2f}s)")
                    for i, c in enumerate(children_mmr):
                        pid = c.get("parent_id", "N/A")
                        tag = "🟢" if c["chunk_id"] in common else "🟠"
                        text_preview = c["text"][:200] + ("..." if len(c["text"]) > 200 else "")
                        st.markdown(
                            f'<div class="chunk-box">{tag} <b>Child {i+1}</b> '
                            f'<code>{c["chunk_id"][:20]}...</code> → parent: <code>{pid[:20]}...</code>'
                            f'<br/>{text_preview}</div>',
                            unsafe_allow_html=True,
                        )

                st.caption("🟢 = shared between both modes | 🔵 = only in RRF (no MMR) | 🟠 = only in MMR")

        st.divider()

        # ── Final Compiled Parent Chunks ──
        mode_label = "MMR" if used_mmr else "RRF (no MMR)"
        st.subheader(f"Final Compiled Parent Chunks (using {mode_label})")

        for doc_id, parents in parent_map.items():
            file_name = next((d["file_name"] for d in docs_list if d.get("doc_id") == doc_id), doc_id)

            # Count how many child chunks mapped to each parent
            final_children = mmr_map.get(doc_id, []) if used_mmr else no_mmr_map.get(doc_id, [])
            parent_child_count = {}
            for c in final_children:
                pid = c.get("parent_id", "")
                parent_child_count[pid] = parent_child_count.get(pid, 0) + 1

            with st.expander(f"📄 {file_name} — {len(parents)} parent chunks (from {len(final_children)} children)", expanded=False):
                for i, p in enumerate(parents):
                    n_children = parent_child_count.get(p["chunk_id"], 0)
                    text_preview = p["text"][:500] + ("..." if len(p["text"]) > 500 else "")
                    st.markdown(
                        f'<div class="parent-box"><b>Parent {i+1}</b> '
                        f'<code>{p["chunk_id"][:24]}...</code> '
                        f'({len(p["text"]):,} chars, {n_children} child hit{"s" if n_children != 1 else ""})'
                        f'<br/><br/>{text_preview}</div>',
                        unsafe_allow_html=True,
                    )

        total_parents = sum(len(v) for v in parent_map.values())
        total_children_used = sum(
            len(mmr_map.get(did, []) if used_mmr else no_mmr_map.get(did, []))
            for did in parent_map
        )
        total_context_chars = sum(len(v) for v in st.session_state["context_map"].values())
        mc1, mc2, mc3 = st.columns(3)
        mc1.metric("Child Chunks Retrieved", total_children_used)
        mc2.metric("Unique Parent Chunks", total_parents)
        mc3.metric("Total Context", f"{total_context_chars:,} chars")

        st.divider()
        if st.button("Accept Chunks & Build Prompt", type="primary", use_container_width=True, key="btn_accept"):
            from pipeline.prompt import build_prompts_for_all_docs

            DynamicSchema = _rebuild_schema()
            if DynamicSchema is None:
                st.error("No schema fields found. Re-run retrieval.")
                st.stop()

            prompt_map = build_prompts_for_all_docs(st.session_state["context_map"], DynamicSchema)
            st.session_state["prompt_map"] = prompt_map
            st.session_state["chunks_accepted"] = True
            st.session_state["extraction_results"] = []
            st.success("Chunks accepted. Go to **Tab 3: Review Prompt** to see the full prompts.")


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 3: Review Prompt & Trigger LLM
# ═══════════════════════════════════════════════════════════════════════════════
with tab3:
    st.header("Review Prompt")

    if not st.session_state["chunks_accepted"]:
        st.info("Accept chunks in Tab 2 first to build the prompts.")
        st.stop()

    prompt_map = st.session_state["prompt_map"]
    docs_list = st.session_state["documents"]

    for doc_id, prompt_text in prompt_map.items():
        file_name = next((d["file_name"] for d in docs_list if d.get("doc_id") == doc_id), doc_id)
        with st.expander(f"📄 {file_name} — prompt ({len(prompt_text):,} chars)", expanded=len(prompt_map) == 1):
            st.markdown(f'<div class="prompt-box">{prompt_text}</div>', unsafe_allow_html=True)

    st.divider()
    st.markdown(f"**{len(prompt_map)}** prompt(s) ready. Click below to send to the LLM.")

    if st.button("Extract Metadata with LLM", type="primary", use_container_width=True, key="btn_extract"):
        from pipeline.llm_extraction import extract_with_prompt

        llm_cfg = get_llm_config(settings)
        if not llm_cfg.is_configured:
            st.error("LLM gateway not configured. Fill LLM_AGENT_NAME, LLM_USER_ID, and LLM_VEGAS_API_URL in the sidebar.")
            st.stop()

        DynamicSchema = _rebuild_schema()
        if DynamicSchema is None:
            st.error("No schema found. Re-run from Tab 2.")
            st.stop()

        doc_url_map = st.session_state.get("doc_url_map", {})
        extraction_results = []

        progress = st.progress(0.0)
        status = st.empty()

        for idx, (doc_id, prompt_text) in enumerate(prompt_map.items()):
            status.info(f"Extracting metadata for document {idx+1}/{len(prompt_map)}...")
            progress.progress((idx + 1) / len(prompt_map))

            metadata = extract_with_prompt(prompt_text, DynamicSchema, llm_config=llm_cfg)

            file_name = next((d["file_name"] for d in docs_list if d.get("doc_id") == doc_id), "")
            extraction_results.append({
                "doc_id": doc_id,
                "file_name": file_name,
                "source_url": doc_url_map.get(doc_id, ""),
                "metadata": metadata,
            })

        progress.progress(1.0)
        status.empty()
        st.session_state["extraction_results"] = extraction_results
        st.success("Extraction complete. Go to **Tab 4: Extraction Results** to view output.")


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 4: Extraction Results
# ═══════════════════════════════════════════════════════════════════════════════
with tab4:
    st.header("Extraction Results")

    results = st.session_state.get("extraction_results", [])
    if not results:
        st.info("No results yet. Run extraction in Tab 3.")
        st.stop()

    # JSON view
    with st.expander("Raw JSON Output", expanded=False):
        st.json(results)

    # Tabular view
    st.subheader("Results Table")
    table_rows = []
    for r in results:
        row = {
            "Document ID": r["doc_id"][:20] + "...",
            "File Name": r["file_name"],
            "Source URL": r["source_url"],
        }
        for k, v in r["metadata"].items():
            display_val = str(v) if v is not None else "(null)"
            if len(display_val) > 80:
                display_val = display_val[:80] + "..."
            row[k] = display_val
        table_rows.append(row)

    st.dataframe(pd.DataFrame(table_rows), use_container_width=True, hide_index=True)

    # Per-document details
    st.subheader("Per-Document Details")
    for r in results:
        with st.expander(f"📄 {r['file_name']} ({r['doc_id'][:16]}...)"):
            st.markdown(f"**Source URL:** {r['source_url']}")
            st.markdown(f"**Document ID:** `{r['doc_id']}`")
            st.markdown("**Extracted Metadata:**")
            for field_name, value in r["metadata"].items():
                if value is not None:
                    st.markdown(f"- **{field_name}:** {value}")
                else:
                    st.markdown(f"- **{field_name}:** *(null)*")
