# Metadata Enrichment Pipeline v2 — Technical Reference

## Overview

A retrieval-augmented metadata enrichment pipeline that automatically extracts structured metadata from unstructured PDF documents (lease agreements) and stores it in Elasticsearch for filterable, semantic search. The pipeline ingests PDFs, chunks them hierarchically, embeds child chunks for vector search, and uses Elasticsearch-native hybrid retrieval (KNN + BM25 + RRF) combined with a single LLM call per document to extract all metadata fields at once.

**Core principle**: Elasticsearch is the single source of truth — all retrieval, storage, and enrichment flows through ES. No embeddings or full chunk payloads are pulled into Python during enrichment.

---

## Architecture

```mermaid
flowchart TD
    subgraph ingest [Stage 1: Ingest]
        PDF["PDF Documents (./data/leases/)"] --> Docling["Docling Document Converter"]
        Docling --> MD["Markdown Text (full_text)"]
        MD --> DocRecord["Document Record {file_name, full_text, title, upload_date}"]
    end

    subgraph chunk [Stage 2: Parent-Child Chunking]
        DocRecord --> ParentSplit["Split into Parent Chunks (~2000 chars, 200 overlap)"]
        ParentSplit --> ParentChunks["Parent Chunks (context for extraction)"]
        ParentSplit --> ChildSplit["Split each Parent into Child Chunks (~512 chars, 50 overlap)"]
        ChildSplit --> ChildChunks["Child Chunks (units of retrieval)"]
    end

    subgraph embed [Stage 3: Embed]
        ChildChunks --> Arctic["Snowflake Arctic Embed M (768d, cosine, normalized)"]
        Arctic --> ChildVectors["Child Chunks + Embedding Vectors"]
    end

    subgraph index [Stage 4: Elasticsearch Index]
        ParentChunks --> BulkIndex["Bulk Index (helpers.bulk)"]
        ChildVectors --> BulkIndex
        BulkIndex --> ES[("Elasticsearch Index (lease_documents)")]
    end

    subgraph enrich [Stage 5: ES-First Batch Enrichment]
        ES --> DocIDs["Get unique doc_ids (aggregation)"]
        DocIDs --> PerDoc["For each doc_id"]
        PerDoc --> PerField["For each metadata field"]
        PerField --> HybridSearch["ES Hybrid Search (KNN + BM25 + RRF)\nscoped to doc_id"]
        HybridSearch --> TopK["Top-k child chunks per field"]
        TopK --> Dedup["Deduplicate across all fields"]
        Dedup --> FetchParents["Fetch parent texts for returned parent_ids only"]
        FetchParents --> Context["Combined context text"]
        Context --> Gemini["1 Gemini LLM call with full Pydantic schema"]
        Gemini --> DocMeta["doc_metadata dict (all fields)"]
        DocMeta --> GetIDs["Get all chunk_ids for doc_id (lightweight query)"]
        GetIDs --> BulkUpdate["Bulk-update all chunks with doc_metadata"]
        BulkUpdate --> ES
    end
```

---

## Technology Stack

| Component | Technology | Purpose |
|-----------|-----------|---------|
| **PDF Parsing** | Docling (with PyMuPDF fallback) | Convert PDF to structured markdown |
| **Embedding** | Snowflake Arctic Embed M (768d) | Dense vector representations for child chunks |
| **Vector + Text Store** | Elasticsearch 8.x | KNN search (`dense_vector`), BM25 full-text, RRF fusion |
| **LLM** | Google Gemini 2.0 Flash | Structured JSON extraction via `response_schema` |
| **Schema** | Pydantic v2 | Metadata schema definition, validation, ES mapping generation |
| **Orchestration** | Python (Jupyter Notebook) | Pipeline orchestration with `tqdm` progress tracking |

---

## Data Model

### Elasticsearch Index Mapping

Index name: `lease_documents`

```
Settings: 1 shard, 0 replicas (single-node dev)

Mappings:
├── chunk_id        keyword         Deterministic SHA-256 hash (prefix: parent_ / child_)
├── parent_id       keyword         Links child → parent (children only)
├── doc_id          keyword         Groups all chunks of one document
├── chunk_type      keyword         "parent" or "child"
├── chunk_index     integer         Order within document
├── text            text (standard) Full-text searchable content
├── file_name       keyword         Source PDF filename
├── title           text + keyword  Document title (multi-field for search + sort)
├── upload_date     date            Ingestion timestamp
├── embedding       dense_vector    768 dims, cosine, indexed (children only)
└── metadata        object          Schema-driven fields (auto-mapped from Pydantic)
    ├── owner_name          keyword
    ├── landlord            keyword
    ├── signing_date        keyword
    ├── expiry_date         keyword
    ├── escalation_clause   keyword
    ├── property_address    keyword
    ├── monthly_rent        keyword
    ├── amendment_number    integer
    └── document_type       keyword
```

### Parent vs Child Chunks

| Attribute | Parent Chunk | Child Chunk |
|-----------|-------------|-------------|
| `chunk_type` | `"parent"` | `"child"` |
| `embedding` | Not stored | 768-dim dense vector |
| `parent_id` | Not stored | Points to parent's `chunk_id` |
| `text` | ~2000 chars (extraction context) | ~512 chars (retrieval unit) |
| `metadata` | Same doc-level metadata | Same doc-level metadata |

**Rationale**: Child chunks are small enough for precise semantic retrieval. When a child is retrieved, its parent's larger text window provides richer context for LLM extraction. Both carry the same document-level metadata for consistent filtering.

---

## Pipeline Stages

### Stage 1: PDF Ingestion

```
PDF → Docling DocumentConverter → Markdown export → Document record
```

- **Primary**: Docling converts PDFs to structured markdown (handles tables, headers, layout)
- **Fallback**: PyMuPDF raw text extraction if Docling fails
- Documents are stored as `{file_name, full_text, title, upload_date}` records

### Stage 2: Parent-Child Chunking

```
full_text → split_text(2000, 200) → parent chunks
each parent → split_text(512, 50) → child chunks
```

- **Parent chunks**: ~2000 characters with 200-char overlap. Used for LLM extraction context.
- **Child chunks**: ~512 characters with 50-char overlap. Embedded and used for vector retrieval.
- Each child stores its `parent_id` to enable parent text lookup at extraction time.
- IDs are deterministic (SHA-256 of content + position), ensuring idempotent re-indexing.

### Stage 3: Embedding

```python
model = SentenceTransformer("Snowflake/snowflake-arctic-embed-m")
embeddings = model.encode(texts, normalize_embeddings=True)
```

- Only **child chunks** are embedded (parents are too large for precise retrieval)
- 768-dimensional vectors, L2-normalized for cosine similarity
- Batch encoding with `show_progress_bar=True`

### Stage 4: Elasticsearch Indexing

- **Mapping auto-generation**: `build_metadata_mapping()` converts Pydantic schema to ES field mappings. Handles `Optional[T]` (anyOf with null) and maps Python types to ES types.
- **Bulk indexing**: Parents (no embedding, no parent_id) and children (with embedding + parent_id) indexed in one `helpers.bulk()` call.
- Index is deleted and recreated on each run (dev workflow).

### Stage 5: Retrieval-Augmented Enrichment

This is the core of the pipeline. For each document:

#### 5a. Per-Field Hybrid Retrieval

For each metadata field, the pipeline runs an ES hybrid search scoped to the document:

```json
{
  "retriever": {
    "rrf": {
      "retrievers": [
        {
          "standard": {
            "query": {
              "bool": {
                "must": [
                  {"term": {"doc_id": "<doc_id>"}},
                  {"term": {"chunk_type": "child"}},
                  {"match": {"text": {"query": "<field query>"}}}
                ]
              }
            }
          }
        },
        {
          "knn": {
            "field": "embedding",
            "query_vector": [<768 floats>],
            "k": 20,
            "num_candidates": 80,
            "filter": {"bool": {"must": [
              {"term": {"doc_id": "<doc_id>"}},
              {"term": {"chunk_type": "child"}}
            ]}}
          }
        }
      ],
      "rank_constant": 60,
      "rank_window_size": 20
    }
  }
}
```

**Two retrieval signals combined with RRF**:
- **BM25 (standard retriever)**: Lexical match on the `text` field — catches exact keyword matches ("landlord", "monthly rent")
- **KNN (knn retriever)**: Cosine similarity on the `embedding` field — catches semantic matches ("lessor" matches "landlord" query)
- **RRF fusion**: `score = 1 / (k + rank)` with `k=60`. No tuning needed; combines both signals without requiring score normalization.

**Query source**: Each field has configurable `field_retrieval_queries` (e.g., `"landlord"` → `["landlord", "lessor", "property owner"]`). If not configured, the field's Pydantic description is used as the query text.

**Multi-query fusion**: When multiple queries exist for a field, each produces a ranked list. These are fused with a second RRF pass in Python to produce the final top-k for that field.

#### 5b. Cross-Field Deduplication

Chunks retrieved across all fields are deduplicated by `chunk_id`. Chunks are sorted by how many fields retrieved them (a chunk retrieved by 5 fields ranks higher than one retrieved by 1 field).

#### 5c. Parent Text Fetch (On-Demand)

For parent-child mode, the pipeline fetches parent texts **only for the specific parent_ids referenced by retrieved child chunks** — not all parents for the document:

```python
parent_ids = list({c["parent_id"] for c in all_chunks if c.get("parent_id")})
parent_texts = _fetch_parent_texts(es_client, index_name, parent_ids)  # ES ids query
```

Parent texts provide the broader context window for LLM extraction.

#### 5d. Batch LLM Extraction (1 Call per Document)

All retrieved context is passed to Gemini in a single call with the **full Pydantic schema** as the structured output constraint:

```python
response = gemini_client.models.generate_content(
    model="gemini-2.0-flash",
    contents=prompt,
    config={
        "response_mime_type": "application/json",
        "response_schema": schema.model_json_schema(),  # Full LeaseMetadata schema
    },
)
parsed = schema.model_validate_json(response.text)
```

- 1 LLM call per document (not per field)
- Gemini is constrained to return valid JSON matching the schema
- Pydantic validation on the response catches malformed output
- On failure, all fields default to `None`

#### 5e. Bulk Metadata Update

After extraction, a lightweight query fetches all `chunk_ids` for the document (parents + children), and a bulk update writes the same `doc_metadata` to every chunk:

```python
chunk_ids = _get_all_chunk_ids(es_client, index_name, doc_id)  # keyword-only, no text/embeddings
actions = [
    {"_op_type": "update", "_index": index_name, "_id": cid, "doc": {"metadata": doc_metadata}}
    for cid in chunk_ids
]
helpers.bulk(es_client, actions)
```

---

## Configuration

### EnrichmentConfig

```python
@dataclass
class EnrichmentConfig:
    metadata_schema: Type[BaseModel]                    # Pydantic model defining metadata fields
    field_retrieval_queries: Dict[str, List[str]]       # Field → search queries for retrieval
    extraction_strategy: Literal[                       # Primary extraction method
        "retrieval_augmented", "section_based", "hybrid"
    ] = "retrieval_augmented"
    context_limit_tokens: int = 8000                    # Max tokens for section-based fallback
    chars_per_token: float = 4.0                        # Char-to-token ratio estimate
    safety_margin: float = 0.7                          # Context window safety buffer
    chunks_per_section: Optional[int] = None            # Override auto-computed section size
    merge_strategy: Literal[                            # Section-based merge strategy
        "first_non_null", "last_non_null", "most_common"
    ] = "first_non_null"
    chunking_mode: Literal["flat", "parent_child"] = "flat"
    top_k_per_field: int = 5                            # Chunks retrieved per field
```

### Metadata Schema (Lease Example)

```python
class LeaseMetadata(BaseModel):
    owner_name:        Optional[str] = Field(None, description="Name of the property owner / tenant")
    landlord:          Optional[str] = Field(None, description="Name of the landlord or lessor")
    signing_date:      Optional[str] = Field(None, description="Date the lease was signed (YYYY-MM-DD)")
    expiry_date:       Optional[str] = Field(None, description="Lease expiration date (YYYY-MM-DD)")
    escalation_clause: Optional[str] = Field(None, description="Rent escalation terms or percentage")
    property_address:  Optional[str] = Field(None, description="Full address of the leased property")
    monthly_rent:      Optional[str] = Field(None, description="Monthly rent amount with currency")
    amendment_number:  Optional[int] = Field(None, description="Amendment number or None for original lease")
    document_type:     Optional[str] = Field(None, description="Document type: lease or amendment")
```

The schema serves triple duty:
1. **ES mapping**: `build_metadata_mapping()` converts field types to ES field mappings
2. **LLM constraint**: `schema.model_json_schema()` is passed as Gemini's `response_schema`
3. **Validation**: `schema.model_validate_json()` validates the LLM response

### Field Retrieval Queries

```python
FIELD_RETRIEVAL_QUERIES = {
    "owner_name":        ["tenant name", "lessee", "party A", "occupant", "owner"],
    "landlord":          ["landlord", "lessor", "property owner", "party B"],
    "signing_date":      ["signed on", "execution date", "lease date", "effective date"],
    "expiry_date":       ["expiration", "lease term ends", "termination date"],
    "escalation_clause": ["rent escalation", "annual increase", "rent adjustment"],
    "property_address":  ["property address", "premises", "located at"],
    "monthly_rent":      ["monthly rent", "base rent", "rent amount"],
    "amendment_number":  ["amendment", "first amendment", "second amendment"],
    "document_type":     ["lease agreement", "amendment", "lease"],
}
```

Multiple queries per field improve recall — "landlord" might not appear in the text, but "lessor" or "property owner" will. Each query is used for both BM25 (keyword) and KNN (semantic) search.

If a field has no configured queries, the pipeline auto-generates one from the field's Pydantic `description` attribute.

---

## Fallback: Section-Based Extraction

When retrieval-augmented extraction is not possible (no embeddings available), the pipeline falls back to section-based extraction:

1. **Group chunks into sections** based on `context_limit_tokens` and `chars_per_token`
2. **Extract per section**: Each section is sent to the LLM with the full schema
3. **Merge across sections**: `merge_extractions()` consolidates section-level results using a configurable strategy (`first_non_null`, `last_non_null`, `most_common`)

---

## Key Design Decisions

### Why ES-Native Hybrid Search (Not Python-Side)

Early versions computed cosine similarity in Python (numpy dot product) and implemented RRF manually. The current version delegates entirely to ES:

- **Performance**: ES's HNSW index is optimized for approximate KNN at scale
- **BM25 for free**: Text field search uses ES's built-in BM25 scorer — no additional computation
- **RRF fusion server-side**: ES's `rrf` retriever combines KNN + BM25 in one request with no score normalization needed
- **No data transfer**: Embedding vectors (768 floats per chunk) never leave ES during enrichment

### Why Batch Extraction (1 LLM Call, Not N)

Extracting all fields in one call instead of per-field:

- **Cost**: 1 API call vs 9 (for the lease schema). ~9x reduction in LLM cost.
- **Latency**: 1 round-trip vs 9 sequential round-trips
- **Cross-field reasoning**: The LLM sees all relevant context at once. "John Smith (Landlord) and Jane Doe (Tenant)" — both landlord and tenant are extracted from the same sentence in one pass.
- **Context deduplication**: Chunks relevant to multiple fields are sent once, not repeatedly.

### Why Parent-Child (Not Flat Chunks)

- **Retrieval precision**: Small child chunks (512 chars) are precise retrieval units — a query for "monthly rent" hits the exact paragraph mentioning rent, not a 2000-char block that also contains security deposit terms.
- **Extraction context**: Once a child is retrieved, its parent (2000 chars) provides surrounding context for the LLM, reducing hallucination from truncated text.
- **Document-level metadata**: All chunks (parents + children) for a document receive the same metadata, enabling consistent filtering regardless of which chunk is returned in a search.

### Why Deterministic IDs

Chunk IDs are SHA-256 hashes of `(doc_id + position)`:

```python
def deterministic_id(content: str, prefix: str = "") -> str:
    h = hashlib.sha256(content.encode("utf-8")).hexdigest()[:16]
    return (prefix + h) if prefix else h
```

This ensures idempotent indexing — re-running the pipeline on the same document overwrites the same ES documents rather than creating duplicates.

---

## Function Reference

| Function | Location | Purpose |
|----------|----------|---------|
| `create_parent_child_chunks()` | Stage 2 | Split document into parent/child chunk hierarchy |
| `embed_child_chunks()` | Stage 3 | Batch-encode child chunks with Snowflake Arctic |
| `build_metadata_mapping()` | Stage 4 | Convert Pydantic schema → ES field mappings |
| `create_es_index()` | Stage 4 | Create ES index with dense_vector + metadata mapping |
| `index_documents()` | Stage 4 | Bulk-index parents + children into ES |
| `es_hybrid_search_chunks()` | Stage 5 | Single ES query: KNN + BM25 + RRF, scoped to doc_id |
| `retrieve_chunks_for_field()` | Stage 5 | Multi-query retrieval for one field with RRF fusion |
| `retrieve_all_fields_chunks()` | Stage 5 | Per-field retrieval + cross-field deduplication |
| `extract_all_fields()` | Stage 5 | One LLM call with full schema → complete metadata dict |
| `enrich_document_retrieval_augmented()` | Stage 5 | Orchestrates retrieve → deduplicate → extract → return |
| `run_enrichment_pipeline()` | Stage 5 | Iterates all documents, enriches, bulk-updates ES |
| `enrich_document_section_based()` | Fallback | Section-based extraction when embeddings unavailable |
| `merge_extractions()` | Fallback | Merge section-level results into document-level metadata |

---

## Dependencies

```
google-genai          # Gemini LLM client
elasticsearch         # Elasticsearch Python client
sentence-transformers # Snowflake Arctic Embed M
pydantic              # Schema definition and validation
tqdm                  # Progress bars
numpy                 # Vector operations (query encoding)
docling               # PDF to markdown conversion
```

---

## Usage

```python
# 1. Configure
config = EnrichmentConfig(
    metadata_schema=LeaseMetadata,
    field_retrieval_queries=FIELD_RETRIEVAL_QUERIES,
    extraction_strategy="retrieval_augmented",
    chunking_mode="parent_child",
    top_k_per_field=5,
)

# 2. Run (assumes documents are already indexed in ES)
run_enrichment_pipeline(es, ES_INDEX, config, embedding_model, overwrite=True)

# 3. Query enriched documents
results = es.search(
    index=ES_INDEX,
    body={
        "query": {
            "bool": {
                "must": [{"match": {"text": "rent increase"}}],
                "filter": [{"term": {"metadata.document_type": "lease"}}]
            }
        }
    }
)
```

---

## Enrichment Flow Diagram (Per Document)

```mermaid
sequenceDiagram
    participant Pipeline as run_enrichment_pipeline
    participant ES as Elasticsearch
    participant Embed as Embedding Model
    participant LLM as Gemini LLM

    Pipeline->>ES: get_unique_doc_ids (aggregation)
    ES-->>Pipeline: [doc_001, doc_002, ...]

    loop For each doc_id
        Pipeline->>ES: _doc_already_enriched? (check metadata)
        ES-->>Pipeline: True/False

        loop For each metadata field (9 fields)
            Pipeline->>Embed: encode(field_query)
            Embed-->>Pipeline: query_vector (768d)
            Pipeline->>ES: Hybrid search (KNN + BM25 + RRF)<br/>filter: doc_id + chunk_type=child
            ES-->>Pipeline: Top-k child chunks (text + parent_id)
        end

        Note over Pipeline: Deduplicate chunks across all fields

        Pipeline->>ES: Fetch parent texts (ids query, only referenced parents)
        ES-->>Pipeline: {parent_id: text}

        Note over Pipeline: Build combined context from parent texts

        Pipeline->>LLM: 1 call: context + full schema → extract all fields
        LLM-->>Pipeline: {owner_name, landlord, signing_date, ...}

        Pipeline->>ES: _get_all_chunk_ids (lightweight, keyword only)
        ES-->>Pipeline: [chunk_id_1, chunk_id_2, ...]
        Pipeline->>ES: Bulk update all chunk_ids with doc_metadata
    end

    Pipeline->>ES: Refresh index
```
