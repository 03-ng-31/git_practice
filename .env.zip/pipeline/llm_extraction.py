"""
LLM extraction module.

Sends a pre-built prompt to the LLM and parses the structured JSON response.
Prompt construction lives in pipeline.prompt — this module only handles the API call.
"""

import json
import requests
from typing import Dict, Any, Type
from pydantic import BaseModel

from pipeline.config import LLMConfig


def extract_with_prompt(
    prompt: str,
    schema: Type[BaseModel],
    llm_config: LLMConfig = None,
    gemini_client=None,
    gemini_model: str = "gemini-2.0-flash",
) -> Dict[str, Any]:
    """
    Send a ready-made prompt to the LLM and parse the JSON response.
    Supports Vegas API gateway (primary) and direct Gemini (fallback).
    """
    if llm_config and llm_config.is_configured:
        return _extract_via_vegas(prompt, schema, llm_config)

    if gemini_client is not None:
        return _extract_via_gemini(prompt, schema, gemini_client, gemini_model)

    print("  [WARN] No LLM backend configured. Returning None for all fields.")
    return {name: None for name in schema.model_fields}


# Keep backward-compatible alias
def extract_all_fields(
    text: str,
    schema: Type[BaseModel],
    llm_config: LLMConfig = None,
    gemini_client=None,
    gemini_model: str = "gemini-2.0-flash",
) -> Dict[str, Any]:
    """Backward-compatible wrapper: builds prompt from raw text, then extracts."""
    from pipeline.prompt import build_extraction_prompt
    prompt = build_extraction_prompt(text, schema)
    return extract_with_prompt(prompt, schema, llm_config, gemini_client, gemini_model)


def _extract_via_vegas(
    prompt: str,
    schema: Type[BaseModel],
    llm_config: LLMConfig,
) -> Dict[str, Any]:
    """Call the Vegas LLM API gateway."""
    try:
        payload = {
            "agent_name": llm_config.agent_name,
            "user_id": llm_config.user_id,
            "prompt": prompt,
            "response_format": "json",
            "response_schema": schema.model_json_schema(),
        }
        headers = {
            "Content-Type": "application/json",
            "X-Agent-Name": llm_config.agent_name,
            "X-User-ID": llm_config.user_id,
        }
        resp = requests.post(
            llm_config.vegas_api_url,
            json=payload,
            headers=headers,
            timeout=120,
        )
        resp.raise_for_status()

        body = resp.json()
        raw_text = (
            body.get("result")
            or body.get("response")
            or body.get("text")
            or body.get("content")
            or json.dumps(body)
        )
        if isinstance(raw_text, dict):
            raw_text = json.dumps(raw_text)

        parsed = schema.model_validate_json(raw_text)
        return parsed.model_dump()
    except Exception as e:
        print(f"  [WARN] Vegas API extraction failed: {e}")
        return {name: None for name in schema.model_fields}


def _extract_via_gemini(
    prompt: str,
    schema: Type[BaseModel],
    gemini_client,
    gemini_model: str,
) -> Dict[str, Any]:
    """Call Gemini directly as fallback."""
    try:
        response = gemini_client.models.generate_content(
            model=gemini_model,
            contents=prompt,
            config={
                "response_mime_type": "application/json",
                "response_schema": schema.model_json_schema(),
            },
        )
        parsed = schema.model_validate_json(response.text)
        return parsed.model_dump()
    except Exception as e:
        print(f"  [WARN] Gemini extraction failed: {e}")
        return {name: None for name in schema.model_fields}
