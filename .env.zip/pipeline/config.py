import os
from dataclasses import dataclass
from typing import Optional, Dict, Any, Type, Literal
from pydantic import BaseModel


@dataclass
class LLMConfig:
    """LLM gateway configuration resolved from environment or user input."""
    agent_name: str = ""
    user_id: str = ""
    vegas_api_url: str = ""

    @classmethod
    def from_env(cls) -> "LLMConfig":
        """Load LLM config from environment variables as defaults."""
        return cls(
            agent_name=os.getenv("LLM_AGENT_NAME", ""),
            user_id=os.getenv("LLM_USER_ID", ""),
            vegas_api_url=os.getenv("LLM_VEGAS_API_URL", ""),
        )

    @property
    def is_configured(self) -> bool:
        return bool(self.agent_name and self.user_id and self.vegas_api_url)


@dataclass
class PipelineSettings:
    """Infrastructure and model configuration."""
    es_host: str = "http://localhost:9200"
    es_index: str = "rag_documents"
    es_user: str = "elastic"
    es_password: str = "changeme"

    embedding_model_name: str = "Snowflake/snowflake-arctic-embed-m"
    embedding_dim: int = 768

    llm_agent_name: str = ""
    llm_user_id: str = ""
    llm_vegas_api_url: str = ""

    parent_chunk_size: int = 2000
    parent_chunk_overlap: int = 200
    child_chunk_size: int = 512
    child_chunk_overlap: int = 50

    data_dir: str = "./data/downloads"

    @property
    def llm_config(self) -> LLMConfig:
        return LLMConfig(
            agent_name=self.llm_agent_name,
            user_id=self.llm_user_id,
            vegas_api_url=self.llm_vegas_api_url,
        )


@dataclass
class EnrichmentConfig:
    """Generic config for metadata enrichment -- works for any document type."""
    metadata_schema: Type[BaseModel] = None
    extraction_strategy: Literal["retrieval_augmented", "section_based", "hybrid"] = "retrieval_augmented"
    context_limit_tokens: int = 8000
    chars_per_token: float = 4.0
    safety_margin: float = 0.7
    chunks_per_section: Optional[int] = None
    merge_strategy: Literal["first_non_null", "last_non_null", "most_common"] = "first_non_null"
    chunking_mode: Literal["flat", "parent_child"] = "parent_child"
    top_k_per_field: int = 5
    use_mmr: bool = False
    mmr_lambda: float = 0.7
    rrf_k: int = 60
