"""
Prompt construction module.

Builds structured, guardrailed extraction prompts from:
  - Compiled parent chunk context (assembled from retrieval)
  - Metadata schema field definitions (names, types, descriptions)

Kept separate so prompts can be inspected, versioned, and tested independently.
"""

import json
from typing import Type, Dict, List, Any, Optional
from pydantic import BaseModel


# ═══════════════════════════════════════════════════════════════════════════════
# Prompt building blocks
# ═══════════════════════════════════════════════════════════════════════════════

def build_role_block() -> str:
    return """<ROLE>
You are a precise, deterministic metadata extraction agent.
Your sole purpose is to extract structured metadata fields from document text.
You have no opinions. You do not summarize. You do not infer beyond what the text states.
</ROLE>"""


def build_objective_block() -> str:
    return """<OBJECTIVE>
Given a set of document text chunks, extract the requested metadata fields and return
them as a single JSON object. Each field must be populated with a value found explicitly
in the text, or set to null if the information is absent or ambiguous.
</OBJECTIVE>"""


def build_guardrails_block() -> str:
    return """<GUARDRAILS>
1. ONLY extract information that is explicitly stated in the provided text.
2. Do NOT hallucinate, guess, or infer values that are not present.
3. Do NOT use external knowledge — treat the document text as the sole source of truth.
4. If a field's value is ambiguous or appears in conflicting forms, return null.
5. Return dates in YYYY-MM-DD format when possible; otherwise return the exact string.
6. Return monetary values with their currency symbol (e.g. "$2,500").
7. Return numeric fields as numbers (int or float), not strings.
8. Strip leading/trailing whitespace from all string values.
9. Do NOT include any explanation, commentary, or markdown — return ONLY the JSON object.
10. The response must be valid, parseable JSON. No trailing commas, no comments.
</GUARDRAILS>"""


def build_field_descriptions(schema: Type[BaseModel]) -> str:
    """Render field names, types, and descriptions from a Pydantic schema."""
    lines = []
    json_schema = schema.model_json_schema()
    properties = json_schema.get("properties", {})

    for name, info in schema.model_fields.items():
        desc = info.description or name.replace("_", " ")
        prop = properties.get(name, {})

        # Resolve type from anyOf (Optional fields) or direct type
        field_type = "string"
        if "anyOf" in prop:
            for option in prop["anyOf"]:
                if option.get("type") != "null":
                    field_type = option.get("type", "string")
                    break
        else:
            field_type = prop.get("type", "string")

        lines.append(f"  - {name} ({field_type}, nullable): {desc}")

    return "\n".join(lines)


def build_output_schema_block(schema: Type[BaseModel]) -> str:
    """Render the expected JSON output schema with example null values."""
    example = {}
    json_schema = schema.model_json_schema()
    properties = json_schema.get("properties", {})

    for name in schema.model_fields:
        prop = properties.get(name, {})
        field_type = "string"
        if "anyOf" in prop:
            for option in prop["anyOf"]:
                if option.get("type") != "null":
                    field_type = option.get("type", "string")
                    break
        else:
            field_type = prop.get("type", "string")

        if field_type == "integer":
            example[name] = "<integer or null>"
        elif field_type == "number":
            example[name] = "<number or null>"
        elif field_type == "boolean":
            example[name] = "<true/false or null>"
        else:
            example[name] = "<string or null>"

    return json.dumps(example, indent=2)


def build_extraction_rules_block() -> str:
    return """<EXTRACTION_RULES>
- Read the entire document text before extracting any field.
- For each field, scan all provided chunks — the answer may span multiple sections.
- If a field appears multiple times with consistent values, use that value.
- If a field appears multiple times with conflicting values, return null.
- Prefer the most specific and complete value (e.g. full address over partial).
- Blank lines, underscores (____), or placeholder text mean the field is unfilled — return null.
</EXTRACTION_RULES>"""


# ═══════════════════════════════════════════════════════════════════════════════
# Main prompt builder
# ═══════════════════════════════════════════════════════════════════════════════

def build_extraction_prompt(
    context: str,
    schema: Type[BaseModel],
    max_context_chars: int = 30000,
) -> str:
    """
    Build a structured, guardrailed extraction prompt.

    Sections:
      1. ROLE — who the LLM is
      2. OBJECTIVE — what it must do
      3. GUARDRAILS — hard constraints and safety rules
      4. FIELDS — what to extract (name, type, description)
      5. OUTPUT_SCHEMA — exact JSON shape expected
      6. EXTRACTION_RULES — how to handle edge cases
      7. DOCUMENT_TEXT — the actual content
      8. INSTRUCTION — final directive
    """
    field_block = build_field_descriptions(schema)
    schema_block = build_output_schema_block(schema)
    truncated_context = context[:max_context_chars]

    return f"""{build_role_block()}

{build_objective_block()}

{build_guardrails_block()}

<FIELDS>
Extract the following metadata fields:
{field_block}
</FIELDS>

<OUTPUT_SCHEMA>
Return a JSON object matching this exact structure:
{schema_block}

Replace each placeholder with the extracted value, or null if not found.
</OUTPUT_SCHEMA>

{build_extraction_rules_block()}

<DOCUMENT_TEXT>
{truncated_context}
</DOCUMENT_TEXT>

<INSTRUCTION>
Now extract all fields from the document text above.
Return ONLY a single valid JSON object — no markdown, no explanation, no extra text.
</INSTRUCTION>"""


def build_prompts_for_all_docs(
    context_map: Dict[str, str],
    schema: Type[BaseModel],
    max_context_chars: int = 30000,
) -> Dict[str, str]:
    """
    Build one prompt per document.

    Args:
        context_map: {doc_id: compiled_parent_text}
        schema: Pydantic model defining the fields to extract.

    Returns:
        {doc_id: full_prompt_string}
    """
    return {
        doc_id: build_extraction_prompt(ctx, schema, max_context_chars)
        for doc_id, ctx in context_map.items()
    }
