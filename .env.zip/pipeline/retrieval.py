import time
from typing import Optional, List, Dict, Any, Type
import numpy as np
from pydantic import BaseModel
from elasticsearch import Elasticsearch
from sentence_transformers import SentenceTransformer

from pipeline.embedding import encode_query


def _parse_hits(hits, doc_id: str) -> List[Dict[str, Any]]:
    """Convert ES hits into chunk dicts."""
    chunks = []
    for hit in hits:
        src = hit["_source"]
        chunk = {
            "chunk_id": src.get("chunk_id", hit["_id"]),
            "doc_id": src.get("doc_id", doc_id),
            "chunk_index": src.get("chunk_index", 0),
            "text": src.get("text", ""),
            "file_name": src.get("file_name", ""),
        }
        if "parent_id" in src:
            chunk["parent_id"] = src["parent_id"]
        chunks.append(chunk)
    return chunks


def es_hybrid_search_chunks(
    es_client: Elasticsearch,
    index_name: str,
    doc_id: str,
    query_text: str,
    query_embedding: np.ndarray,
    top_k: int,
    rrf_k: int = 60,
    chunking_mode: str = "parent_child",
) -> List[Dict[str, Any]]:
    """Hybrid search (BM25 + KNN) with RRF fusion in Python."""
    fetch_k = max(top_k * 2, 20)
    source_fields = ["chunk_id", "doc_id", "chunk_index", "text", "file_name", "parent_id"]
    doc_filter = [{"term": {"doc_id": doc_id}}]
    if chunking_mode == "parent_child":
        doc_filter.append({"term": {"chunk_type": "child"}})

    bm25_result = es_client.search(
        index=index_name,
        body={
            "query": {"bool": {"must": doc_filter + [{"match": {"text": {"query": query_text}}}]}},
            "size": fetch_k,
            "_source": source_fields,
        },
    )
    knn_result = es_client.search(
        index=index_name,
        body={
            "knn": {
                "field": "embedding",
                "query_vector": query_embedding.tolist(),
                "k": fetch_k,
                "num_candidates": min(100, fetch_k * 4),
                "filter": {"bool": {"must": doc_filter}},
            },
            "size": fetch_k,
            "_source": source_fields,
        },
    )

    bm25_chunks = _parse_hits(bm25_result["hits"]["hits"], doc_id)
    knn_chunks = _parse_hits(knn_result["hits"]["hits"], doc_id)

    chunk_by_id: Dict[str, Dict[str, Any]] = {}
    rrf_scores: Dict[str, float] = {}
    for ranked_list in [bm25_chunks, knn_chunks]:
        for rank_1, c in enumerate(ranked_list, start=1):
            cid = c["chunk_id"]
            rrf_scores[cid] = rrf_scores.get(cid, 0.0) + 1.0 / (rrf_k + rank_1)
            chunk_by_id[cid] = c

    sorted_ids = sorted(rrf_scores, key=rrf_scores.get, reverse=True)
    return [chunk_by_id[cid] for cid in sorted_ids[:top_k]]


def _get_field_queries(schema: Type[BaseModel], field_name: str) -> tuple:
    """Build retrieval queries from the schema: (description, keywords, all_queries)."""
    field_info = schema.model_fields.get(field_name)
    desc = field_info.description if field_info and field_info.description else field_name.replace("_", " ")
    extra = (field_info.json_schema_extra or {}) if field_info else {}
    keywords = extra.get("keywords", [])
    return desc, keywords, [desc] + keywords


def retrieve_chunks_for_field(
    es_client: Elasticsearch,
    index_name: str,
    doc_id: str,
    field_name: str,
    embedding_model: SentenceTransformer,
    schema: Type[BaseModel],
    top_k: int = 5,
    chunking_mode: str = "parent_child",
    rrf_k: int = 60,
) -> List[Dict[str, Any]]:
    """Retrieve top-k chunks for a single field using hybrid search + RRF."""
    _, _, queries = _get_field_queries(schema, field_name)

    rrf_scores: Dict[str, float] = {}
    chunk_by_id: Dict[str, Dict[str, Any]] = {}
    for query in queries:
        query_emb = encode_query(embedding_model, query)
        ranked = es_hybrid_search_chunks(
            es_client, index_name, doc_id, query, query_emb,
            top_k=max(top_k * 2, 20), rrf_k=rrf_k, chunking_mode=chunking_mode,
        )
        for rank_1based, c in enumerate(ranked, start=1):
            cid = c["chunk_id"]
            rrf_scores[cid] = rrf_scores.get(cid, 0.0) + 1.0 / (rrf_k + rank_1based)
            chunk_by_id[cid] = c

    sorted_cids = sorted(rrf_scores, key=rrf_scores.get, reverse=True)
    return [chunk_by_id[cid] for cid in sorted_cids[:top_k]]


def mmr_rerank(
    chunks: List[Dict[str, Any]],
    relevance_scores: Dict[str, float],
    embedding_model: SentenceTransformer,
    lambda_param: float = 0.7,
    top_k: Optional[int] = None,
) -> List[Dict[str, Any]]:
    """Maximal Marginal Relevance re-ranking for diversity."""
    if not chunks:
        return []
    if top_k is None:
        top_k = len(chunks)

    texts = [c["text"] for c in chunks]
    embeddings = embedding_model.encode(texts, normalize_embeddings=True)
    sim_matrix = embeddings @ embeddings.T

    selected_idxs: List[int] = []
    remaining = set(range(len(chunks)))

    for _ in range(min(top_k, len(chunks))):
        best_idx, best_score = -1, -float("inf")
        for idx in remaining:
            rel = relevance_scores.get(chunks[idx]["chunk_id"], 0.0)
            max_sim = max((sim_matrix[idx][j] for j in selected_idxs), default=0.0)
            score = lambda_param * rel - (1 - lambda_param) * max_sim
            if score > best_score:
                best_score, best_idx = score, idx
        selected_idxs.append(best_idx)
        remaining.discard(best_idx)

    return [chunks[i] for i in selected_idxs]


def retrieve_all_fields_chunks(
    es_client: Elasticsearch,
    index_name: str,
    doc_id: str,
    schema: Type[BaseModel],
    embedding_model: SentenceTransformer,
    top_k_per_field: int = 5,
    chunking_mode: str = "parent_child",
    use_mmr: bool = False,
    mmr_lambda: float = 0.7,
    rrf_k: int = 60,
) -> tuple:
    """
    For each metadata field, retrieve top-k chunks. Deduplicate across all fields.
    Returns (unique_chunks_list, elapsed_seconds).
    """
    field_names = list(schema.model_fields.keys())
    chunk_by_id: Dict[str, Dict[str, Any]] = {}
    chunk_hit_count: Dict[str, int] = {}

    t0 = time.time()
    for field_name in field_names:
        retrieved = retrieve_chunks_for_field(
            es_client, index_name, doc_id, field_name,
            embedding_model, schema, top_k_per_field, chunking_mode, rrf_k,
        )
        for c in retrieved:
            cid = c["chunk_id"]
            chunk_by_id[cid] = c
            chunk_hit_count[cid] = chunk_hit_count.get(cid, 0) + 1

    if not chunk_by_id:
        return [], time.time() - t0

    if use_mmr:
        max_hits = max(chunk_hit_count.values())
        relevance = {cid: count / max_hits for cid, count in chunk_hit_count.items()}
        result = mmr_rerank(
            list(chunk_by_id.values()), relevance,
            embedding_model, lambda_param=mmr_lambda,
        )
    else:
        sorted_cids = sorted(chunk_hit_count, key=chunk_hit_count.get, reverse=True)
        result = [chunk_by_id[cid] for cid in sorted_cids]

    elapsed = time.time() - t0
    return result, elapsed


def fetch_chunks_for_doc(
    es_client: Elasticsearch,
    index_name: str,
    doc_id: str,
    chunking_mode: str = "flat",
    include_embedding: bool = True,
) -> List[Dict[str, Any]]:
    """Fetch chunks for a document from ES."""
    if chunking_mode == "parent_child":
        query = {"bool": {"must": [{"term": {"doc_id": doc_id}}, {"term": {"chunk_type": "child"}}]}}
    else:
        query = {"term": {"doc_id": doc_id}}

    source = ["chunk_id", "doc_id", "chunk_index", "text", "file_name"]
    if chunking_mode == "parent_child":
        source.append("parent_id")
    if include_embedding:
        source.append("embedding")

    result = es_client.search(
        index=index_name,
        body={"query": query, "sort": [{"chunk_index": "asc"}], "size": 1000, "_source": source},
    )

    chunks = []
    for hit in result["hits"]["hits"]:
        src = hit["_source"]
        chunk = {
            "chunk_id": src.get("chunk_id", hit["_id"]),
            "doc_id": src.get("doc_id", doc_id),
            "chunk_index": src.get("chunk_index", 0),
            "text": src.get("text", ""),
            "file_name": src.get("file_name", ""),
        }
        if "parent_id" in src:
            chunk["parent_id"] = src["parent_id"]
        if "embedding" in src:
            chunk["embedding"] = src["embedding"]
        chunks.append(chunk)
    return chunks


def fetch_parent_chunks_for_doc(
    es_client: Elasticsearch,
    index_name: str,
    doc_id: str,
) -> List[Dict[str, Any]]:
    """Fetch parent chunks for a document."""
    result = es_client.search(
        index=index_name,
        body={
            "query": {"bool": {"must": [{"term": {"doc_id": doc_id}}, {"term": {"chunk_type": "parent"}}]}},
            "sort": [{"chunk_index": "asc"}],
            "size": 1000,
            "_source": ["chunk_id", "text"],
        },
    )
    return [{"chunk_id": h["_source"]["chunk_id"], "text": h["_source"].get("text", "")} for h in result["hits"]["hits"]]


def fetch_parent_texts(
    es_client: Elasticsearch,
    index_name: str,
    parent_ids: List[str],
) -> Dict[str, str]:
    """Fetch parent chunk texts by their IDs."""
    if not parent_ids:
        return {}
    result = es_client.search(
        index=index_name,
        body={
            "query": {"ids": {"values": parent_ids}},
            "size": len(parent_ids),
            "_source": ["chunk_id", "text"],
        },
    )
    return {h["_source"]["chunk_id"]: h["_source"].get("text", "") for h in result["hits"]["hits"]}
