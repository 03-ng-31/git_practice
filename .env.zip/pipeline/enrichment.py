from typing import List, Dict, Any, Type, Optional
from pydantic import BaseModel
from elasticsearch import Elasticsearch, helpers
from sentence_transformers import SentenceTransformer

from pipeline.config import EnrichmentConfig, LLMConfig
from pipeline.retrieval import (
    retrieve_all_fields_chunks,
    fetch_parent_texts,
    fetch_chunks_for_doc,
)
from pipeline.llm_extraction import extract_all_fields
from pipeline.es_indexing import get_unique_doc_ids


def merge_extractions(
    extractions: List[Dict[str, Any]],
    strategy: str = "first_non_null",
) -> Dict[str, Any]:
    """Merge multiple section-level extractions into one doc-level dict."""
    if not extractions:
        return {}
    all_fields = {k for ext in extractions for k in ext}
    merged = {}
    for field in all_fields:
        values = [ext[field] for ext in extractions if ext.get(field) is not None]
        if not values:
            merged[field] = None
        elif strategy == "last_non_null":
            merged[field] = values[-1]
        elif strategy == "most_common":
            merged[field] = max(set(values), key=values.count)
        else:
            merged[field] = values[0]
    return merged


def assemble_context(
    all_chunks: List[Dict[str, Any]],
    es_client: Elasticsearch,
    index_name: str,
    chunking_mode: str = "parent_child",
) -> str:
    """Assemble context text from retrieved chunks, resolving parent texts if needed."""
    if not all_chunks:
        return ""

    if chunking_mode == "parent_child":
        parent_ids = list({c["parent_id"] for c in all_chunks if c.get("parent_id")})
        parent_text_map = fetch_parent_texts(es_client, index_name, parent_ids)
        context_parts = [parent_text_map[pid] for pid in parent_ids if pid in parent_text_map]
        return "\n\n".join(context_parts) if context_parts else "\n\n".join(c["text"] for c in all_chunks)
    else:
        return "\n\n".join(c["text"] for c in all_chunks)


def enrich_document_retrieval_augmented(
    es_client: Elasticsearch,
    index_name: str,
    doc_id: str,
    config: EnrichmentConfig,
    embedding_model: SentenceTransformer,
    llm_config: LLMConfig = None,
) -> Dict[str, Any]:
    """
    ES-first batch enrichment:
      1. For each field -> ES hybrid search -> top-k chunks
      2. Deduplicate chunks across all fields
      3. If parent_child -> fetch parent texts
      4. ONE LLM call with full schema -> extract all fields
    """
    all_chunks, elapsed = retrieve_all_fields_chunks(
        es_client, index_name, doc_id,
        schema=config.metadata_schema,
        embedding_model=embedding_model,
        top_k_per_field=config.top_k_per_field,
        chunking_mode=config.chunking_mode,
        use_mmr=config.use_mmr,
        mmr_lambda=config.mmr_lambda,
        rrf_k=config.rrf_k,
    )
    if not all_chunks:
        return {f: None for f in config.metadata_schema.model_fields}

    context = assemble_context(all_chunks, es_client, index_name, config.chunking_mode)
    if not context.strip():
        return {f: None for f in config.metadata_schema.model_fields}

    return extract_all_fields(
        context,
        config.metadata_schema,
        llm_config=llm_config,
    )


def _get_all_chunk_ids(es_client: Elasticsearch, index_name: str, doc_id: str) -> List[str]:
    """Get all chunk_ids for a doc (parents + children)."""
    result = es_client.search(
        index=index_name,
        body={"query": {"term": {"doc_id": doc_id}}, "size": 10000, "_source": ["chunk_id"]},
    )
    return [h["_source"]["chunk_id"] for h in result["hits"]["hits"]]


def run_enrichment_pipeline(
    es_client: Elasticsearch,
    index_name: str,
    config: EnrichmentConfig,
    embedding_model: SentenceTransformer,
    llm_config: LLMConfig = None,
    overwrite: bool = False,
    progress_callback=None,
) -> List[Dict[str, Any]]:
    """
    Enrich all documents: per-field ES hybrid search -> LLM extract -> bulk-update ES.
    Returns list of {doc_id, metadata} dicts.
    """
    doc_ids = get_unique_doc_ids(es_client, index_name)
    results = []

    for i, doc_id in enumerate(doc_ids):
        if progress_callback:
            progress_callback(i, len(doc_ids), f"Enriching doc {doc_id[:16]}...")

        doc_metadata = enrich_document_retrieval_augmented(
            es_client, index_name, doc_id, config, embedding_model,
            llm_config=llm_config,
        )

        chunk_ids = _get_all_chunk_ids(es_client, index_name, doc_id)
        actions = [
            {"_op_type": "update", "_index": index_name, "_id": cid, "doc": {"metadata": doc_metadata}}
            for cid in chunk_ids
        ]
        if actions:
            helpers.bulk(es_client, actions, raise_on_error=False)

        results.append({"doc_id": doc_id, "metadata": doc_metadata})

    es_client.indices.refresh(index=index_name)
    return results
