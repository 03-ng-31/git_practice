import urllib.request
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional


def download_pdf(url: str, dest: Path) -> bool:
    """Download PDF from URL to dest path. Returns True on success."""
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; rv:91.0) Gecko/20100101 Firefox/91.0"},
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            dest.write_bytes(resp.read())
        return True
    except Exception as e:
        print(f"Download failed {url}: {e}")
        return False


def _load_pdf_with_pymupdf(path: Path) -> str:
    """Fallback: extract text with PyMuPDF when Docling fails."""
    try:
        import fitz
        doc = fitz.open(path)
        text = "".join(page.get_text() for page in doc)
        doc.close()
        return text or ""
    except Exception:
        return ""


def load_pdf_with_docling(path: Path, use_fallback_on_error: bool = True) -> Dict[str, Any]:
    """Convert a single PDF to text using Docling, with PyMuPDF fallback."""
    try:
        from docling.document_converter import DocumentConverter
        converter = DocumentConverter()
        result = converter.convert(str(path))
        doc = result.document
        full_text = doc.export_to_markdown() if hasattr(doc, "export_to_markdown") else str(doc)
        if not full_text or not full_text.strip():
            full_text = ""
    except Exception as e:
        full_text = ""
        if use_fallback_on_error:
            full_text = _load_pdf_with_pymupdf(path)
            if not full_text:
                print(f"  [Fallback] {path.name}: Docling failed ({e}), PyMuPDF returned no text.")
            else:
                print(f"  [Fallback] {path.name}: Docling failed ({e}), used PyMuPDF ({len(full_text)} chars).")
        else:
            raise

    try:
        mtime = path.stat().st_mtime
        upload_date = datetime.fromtimestamp(mtime).strftime("%Y-%m-%d")
    except Exception:
        upload_date = datetime.utcnow().strftime("%Y-%m-%d")

    title = path.stem.replace("_", " ").replace("-", " ")
    return {
        "file_name": path.name,
        "title": title,
        "upload_date": upload_date,
        "full_text": full_text if full_text else "",
    }


def download_and_load_pdfs(
    urls: List[str],
    data_dir: str = "./data/downloads",
    progress_callback=None,
) -> List[Dict[str, Any]]:
    """
    Download PDFs from URLs, extract text, return list of document dicts.
    Each dict has: file_name, title, upload_date, full_text, source_url.
    progress_callback(current, total, message) is called for UI updates.
    """
    dest = Path(data_dir).resolve()
    dest.mkdir(parents=True, exist_ok=True)

    documents: List[Dict[str, Any]] = []
    total = len(urls)

    for i, url in enumerate(urls):
        url = url.strip()
        if not url:
            continue

        name = url.rstrip("/").split("/")[-1] or f"downloaded_{i}.pdf"
        if not name.lower().endswith(".pdf"):
            name = f"downloaded_{i}.pdf"

        pdf_path = dest / name

        if progress_callback:
            progress_callback(i, total, f"Downloading: {name}")

        if not pdf_path.exists():
            success = download_pdf(url, pdf_path)
            if not success:
                if progress_callback:
                    progress_callback(i, total, f"Failed to download: {name}")
                continue

        if progress_callback:
            progress_callback(i, total, f"Extracting text: {name}")

        try:
            doc = load_pdf_with_docling(pdf_path)
            doc["source_url"] = url
            documents.append(doc)
        except Exception as e:
            print(f"Skip {pdf_path}: {e}")

    if progress_callback:
        progress_callback(total, total, "Done")

    return documents
