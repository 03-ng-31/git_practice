from typing import List, Dict, Any
import numpy as np
from sentence_transformers import SentenceTransformer


def embed_child_chunks(
    documents: List[Dict[str, Any]],
    model: SentenceTransformer,
    batch_size: int = 64,
) -> int:
    """Encode child chunk texts and attach embeddings in place. Returns count of embedded chunks."""
    all_children = [c for doc in documents for c in doc.get("child_chunks", [])]
    if not all_children:
        return 0
    texts = [c["text"] for c in all_children]
    embs = model.encode(texts, batch_size=batch_size, normalize_embeddings=True, show_progress_bar=True)
    for child, emb in zip(all_children, embs):
        child["embedding"] = emb.tolist()
    return len(all_children)


def encode_query(embedding_model: SentenceTransformer, query: str) -> np.ndarray:
    """Encode a single query string for retrieval."""
    try:
        return embedding_model.encode(query, normalize_embeddings=True, prompt_name="query")
    except TypeError:
        return embedding_model.encode(query, normalize_embeddings=True)
