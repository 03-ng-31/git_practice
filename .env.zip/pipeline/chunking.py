import hashlib
from typing import Optional, List, Dict, Any, Type
from pydantic import BaseModel


GENERIC_METADATA_KEYS = ["document_type", "source_file"]


def deterministic_id(content: str, prefix: str = "") -> str:
    h = hashlib.sha256(content.encode("utf-8")).hexdigest()[:16]
    return (prefix + h) if prefix else h


def split_text(text: str, chunk_size: int, overlap: int) -> List[str]:
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        chunks.append(text[start:end])
        start += chunk_size - overlap
    return chunks


def get_initial_metadata(metadata_schema: Optional[Type[BaseModel]] = None) -> Dict[str, Any]:
    """Build initial metadata dict (all None). Schema-driven when provided; else generic keys."""
    if metadata_schema is not None:
        return {k: None for k in metadata_schema.model_fields.keys()}
    return {k: None for k in GENERIC_METADATA_KEYS}


def create_parent_child_chunks(
    document: Dict[str, Any],
    metadata_schema: Optional[Type[BaseModel]] = None,
    parent_chunk_size: int = 2000,
    parent_chunk_overlap: int = 200,
    child_chunk_size: int = 512,
    child_chunk_overlap: int = 50,
) -> Dict[str, Any]:
    """Produce parent and child chunks; each chunk gets initial metadata (all None)."""
    full_text = document["full_text"] or ""
    file_name = document["file_name"]
    doc_id = deterministic_id(file_name, prefix="doc_")
    initial_metadata = get_initial_metadata(metadata_schema)

    parent_texts = split_text(full_text, parent_chunk_size, parent_chunk_overlap)
    parent_chunks = []
    child_chunks = []

    for p_idx, p_text in enumerate(parent_texts):
        parent_id = deterministic_id(f"{doc_id}_{p_idx}", prefix="parent_")
        parent_chunks.append({
            "chunk_id": parent_id,
            "doc_id": doc_id,
            "chunk_type": "parent",
            "chunk_index": p_idx,
            "text": p_text,
            "file_name": file_name,
            "title": document.get("title", file_name),
            "upload_date": document.get("upload_date", ""),
            "metadata": dict(initial_metadata),
        })

        child_texts = split_text(p_text, child_chunk_size, child_chunk_overlap)
        for c_idx, c_text in enumerate(child_texts):
            child_id = deterministic_id(f"{parent_id}_{c_idx}", prefix="child_")
            child_chunks.append({
                "chunk_id": child_id,
                "parent_id": parent_id,
                "doc_id": doc_id,
                "chunk_type": "child",
                "chunk_index": c_idx,
                "text": c_text,
                "file_name": file_name,
                "title": document.get("title", file_name),
                "upload_date": document.get("upload_date", ""),
                "metadata": dict(initial_metadata),
            })

    document["doc_id"] = doc_id
    document["parent_chunks"] = parent_chunks
    document["child_chunks"] = child_chunks
    return document
