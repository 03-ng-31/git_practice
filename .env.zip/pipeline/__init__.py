# Lazy package — heavy dependencies (sentence_transformers, etc.) are only
# imported when individual submodules are accessed, not at package import time.
