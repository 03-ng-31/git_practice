from typing import List, Dict, Any, Type
from pydantic import BaseModel
from elasticsearch import Elasticsearch, helpers


def build_metadata_mapping(schema: Type[BaseModel]) -> Dict[str, Any]:
    """Derive ES field mappings from Pydantic metadata schema."""
    type_map = {
        "string": {"type": "keyword"},
        "integer": {"type": "integer"},
        "number": {"type": "float"},
        "boolean": {"type": "boolean"},
    }
    json_schema = schema.model_json_schema()
    properties = {}
    for field_name, field_def in json_schema.get("properties", {}).items():
        if "anyOf" in field_def:
            for option in field_def["anyOf"]:
                if option.get("type") != "null":
                    properties[field_name] = type_map.get(option["type"], {"type": "keyword"})
                    break
        else:
            properties[field_name] = type_map.get(field_def.get("type", "string"), {"type": "keyword"})
    return properties


def create_es_index(
    es_client: Elasticsearch,
    index_name: str,
    schema: Type[BaseModel],
    embedding_dim: int = 768,
) -> List[str]:
    """Create ES index with dense_vector and metadata mappings. Returns list of metadata field names."""
    metadata_fields = build_metadata_mapping(schema)
    mapping = {
        "settings": {"number_of_shards": 1, "number_of_replicas": 0},
        "mappings": {
            "properties": {
                "chunk_id": {"type": "keyword"},
                "parent_id": {"type": "keyword"},
                "doc_id": {"type": "keyword"},
                "chunk_type": {"type": "keyword"},
                "chunk_index": {"type": "integer"},
                "text": {"type": "text", "analyzer": "standard"},
                "file_name": {"type": "keyword"},
                "title": {"type": "text", "fields": {"raw": {"type": "keyword"}}},
                "upload_date": {"type": "date"},
                "embedding": {
                    "type": "dense_vector",
                    "dims": embedding_dim,
                    "index": True,
                    "similarity": "cosine",
                },
                "metadata": {"type": "object", "properties": metadata_fields},
            }
        },
    }
    if es_client.indices.exists(index=index_name):
        es_client.indices.delete(index=index_name)
    es_client.indices.create(index=index_name, body=mapping)
    return list(metadata_fields.keys())


def _chunk_to_source(chunk: Dict[str, Any]) -> Dict[str, Any]:
    """Build an ES _source dict from a chunk."""
    src = {
        "chunk_id": chunk["chunk_id"],
        "doc_id": chunk["doc_id"],
        "chunk_type": chunk["chunk_type"],
        "chunk_index": chunk["chunk_index"],
        "text": chunk["text"],
        "file_name": chunk["file_name"],
        "title": chunk.get("title", ""),
        "upload_date": chunk.get("upload_date"),
        "metadata": chunk.get("metadata", {}),
    }
    if "parent_id" in chunk:
        src["parent_id"] = chunk["parent_id"]
    if "embedding" in chunk:
        src["embedding"] = chunk["embedding"]
    return src


def index_documents(
    es_client: Elasticsearch,
    documents: List[Dict[str, Any]],
    index_name: str,
) -> Dict[str, int]:
    """Bulk-index parent and child chunks. Returns counts dict."""
    actions = []
    for doc in documents:
        for chunk in doc.get("parent_chunks", []) + doc.get("child_chunks", []):
            actions.append({
                "_index": index_name,
                "_id": chunk["chunk_id"],
                "_source": _chunk_to_source(chunk),
            })
    if actions:
        helpers.bulk(es_client, actions, raise_on_error=False)
        es_client.indices.refresh(index=index_name)

    n_parents = sum(len(d.get("parent_chunks", [])) for d in documents)
    n_children = sum(len(d.get("child_chunks", [])) for d in documents)
    return {"total": len(actions), "parents": n_parents, "children": n_children}


def get_unique_doc_ids(es_client: Elasticsearch, index_name: str) -> List[str]:
    result = es_client.search(
        index=index_name,
        body={"size": 0, "aggs": {"doc_ids": {"terms": {"field": "doc_id", "size": 10000}}}},
    )
    return [b["key"] for b in result["aggregations"]["doc_ids"]["buckets"]]
