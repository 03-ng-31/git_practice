"""
MCP Vector DB Server - Exposes Elasticsearch (lease_documents) as MCP tools.

Run with: python mcp_vector_db_server.py
Or: uv run --with mcp mcp_vector_db_server.py

Connect via MCP Inspector: npx -y @modelcontextprotocol/inspector
URL: http://localhost:8000/mcp
"""

import os
import json
from typing import Optional, List, Dict, Any

from mcp.server.fastmcp import FastMCP
from elasticsearch import Elasticsearch
from sentence_transformers import SentenceTransformer

# ── Configuration ─────────────────────────────────────────────────────────────
ES_HOST = os.getenv("ES_HOST", "http://localhost:9200")
ES_INDEX = os.getenv("ES_INDEX", "lease_documents")
ES_USER = os.getenv("ES_USER", "elastic")
ES_PASSWORD = os.getenv("ES_PASSWORD", "changeme")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "BAAI/bge-small-en-v1.5")
EMBEDDING_DIM = 384
TOP_K = 5
RRF_RANK_CONSTANT = 60
RRF_WINDOW_SIZE = 50

# ── Initialize MCP Server ────────────────────────────────────────────────────
mcp = FastMCP(
    "RAG Metadata Vector DB",
    json_response=True,
)

# Lazy-initialized clients (set on first tool call)
_es: Optional[Elasticsearch] = None
_embed_model: Optional[SentenceTransformer] = None


def _get_es() -> Elasticsearch:
    global _es
    if _es is None:
        kwargs: Dict[str, Any] = {"hosts": [ES_HOST], "verify_certs": False}
        if ES_USER and ES_PASSWORD:
            kwargs["basic_auth"] = (ES_USER, ES_PASSWORD)
        _es = Elasticsearch(**kwargs)
    return _es


def _get_embed_model() -> SentenceTransformer:
    global _embed_model
    if _embed_model is None:
        _embed_model = SentenceTransformer(EMBEDDING_MODEL)
    return _embed_model


def _embed_query(query: str) -> List[float]:
    return _get_embed_model().encode(query, normalize_embeddings=True).tolist()


# ── MCP Tools ────────────────────────────────────────────────────────────────

@mcp.tool()
def search_vector_db(
    query: str,
    top_k: int = 5,
    metadata_filters: Optional[Dict[str, str]] = None,
) -> str:
    """
    Semantic search over the lease document vector database.
    Uses hybrid RRF (BM25 + KNN) for best retrieval quality.

    Args:
        query: Natural language search query (e.g., "escalation clause", "monthly rent").
        top_k: Number of chunks to return (default 5).
        metadata_filters: Optional dict of metadata filters, e.g. {"owner_name": "John Smith", "document_type": "lease"}.

    Returns:
        JSON string with retrieved chunks (text, file_name, metadata).
    """
    es = _get_es()
    query_vector = _embed_query(query)

    base_filter = [{"term": {"chunk_type": "child"}}]
    if metadata_filters:
        for field, value in metadata_filters.items():
            if value:
                base_filter.append({"wildcard": {f"metadata.{field}": {"value": f"*{str(value).lower()}*", "case_insensitive": True}}})

    filter_clause = {"bool": {"must": base_filter}}

    search_body = {
        "size": min(top_k, 20),
        "retriever": {
            "rrf": {
                "retrievers": [
                    {
                        "standard": {
                            "query": {
                                "bool": {
                                    "must": {"match": {"text": query}},
                                    "filter": filter_clause,
                                }
                            }
                        }
                    },
                    {
                        "knn": {
                            "field": "embedding",
                            "query_vector": query_vector,
                            "k": RRF_WINDOW_SIZE,
                            "num_candidates": RRF_WINDOW_SIZE * 2,
                            "filter": filter_clause,
                        }
                    },
                ],
                "rank_constant": RRF_RANK_CONSTANT,
                "rank_window_size": RRF_WINDOW_SIZE,
            }
        },
        "_source": {"excludes": ["embedding"]},
    }

    result = es.search(index=ES_INDEX, body=search_body)
    hits = result["hits"]["hits"]

    out = []
    for h in hits:
        src = h["_source"]
        out.append({
            "chunk_id": src.get("chunk_id", h["_id"]),
            "text": src.get("text", ""),
            "file_name": src.get("file_name", "unknown"),
            "metadata": src.get("metadata", {}),
        })
    return json.dumps({"query": query, "num_results": len(out), "results": out}, indent=2)


@mcp.tool()
def get_metadata_fields() -> str:
    """
    List available metadata fields in the vector database index.
    Use this to know which fields can be used in metadata_filters for search_vector_db.

    Returns:
        JSON with field names and their Elasticsearch types.
    """
    es = _get_es()
    mapping = es.indices.get_mapping(index=ES_INDEX)
    props = mapping[ES_INDEX]["mappings"]["properties"]
    meta_props = props.get("metadata", {}).get("properties", {})
    fields = {name: info.get("type", "keyword") for name, info in meta_props.items()}
    return json.dumps({"index": ES_INDEX, "metadata_fields": fields}, indent=2)


@mcp.tool()
def search_by_metadata(metadata_filters: Dict[str, str], top_k: int = 10) -> str:
    """
    Retrieve documents by metadata filters only (no semantic search).
    Useful when you know exact metadata values (e.g., owner_name, document_type).

    Args:
        metadata_filters: Dict of field -> value, e.g. {"document_type": "amendment", "owner_name": "John"}.
        top_k: Max number of chunks to return.

    Returns:
        JSON with matching chunks.
    """
    es = _get_es()
    must = [{"term": {"chunk_type": "child"}}]
    for field, value in metadata_filters.items():
        if value:
            must.append({"wildcard": {f"metadata.{field}": {"value": f"*{str(value).lower()}*", "case_insensitive": True}}})

    search_body = {
        "size": min(top_k, 50),
        "query": {"bool": {"must": must}},
        "_source": {"excludes": ["embedding"]},
    }

    result = es.search(index=ES_INDEX, body=search_body)
    hits = result["hits"]["hits"]

    out = []
    for h in hits:
        src = h["_source"]
        out.append({
            "chunk_id": src.get("chunk_id", h["_id"]),
            "text": src.get("text", ""),
            "file_name": src.get("file_name", "unknown"),
            "metadata": src.get("metadata", {}),
        })
    return json.dumps({"filters": metadata_filters, "num_results": len(out), "results": out}, indent=2)


@mcp.tool()
def get_index_stats() -> str:
    """
    Get basic statistics about the vector database index (document count, etc.).

    Returns:
        JSON with index stats.
    """
    es = _get_es()
    count = es.count(index=ES_INDEX)
    return json.dumps({
        "index": ES_INDEX,
        "total_documents": count["count"],
    }, indent=2)


if __name__ == "__main__":
    import sys
    # Use stdio for Cursor/MCP clients; use streamable-http for MCP Inspector
    transport = "streamable-http" if "--http" in sys.argv else "stdio"
    mcp.run(transport=transport)
