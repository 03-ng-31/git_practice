# RAG Metadata Pipeline — Production

Production-grade metadata-aware RAG for lease and amendment documents.

## Quick Start

### With Docker Compose

```bash
# Set your Gemini API key
export GEMINI_API_KEY=your_key_here

# Start Elasticsearch + API
docker-compose up -d

# API at http://localhost:8000
# Docs at http://localhost:8000/docs
```

### Local Development

```bash
# Install
pip install -e .

# Start Elasticsearch (or use docker-compose up elasticsearch -d)
# Set GEMINI_API_KEY in .env

# Run API
uvicorn rag_metadata.api.main:app --reload --port 8000
```

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Health check (ES + embedding model) |
| `/upload` | POST | Upload PDF for ingest + enrichment |
| `/ingest` | POST | Alias for `/upload` |
| `/query` | POST | Natural language RAG query |
| `/enrich` | POST | Run metadata enrichment on all docs |

### Example: Upload PDF

```bash
curl -X POST -F "file=@lease.pdf" http://localhost:8000/upload
```

### Example: Query

```bash
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"query": "What is the escalation clause?"}'
```

## Configuration

Environment variables (see `.env.example`):

- `GEMINI_API_KEY` — Required for LLM extraction and RAG
- `RAG_ES_HOST` — Elasticsearch URL (default: http://localhost:9200)
- `RAG_ES_INDEX` — Index name (default: lease_documents)
- `RAG_ES_USER` / `RAG_ES_PASSWORD` — ES credentials

## Architecture

1. **Ingest**: PDF → parse → chunk (parent-child or flat) → embed → index to ES
2. **Enrichment**: Per-field retrieval-augmented extraction → bulk update metadata
3. **Retrieval**: Query → document selector → metadata extractor → RRF hybrid search → parent expansion → RAG generation
