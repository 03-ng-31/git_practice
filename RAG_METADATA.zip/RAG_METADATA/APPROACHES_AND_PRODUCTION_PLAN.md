# RAG Metadata Pipeline — Approaches & Production Execution Plan

Complete outline of approaches from the notebooks and plan for production-grade execution.

---

## Table of Contents

1. [Notebook 1: Metadata Enrichment Pipeline v2](#1-notebook-1-metadata-enrichment-pipeline-v2)
2. [Notebook 2: Metadata Retrieval Pipeline](#2-notebook-2-metadata-retrieval-pipeline)
3. [Notebook 3: Embedding, Chunking & Retrieval Tuning](#3-notebook-3-embedding-chunking--retrieval-tuning)
4. [Production Execution Plan](#4-production-execution-plan)

---

## 1. Notebook 1: Metadata Enrichment Pipeline v2

### 1.1 Overview

Generic, retrieval-augmented metadata enrichment. Architecture changes from v1:

- **Chunking**: Flat or parent-child
- **Extraction**: Retrieval-augmented (primary) or section-based (fallback)
- **Context window**: Only retrieved chunks/sections sent to LLM — never exceeded
- **Per-chunk metadata**: Retrieved chunks get value; others get explicit `null`
- **Generic**: Schema-agnostic via config

### 1.2 Configuration

**EnrichmentConfig** (dataclass):

| Field | Type | Description |
|-------|------|-------------|
| `metadata_schema` | `Type[BaseModel]` | Pydantic schema for metadata fields |
| `field_retrieval_queries` | `Dict[str, List[str]]` | Field name → list of search queries for in-doc retrieval |
| `extraction_strategy` | `"retrieval_augmented"` \| `"section_based"` \| `"hybrid"` | Primary extraction mode |
| `context_limit_tokens` | `int` | Max tokens for LLM context (default: 8000) |
| `chars_per_token` | `float` | Chars per token estimate (default: 4.0) |
| `safety_margin` | `float` | Safety margin for context (default: 0.7) |
| `chunks_per_section` | `Optional[int]` | Chunks per section for section-based fallback |
| `merge_strategy` | `"first_non_null"` \| `"last_non_null"` \| `"most_common"` | How to merge multi-section extractions |
| `chunking_mode` | `"flat"` \| `"parent_child"` | Chunk structure |
| `top_k_per_field` | `int` | Top-k chunks retrieved per metadata field (default: 5) |

### 1.3 Metadata Schema (Lease Example)

```python
class LeaseMetadata(BaseModel):
    owner_name: Optional[str] = Field(None, description="Name of the property owner / tenant")
    landlord: Optional[str] = Field(None, description="Name of the landlord or lessor")
    signing_date: Optional[str] = Field(None, description="Date the lease was signed (YYYY-MM-DD)")
    expiry_date: Optional[str] = Field(None, description="Lease expiration date (YYYY-MM-DD)")
    escalation_clause: Optional[str] = Field(None, description="Rent escalation terms or percentage")
    property_address: Optional[str] = Field(None, description="Full address of the leased property")
    monthly_rent: Optional[str] = Field(None, description="Monthly rent amount with currency")
    amendment_number: Optional[int] = Field(None, description="Amendment number or None for original lease")
    document_type: Optional[str] = Field(None, description="Document type: lease or amendment")
```

### 1.4 Field Retrieval Queries

Per-field semantic queries for in-doc retrieval:

| Field | Example Queries |
|-------|-----------------|
| `owner_name` | "tenant name", "lessee", "party A", "occupant", "owner" |
| `landlord` | "landlord", "lessor", "property owner", "party B" |
| `signing_date` | "signed on", "execution date", "lease date", "effective date" |
| `expiry_date` | "expiration", "lease term ends", "termination date" |
| `escalation_clause` | "rent escalation", "annual increase", "rent adjustment" |
| `property_address` | "property address", "premises", "located at" |
| `monthly_rent` | "monthly rent", "base rent", "rent amount" |
| `amendment_number` | "amendment", "first amendment", "second amendment" |
| `document_type` | "lease agreement", "amendment", "lease" |

### 1.5 Approach Flow

| Step | Action |
|------|--------|
| 1 | Fetch all chunks for a document from ES (flat or parent-child) |
| 2 | For each metadata field: run in-doc semantic search using `field_retrieval_queries` |
| 3 | Retrieve top-k chunks per field (cosine similarity on embeddings) |
| 4 | Extract single field value from retrieved chunk text via LLM (Gemini) |
| 5 | Assign value to retrieved chunks; assign `null` to non-retrieved chunks |
| 6 | Bulk-update ES with per-chunk metadata |

### 1.6 Fallback: Section-Based Extraction

When embeddings are missing or strategy is `section_based`:

- Group chunks into sections (size from `context_limit_tokens` × `chars_per_token` × `safety_margin`)
- Extract all metadata fields per section via LLM
- Merge extractions using `merge_strategy` (first_non_null, last_non_null, most_common)
- Assign merged metadata to all chunks in the document

### 1.7 Key Functions

| Function | Purpose |
|----------|---------|
| `get_unique_doc_ids()` | Get all doc IDs in index |
| `fetch_chunks_for_doc()` | Fetch chunks for a doc (flat or parent-child) |
| `in_doc_retrieve()` | Semantic search within doc chunks (cosine similarity) |
| `retrieve_chunks_for_field()` | Multi-query retrieval for a field; dedupe; top-k |
| `extract_field_from_text()` | LLM extraction of single field from text |
| `merge_extractions()` | Merge multiple extractions by strategy |
| `enrich_document_retrieval_augmented()` | Full per-field retrieval-augmented enrichment |
| `enrich_document_section_based()` | Section-based fallback enrichment |
| `run_enrichment_pipeline()` | Run enrichment for all docs; bulk ES update |

### 1.8 Dependencies

- `google-genai`, `elasticsearch`, `sentence-transformers`, `pydantic`, `tqdm`, `numpy`
- `ES_HOST`, `ES_INDEX`, `ES_USER`, `ES_PASSWORD`; `GEMINI_API_KEY`; `EMBEDDING_MODEL_NAME` (e.g. `BAAI/bge-small-en-v1.5`)

---

## 2. Notebook 2: Metadata Retrieval Pipeline

### 2.1 Overview

Metadata-aware RAG retrieval:

1. Extract metadata filters from natural language queries (Gemini)
2. Combine metadata filtering with RRF hybrid search (BM25 + KNN)
3. Expand child results to parent context
4. Generate answers with citations (Gemini)

### 2.2 Configuration

| Setting | Value | Description |
|---------|-------|-------------|
| `TOP_K` | 5 | Number of child chunks to retrieve |
| `RRF_RANK_CONSTANT` | 60 | RRF k parameter |
| `RRF_WINDOW_SIZE` | 50 | Per-retriever result window |
| `EMBEDDING_DIM` | 384 | Embedding dimension (BGE-small) |

### 2.3 Dynamic Schema Discovery

- Read ES index mapping for `metadata.*` fields
- Build `{field_name: es_type}` mapping
- Used by `QueryMetadataExtractor` to know which fields to extract and how to build ES filters

### 2.4 Query Metadata Extractor

**ExtractedFilters** (Pydantic):

- `filters`: `Dict[str, Optional[str]]` — field → extracted value
- `cleaned_query`: `str` — query with metadata parts removed

**QueryMetadataExtractor**:

- Uses Gemini LLM with structured output
- Prompt: available fields + rules (normalize dates, extract names, etc.)
- `extract(query)` → `ExtractedFilters`
- `to_es_filters(extracted)` → ES filter clauses:
  - `keyword` → wildcard (case-insensitive)
  - `integer`/`float` → term
  - others → match

**Example**:

- Query: *"What is the escalation clause in John Smith's lease signed in 2023?"*
- Filters: `{owner_name: "John Smith", signing_date: "2023", document_type: "lease"}`
- Cleaned query: *"What is the escalation clause?"*

### 2.5 Hybrid Retriever (RRF)

**HybridRetriever**:

- BM25 + KNN with optional metadata pre-filtering
- Base filter: `chunk_type == "child"`
- RRF formula: `score(d) = Σ 1/(k + rank_i(d))` across retrievers

**Methods**:

- `search_rrf(query, metadata_filters)` — BM25 + KNN with filters
- `search_bm25_only(query, metadata_filters)`
- `search_knn_only(query, metadata_filters)`

### 2.6 Parent Context Expansion

- For each child hit, fetch parent chunk via `parent_id`
- Build context list with `child_text`, `parent_text`, `file_name`, `metadata`
- Use parent text when unique; otherwise child text for LLM

### 2.7 RAG Generator

**RAGAnswer** (Pydantic):

- `answer`: `str`
- `sources`: `List[str]`
- `confidence`: `"high"` | `"medium"` | `"low"`

**RAGGenerator**:

- System prompt: answer only from context; cite sources
- Context template: `--- Context Passage [N] (Source: file_name) ---`
- Uses parent text when available for richer context

### 2.8 Full Pipeline

**MetadataAwareRAGPipeline**:

1. Extract metadata filters from query (Gemini)
2. Convert to ES filters
3. RRF hybrid search with those filters
4. Fallback: retry without filters if no hits
5. Expand to parent context
6. Generate answer with citations (Gemini)

### 2.9 Architecture

```
User Query
    │
    ├──▶ [Gemini] Extract metadata filters + cleaned query
    │
    ├──▶ [SentenceTransformers] Embed cleaned query
    │
    ├──▶ [Elasticsearch RRF]
    │       ├── BM25 (text match) ──┐
    │       ├── KNN (vector)     ───┤── RRF Fusion ──▶ Top-K child chunks
    │       └── Metadata filters ───┘
    │
    ├──▶ [ES mget] Fetch parent chunks for context expansion
    │
    └──▶ [Gemini] Generate answer with citations
```

---

## 3. Notebook 3: Embedding, Chunking & Retrieval Tuning

### 3.1 Overview

Core scenario:

> *"What changes were brought in the 3rd amendment compared to the original lease agreement?"*

Only original lease + 3rd amendment should be retrieved; naive retrieval may return 1st/2nd amendments.

### 3.2 Embedding Fine-Tuning

| Approach | Description | Effort |
|----------|-------------|--------|
| **Contrastive fine-tuning** | (query, positive_doc, negative_doc) triplets | Medium |
| **Matryoshka embeddings** | Variable-dim embeddings | Advanced |
| **In-batch negatives** | Other batch items as negatives | Lower |
| **Domain adaptation** | Continue training on lease/contract text | Medium |

**Recipe (SentenceTransformers)**:

- `InputExample(texts=[query, positive_chunk], label=1.0)`
- `InputExample(texts=[query, negative_chunk], label=0.0)`
- `CosineSimilarityLoss` or `TripletLoss`
- Train on `(query, positive, negative)` triplets

### 3.3 Chunking Strategies

| Strategy | How it works | Best for |
|----------|--------------|----------|
| **Parent-child** | Parent ~2000 chars, child ~512 chars | Hierarchy, parent expansion |
| **Semantic** | Split where embedding similarity drops | Variable-length coherent segments |
| **Recursive** | Split by `\n\n`, then `\n`, then `.` until size | Preserve paragraph/sentence structure |
| **Document-aware** | Chunk by logical sections (Rent, Term, Obligations) | Contracts with clear sections |
| **Overlap + doc boundary** | No split across doc boundaries; overlap within doc | Amendment comparison |
| **Amendment-aware** | Each amendment = separate doc; chunk within amendment only | "Changes in 3rd vs original" |

**ChunkingConfig**:

- `strategy`: "parent_child" | "recursive" | "semantic" | "document_aware"
- `chunk_size`, `overlap`, `parent_size`
- `respect_doc_boundaries`: `bool`

### 3.4 Contract Grouping

**Data model**:

```
contract_id: "LEASE-001"
  ├── Master Lease (document_type: "lease", amendment_number: null)
  ├── 1st Amendment (amendment_number: 1)
  ├── 2nd Amendment (amendment_number: 2)
  └── 3rd Amendment (amendment_number: 3)
```

**Fields per chunk**:

- `contract_id`
- `document_type`: "lease" | "amendment"
- `amendment_number`: null | 1 | 2 | 3
- `doc_id`: unique per document

### 3.5 Document Selection (LLM)

**DocumentSelector output** (JSON):

```json
{
  "include_original_lease": true/false,
  "include_amendments": [1, 2, 3] or [],
  "include_all": true/false,
  "comparison_mode": "original_vs_N" | "N_vs_M" | "all_over_time" | "find_first" | "single_doc",
  "target_amendment": null | 3 | "latest",
  "contract_id": null or "LEASE-001",
  "confidence": "high" | "medium" | "low"
}
```

**Examples**:

- "What changed in 3rd vs original?" → `include_original_lease: true`, `include_amendments: [3]`, `comparison_mode: "original_vs_N"`
- "Compare 2nd and 3rd amendment" → `include_amendments: [2,3]`, `comparison_mode: "N_vs_M"`
- "Summarize all changes over time" → `include_all: true`, `comparison_mode: "all_over_time"`
- "What changed in the latest amendment?" → `target_amendment: "latest"`, `include_original_lease: true`, `confidence: "medium"`
- "Which amendment first introduced 5% escalation?" → `include_all: true`, `comparison_mode: "find_first"`, `confidence: "low"`

### 3.6 ES Document Filter

**build_doc_filter_simple()**:

- `include_original` → `must_not exists metadata.amendment_number` (or `amendment_number: 0`)
- `amendment_numbers` → `terms` on `metadata.amendment_number`
- `contract_id` → `term` on `metadata.contract_id`

### 3.7 Fallbacks

- `target_amendment: "latest"` → resolve from ES `max(amendment_number)`
- `confidence: "low"` → `include_all: true` (retrieve from all docs)
- `include_all: true` → no document filter

### 3.8 Document-Aware Retrieval Flow

1. User query → LLM document selector
2. Apply fallbacks (latest, low confidence)
3. Build ES filter from selector output
4. RRF hybrid search with document filter + metadata filters

### 3.9 Query Decomposition

For multi-doc aggregation (e.g. "Compare rent across original, 1st, 2nd, 3rd"):

- Split into sub-queries per document
- Each sub-query filtered to one doc
- Merge chunks for LLM

### 3.10 Amendment Comparison Chunking

| Approach | Description |
|----------|-------------|
| **Doc-boundary chunking** | Never split across doc boundaries |
| **Doc ID in chunk** | Filter by `doc_id` at retrieval |
| **Section-aligned** | Chunk by section (Section 1, 2, 3...); align "Section 2" in original with "Section 2" in 3rd amendment |
| **Deduplication** | Store identical clauses once with `doc_ids: [orig, amend3]` |

### 3.11 Summary Table

| Topic | Recommendation |
|-------|----------------|
| **Embedding fine-tuning** | Contrastive (query, pos, neg); SentenceTransformers `CosineSimilarityLoss` |
| **Chunking** | Parent-child for hierarchy; add recursive/semantic; respect doc boundaries |
| **Contract grouping** | Store `contract_id`, `amendment_number` on every chunk |
| **Document selection** | LLM parses query → `include_original_lease`, `include_amendments`, `comparison_mode`, `confidence` |
| **Complex queries** | `target_amendment: "latest"` → resolve from ES; `confidence: "low"` → `include_all` |
| **Two-stage retrieval** | 1) Filter to selected docs 2) RRF within those docs only |
| **Amendment comparison** | Section-aligned chunking; filter to original + N-th amendment only |
| **Query decomposition** | For multi-doc aggregation, split into sub-queries per document |

---

## 4. Production Execution Plan

### 4.1 Phase 1: Core Infrastructure

| Step | Action |
|------|--------|
| 1.1 | **Config & secrets** — Env vars for `GEMINI_API_KEY`, ES credentials, model names |
| 1.2 | **Elasticsearch** — Docker Compose; index mapping with `metadata.*`, `embedding`, `parent_id`, `chunk_type` |
| 1.3 | **Ingest pipeline** — PDF → parse → chunk (parent-child or flat) → embed → index to ES |

### 4.2 Phase 2: Enrichment Pipeline

| Step | Action |
|------|--------|
| 2.1 | **Schema config** — Pydantic metadata schema + `field_retrieval_queries` per document type |
| 2.2 | **Enrichment flow** — Per-field in-doc retrieval → LLM extraction → bulk ES update |
| 2.3 | **Fallback** — Section-based extraction when embeddings missing |
| 2.4 | **Idempotency** — Skip docs with non-null metadata unless `overwrite=True` |

### 4.3 Phase 3: Retrieval Pipeline

| Step | Action |
|------|--------|
| 3.1 | **Document selector** — LLM selects original vs amendments (e.g. "3rd vs original" → original + 3rd) |
| 3.2 | **Metadata extractor** — LLM extracts filters from query → ES filter clauses |
| 3.3 | **RRF hybrid search** — BM25 + KNN with combined document + metadata filters |
| 3.4 | **Parent expansion** — Fetch parent chunks for retrieved children |
| 3.5 | **RAG generation** — Answer with citations and confidence |

### 4.4 Phase 4: API & Deployment

| Step | Action |
|------|--------|
| 4.1 | **REST API** — FastAPI: `/upload`, `/query`, `/enrich`, `/health` |
| 4.2 | **Docker** — Compose for ES + API; health checks |
| 4.3 | **Error handling** — Retries, fallback (no filters when filtered search returns nothing) |

### 4.5 Phase 5: Optional Enhancements

| Step | Action |
|------|--------|
| 5.1 | **Embedding fine-tuning** — Contrastive training on (query, pos, neg) for lease/contract domain |
| 5.2 | **Chunking variants** — Recursive, semantic, or document-aware chunking |
| 5.3 | **Section-aligned chunking** — For amendment comparison (Section 2 vs Section 2) |
| 5.4 | **Query decomposition** — Multi-hop / aggregation queries split into sub-queries |

### 4.6 Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         PRODUCTION RAG PIPELINE                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  INGEST                    ENRICHMENT                   RETRIEVAL            │
│  ──────                    ─────────                   ─────────           │
│  PDF → Parse → Chunk       Per-field retrieve          Query → LLM          │
│  → Embed → ES Index        → Extract → ES update      (doc selector +      │
│                                                         metadata extractor)  │
│                                                         → RRF hybrid search │
│                                                         → Parent expansion   │
│                                                         → RAG generation     │
│                                                                             │
│  ┌─────────────┐          ┌─────────────────┐        ┌─────────────────┐     │
│  │ Elasticsearch│◄─────────│ Metadata Schema  │        │ Document Filter │     │
│  │ (lease_docs) │          │ + Field Queries  │        │ (original + N)   │     │
│  └─────────────┘          └─────────────────┘        └─────────────────┘     │
│         │                           │                          │            │
│         └───────────────────────────┴──────────────────────────┘            │
│                              Gemini + SentenceTransformers                   │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 4.7 Environment Variables

- `GEMINI_API_KEY` — Required for LLM extraction and RAG
- `RAG_ES_HOST` — Elasticsearch URL (default: http://localhost:9200)
- `RAG_ES_INDEX` — Index name (default: lease_documents)
- `RAG_ES_USER` / `RAG_ES_PASSWORD` — ES credentials

### 4.8 API Endpoints

| Endpoint | Method | Description |
|----------|--------|--------------|
| `/health` | GET | Health check (ES + embedding model) |
| `/upload` | POST | Upload PDF for ingest + enrichment |
| `/ingest` | POST | Alias for `/upload` |
| `/query` | POST | Natural language RAG query |
| `/enrich` | POST | Run metadata enrichment on all docs |

---

*Document generated from notebooks: 01_metadata_enrichment_pipeline_v2.ipynb, 02_metadata_retrieval_pipeline.ipynb, 03_embedding_chunking_retrieval_tuning.ipynb*
