"""FastAPI application for RAG Metadata Pipeline."""
