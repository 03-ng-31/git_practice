"""FastAPI application for RAG Metadata Pipeline."""

import logging
import uuid
from typing import Any, Dict, Optional

from fastapi import BackgroundTasks, FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from ..config import get_settings
from ..pipelines import EnrichmentPipeline, IngestPipeline, MetadataAwareRAGPipeline

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="RAG Metadata Pipeline API",
    description="Metadata-aware RAG for lease and amendment documents",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Lazy-initialized clients
_settings: Optional[Any] = None
_es_client: Optional[Any] = None
_embedding_model: Optional[Any] = None
_gemini_client: Optional[Any] = None
_ingest_pipeline: Optional[IngestPipeline] = None
_enrichment_pipeline: Optional[EnrichmentPipeline] = None
_rag_pipeline: Optional[MetadataAwareRAGPipeline] = None


def get_es_client():
    """Lazy-init Elasticsearch client."""
    global _es_client
    if _es_client is None:
        from elasticsearch import Elasticsearch

        settings = get_settings()
        kwargs = {"hosts": [settings.es_host]}
        if settings.es_user and settings.es_password:
            kwargs["basic_auth"] = (settings.es_user, settings.es_password)
        kwargs["verify_certs"] = False
        _es_client = Elasticsearch(**kwargs)
    return _es_client


def get_embedding_model():
    """Lazy-init embedding model."""
    global _embedding_model
    if _embedding_model is None:
        from sentence_transformers import SentenceTransformer

        settings = get_settings()
        _embedding_model = SentenceTransformer(settings.embedding_model_name)
    return _embedding_model


def get_gemini_client():
    """Lazy-init Gemini client."""
    global _gemini_client
    if _gemini_client is None:
        from google import genai

        settings = get_settings()
        _gemini_client = genai.Client(api_key=settings.gemini_api_key)
    return _gemini_client


def get_ingest_pipeline() -> IngestPipeline:
    """Lazy-init ingest pipeline."""
    global _ingest_pipeline
    if _ingest_pipeline is None:
        settings = get_settings()
        _ingest_pipeline = IngestPipeline(
            es_client=get_es_client(),
            embedding_model=get_embedding_model(),
            index_name=settings.es_index,
        )
        _ingest_pipeline.ensure_index()
    return _ingest_pipeline


def get_enrichment_pipeline() -> EnrichmentPipeline:
    """Lazy-init enrichment pipeline."""
    global _enrichment_pipeline
    if _enrichment_pipeline is None:
        from ..config import get_enrichment_config

        settings = get_settings()
        _enrichment_pipeline = EnrichmentPipeline(
            es_client=get_es_client(),
            index_name=settings.es_index,
            gemini_client=get_gemini_client(),
            embedding_model=get_embedding_model(),
            config=get_enrichment_config(),
        )
    return _enrichment_pipeline


def get_rag_pipeline() -> MetadataAwareRAGPipeline:
    """Lazy-init RAG pipeline."""
    global _rag_pipeline
    if _rag_pipeline is None:
        settings = get_settings()
        _rag_pipeline = MetadataAwareRAGPipeline(
            es_client=get_es_client(),
            index_name=settings.es_index,
            gemini_client=get_gemini_client(),
            embedding_model=get_embedding_model(),
        )
    return _rag_pipeline


class QueryRequest(BaseModel):
    """Request body for query endpoint."""

    query: str = Field(..., description="Natural language query")
    verbose: bool = Field(default=False, description="Include verbose output")


class QueryResponse(BaseModel):
    """Response from query endpoint."""

    query: str
    answer: str
    sources: list[str]
    confidence: str
    extracted_filters: Optional[Dict[str, Any]] = None
    num_hits: Optional[int] = None


class IngestResponse(BaseModel):
    """Response from ingest endpoint."""

    doc_id: str
    chunks_indexed: int
    file_name: Optional[str] = None
    error: Optional[str] = None


class HealthResponse(BaseModel):
    """Health check response."""

    status: str
    elasticsearch: bool
    embedding_model: bool


@app.get("/health", response_model=HealthResponse)
def health_check():
    """Check ES and embedding model readiness."""
    es_ok = False
    try:
        es = get_es_client()
        es.info()
        es_ok = True
    except Exception as e:
        logger.warning("Elasticsearch health check failed: %s", e)

    emb_ok = False
    try:
        get_embedding_model()
        emb_ok = True
    except Exception as e:
        logger.warning("Embedding model health check failed: %s", e)

    return HealthResponse(
        status="ok" if (es_ok and emb_ok) else "degraded",
        elasticsearch=es_ok,
        embedding_model=emb_ok,
    )


@app.post("/upload", response_model=IngestResponse)
async def upload_file(
    file: UploadFile = File(...),
    background_tasks: BackgroundTasks = None,
    run_enrichment: bool = True,
):
    """Upload a PDF file for ingestion and optional enrichment."""
    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="PDF file required")

    content = await file.read()
    doc_id = str(uuid.uuid4())

    try:
        pipeline = get_ingest_pipeline()
        result = pipeline.ingest_bytes(content, doc_id=doc_id, file_name=file.filename or "upload.pdf")

        if run_enrichment and result.get("chunks_indexed", 0) > 0:
            if background_tasks:
                background_tasks.add_task(run_enrichment_for_doc, doc_id)
            else:
                run_enrichment_for_doc(doc_id)

        return IngestResponse(
            doc_id=result["doc_id"],
            chunks_indexed=result.get("chunks_indexed", 0),
            file_name=result.get("file_name"),
            error=result.get("error"),
        )
    except Exception as e:
        logger.exception("Ingest failed")
        raise HTTPException(status_code=500, detail=str(e))


def run_enrichment_for_doc(doc_id: str):
    """Run enrichment for a single document (used in background)."""
    try:
        pipeline = get_enrichment_pipeline()
        pipeline.run(overwrite=True)
    except Exception as e:
        logger.warning("Enrichment failed for doc %s: %s", doc_id, e)


@app.post("/ingest", response_model=IngestResponse)
async def ingest_document(
    file: UploadFile = File(...),
    run_enrichment: bool = True,
):
    """Alias for /upload."""
    return await upload_file(file=file, run_enrichment=run_enrichment)


@app.post("/query", response_model=QueryResponse)
def query(request: QueryRequest):
    """Run RAG query on the indexed documents."""
    try:
        pipeline = get_rag_pipeline()
        result = pipeline.run(query=request.query, verbose=request.verbose)
        return QueryResponse(
            query=result["query"],
            answer=result["answer"],
            sources=result.get("sources", []),
            confidence=result.get("confidence", "low"),
            extracted_filters=result.get("extracted_filters"),
            num_hits=result.get("num_hits"),
        )
    except Exception as e:
        logger.exception("Query failed")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/enrich")
def enrich_all():
    """Run enrichment for all documents in the index."""
    try:
        pipeline = get_enrichment_pipeline()
        result = pipeline.run(overwrite=True)
        return result
    except Exception as e:
        logger.exception("Enrichment failed")
        raise HTTPException(status_code=500, detail=str(e))


def create_app():
    """Create and return the FastAPI app."""
    return app
