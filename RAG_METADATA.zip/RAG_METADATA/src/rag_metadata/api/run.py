"""Run the FastAPI server."""

import uvicorn

from .main import app


def main():
    """Entry point for rag-metadata-serve."""
    uvicorn.run(
        "rag_metadata.api.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
    )


if __name__ == "__main__":
    main()
