"""Metadata schema and enrichment configuration."""

from dataclasses import dataclass
from typing import Any, Dict, List, Literal, Optional, Type

from pydantic import BaseModel, Field


class LeaseMetadata(BaseModel):
    """Structured metadata extracted from lease/amendment documents."""

    owner_name: Optional[str] = Field(None, description="Name of the property owner / tenant")
    landlord: Optional[str] = Field(None, description="Name of the landlord or lessor")
    signing_date: Optional[str] = Field(None, description="Date the lease was signed (YYYY-MM-DD)")
    expiry_date: Optional[str] = Field(None, description="Lease expiration date (YYYY-MM-DD)")
    escalation_clause: Optional[str] = Field(None, description="Rent escalation terms or percentage")
    property_address: Optional[str] = Field(None, description="Full address of the leased property")
    monthly_rent: Optional[str] = Field(None, description="Monthly rent amount with currency")
    amendment_number: Optional[int] = Field(None, description="Amendment number or None for original lease")
    document_type: Optional[str] = Field(None, description="Document type: lease or amendment")
    contract_id: Optional[str] = Field(None, description="Contract ID grouping lease and amendments")


FIELD_RETRIEVAL_QUERIES: Dict[str, List[str]] = {
    "owner_name": ["tenant name", "lessee", "party A", "occupant", "owner"],
    "landlord": ["landlord", "lessor", "property owner", "party B"],
    "signing_date": ["signed on", "execution date", "lease date", "effective date"],
    "expiry_date": ["expiration", "lease term ends", "termination date"],
    "escalation_clause": ["rent escalation", "annual increase", "rent adjustment"],
    "property_address": ["property address", "premises", "located at"],
    "monthly_rent": ["monthly rent", "base rent", "rent amount"],
    "amendment_number": ["amendment", "first amendment", "second amendment"],
    "document_type": ["lease agreement", "amendment", "lease"],
    "contract_id": ["contract", "agreement number", "lease number"],
}


@dataclass
class EnrichmentConfig:
    """Generic config — works for any document type."""

    metadata_schema: Type[BaseModel]
    field_retrieval_queries: Dict[str, List[str]]
    extraction_strategy: Literal["retrieval_augmented", "section_based", "hybrid"] = "retrieval_augmented"
    context_limit_tokens: int = 8000
    chars_per_token: float = 4.0
    safety_margin: float = 0.7
    chunks_per_section: Optional[int] = None
    merge_strategy: Literal["first_non_null", "last_non_null", "most_common"] = "first_non_null"
    chunking_mode: Literal["flat", "parent_child"] = "flat"
    chunk_text_key: str = "text"
    chunk_index_key: str = "chunk_index"
    chunk_id_key: str = "chunk_id"
    doc_id_key: str = "doc_id"
    top_k_per_field: int = 5


def get_enrichment_config() -> EnrichmentConfig:
    """Return default enrichment config for lease documents."""
    return EnrichmentConfig(
        metadata_schema=LeaseMetadata,
        field_retrieval_queries=FIELD_RETRIEVAL_QUERIES,
        extraction_strategy="retrieval_augmented",
        chunking_mode="flat",
        top_k_per_field=5,
    )
