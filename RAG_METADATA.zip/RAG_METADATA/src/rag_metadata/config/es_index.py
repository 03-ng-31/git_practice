"""Elasticsearch index mapping for lease documents."""

from typing import Any, Dict

EMBEDDING_DIM = 384


def get_lease_index_mapping() -> Dict[str, Any]:
    """Return the index mapping for lease_documents."""
    return {
        "mappings": {
            "properties": {
                "chunk_id": {"type": "keyword"},
                "doc_id": {"type": "keyword"},
                "parent_id": {"type": "keyword"},
                "chunk_type": {"type": "keyword"},
                "chunk_index": {"type": "integer"},
                "text": {"type": "text"},
                "file_name": {"type": "keyword"},
                "embedding": {
                    "type": "dense_vector",
                    "dims": EMBEDDING_DIM,
                    "index": True,
                    "similarity": "cosine",
                },
                "metadata": {
                    "type": "object",
                    "properties": {
                        "owner_name": {"type": "keyword"},
                        "landlord": {"type": "keyword"},
                        "signing_date": {"type": "keyword"},
                        "expiry_date": {"type": "keyword"},
                        "escalation_clause": {"type": "text"},
                        "property_address": {"type": "keyword"},
                        "monthly_rent": {"type": "keyword"},
                        "amendment_number": {"type": "integer"},
                        "document_type": {"type": "keyword"},
                        "contract_id": {"type": "keyword"},
                    },
                },
            }
        },
        "settings": {
            "number_of_shards": 1,
            "number_of_replicas": 0,
        },
    }
