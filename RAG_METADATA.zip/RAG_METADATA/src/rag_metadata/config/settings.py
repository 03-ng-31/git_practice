"""Pydantic Settings for environment configuration."""

from functools import lru_cache
from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    model_config = SettingsConfigDict(
        env_prefix="RAG_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        populate_by_name=True,
    )

    # Gemini (GEMINI_API_KEY from env, no prefix)
    gemini_api_key: str = Field(default="YOUR_GEMINI_API_KEY", validation_alias="GEMINI_API_KEY")
    gemini_model: str = Field(default="gemini-2.0-flash")

    # Elasticsearch
    es_host: str = Field(default="http://localhost:9200")
    es_index: str = Field(default="lease_documents")
    es_user: Optional[str] = Field(default="elastic")
    es_password: Optional[str] = Field(default="changeme")

    # Embeddings
    embedding_model_name: str = Field(default="BAAI/bge-small-en-v1.5")
    embedding_dim: int = Field(default=384)

    # Retrieval
    top_k: int = Field(default=5)
    rrf_rank_constant: int = Field(default=60)
    rrf_window_size: int = Field(default=50)


@lru_cache
def get_settings() -> Settings:
    """Return cached settings instance."""
    return Settings()
