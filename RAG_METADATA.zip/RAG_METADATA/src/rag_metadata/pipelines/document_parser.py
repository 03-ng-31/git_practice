"""Document parsing for PDF and text extraction."""

from pathlib import Path
from typing import Optional, Union

import fitz  # PyMuPDF


def extract_text_from_pdf(file_path: Union[str, Path]) -> str:
    """Extract text from a PDF file using PyMuPDF."""
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    doc = fitz.open(path)
    text_parts: list[str] = []
    for page in doc:
        text_parts.append(page.get_text())
    doc.close()
    return "\n\n".join(text_parts)


def extract_text_from_file(file_path: Union[str, Path]) -> str:
    """Extract text from a file. Supports PDF; falls back to plain text."""
    path = Path(file_path)
    suffix = path.suffix.lower()

    if suffix == ".pdf":
        return extract_text_from_pdf(path)
    else:
        return path.read_text(encoding="utf-8", errors="replace")
