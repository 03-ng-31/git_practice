"""Metadata-aware RAG retrieval pipeline."""

import json
import logging
from typing import Any, Dict, List, Optional

from elasticsearch import Elasticsearch
from google import genai
from pydantic import BaseModel, Field
from sentence_transformers import SentenceTransformer

from ..config import get_settings
from ..config.es_index import EMBEDDING_DIM
from .document_selector import DocumentSelector

logger = logging.getLogger(__name__)


def discover_metadata_fields(es_client: Elasticsearch, index_name: str) -> Dict[str, str]:
    """Read ES index mapping and return metadata field names with their types."""
    try:
        mapping = es_client.indices.get_mapping(index=index_name)
        properties = mapping[index_name]["mappings"]["properties"]
        meta_props = properties.get("metadata", {}).get("properties", {})
        return {name: info.get("type", "keyword") for name, info in meta_props.items()}
    except Exception:
        return {}


class ExtractedFilters(BaseModel):
    """Structured output for metadata filters extracted from a user query."""

    filters: Dict[str, Optional[str]] = Field(
        default_factory=dict,
        description="Metadata filters extracted from the query.",
    )
    cleaned_query: str = Field(
        description="The original query with metadata-specific parts removed.",
    )


class QueryMetadataExtractor:
    """Extracts metadata filters from natural language queries using Gemini."""

    PROMPT_TEMPLATE = (
        "You are part of a search system for legal lease and amendment documents. "
        "Given a user query, extract any metadata filters that match the available fields below. "
        "Also produce a 'cleaned_query' that removes the metadata-specific parts, keeping only "
        "the core semantic question for text/vector search.\n\n"
        "Available metadata fields:\n{field_descriptions}\n\n"
        "Rules:\n"
        "- Only extract a field if the query explicitly or strongly implies its value.\n"
        "- For date fields, normalize to YYYY-MM-DD or just YYYY if only the year is given.\n"
        "- For name fields, extract the name as-is from the query.\n"
        "- If no metadata filters are implied, return an empty filters dict.\n"
        "- The cleaned_query should be a meaningful search query, not empty.\n\n"
        "Examples:\n"
        '  Query: "What is the escalation clause in John Smith\'s lease signed in 2023?"\n'
        '  filters: {{"owner_name": "John Smith", "signing_date": "2023", "document_type": "lease"}}\n'
        '  cleaned_query: "What is the escalation clause?"\n\n'
        '  Query: "Show all amendments for 123 Main Street"\n'
        '  filters: {{"property_address": "123 Main Street", "document_type": "amendment"}}\n'
        '  cleaned_query: "Show all documents"\n\n'
        "Now process this query:\n"
        'Query: "{query}"'
    )

    def __init__(
        self,
        gemini_client: genai.Client,
        available_fields: Dict[str, str],
        model: Optional[str] = None,
    ):
        self.gemini_client = gemini_client
        self.available_fields = available_fields
        self.model = model or get_settings().gemini_model

    def _field_descriptions(self) -> str:
        return "\n".join(f"  - {name} (type: {es_type})" for name, es_type in self.available_fields.items())

    def extract(self, query: str) -> ExtractedFilters:
        """Extract metadata filters from a user query."""
        prompt = self.PROMPT_TEMPLATE.format(
            field_descriptions=self._field_descriptions(),
            query=query,
        )
        response = self.gemini_client.models.generate_content(
            model=self.model,
            contents=prompt,
            config={
                "response_mime_type": "application/json",
                "response_schema": ExtractedFilters.model_json_schema(),
            },
        )
        return ExtractedFilters.model_validate_json(response.text)

    def to_es_filters(self, extracted: ExtractedFilters) -> List[Dict[str, Any]]:
        """Convert extracted filters to Elasticsearch filter clauses."""
        clauses = []
        for field_name, value in extracted.filters.items():
            if value is None or field_name not in self.available_fields:
                continue
            es_field = f"metadata.{field_name}"
            es_type = self.available_fields[field_name]
            if es_type == "keyword":
                clauses.append({
                    "wildcard": {es_field: {"value": f"*{value.lower()}*", "case_insensitive": True}}
                })
            elif es_type in ("integer", "float"):
                try:
                    clauses.append({
                        "term": {es_field: int(value) if es_type == "integer" else float(value)}
                    })
                except ValueError:
                    clauses.append({
                        "wildcard": {es_field: {"value": f"*{value}*", "case_insensitive": True}}
                    })
            else:
                clauses.append({"match": {es_field: value}})
        return clauses


class HybridRetriever:
    """Elasticsearch hybrid retriever using RRF (BM25 + KNN) with metadata filtering."""

    def __init__(
        self,
        es_client: Elasticsearch,
        index_name: str,
        embedding_model: SentenceTransformer,
        embedding_dim: int = EMBEDDING_DIM,
        top_k: Optional[int] = None,
        rrf_rank_constant: Optional[int] = None,
        rrf_window_size: Optional[int] = None,
    ):
        settings = get_settings()
        self.es = es_client
        self.index = index_name
        self.embed_model = embedding_model
        self.embedding_dim = embedding_dim
        self.top_k = top_k or settings.top_k
        self.rrf_k = rrf_rank_constant or settings.rrf_rank_constant
        self.rrf_window = rrf_window_size or settings.rrf_window_size

    def _embed_query(self, query: str) -> List[float]:
        return self.embed_model.encode(query, normalize_embeddings=True).tolist()

    def search_rrf(
        self,
        query: str,
        metadata_filters: Optional[List[Dict[str, Any]]] = None,
    ) -> List[Dict[str, Any]]:
        """Execute RRF hybrid search. Supports child and flat chunk types."""
        query_vector = self._embed_query(query)
        base_filter: List[Dict[str, Any]] = [
            {"terms": {"chunk_type": ["child", "flat"]}}
        ]
        if metadata_filters:
            base_filter.extend(metadata_filters)
        filter_clause = {"bool": {"must": base_filter}}

        search_body = {
            "size": self.top_k,
            "retriever": {
                "rrf": {
                    "retrievers": [
                        {
                            "standard": {
                                "query": {
                                    "bool": {
                                        "must": {"match": {"text": query}},
                                        "filter": filter_clause,
                                    }
                                }
                            }
                        },
                        {
                            "knn": {
                                "field": "embedding",
                                "query_vector": query_vector,
                                "k": self.rrf_window,
                                "num_candidates": self.rrf_window * 2,
                                "filter": filter_clause,
                            }
                        },
                    ],
                    "rank_constant": self.rrf_k,
                    "rank_window_size": self.rrf_window,
                }
            },
            "_source": {"excludes": ["embedding"]},
        }

        result = self.es.search(index=self.index, body=search_body)
        return [hit for hit in result["hits"]["hits"]]


def expand_to_parent_context(
    es_client: Elasticsearch,
    index_name: str,
    child_hits: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """For each child hit, fetch parent chunk and attach parent text."""
    parent_ids = list({
        hit["_source"]["parent_id"]
        for hit in child_hits
        if hit["_source"].get("parent_id")
    })

    parent_map: Dict[str, Any] = {}
    if parent_ids:
        parent_results = es_client.mget(
            index=index_name,
            body={"ids": parent_ids},
            _source=["text", "chunk_id", "file_name", "metadata"],
        )
        for pdoc in parent_results.get("docs", []):
            if pdoc.get("found"):
                parent_map[pdoc["_id"]] = pdoc["_source"]

    contexts = []
    seen_parents = set()
    for hit in child_hits:
        src = hit["_source"]
        parent_id = src.get("parent_id", "")
        parent = parent_map.get(parent_id, {})
        ctx = {
            "child_id": src.get("chunk_id", hit["_id"]),
            "child_text": src["text"],
            "parent_id": parent_id,
            "parent_text": parent.get("text", src["text"]),
            "file_name": src.get("file_name", "unknown"),
            "metadata": src.get("metadata", {}),
            "is_unique_parent": parent_id not in seen_parents,
        }
        seen_parents.add(parent_id)
        contexts.append(ctx)
    return contexts


class RAGAnswer(BaseModel):
    """Structured RAG response."""

    answer: str = Field(description="The comprehensive answer.")
    sources: List[str] = Field(default_factory=list, description="Source references.")
    confidence: str = Field(description="Confidence level: high, medium, or low.")


class RAGGenerator:
    """Generates answers from retrieved context using Gemini."""

    SYSTEM_PROMPT = (
        "You are a knowledgeable assistant specializing in lease and property documents. "
        "Answer the user's question based ONLY on the provided context passages. "
        "If the context does not contain enough information, say so clearly. "
        "Always cite which source documents support your answer."
    )
    CONTEXT_TEMPLATE = (
        "--- Context Passage [{index}] (Source: {file_name}) ---\n"
        "Metadata: {metadata}\n"
        "{text}\n"
        "--- End Passage [{index}] ---\n\n"
    )

    def __init__(self, gemini_client: genai.Client, model: Optional[str] = None):
        self.gemini_client = gemini_client
        self.model = model or get_settings().gemini_model

    def generate(
        self,
        query: str,
        contexts: List[Dict[str, Any]],
        applied_filters: Optional[Dict[str, Any]] = None,
    ) -> RAGAnswer:
        """Generate RAG answer from retrieved contexts."""
        context_parts = []
        for i, ctx in enumerate(contexts):
            text = ctx["parent_text"] if ctx.get("is_unique_parent") else ctx["child_text"]
            meta_str = json.dumps(ctx.get("metadata", {}), default=str)
            context_parts.append(self.CONTEXT_TEMPLATE.format(
                index=i + 1,
                file_name=ctx["file_name"],
                metadata=meta_str,
                text=text,
            ))
        context_block = "".join(context_parts)
        filter_info = ""
        if applied_filters:
            filter_info = f"\n\nApplied metadata filters: {json.dumps(applied_filters, default=str)}"
        prompt = (
            f"{self.SYSTEM_PROMPT}\n\n"
            f"Context:\n{context_block}"
            f"{filter_info}\n\n"
            f"User Question: {query}\n\n"
            f"Provide a comprehensive answer with source citations."
        )
        response = self.gemini_client.models.generate_content(
            model=self.model,
            contents=prompt,
            config={
                "response_mime_type": "application/json",
                "response_schema": RAGAnswer.model_json_schema(),
            },
        )
        return RAGAnswer.model_validate_json(response.text)


class MetadataAwareRAGPipeline:
    """End-to-end RAG pipeline with document selection and metadata extraction."""

    def __init__(
        self,
        es_client: Elasticsearch,
        index_name: str,
        gemini_client: genai.Client,
        embedding_model: SentenceTransformer,
        use_document_selector: bool = True,
    ):
        self.es = es_client
        self.index_name = index_name
        self.gemini_client = gemini_client
        self.embedding_model = embedding_model

        metadata_fields = discover_metadata_fields(es_client, index_name)
        if not metadata_fields:
            metadata_fields = {
                "owner_name": "keyword",
                "landlord": "keyword",
                "signing_date": "keyword",
                "expiry_date": "keyword",
                "escalation_clause": "text",
                "property_address": "keyword",
                "monthly_rent": "keyword",
                "amendment_number": "integer",
                "document_type": "keyword",
                "contract_id": "keyword",
            }

        self.query_extractor = QueryMetadataExtractor(gemini_client, metadata_fields)
        self.retriever = HybridRetriever(es_client, index_name, embedding_model)
        self.generator = RAGGenerator(gemini_client)
        self.document_selector = (
            DocumentSelector(gemini_client, es_client, index_name) if use_document_selector else None
        )

    def run(self, query: str, verbose: bool = False) -> Dict[str, Any]:
        """Execute the full pipeline and return structured results."""
        result: Dict[str, Any] = {"query": query}

        all_filters: List[Dict[str, Any]] = []

        if self.document_selector:
            doc_selector_output = self.document_selector.select(query)
            doc_filters = self.document_selector.to_es_filters(doc_selector_output)
            all_filters.extend(doc_filters)
            result["document_selector"] = doc_selector_output

        extracted = self.query_extractor.extract(query)
        result["extracted_filters"] = extracted.filters
        result["cleaned_query"] = extracted.cleaned_query
        meta_filters = self.query_extractor.to_es_filters(extracted)
        all_filters.extend(meta_filters)

        search_query = extracted.cleaned_query or query
        hits = self.retriever.search_rrf(search_query, metadata_filters=all_filters if all_filters else None)
        result["num_hits"] = len(hits)

        if not hits and all_filters:
            if verbose:
                logger.info("No results with filters. Retrying without metadata filters.")
            hits = self.retriever.search_rrf(search_query, metadata_filters=None)
            result["fallback_no_filters"] = True

        contexts = expand_to_parent_context(self.es, self.index_name, hits)
        result["num_contexts"] = len(contexts)

        if contexts:
            answer = self.generator.generate(
                query=query,
                contexts=contexts,
                applied_filters=extracted.filters,
            )
            result["answer"] = answer.answer
            result["sources"] = answer.sources
            result["confidence"] = answer.confidence
        else:
            result["answer"] = "No relevant documents found for this query."
            result["sources"] = []
            result["confidence"] = "low"

        return result
