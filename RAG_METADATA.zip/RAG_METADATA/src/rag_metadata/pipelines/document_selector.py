"""Document selector for contract/amendment-aware retrieval."""

import json
from typing import Any, Dict, List, Optional

from elasticsearch import Elasticsearch
from google import genai
from pydantic import BaseModel, Field

from ..config import get_settings


DOCUMENT_SELECTOR_PROMPT = """
You are a document selector for a contract/lease retrieval system.
Given a user query, determine which documents must be retrieved for answering it.

A contract can have: 1 original lease + multiple amendments (1st, 2nd, 3rd, etc.).

Comparison modes:
- original_vs_N: compare original to a specific amendment (e.g. 3rd vs original)
- N_vs_M: compare two amendments (e.g. 2nd vs 3rd)
- all_over_time: need all docs for aggregation (e.g. "summarize all changes")
- find_first: multi-hop (e.g. "which amendment first introduced X?")
- single_doc: only one document needed

For "latest" or "most recent" amendment, set target_amendment to "latest" (resolved later from index).
Set confidence to "low" when the query is ambiguous or underspecified.

Return JSON:
{{
  "include_original_lease": true/false,
  "include_amendments": [1, 2, 3] or [],
  "include_all": true/false,
  "comparison_mode": "original_vs_N" | "N_vs_M" | "all_over_time" | "find_first" | "single_doc",
  "target_amendment": null | 3 | "latest",
  "contract_id": null or "LEASE-001",
  "confidence": "high" | "medium" | "low"
}}

Examples:
- "What changed in 3rd vs original?" -> include_original_lease: true, include_amendments: [3], comparison_mode: "original_vs_N"
- "Compare 2nd and 3rd amendment" -> include_amendments: [2,3], comparison_mode: "N_vs_M"
- "Summarize all changes over time" -> include_all: true, comparison_mode: "all_over_time"
- "What changed in the latest amendment?" -> target_amendment: "latest", include_original_lease: true, confidence: "medium"
- "Which amendment first introduced 5% escalation?" -> include_all: true, comparison_mode: "find_first", confidence: "low"

Query: "{query}"
"""


class DocumentSelectorOutput(BaseModel):
    """Structured output from document selector."""

    include_original_lease: bool = False
    include_amendments: List[int] = Field(default_factory=list)
    include_all: bool = False
    comparison_mode: str = "single_doc"
    target_amendment: Optional[Any] = None
    contract_id: Optional[str] = None
    confidence: str = "medium"


def resolve_latest_amendment(
    es_client: Elasticsearch,
    index_name: str,
    contract_id: Optional[str] = None,
) -> Optional[int]:
    """Query ES for max amendment_number; used when target_amendment='latest'."""
    query: Dict[str, Any] = {"match_all": {}}
    if contract_id:
        query = {"term": {"metadata.contract_id": contract_id}}
    r = es_client.search(
        index=index_name,
        body={
            "size": 0,
            "query": query,
            "aggs": {"max_amend": {"max": {"field": "metadata.amendment_number"}}},
        },
    )
    val = r.get("aggregations", {}).get("max_amend", {}).get("value")
    return int(val) if val is not None else None


def apply_selector_fallbacks(
    selector_output: Dict[str, Any],
    es_client: Optional[Elasticsearch] = None,
    index_name: str = "lease_documents",
) -> Dict[str, Any]:
    """Resolve 'latest', expand when confidence is low, handle include_all."""
    out = dict(selector_output)
    if out.get("target_amendment") == "latest" and es_client is not None:
        latest = resolve_latest_amendment(es_client, index_name, out.get("contract_id"))
        if latest is not None:
            out["include_amendments"] = list(set(out.get("include_amendments", []) + [latest]))
        out.pop("target_amendment", None)
    if out.get("confidence") == "low":
        out["include_all"] = True
    return out


def build_doc_filter_simple(
    include_original: bool,
    amendment_numbers: List[int],
    contract_id: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    Build ES filter: only chunks from original lease and/or specified amendments.
    Schema: metadata.amendment_number = null for original, 1/2/3 for amendments.
    """
    must: List[Dict[str, Any]] = []
    if contract_id:
        must.append({"term": {"metadata.contract_id": contract_id}})

    should: List[Dict[str, Any]] = []
    if include_original:
        should.append({"bool": {"must_not": {"exists": {"field": "metadata.amendment_number"}}}})
        should.append({"term": {"metadata.amendment_number": 0}})
    if amendment_numbers:
        should.append({"terms": {"metadata.amendment_number": amendment_numbers}})

    if should:
        must.append({"bool": {"should": should, "minimum_should_match": 1}})
    return must


class DocumentSelector:
    """LLM-powered document selection for complex queries."""

    def __init__(
        self,
        gemini_client: genai.Client,
        es_client: Elasticsearch,
        index_name: str,
        model: Optional[str] = None,
    ):
        self.gemini_client = gemini_client
        self.es_client = es_client
        self.index_name = index_name
        self.model = model or get_settings().gemini_model

    def select(self, query: str) -> Dict[str, Any]:
        """Parse query and return document selection with fallbacks applied."""
        prompt = DOCUMENT_SELECTOR_PROMPT.format(query=query)
        try:
            response = self.gemini_client.models.generate_content(
                model=self.model,
                contents=prompt,
                config={"response_mime_type": "application/json"},
            )
            output = json.loads(response.text)
        except Exception:
            output = {"include_all": True, "confidence": "low"}

        return apply_selector_fallbacks(output, self.es_client, self.index_name)

    def to_es_filters(self, selector_output: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Convert selector output to ES filter clauses."""
        if selector_output.get("include_all"):
            return []
        return build_doc_filter_simple(
            include_original=selector_output.get("include_original_lease", False),
            amendment_numbers=selector_output.get("include_amendments", []),
            contract_id=selector_output.get("contract_id"),
        )
