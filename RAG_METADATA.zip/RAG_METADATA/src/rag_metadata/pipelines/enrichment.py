"""Metadata enrichment pipeline — retrieval-augmented and section-based extraction."""

from typing import Any, Dict, List, Type

import numpy as np
from elasticsearch import Elasticsearch, helpers
from google import genai
from pydantic import BaseModel, create_model
from sentence_transformers import SentenceTransformer
from tqdm.auto import tqdm

from ..config import get_enrichment_config, get_settings
from .enrichment_core import (
    compute_section_size,
    enrich_document_retrieval_augmented,
    enrich_document_section_based,
    fetch_chunks_for_doc,
    get_unique_doc_ids,
    merge_extractions,
)


def _doc_already_enriched(es_client: Elasticsearch, index_name: str, doc_id: str) -> bool:
    """Check if document already has non-null metadata."""
    r = es_client.search(
        index=index_name,
        body={"query": {"term": {"doc_id": doc_id}}, "size": 1, "_source": ["metadata"]},
    )
    if not r["hits"]["hits"]:
        return False
    meta = r["hits"]["hits"][0]["_source"].get("metadata", {})
    return any(v is not None for v in meta.values())


class EnrichmentPipeline:
    """Runs metadata enrichment on indexed documents."""

    def __init__(
        self,
        es_client: Elasticsearch,
        index_name: str,
        gemini_client: genai.Client,
        embedding_model: SentenceTransformer,
        config=None,
    ):
        self.es = es_client
        self.index_name = index_name
        self.gemini_client = gemini_client
        self.embedding_model = embedding_model
        self.config = config or get_enrichment_config()

    def run(self, overwrite: bool = False) -> Dict[str, Any]:
        """Enrich all documents in the index."""
        doc_ids = get_unique_doc_ids(self.es, self.index_name)
        enriched = 0
        skipped = 0

        for doc_id in tqdm(doc_ids, desc="Enriching documents"):
            if not overwrite and _doc_already_enriched(self.es, self.index_name, doc_id):
                skipped += 1
                continue

            chunks = fetch_chunks_for_doc(
                self.es,
                self.index_name,
                doc_id,
                self.config.chunking_mode,
                include_embedding=True,
            )
            if not chunks:
                continue

            has_embeddings = any(
                "embedding" in c and c.get("embedding") and sum(c.get("embedding", [0])) != 0
                for c in chunks
            )
            if self.config.extraction_strategy == "retrieval_augmented" and has_embeddings:
                chunks = enrich_document_retrieval_augmented(
                    chunks, self.config, self.embedding_model, self.gemini_client
                )
            else:
                chunks = enrich_document_section_based(chunks, self.config, self.gemini_client)

            actions = [
                {
                    "_op_type": "update",
                    "_index": self.index_name,
                    "_id": c["chunk_id"],
                    "doc": {"metadata": c["metadata"]},
                }
                for c in chunks
            ]
            helpers.bulk(self.es, actions, raise_on_error=False)
            enriched += 1

        self.es.indices.refresh(index=self.index_name)
        return {"enriched": enriched, "skipped": skipped, "total": len(doc_ids)}
