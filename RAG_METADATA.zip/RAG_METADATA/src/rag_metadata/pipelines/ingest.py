"""Ingest pipeline: parse → chunk → embed → index."""

import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from elasticsearch import Elasticsearch, helpers
from sentence_transformers import SentenceTransformer

from ..config import get_enrichment_config, get_settings
from ..config.es_index import EMBEDDING_DIM, get_lease_index_mapping
from .chunking import ChunkingConfig, chunk_document
from .document_parser import extract_text_from_file


class IngestPipeline:
    """Orchestrates document ingestion: parse, chunk, embed, index."""

    def __init__(
        self,
        es_client: Optional[Elasticsearch] = None,
        embedding_model: Optional[SentenceTransformer] = None,
        index_name: Optional[str] = None,
        chunking_config: Optional[ChunkingConfig] = None,
    ):
        settings = get_settings()
        self.es = es_client or self._create_es_client(settings)
        self.index_name = index_name or settings.es_index
        self.embedding_model = embedding_model or SentenceTransformer(settings.embedding_model_name)
        self.chunking_config = chunking_config or ChunkingConfig(
            strategy="parent_child",
            chunk_size=512,
            overlap=50,
            parent_size=2000,
        )

    def _create_es_client(self, settings) -> Elasticsearch:
        kwargs: Dict[str, Any] = {"hosts": [settings.es_host]}
        if settings.es_user and settings.es_password:
            kwargs["basic_auth"] = (settings.es_user, settings.es_password)
        kwargs["verify_certs"] = False
        return Elasticsearch(**kwargs)

    def ensure_index(self) -> None:
        """Create index with mapping if it does not exist."""
        if not self.es.indices.exists(index=self.index_name):
            mapping = get_lease_index_mapping()
            self.es.indices.create(index=self.index_name, body=mapping)

    def ingest_file(
        self,
        file_path: Union[str, Path],
        doc_id: Optional[str] = None,
        file_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Ingest a single file: extract text, chunk, embed, index.
        Returns summary with doc_id and chunk count.
        """
        path = Path(file_path)
        doc_id = doc_id or str(uuid.uuid4())
        file_name = file_name or path.name

        text = extract_text_from_file(path)
        if not text.strip():
            return {"doc_id": doc_id, "chunks_indexed": 0, "error": "Empty document"}

        chunks = chunk_document(text, self.chunking_config, doc_id, file_name)

        # Embed only chunks that will be used for retrieval (child or flat)
        chunks_to_embed = [c for c in chunks if c["chunk_type"] in ("child", "flat")]
        if chunks_to_embed:
            texts = [c["text"] for c in chunks_to_embed]
            embeddings = self.embedding_model.encode(texts, normalize_embeddings=True)
            for i, c in enumerate(chunks_to_embed):
                c["embedding"] = embeddings[i].tolist()

        # Parent chunks don't need embeddings for retrieval (we expand from children)
        # But we can add empty or skip - ES mapping may require it. Use zeros for parent.
        for c in chunks:
            if "embedding" not in c:
                c["embedding"] = [0.0] * EMBEDDING_DIM

        actions = [
            {
                "_index": self.index_name,
                "_id": c["chunk_id"],
                "_source": c,
            }
            for c in chunks
        ]
        helpers.bulk(self.es, actions, raise_on_error=False)
        self.es.indices.refresh(index=self.index_name)

        return {"doc_id": doc_id, "chunks_indexed": len(chunks), "file_name": file_name}

    def ingest_bytes(
        self,
        content: bytes,
        doc_id: str,
        file_name: str = "upload.pdf",
    ) -> Dict[str, Any]:
        """Ingest from bytes (e.g. uploaded file). Writes to temp file for PDF parsing."""
        import tempfile

        suffix = Path(file_name).suffix or ".pdf"
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as f:
            f.write(content)
            temp_path = f.name
        try:
            return self.ingest_file(temp_path, doc_id=doc_id, file_name=file_name)
        finally:
            Path(temp_path).unlink(missing_ok=True)
