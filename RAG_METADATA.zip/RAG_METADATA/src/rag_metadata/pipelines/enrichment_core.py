"""Core enrichment logic: in-doc retrieval, LLM extraction, merge."""

from typing import Any, Dict, List, Type

import numpy as np
from elasticsearch import Elasticsearch
from google import genai
from pydantic import BaseModel, create_model
from sentence_transformers import SentenceTransformer
from tqdm.auto import tqdm

from ..config import EnrichmentConfig, get_settings


def get_unique_doc_ids(es_client: Elasticsearch, index_name: str) -> List[str]:
    """Get unique doc_ids from the index."""
    result = es_client.search(
        index=index_name,
        body={"size": 0, "aggs": {"doc_ids": {"terms": {"field": "doc_id", "size": 10000}}}},
    )
    return [b["key"] for b in result["aggregations"]["doc_ids"]["buckets"]]


def fetch_chunks_for_doc(
    es_client: Elasticsearch,
    index_name: str,
    doc_id: str,
    chunking_mode: str = "flat",
    include_embedding: bool = True,
) -> List[Dict[str, Any]]:
    """Fetch all chunks for a document. Supports flat or parent-child."""
    if chunking_mode == "parent_child":
        query = {
            "bool": {
                "must": [
                    {"term": {"doc_id": doc_id}},
                    {"terms": {"chunk_type": ["parent", "child"]}},
                ]
            }
        }
    else:
        query = {"term": {"doc_id": doc_id}}

    source = ["chunk_id", "doc_id", "chunk_index", "text", "file_name", "chunk_type", "parent_id"]
    if include_embedding:
        source.append("embedding")

    result = es_client.search(
        index=index_name,
        body={
            "query": query,
            "sort": [{"chunk_index": "asc"}],
            "size": 1000,
            "_source": source,
        },
    )

    chunks = []
    for hit in result["hits"]["hits"]:
        src = hit["_source"]
        chunk = {
            "chunk_id": src.get("chunk_id", hit["_id"]),
            "doc_id": src.get("doc_id", doc_id),
            "chunk_index": src.get("chunk_index", 0),
            "text": src.get("text", ""),
            "file_name": src.get("file_name", ""),
            "chunk_type": src.get("chunk_type", "flat"),
            "parent_id": src.get("parent_id"),
        }
        if "embedding" in src:
            chunk["embedding"] = src["embedding"]
        chunks.append(chunk)
    return chunks


def in_doc_retrieve(
    chunks: List[Dict[str, Any]],
    query: str,
    embedding_model: SentenceTransformer,
    top_k: int = 5,
) -> List[Dict[str, Any]]:
    """Retrieve top-k chunks most relevant to the query via cosine similarity."""
    chunks_with_emb = [
        c
        for c in chunks
        if "embedding" in c
        and c.get("embedding")
        and (not isinstance(c["embedding"], list) or sum(abs(x) for x in c["embedding"]) > 0)
    ]
    if not chunks_with_emb:
        return chunks[:top_k]

    query_embedding = embedding_model.encode(query, normalize_embeddings=True)
    chunk_embeddings = np.array([c["embedding"] for c in chunks_with_emb])
    scores = np.dot(chunk_embeddings, query_embedding)
    top_indices = np.argsort(scores)[::-1][:top_k]
    return [chunks_with_emb[i] for i in top_indices]


def retrieve_chunks_for_field(
    chunks: List[Dict[str, Any]],
    field_name: str,
    field_queries: List[str],
    embedding_model: SentenceTransformer,
    top_k: int = 5,
) -> List[Dict[str, Any]]:
    """Retrieve chunks for a field using multiple queries; deduplicate and take top-k."""
    seen_ids = set()
    results = []
    for q in field_queries:
        retrieved = in_doc_retrieve(chunks, q, embedding_model, top_k=top_k)
        for c in retrieved:
            cid = c.get("chunk_id", id(c))
            if cid not in seen_ids:
                seen_ids.add(cid)
                results.append(c)
                if len(results) >= top_k:
                    return results
    return results[:top_k]


def extract_field_from_text(
    text: str,
    field_name: str,
    schema: Type[BaseModel],
    gemini_client: genai.Client,
    model: str,
) -> Any:
    """Extract a single field value from text using Gemini structured output."""
    field_info = schema.model_fields.get(field_name)
    if not field_info:
        return None

    desc = field_info.description or field_name
    prompt = f"""Extract the following metadata field from the document text.
Field: {field_name}
Description: {desc}

If the value cannot be determined, return null.

--- DOCUMENT TEXT ---
{text[:15000]}
--- END ---

Return ONLY a JSON object with the key "{field_name}" and the extracted value (or null)."""

    single_schema = create_model(
        f"SingleField_{field_name}",
        **{field_name: (field_info.annotation, field_info.default)},
    )

    try:
        response = gemini_client.models.generate_content(
            model=model,
            contents=prompt,
            config={
                "response_mime_type": "application/json",
                "response_schema": single_schema.model_json_schema(),
            },
        )
        parsed = single_schema.model_validate_json(response.text)
        return getattr(parsed, field_name, None)
    except Exception:
        return None


def merge_extractions(
    extractions: List[Dict[str, Any]],
    strategy: str = "first_non_null",
) -> Dict[str, Any]:
    """Merge multiple extractions into one."""
    if not extractions:
        return {}
    all_fields = set()
    for ext in extractions:
        all_fields.update(ext.keys())
    merged = {}
    for field in all_fields:
        values = [ext.get(field) for ext in extractions if ext.get(field) is not None]
        if not values:
            merged[field] = None
        elif strategy == "first_non_null":
            merged[field] = values[0]
        elif strategy == "last_non_null":
            merged[field] = values[-1]
        elif strategy == "most_common":
            merged[field] = max(set(values), key=values.count)
        else:
            merged[field] = values[0]
    return merged


def compute_section_size(config: EnrichmentConfig, chunk_size_chars: int = 512) -> int:
    """Compute number of chunks per section."""
    if config.chunks_per_section is not None:
        return config.chunks_per_section
    max_chars = int(config.context_limit_tokens * config.chars_per_token * config.safety_margin)
    return max(1, max_chars // chunk_size_chars)


def _build_schema_description(schema: Type[BaseModel]) -> str:
    return "\n".join(f"  - {n}: {f.description or n}" for n, f in schema.model_fields.items())


def enrich_document_retrieval_augmented(
    chunks: List[Dict[str, Any]],
    config: EnrichmentConfig,
    embedding_model: SentenceTransformer,
    gemini_client: genai.Client,
) -> List[Dict[str, Any]]:
    """Per-field: retrieve chunks → extract → assign value to retrieved, null to others."""
    settings = get_settings()
    model = settings.gemini_model

    field_names = list(config.metadata_schema.model_fields.keys())
    doc_metadata: Dict[str, Any] = {f: None for f in field_names}

    for chunk in chunks:
        chunk["metadata"] = {f: None for f in field_names}

    for field_name in tqdm(field_names, desc="Extracting fields"):
        queries = config.field_retrieval_queries.get(field_name, [field_name.replace("_", " ")])
        retrieved = retrieve_chunks_for_field(
            chunks, field_name, queries, embedding_model, config.top_k_per_field
        )
        if not retrieved:
            continue

        context = "\n\n".join(c["text"] for c in retrieved)
        if not context.strip():
            continue

        try:
            value = extract_field_from_text(
                context, field_name, config.metadata_schema, gemini_client, model
            )
        except Exception:
            value = None

        doc_metadata[field_name] = value
        retrieved_ids = {c.get("chunk_id", id(c)) for c in retrieved}
        for chunk in chunks:
            cid = chunk.get("chunk_id", id(chunk))
            chunk["metadata"][field_name] = value if cid in retrieved_ids else None

    return chunks


def enrich_document_section_based(
    chunks: List[Dict[str, Any]],
    config: EnrichmentConfig,
    gemini_client: genai.Client,
) -> List[Dict[str, Any]]:
    """Section-based extraction: group chunks, extract per section, merge, assign."""
    settings = get_settings()
    text_key = config.chunk_text_key
    section_size = compute_section_size(config, len(chunks[0].get(text_key, "")) if chunks else 512)
    sections = [chunks[i : i + section_size] for i in range(0, len(chunks), section_size)]
    schema_desc = _build_schema_description(config.metadata_schema)

    extractions = []
    for section_chunks in tqdm(sections, desc="Extracting sections"):
        section_text = "\n\n".join(c.get(text_key, "") for c in section_chunks)
        section_text = section_text[:15000]
        prompt = f"""Extract the requested metadata fields from this document section.
If a field cannot be determined, return null.

Schema:
{schema_desc}

--- DOCUMENT SECTION ---
{section_text}
--- END ---

Return ONLY a JSON object matching the schema."""
        try:
            meta = config.metadata_schema.model_validate_json(
                gemini_client.models.generate_content(
                    model=settings.gemini_model,
                    contents=prompt,
                    config={
                        "response_mime_type": "application/json",
                        "response_schema": config.metadata_schema.model_json_schema(),
                    },
                ).text
            )
            extractions.append(meta.model_dump())
        except Exception:
            extractions.append({f: None for f in config.metadata_schema.model_fields})

    merged = merge_extractions(extractions, config.merge_strategy)
    for chunk in chunks:
        chunk["metadata"] = dict(merged)
    return chunks
