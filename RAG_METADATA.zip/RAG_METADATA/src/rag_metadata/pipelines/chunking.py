"""Chunking strategies for document processing."""

import uuid
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class ChunkingConfig:
    """Configuration for chunking strategy."""

    strategy: str  # "parent_child", "recursive", "flat"
    chunk_size: int = 512
    overlap: int = 50
    parent_size: int = 2000
    respect_doc_boundaries: bool = True


def recursive_split(
    text: str,
    separators: List[str],
    chunk_size: int,
    overlap: int = 0,
) -> List[str]:
    """Recursive character split: try separators in order until chunks fit."""
    if not text or len(text) <= chunk_size:
        return [text] if text else []

    sep = separators[0] if separators else " "
    parts = text.split(sep)
    chunks: List[str] = []
    current = ""

    for p in parts:
        candidate = (current + sep + p) if current else p
        if len(candidate) <= chunk_size:
            current = candidate
        else:
            if current:
                chunks.append(current)
            if len(p) > chunk_size and len(separators) > 1:
                chunks.extend(recursive_split(p, separators[1:], chunk_size, overlap))
                current = ""
            else:
                current = p[:chunk_size]

    if current:
        chunks.append(current)
    return chunks


def parent_child_chunk(
    text: str,
    parent_size: int = 2000,
    child_size: int = 512,
    overlap: int = 50,
) -> tuple[List[dict], List[dict]]:
    """
    Create parent and child chunks. Parents are larger; each parent contains
    multiple children. Children reference parent via parent_id.
    """
    separators = ["\n\n", "\n", ". ", " "]
    parent_texts = recursive_split(text, separators, parent_size, overlap)

    parents: List[dict] = []
    children: List[dict] = []

    for pi, ptext in enumerate(parent_texts):
        if not ptext.strip():
            continue
        parent_id = str(uuid.uuid4())
        parents.append(
            {
                "chunk_id": parent_id,
                "chunk_type": "parent",
                "chunk_index": pi,
                "text": ptext,
                "parent_id": None,
            }
        )

        child_texts = recursive_split(ptext, separators, child_size, overlap)
        for ci, ctext in enumerate(child_texts):
            if not ctext.strip():
                continue
            child_id = str(uuid.uuid4())
            children.append(
                {
                    "chunk_id": child_id,
                    "chunk_type": "child",
                    "chunk_index": ci,
                    "text": ctext,
                    "parent_id": parent_id,
                }
            )

    return parents, children


def flat_chunk(
    text: str,
    chunk_size: int = 512,
    overlap: int = 50,
) -> List[dict]:
    """Create flat chunks (no parent-child hierarchy)."""
    separators = ["\n\n", "\n", ". ", " "]
    chunks_text = recursive_split(text, separators, chunk_size, overlap)

    chunks: List[dict] = []
    for i, ctext in enumerate(chunks_text):
        if not ctext.strip():
            continue
        chunks.append(
            {
                "chunk_id": str(uuid.uuid4()),
                "chunk_type": "flat",
                "chunk_index": i,
                "text": ctext,
                "parent_id": None,
            }
        )
    return chunks


def chunk_document(
    text: str,
    config: ChunkingConfig,
    doc_id: str,
    file_name: str = "unknown",
) -> List[dict]:
    """
    Chunk a document according to config. Returns list of chunk dicts
    ready for embedding and indexing.
    """
    if config.strategy == "parent_child":
        parents, children = parent_child_chunk(
            text,
            parent_size=config.parent_size,
            child_size=config.chunk_size,
            overlap=config.overlap,
        )
        result: List[dict] = []
        for p in parents:
            p["doc_id"] = doc_id
            p["file_name"] = file_name
            result.append(p)
        for c in children:
            c["doc_id"] = doc_id
            c["file_name"] = file_name
            result.append(c)
        return result
    else:
        chunks = flat_chunk(text, chunk_size=config.chunk_size, overlap=config.overlap)
        for c in chunks:
            c["doc_id"] = doc_id
            c["file_name"] = file_name
        return chunks
