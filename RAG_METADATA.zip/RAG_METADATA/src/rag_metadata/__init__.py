"""RAG Metadata Pipeline — Production-grade metadata enrichment and retrieval for lease documents."""

__version__ = "0.1.0"
