# Cell-Site FMV Data Dictionary — Open-Source Enrichment Sources

This document catalogs **open-source data sources** that support the Cell-Site FMV Data Dictionary (seven domains). For each source we document: **data**, **URL/API**, **refresh rate**, **API framework**, **which attributes they support**, and **how to fetch**.

---

## Summary: Open vs. Proprietary

| Domain | Open-Source Coverage | Gaps (proprietary or manual) |
|--------|----------------------|------------------------------|
| 1 — Internal Contract & Payments | — | Internal only |
| 2 — Zoning & Permitting | WRLURI (research); NEPA/Section 106/FAA are procedural | Zoning district, permit type, ordinance text (county/municipal) |
| 3 — Physical Cell Site | FCC ASR, USGS elevation/NLCD | Lease area, equipment counts (internal/survey) |
| 4 — Network Parameters | FCC ASR (tenant/structure), OpenCelliD (cells/tech) | Carrier KPIs, backhaul, criticality (internal) |
| 5 — Microeconomic | Census ACS, HUD SAFMR, FHFA HPI, Census Geocoder | Zillow (terms restrict bulk), CoStar (paid) |
| 6 — Macroeconomic | FRED, BLS | Construction/wireless indices (some FRED) |
| 7 — Competition & Geospatial | FCC ASR, OpenCelliD, FEMA NFHL, USGS | Hazard composites (derived) |

---

## 1. FCC — Antenna Structure Registration (ASR) & ULS

**Purpose:** Physical tower attributes, structure owner, registration status, coordinates, height; tower counts for competition metrics.

| Item | Detail |
|------|--------|
| **Data** | ASR: registration records (tower location, height, status, construction). ULS: licenses (microwave, cellular, etc.). |
| **Data source** | FCC Wireless Telecommunications Bureau, Public Access Files. |
| **URL (bulk)** | **Daily (transactions):** https://data.fcc.gov/download/pub/uls/daily/ — e.g. `r_tow_*.zip` (ASR Registration), `a_tow_*.zip` (ASR Applications), `d_tow_*.zip` (FAA Determinations). **Weekly (full):** https://data.fcc.gov/download/pub/uls/complete/ — `r_tower.zip` (~35 MB), `a_tower.zip` (~193 MB), `d_tower.zip` (~51 MB). |
| **Refresh rate** | Daily (incremental); weekly full refresh (typically weekend). |
| **API framework** | **No REST API for bulk ASR.** Bulk only via HTTP download of zip files. Pipe-delimited text; multi-file schema (see FCC ASR table definitions). |
| **Auth** | None for bulk downloads. |
| **FMV attributes supported** | `structure_type`, `tower_height_ft`, `tower_height_amsl_ft`, `ground_elevation_ft` (if parsed), `fcc_asr_registration_number`, `fcc_asr_status`, `construction_year`, `structure_owner`, `fcc_tower_count`, `fcc_tower_density`, `competitor_tower_distance_km`, `same_carrier_tower_distance_km`, `tower_vintage_years`, `faa_obstruction_review` (from FAA determination records). |

**Fetch approach:** Download zip from base URL + file name; unzip; parse pipe-delimited files per FCC ASR/ULS documentation (see [FCC Public Access Files](https://www.fcc.gov/wireless/data/public-access-files-database-downloads)).

---

## 2. Census Bureau — American Community Survey (ACS)

**Purpose:** Microeconomic and demographic attributes at tract/county level.

| Item | Detail |
|------|--------|
| **Data** | Population, income, housing, vacancy, median rent, median home value, etc. |
| **Data source** | U.S. Census Bureau, ACS. |
| **URL / API** | **API base:** `https://api.census.gov/data/{year}/acs/acs5` (5-year); `.../acs1` (1-year). **Example:** `https://api.census.gov/data/2022/acs/acs5?get=B01003_001E,B19013_001E&for=tract:*&in=state:36&key=YOUR_KEY`. |
| **Refresh rate** | 5-year: annual release (e.g., 2022 ACS 5-year released Dec 2023); 1-year: annual for areas 65k+ pop. |
| **API framework** | REST JSON; GET with `get` (variables), `for` (geography), `in` (parent geography). Free API key: [Census API Key](https://api.census.gov/data/key_signup.html). 500 requests/day without key. |
| **Auth** | Optional API key (recommended). |
| **FMV attributes supported** | `census_population`, `census_population_density`, `census_median_income`, `census_median_home_value`, `census_median_rent`, `census_housing_units`, `census_vacant_housing`, `census_vacancy_rate`, `census_median_age`, `census_fips_code` (from geography in response). `census_population_3km` requires GIS (buffer + tract overlay). |

**Variable IDs (examples):** B01003_001E (total pop), B19013_001E (median HH income), B25077_001E (median home value), B25064_001E (median gross rent), B25002_003E (vacant units), B25002_001E (total units).

---

## 3. Census Bureau — Geocoder

**Purpose:** Address or lat/lon → coordinates and Census geographies (tract, county, FIPS).

| Item | Detail |
|------|--------|
| **Data** | Geocoded coordinates; Census tract, block, county, state (FIPS). |
| **Data source** | Census Geocoder (TIGER-based). |
| **URL / API** | **Geographies by address:** `https://geocoding.geo.census.gov/geocoder/geographies/address?street=...&city=...&state=...&zip=...&benchmark=Public_AR_Current&vintage=Current&format=json`. **Geographies by coordinates:** `https://geocoding.geo.census.gov/geocoder/geographies?x=-73.99&y=40.71&benchmark=Public_AR_Current&vintage=Current&format=json`. |
| **Refresh rate** | Benchmark/vintage updated with TIGER (typically twice yearly). |
| **API framework** | REST GET; JSON. No key required. |
| **Auth** | None. |
| **FMV attributes supported** | `census_fips_code` (state, county, tract); linking site lat/lon to tract for ACS join. |

**Docs:** [Census Geocoding Services API](https://geocoding.geo.census.gov/geocoder/Geocoding_Services_API.html).

---

## 4. FRED — Federal Reserve Economic Data

**Purpose:** Macroeconomic and real-estate indices for 10-year forecasting and market drift.

| Item | Detail |
|------|--------|
| **Data** | CPI, interest rates, unemployment, GDP, mortgage rates, commercial real estate indices, etc. |
| **Data source** | Federal Reserve Bank of St. Louis (FRED). |
| **URL / API** | **API base:** `https://api.stlouisfed.org/fred/`. **Series observations:** `https://api.stlouisfed.org/fred/series/observations?series_id=CPIAUCSL&api_key=KEY&file_type=json`. |
| **Refresh rate** | Series-dependent: monthly (e.g., CPI), daily (e.g., rates), quarterly (e.g., GDP). |
| **API framework** | REST GET; JSON/XML. Free API key: [FRED API](https://fred.stlouisfed.org/docs/api/fred/). |
| **Auth** | API key required. |
| **FMV attributes supported** | `cpi_all_urban` (CPIAUCSL), `cpi_shelter` (CUSR0000SAH1), `cpi_rent_primary_residence` (CUSR0000SEHA), `fed_funds_rate` (FEDFUNDS), `treasury_10yr_yield` (DGS10), `mortgage_rate_30yr` (MORTGAGE30US), `unemployment_rate_national` (UNRATE), `gdp_growth_national` (A191RL1Q225SBEA), `commercial_re_price_index` (e.g., BOGZ1FL075035503Q). |

**Python:** `fredapi` — `pip install fredapi`; `Fred(api_key=key).get_series('CPIAUCSL')`.

---

## 5. BLS — Bureau of Labor Statistics (LAUS)

**Purpose:** Local (county/MSA) unemployment for macro/micro controls.

| Item | Detail |
|------|--------|
| **Data** | Local Area Unemployment Statistics (LAUS): unemployment rate, labor force, employment by county/MSA. |
| **Data source** | BLS. |
| **URL / API** | **API:** `https://api.bls.gov/publicAPI/v2/timeseries/data/`. POST with JSON body: `{"seriesid":["LAUCN360610000000003"],"startyear":"2020","endyear":"2024"}`. Optional registration for higher limits. |
| **Refresh rate** | Monthly. |
| **API framework** | REST POST (v2); JSON. [BLS Public Data API](https://www.bls.gov/developers/). |
| **Auth** | Optional API key (increases rate limits). |
| **FMV attributes supported** | `unemployment_rate_local` (county/MSA). Series ID format: LAUCN + FIPS state (2) + FIPS county (3) + 0000000 + 003 (unemployment rate). |

**Python:** `requests.post(url, json=payload)`.

---

## 6. OpenCelliD

**Purpose:** Cell tower and cell IDs; technology mix; tower/carrier counts for competition and network proxies.

| Item | Detail |
|------|--------|
| **Data** | Cell positions (lat/lon), radio type (GSM, LTE, NR, etc.), MCC/MNC, optional signal/accuracy. |
| **Data source** | Unwired Labs / OpenCelliD community. |
| **URL / API** | **Base:** `https://opencellid.org`. **Cell position:** GET `https://opencellid.org/cell/get?key=APIKEY&mcc=...&mnc=...&lac=...&cellid=...&format=json`. **Cells in area:** GET `https://opencellid.org/cell/getInArea?key=APIKEY&bb=min_lat,min_lon,max_lat,max_lon&format=json`. **Cell count in area:** `.../cell/getCountInArea?key=APIKEY&bb=...`. |
| **Refresh rate** | Community-driven; API returns current DB state. Full DB dumps available (see [OpenCelliD Downloads](https://opencellid.org/downloads)). |
| **API framework** | REST GET/POST; JSON/XML/CSV/KML. API key required (free registration). |
| **Auth** | API key (query param `key=`). Free tier: 1000 requests/day; whitelisting for higher. |
| **FMV attributes supported** | `opencellid_tower_count`, `opencellid_tower_density`, `opencellid_carrier_count`, `opencellid_tech_distribution` (2G/3G/4G/5G counts from `radio` field). |

**Docs:** [OpenCelliD API](https://wiki.opencellid.org/wiki/API).

---

## 7. USGS — 3DEP Elevation & National Map

**Purpose:** Ground elevation, elevation variance (terrain), DEM for topography class.

| Item | Detail |
|------|--------|
| **Data** | DEM (10 m, 30 m, 60 m); point elevation; slope/aspect. |
| **Data source** | USGS 3D Elevation Program (3DEP), National Map. |
| **URL / API** | **TNM Access API:** `https://tnmaccess.usgs.gov/api/v1/`. **3DEP elevation service** used by Python wrappers. No single “elevation by lat/lon” REST URL in TNM; use Python libraries. |
| **Refresh rate** | 3DEP tiles updated periodically; not real-time. |
| **API framework** | REST (TNM); Python: **py3dep** (`pip install py3dep`) — `elevation_bycoords()`, `get_dem()`, etc. Returns xarray/GeoJSON. |
| **Auth** | None for public 3DEP. |
| **FMV attributes supported** | `ground_elevation_ft`, `terrain_elevation_variance_m` (from DEM in radius), `topography_class` (derived from DEM). |

**Python:** `py3dep.elevation_bycoords([(lon, lat)])` for point elevation.

---

## 8. USGS — NLCD (National Land Cover Database)

**Purpose:** Parcel/area land cover for `nlcd_land_cover_code`.

| Item | Detail |
|------|--------|
| **Data** | Land cover classification (e.g., developed, forest, water) at 30 m. |
| **Data source** | USGS EROS / MRLC. |
| **URL / API** | **MRLC data:** https://www.mrlc.gov/data. **AWS S3:** Programmatic access (us-west-2). **WMS/WCS:** OGC services on MRLC Data Services. No simple “point value” REST API; use GeoTIFF clip or WCS. |
| **Refresh rate** | Annual NLCD releases (e.g., 2019, 2021); not daily. |
| **API framework** | Bulk download (GeoTIFF); S3; WMS/WCS. Python: `rasterio` + point sample or clip. |
| **Auth** | None. |
| **FMV attributes supported** | `nlcd_land_cover_code`. |

---

## 9. FEMA — National Flood Hazard Layer (NFHL)

**Purpose:** Flood zone for hazard/composite risk.

| Item | Detail |
|------|--------|
| **Data** | Flood zones (A, AE, V, etc.), BFE, boundaries. |
| **Data source** | FEMA. |
| **URL / API** | **ArcGIS REST:** `https://hazards.fema.gov/arcgis/rest/services/public/NFHL/MapServer` (query). **FeatureServer:** `https://services.arcgis.com/.../FEMA_National_Flood_Hazard_Layer/FeatureServer`. Query by geometry or envelope. |
| **Refresh rate** | Continuous revisions; service reflects current NFHL. |
| **API framework** | ArcGIS REST (Query); JSON. |
| **Auth** | None for public MapServer/FeatureServer. |
| **FMV attributes supported** | FEMA flood zone (for `composite_hazard_score` / hazard attributes). |

**Python:** `requests.get` with `where=1=1&geometry=...&outFields=*&f=json` or use `geopandas` with ArcGIS REST.

---

## 10. HUD — Small Area Fair Market Rents (SAFMR)

**Purpose:** ZIP-level rent index for microeconomic controls.

| Item | Detail |
|------|--------|
| **Data** | SAFMR by bedroom count by ZIP (ZCTA). |
| **Data source** | HUD USER. |
| **URL / API** | **ArcGIS Feature Server:** `https://services.arcgis.com/VTyQ9soqVukalItT/arcgis/rest/services/HUD_PDR_Small_Area_Fair_Market_Rents/FeatureServer`. **Portal:** https://www.huduser.gov/portal/datasets/fmr/smallarea/index.html. **Data.gov:** CSV/Shapefile. |
| **Refresh rate** | Annual (FMR/SAFMR updates). |
| **API framework** | ArcGIS REST query; JSON. Max 1000 records/request. |
| **Auth** | None. |
| **FMV attributes supported** | `hud_safmr` (by ZIP/ZCTA). |

---

## 11. FHFA — House Price Index (HPI)

**Purpose:** House price indices for CBSA/state/ZIP for market drift.

| Item | Detail |
|------|--------|
| **Data** | Purchase-only and all-transactions HPI; quarterly/monthly; US, state, MSA, county, ZIP, tract. |
| **Data source** | FHFA. |
| **URL / API** | **Downloads:** https://www.fhfa.gov/DataTools/Downloads/Pages/House-Price-Index-Datasets.aspx. CSV, JSON, XML, SQL. **No standard public REST API**; use bulk download and filter. |
| **Refresh rate** | Quarterly and monthly (series-dependent). |
| **API framework** | Bulk download (CSV/JSON). |
| **Auth** | None. |
| **FMV attributes supported** | `fhfa_hpi` (CBSA/state/ZIP/time). |

---

## 12. Wharton WRLURI / NBER Data Appendix

**Purpose:** Proxy for local regulatory restrictiveness (zoning/permit difficulty).

| Item | Detail |
|------|--------|
| **Data** | Wharton Residential Land Use Regulatory Index (WRLURI) and sub-indices (e.g., approval delay) by community. |
| **Data source** | Wharton/NBER. |
| **URL / API** | **NBER data appendix:** http://www.nber.org/data-appendix/w26573. **Paper:** NBER w26573. **NLURI (newer):** https://www.nluri.com/ (block-group level; different product). |
| **Refresh rate** | One-time / periodic research release; not real-time. |
| **API framework** | Download (Excel/CSV from NBER data appendix); no REST API. |
| **Auth** | None. |
| **FMV attributes supported** | `wrluri_index`, `wrluri_approval_delay_index` (after joining to jurisdiction). |

---

## 13. Zillow / Commercial Indices (Limitations)

**Purpose:** ZORI, ZHVI for rent/home value.

| Item | Detail |
|------|--------|
| **Data** | Zillow Observed Rent Index (ZORI), Zillow Home Value Index (ZHVI) by geography. |
| **Data source** | Zillow Research. |
| **URL / API** | **Public data:** Zillow Research publishes CSV/Excel for research (e.g., data.zillow.com). **API:** Zillow’s main APIs are for licensed/consumer use; bulk programmatic use often restricted by terms. |
| **Refresh rate** | Monthly for indices. |
| **API framework** | Download from Zillow Research where allowed; check terms for API. |
| **FMV attributes supported** | `zillow_zori`, `zillow_zhvi` (where use is permitted). |

**Note:** Treat as “conditional open”; verify current Zillow Research terms before automation.

---

## 14. TIGER/Line — Highways / Distance to Highway

**Purpose:** Distance to nearest major highway for accessibility.

| Item | Detail |
|------|--------|
| **Data** | Roads (including primary roads/highways). |
| **Data source** | Census TIGER/Line. |
| **URL / API** | **Download:** https://www.census.gov/cgi-bin/geo/shapefiles/index.php (by state/county). **TIGERweb REST:** for boundaries. Road geometry: shapefile or GeoJSON; compute distance in GIS. |
| **Refresh rate** | Annual. |
| **API framework** | Bulk shapefile/GeoJSON; no “distance to highway” API — derive with geopandas/shapely. |
| **FMV attributes supported** | `distance_to_nearest_highway_km`. |

---

## Quick Reference: API Keys and Python Packages

| Source | API key needed? | Python package / method |
|--------|------------------|--------------------------|
| Census ACS | Optional (higher limits with key) | `census` or `requests` |
| Census Geocoder | No | `requests` |
| FRED | Yes | `fredapi` |
| BLS | Optional | `requests` |
| OpenCelliD | Yes (free reg.) | `requests` |
| FCC ASR | No | `urllib`/`requests` + zip + parse |
| USGS 3DEP | No | `py3dep` |
| FEMA NFHL | No | `requests` or `geopandas` |
| HUD SAFMR | No | `requests` (ArcGIS query) |
| FHFA HPI | No | Bulk CSV download |
| WRLURI | No | Manual/download |

---

## Environment and data layout

- **API keys:** Copy **`.env.example`** to **`.env`** in the project root; do not commit `.env`. See **`docs/DATA_LOCATIONS_AND_UNIFIED_DATASET.md`** for data paths and the unified dataset.
- **Data locations and table joins:** **`docs/DATA_LOCATIONS_AND_UNIFIED_DATASET.md`** defines directory layout (`data/raw`, `data/processed`, `data/unified`), the site-level spine, join keys for each source, and how assimilation produces **one unified dataset** (`data/unified/sites_enriched.parquet`) for solutioning.

---

## File Manifest (Notebook)

The companion Jupyter notebook **`00_data_enrichment_sources.ipynb`** demonstrates:

1. **Census ACS** — fetch tract-level variables by state/tract.
2. **Census Geocoder** — address and coordinates → FIPS/tract.
3. **FRED** — CPI, 10Y Treasury, Fed Funds (fredapi).
4. **BLS** — LAUS county unemployment (requests POST).
5. **OpenCelliD** — cells in bounding box (requests GET; requires key).
6. **FCC ASR** — download weekly ASR registration zip and list contents (no key).
7. **USGS 3DEP** — point elevation via py3dep.
8. **FEMA NFHL** — query flood layer by extent (ArcGIS REST).
9. **HUD SAFMR** — query by state/ZIP (ArcGIS REST).

Environment: see `requirements.txt`; add `fredapi`, `census`, `py3dep`, `requests` as needed.
