from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder

inquiry_prompt = ChatPromptTemplate.from_messages([
    ("system", "Please respond to the user with the following message \\n"
              "The following feature is a work in progress, kindly reach out us om xyz@xyz.com for further support\\n"),
    MessagesPlaceholder(variable_name="chat_history"),
    ("user", "{user_input}"),
    MessagesPlaceholder(variable_name="agent_scratchpad")
])
