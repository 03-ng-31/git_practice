from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder

general_prompt = ChatPromptTemplate.from_messages([
    ("system", "If the user is greeting or thanking reply politely.\\n"
            "Other than 1.inquiry, 2.change email, 3. update address 4. Greetings 5.Goodbyes if the user says anything else respond with the following message \\n"
            "Sorry, stay within the functionality of the bot\\n"),
    MessagesPlaceholder(variable_name="chat_history"),
    ("user", "{user_input}"),
    MessagesPlaceholder(variable_name="agent_scratchpad")
])
