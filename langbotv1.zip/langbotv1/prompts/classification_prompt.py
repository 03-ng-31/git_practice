from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder

classification_prompt = ChatPromptTemplate.from_messages([
    ("system", "classify the user input into either of the three classes only \\n 1)inquiry\\n 2)change email\\n 3) update address \\n"
               "If neither of the above three classes then classify it as others\\n"
               "The output should adhere to the labels as mentioned above only\\n"
               "If you dont clearly understand, prompt the user to repeat again"),
    MessagesPlaceholder(variable_name="chat_history"),
    ("user", "{user_input}"),
    MessagesPlaceholder(variable_name="agent_scratchpad")
])
