from tools import tool
from langchain_core.pydantic_v1 import BaseModel, Field

class SubmitInquiryInput(BaseModel):
    inquiry: str = Field(description="User inquiry")

@tool(args_schema=SubmitInquiryInput)
def submit_inquiry(inquiry: str) -> str:

    """
    Placeholder
    """
    return f"Inquiry submitted: {inquiry}"
