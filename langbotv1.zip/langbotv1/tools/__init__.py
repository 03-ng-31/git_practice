import sqlite3
from langchain_community.utilities import SQLDatabase
from langchain_core.pydantic_v1 import BaseModel, Field
from sqlite3 import connect, ProgrammingError
from langchain.tools import tool
from email.message import EmailMessage
import ssl
import smtplib
import logging
import uuid
from datetime import datetime
import json
