from tools import tool, sqlite3, json, datetime, EmailMessage, uuid, smtplib, ssl, BaseModel, Field
import os
from dotenv import load_dotenv
# Load environment variables from .env file
load_dotenv(dotenv_path='credentials/.env')
smtp_username = os.getenv("SMTP_USERNAME")
smtp_password = os.getenv("SMTP_PASSWORD")

class AddressInput(BaseModel):
    contract_id: str = Field(description="Contract ID")

class UpdateAddressInput(AddressInput):
    street: str = Field(description="Street address")
    city: str = Field(description="City")
    state: str = Field(description="State")
    zip_code: str = Field(description="Zip code")

@tool(args_schema=AddressInput)
def get_addresses_by_contract_id(contract_id: str) -> str:
    """
    Retrieve all addresses associated with a given contract ID from the landlords database.
    """
    addresses = {}

    # Connect to the SQLite database using a context manager
    with sqlite3.connect('data/landlords.db') as conn:
        cursor = conn.cursor()
        
        # Fetch the list of addresses for the given contract ID
        cursor.execute('''
        SELECT Address FROM address WHERE Contract_ID = ?
        ''', (contract_id,))
        fetched_addresses = cursor.fetchall()
    
    # Check if no addresses were found
    if not fetched_addresses:
        return json.dumps({"message": "No addresses found for the given Contract ID."})

    # Convert addresses to a dictionary with numeric keys
    for i, (address,) in enumerate(fetched_addresses, start=1):
        addresses[i] = address
    
    # Convert dictionary to JSON format
    addresses_json = json.dumps(addresses)
    
    # Return the list of addresses
    return addresses_json

def update_address(contract_id: str, street: str, city: str, state: str, zip_code: str) -> dict:
    """
    Insert a new address row for the given contract ID with the current date and the last email ID.
    """
    full_address = f"{street}, {city}, {state}, {zip_code}"
    update_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    try:
        with sqlite3.connect('data/landlords.db') as conn:
            cursor = conn.cursor()

            # Retrieve the last email ID associated with the contract ID
            cursor.execute('''
            SELECT Email FROM address WHERE Contract_ID = ? ORDER BY Date_of_Updation DESC LIMIT 1
            ''', (contract_id,))
            email_row = cursor.fetchone()
            
            if not email_row:
                return {"message": "No email found for the given Contract ID."}

            last_email = email_row[0]

            # Insert the new address row
            cursor.execute('''
            INSERT INTO address (Contract_ID, Address, Date_of_Updation, Email)
            VALUES (?, ?, ?, ?)
            ''', (contract_id, full_address, update_date, last_email))
            
            conn.commit()

        return {"message": "Address updated successfully.", "email": last_email}

    except Exception as e:
        return {"message": f"Failed to update address: {e}"}

def send_confirmation_email(email_id: str) -> str:
    """
    Send a confirmation email to the new email address.
    """
    reference_id = str(uuid.uuid4())
    smtp_server = "smtp.gmail.com"
    smtp_port = 465
    smtp_username = smtp_username
    smtp_password = smtp_password

    subject = 'Address Change Confirmation'
    body = f"""\
    We have received your request for updating the address for your account. Kindly find your reference ID for further communications.

    Reference ID: {reference_id}

    If you did not request this change, please contact our support team immediately.

    Regards,
    Landlord Portal
    """

    instance = EmailMessage()
    instance["From"] = smtp_username
    instance["To"] = email_id
    instance["Subject"] = subject
    instance.set_content(body)
    
    context = ssl.create_default_context()
    try:
        with smtplib.SMTP_SSL(smtp_server, smtp_port, context=context) as smtp:
            smtp.login(smtp_username, smtp_password)
            smtp.sendmail(smtp_username, email_id, instance.as_string())
            return "Email sent successfully."
    except Exception as e:
        return f"Failed to send email: {e}"

@tool(args_schema=UpdateAddressInput)
def update_address_and_send_email(contract_id: str, street: str, city: str, state: str, zip_code: str):
    """
    Updates the address in the database for the given contract ID and sends a confirmation email if the update is successful."
    """
    try:
        update_result = update_address(contract_id, street, city, state, zip_code)

        if update_result["message"] == "Address updated successfully.":
            email_status = send_confirmation_email(update_result["email"])
            return {"message": update_result["message"], "email_status": email_status}
        else:
            return update_result
    except Exception as e:
        return {"message": f"An error occurred: {e}"}
