from tools import tool, sqlite3, json, datetime, EmailMessage, uuid, smtplib, ssl, BaseModel, Field
import logging
import os
from dotenv import load_dotenv
# Load environment variables from .env file
load_dotenv(dotenv_path='credentials/.env')
smtp_username = os.getenv("SMTP_USERNAME")
smtp_password = os.getenv("SMTP_PASSWORD")
# Configure logging
logging.basicConfig(level=logging.INFO)

class EmailDetails(BaseModel):
    """Extracts Entities such as Contract ID and Email ID from the user input."""
    contract_id: str = Field(description="Contract ID")
    email_id: str = Field(description="Email ID")

def update_email_in_db(contract_id: str, email_id: str) -> str:
    """
    Update the email address for a given contract ID in the database.
    """
    try:
        conn = sqlite3.connect('data/landlords.db')
        cursor = conn.cursor()
        sql = "UPDATE address SET Email = ? WHERE Contract_ID = ?"
        cursor.execute(sql, (email_id, contract_id))
        if cursor.rowcount == 0:
            return "Contract ID not found."
        else:
            conn.commit()
            return "Email address updated successfully."
    except sqlite3.OperationalError as e:
        return f"Failed to update email address: {e}"
    finally:
        conn.close()

def send_confirmation_email(email_id: str) -> str:
    """
    Send a confirmation email to the new email address.
    """
    reference_id = str(uuid.uuid4())
    smtp_server = "smtp.gmail.com"
    smtp_port = 465
    smtp_username = smtp_username
    smtp_password = smtp_password
    subject = 'LLP- Address Update'
    body = f"""\
    We have received your request for updating the Email address for your contract ID. Kindly find your reference ID for further communications.

    Reference ID: {reference_id}

    Regards,
    Landlord portal
    """

    instance = EmailMessage()
    instance["From"] = smtp_username
    instance["To"] = email_id
    instance["Subject"] = subject
    instance.set_content(body)
    
    context = ssl.create_default_context()
    try:
        with smtplib.SMTP_SSL(smtp_server, smtp_port, context=context) as smtp:
            smtp.login(smtp_username, smtp_password)
            smtp.sendmail(smtp_username, email_id, instance.as_string())
            return "Email sent successfully."
    except Exception as e:
        return f"Failed to send email: {e}"
    
@tool(args_schema=EmailDetails)
def update_email_and_notify(contract_id: str, email_id: str) -> str:
    """
    Update the email address for a given contract ID in the database and send a confirmation email.

    This function performs the following steps:
    1. Updates the email address associated with the provided contract ID in the database.
    2. Sends a confirmation email to the new email address if the update is successful.

    Returns:
        str: A message indicating the result of the operation.
    """
    # Update email in the database
    update_result = update_email_in_db(contract_id, email_id)
    if "successfully" in update_result:
        # Send confirmation email if update was successful
        email_result = send_confirmation_email(email_id)
        if "successfully" in email_result:
            return f"{update_result} and {email_result}"
        else:
            return f"{update_result} but {email_result}"
    else:
        return update_result
