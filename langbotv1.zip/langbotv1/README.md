
# Landlord Portal Support Bot

## Overview

The Landlord Portal Support Bot is an AI-powered chatbot designed to assist users with common tasks related to managing landlord information, 
such as updating addresses and email addresses. The bot is built using the LangChain framework and leverages OpenAI's language models for natural language understanding and generation.

## Features

- **Address Management**:
  - Retrieve all addresses associated with a given contract ID.
  - Update the address for a given contract ID and send a confirmation email.
  
- **Email Management**:
  - Update the email address for a given contract ID and send a confirmation email.
  
- **Inquiry Handling**:
  - Respond to general inquiries with a placeholder response.

## Project Structure

```
LLP Chatbot/
├── agents/
│   ├── __init__.py
│   ├── classification_agent.py
│   ├── general_agent.py
│   ├── inquiry_agent.py
│   ├── address_agent.py
│   ├── email_update_agent.py
├── prompts/
│   ├── __init__.py
│   ├── replace_address_prompt.py
│   ├── update_email_address_prompt.py
│   ├── classification_prompt.py
│   ├── inquiry_prompt.py
│   ├── general_prompt.py
├── tools/
│   ├── __init__.py
│   ├── address_tools.py
│   ├── email_tools.py
│   ├── inquiry_tools.py
├── data/
│   ├── landlords.db
├── credentials/
│   ├── .env
├── initialize_db.py
└── main.py
```

### Components

- **Agents**: Contains the agents responsible for handling different types of user inputs and managing the conversation flow.
- **Prompts**: Contains the prompt templates used by the agents to interact with the users.
- **Tools**: Contains the tools used by the agents to perform specific tasks such as querying the database and sending emails.
- **Data**: Contains the SQLite database file (`landlords.db`) with the landlord data.
- **Credentials**: Contains the `.env` file with environment variables for sensitive information such as API keys and SMTP credentials.
- **initialize_db.py**: Script to initialize the SQLite database with dummy data.
- **main.py**: The main script to run the chatbot.

## Setup
    ```

1. **Install dependencies**:
    ```sh
    pip install -r requirements.txt
    ```

2. **Setup environment variables**:
    Create a `.env` file in the `credentials` directory with the following content:
    ```env
    LANGCHAIN_TRACING_V2=true
    LANGCHAIN_API_KEY=your_langchain_api_key
    OPENAI_API_KEY=your_openai_api_key
    SMTP_USERNAME=your_smtp_username
    SMTP_PASSWORD=your_smtp_password
    ```

3. **Initialize the database**:
    ```sh
    python initialize_db.py
    ```

4. **Run the chatbot**:
    ```sh
    python main.py
    ```

## Usage

The chatbot will start and wait for user input. You can interact with the bot by entering commands related to address and email management. To exit the chatbot, type `exit` or `bye`.

## Further Improvements

- **Enhance Natural Language Understanding**:
  - Improve the prompt templates and add more examples to handle a wider variety of user inputs.
  - Implement a more robust classification system to better understand user intents.

- **Database Management**:
  - Add more comprehensive error handling and validation for database operations.
  - Implement database migration scripts for easier updates and maintenance.

- **User Interface**:
  - Develop a web or mobile interface to provide a more user-friendly experience.
  - Integrate with popular messaging platforms like Slack or Microsoft Teams.

- **Functionality Expansion**:
  - Add support for additional tasks such as retrieving account details, managing rental payments, and more.
  - Implement user authentication and authorization for secure access to sensitive information.

- **Performance Optimization**:
  - Optimize database queries and improve the overall performance of the bot.
  - Implement caching mechanisms to reduce the response time for frequently accessed data.
