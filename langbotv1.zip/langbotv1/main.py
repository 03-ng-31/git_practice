import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv(dotenv_path='credentials/.env')
# Access the environment variables
openai_api_key = os.getenv("OPENAI_API_KEY")
smtp_username = os.getenv("SMTP_USERNAME")
smtp_password = os.getenv("SMTP_PASSWORD")
print("OpenAI API Key:", openai_api_key)
print("SMTP Username:", smtp_username)

from agents.classification_agent import classification_agent
from agents.general_agent import general_agent
from agents.inquiry_agent import inquiry_agent
from agents.address_agent import address_agent_executor
from agents.email_update_agent import email_update_agent_executor_chain
from langchain_core.runnables import RunnableBranch

branch = RunnableBranch(
    (lambda x: "update address" in x["output"].lower(), lambda x: address_agent_executor.invoke({"user_input": x['user_input']})),
    (lambda x: "change email" in x["output"].lower(), lambda x: email_update_agent_executor_chain.invoke({"user_input": x['user_input']})),
    (lambda x: "inquiry" in x["output"].lower(), lambda x: inquiry_agent.invoke({"user_input": x['user_input']})),
    lambda x: general_agent.invoke({"user_input": x['user_input']})
)

full_chain = classification_agent | branch

while True:
    user_input = input()
    if user_input in ['exit', 'bye']:
        break
    else:
        response = full_chain.invoke({"user_input": user_input})
        print(response)
