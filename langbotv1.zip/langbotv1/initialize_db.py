import sqlite3

def create_database():
    conn = sqlite3.connect('data/landlords.db')
    cursor = conn.cursor()

    # Create the table with an alphanumeric Contract_ID of at least 10 characters and an Email column
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS address (
        Contract_ID TEXT,
        Date_of_Updation TEXT,
        Address TEXT,
        Email TEXT
    )
    ''')

    # Insert dummy data with alphanumeric Contract_ID (at least 10 characters) and unique emails for each Contract_ID
    dummy_data = [
        ('A1B2C3D4E5', '2024-01-01', '123 Main St, Springfield', 'email1@example.com'),
        ('A1B2C3D4E5', '2024-02-01', '124 Main St, Springfield', 'email1@example.com'),
        ('F6G7H8I9J0', '2024-01-15', '456 Elm St, Shelbyville', 'email2@example.com'),
        ('F6G7H8I9J0', '2024-03-20', '457 Elm St, Shelbyville', 'email2@example.com'),
        ('K1L2M3N4O5', '2024-02-10', '789 Maple St, Capital City', 'email3@example.com'),
        ('P6Q7R8S9T0', '2024-04-05', '321 Oak St, Springfield', 'email4@example.com'),
        ('U1V2W3X4Y5', '2024-05-15', '654 Pine St, Shelbyville', 'email5@example.com'),
        ('Z1Y2X3W4V5', '2024-06-01', '987 Cedar St, Springfield', 'email6@example.com'),
        ('T6S5R4Q3P2', '2024-07-20', '741 Birch St, Shelbyville', 'email7@example.com'),
        ('N8M7L6K5J4', '2024-08-15', '852 Maple St, Capital City', 'email8@example.com'),
        ('I9H8G7F6E5', '2024-09-10', '963 Elm St, Springfield', 'email9@example.com'),
        ('D4C3B2A1Z0', '2024-10-05', '159 Oak St, Shelbyville', 'email10@example.com'),
        ('X1W2V3U4T5', '2024-11-15', '753 Pine St, Springfield', 'email11@example.com'),
        ('R5Q6P7O8N9', '2024-12-25', '246 Cedar St, Shelbyville', 'email12@example.com'),
        ('M3L2K1J0H9', '2025-01-30', '357 Birch St, Capital City', 'email13@example.com'),
        ('G8F7E6D5C4', '2025-02-14', '468 Maple St, Springfield', 'email14@example.com'),
        ('B2A1Z0Y9X8', '2025-03-10', '579 Elm St, Shelbyville', 'email15@example.com'),
        ('W3V4U5T6S7', '2025-04-05', '680 Oak St, Capital City', 'email16@example.com'),
        ('Q6P7O8N9M0', '2025-05-20', '791 Pine St, Springfield', 'email17@example.com')
    ]

    # Insert data into the table
    cursor.executemany('''
    INSERT INTO address (Contract_ID, Date_of_Updation, Address, Email)
    VALUES (?, ?, ?, ?)
    ''', dummy_data)

    # Commit the changes and close the connection
    conn.commit()
    conn.close()

if __name__ == "__main__":
    create_database()
    print("Database initialized successfully.")
