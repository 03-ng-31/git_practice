from agents import (
    AgentExecutor,
    RunnablePassthrough,
    ChatOpenAI,
    ConversationBufferMemory,
    format_tool_to_openai_function,
    OpenAIFunctionsAgentOutputParser,
    format_to_openai_functions
)
from prompts.update_email_address_prompt import update_email_address_prompt
from tools.email_tools import update_email_and_notify

import os
from dotenv import load_dotenv
# Load environment variables from .env file
load_dotenv(dotenv_path='credentials/.env')
openai_api_key = os.getenv("OPENAI_API_KEY")
print('ea.openai_api_key'+ str(openai_api_key))

email_update_tools = [update_email_and_notify]
email_update_functions = [format_tool_to_openai_function(f) for f in email_update_tools]
email_update_model = ChatOpenAI(model="gpt-4o-mini",temperature=0,max_retries=2,api_key=openai_api_key).bind(functions=email_update_functions)
output_parser = OpenAIFunctionsAgentOutputParser()

update_email_address_chain = RunnablePassthrough.assign(
    agent_scratchpad=lambda x: format_to_openai_functions(x["intermediate_steps"])
) | update_email_address_prompt | email_update_model | output_parser

email_update_memory = ConversationBufferMemory(return_messages=True, memory_key="chat_history")
email_update_agent_executor_chain = AgentExecutor(agent=update_email_address_chain, tools=email_update_tools, verbose=True, memory=email_update_memory)
