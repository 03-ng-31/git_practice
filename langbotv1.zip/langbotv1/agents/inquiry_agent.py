from agents import (
    AgentExecutor,
    RunnablePassthrough,
    ChatOpenAI,
    ConversationBufferMemory,
    format_tool_to_openai_function,
    OpenAIFunctionsAgentOutputParser,
    format_to_openai_functions
)

from prompts.inquiry_prompt import inquiry_prompt
from tools.inquiry_tools import submit_inquiry

import os
from dotenv import load_dotenv
# Load environment variables from .env file
load_dotenv(dotenv_path='credentials/.env')
openai_api_key = os.getenv("OPENAI_API_KEY")
print('ia.openai_api_key'+ str(openai_api_key))

inquiry_tools = [submit_inquiry]
inquiry_model = ChatOpenAI(model="gpt-4o-mini",temperature=0,max_retries=2,api_key=openai_api_key).bind(functions=inquiry_tools)
output_parser = OpenAIFunctionsAgentOutputParser()

inquiry_chain = RunnablePassthrough.assign(
    agent_scratchpad=lambda x: format_to_openai_functions(x["intermediate_steps"])
) | inquiry_prompt | inquiry_model | output_parser

inquiry_memory = ConversationBufferMemory(return_messages=True, memory_key="chat_history")
inquiry_agent = AgentExecutor(agent=inquiry_chain, tools=inquiry_tools, verbose=True, memory=inquiry_memory)

