from agents import (
    AgentExecutor,
    RunnablePassthrough,
    ChatOpenAI,
    ConversationBufferMemory,
    format_tool_to_openai_function,
    OpenAIFunctionsAgentOutputParser,
    format_to_openai_functions
)
from prompts.general_prompt import general_prompt

import os
from dotenv import load_dotenv
# Load environment variables from .env file
load_dotenv(dotenv_path='credentials/.env')
openai_api_key = os.getenv("OPENAI_API_KEY")
print('ga.openai_api_key'+ str(openai_api_key))

general_tools = []
general_model = ChatOpenAI(model="gpt-4o-mini",temperature=0,max_retries=2,api_key=openai_api_key)
output_parser = OpenAIFunctionsAgentOutputParser()

general_chain = RunnablePassthrough.assign(
    agent_scratchpad=lambda x: format_to_openai_functions(x["intermediate_steps"])
) | general_prompt | general_model | output_parser

general_memory = ConversationBufferMemory(return_messages=True, memory_key="chat_history")
general_agent = AgentExecutor(agent=general_chain, tools=general_tools, verbose=True, memory=general_memory)

