from agents import (
    AgentExecutor,
    RunnablePassthrough,
    ChatOpenAI,
    ConversationBufferMemory,
    format_tool_to_openai_function,
    OpenAIFunctionsAgentOutputParser,
    format_to_openai_functions
)
from prompts.replace_address_prompt import replace_address_prompt
from tools.address_tools import get_addresses_by_contract_id, update_address_and_send_email
import os
from dotenv import load_dotenv
# Load environment variables from .env file
load_dotenv(dotenv_path='credentials/.env')
openai_api_key = os.getenv("OPENAI_API_KEY")
print('aa.openai_api_key'+ str(openai_api_key))

address_tools = [get_addresses_by_contract_id, update_address_and_send_email]
address_update_functions = [format_tool_to_openai_function(f) for f in address_tools]
address_model = ChatOpenAI(model="gpt-4o-mini",temperature=0,max_retries=2,api_key=openai_api_key).bind(functions=address_update_functions)
output_parser = OpenAIFunctionsAgentOutputParser()

update_address_chain = RunnablePassthrough.assign(
    agent_scratchpad=lambda x: format_to_openai_functions(x["intermediate_steps"])
) | replace_address_prompt | address_model | output_parser

address_memory = ConversationBufferMemory(return_messages=True, memory_key="chat_history")
address_agent_executor = AgentExecutor(agent=update_address_chain, tools=address_tools, verbose=True, memory=address_memory)
