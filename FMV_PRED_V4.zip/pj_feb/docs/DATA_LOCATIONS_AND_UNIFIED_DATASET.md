# Data Locations and Unified Dataset — Cell-Site FMV

This document defines **where data lives**, **how tables join**, and **how we build one unified dataset** for downstream modeling and solutioning.

---

## 1. Data directory layout

All paths are relative to the **project root** (`pj_feb/`). Notebooks run with `cwd` = project root or `notebooks/`; use `../data/` or a config-based root when needed.

```
pj_feb/
├── .env                    # API keys (from .env.example) — do not commit
├── .env.example            # Template for API keys
├── data/
│   ├── raw/                # Raw downloads (FCC zips, FHFA CSV, etc.)
│   │   ├── fcc/
│   │   │   ├── r_tower.zip
│   │   │   ├── a_tower.zip
│   │   │   └── d_tower.zip
│   │   ├── fhfa/
│   │   │   └── hpi_*.csv
│   │   └── wrluri/
│   │       └── w26573_data_appendix.*
│   │
│   ├── processed/          # One table per source (cleaned, keyed for join)
│   │   ├── spine_sites.parquet      # Site-level spine (see below)
│   │   ├── acs_tract.parquet       # Census ACS by tract
│   │   ├── census_geocode.parquet   # Optional: pre-geocoded site → tract
│   │   ├── fcc_asr.parquet          # FCC ASR tower records
│   │   ├── opencellid_*.parquet     # OpenCelliD cells/aggregates by area
│   │   ├── fred_macro.parquet       # FRED series (date × series_id × value)
│   │   ├── bls_laus.parquet         # BLS LAUS by county/MSA × date
│   │   ├── hud_safmr.parquet        # HUD SAFMR by ZCTA
│   │   ├── fhfa_hpi.parquet         # FHFA HPI by geography × date
│   │   ├── fema_flood.parquet       # FEMA flood zone by geometry/ID
│   │   ├── usgs_elevation.parquet   # Point elevations (site_id or lat/lon)
│   │   └── wrluri.parquet           # WRLURI by jurisdiction (if used)
│   │
│   ├── unified/            # Single table for modeling
│   │   └── sites_enriched.parquet   # One row per site, all attributes joined
│   │
│   └── synthetic/          # Synthetic data for dev/sims
│       └── synthetic_5k_sites.parquet
│
├── docs/
├── notebooks/
└── ...
```

**Convention:** Scripts that **fetch** write to `data/raw/` or directly to `data/processed/` after cleaning. The **assimilation** step reads from `data/processed/` and writes `data/unified/sites_enriched.parquet`.

---

## 2. The spine: site-level master

The **spine** is the one table that every other dataset joins to. It has **one row per cell site** and the minimal keys needed to attach geography and external IDs.

**Recommended spine columns:**

| Column | Type | Description |
|--------|------|-------------|
| `site_id` | str | Primary key (internal or from lease system) |
| `latitude` | float | WGS84 |
| `longitude` | float | WGS84 |
| `address` | str | Optional; used for geocoding if no lat/lon |
| `state_fips` | str | 2-digit FIPS (for state-level joins) |
| `county_fips` | str | 5-digit FIPS (state+county) |
| `tract_fips` | str | 11-digit FIPS (state+county+tract) — **main join key for ACS** |
| `zip_code` | str | ZIP or ZCTA — for HUD SAFMR, FHFA HPI |
| `asr_number` | str | FCC ASR registration number (if known) — for FCC ASR join |
| `as_of_date` | date | Optional; snapshot date for time-varying joins |

**Where the spine comes from:** Internal lease/site master (contract & payments domain). For synthetic runs, the spine is the synthetic site table (e.g. `data/synthetic/synthetic_5k_sites.parquet`) after adding `tract_fips` and optionally `zip_code` via **Census Geocoder** (lat/lon → tract, ZIP).

**Output:** Spine is stored as `data/processed/spine_sites.parquet` (or the synthetic file is treated as the spine when not using real internal data).

---

## 3. Table joins — how each source attaches to the spine

Join order and keys:

| # | Source | Processed table | Join key(s) | Join type | Notes |
|---|--------|------------------|-------------|-----------|--------|
| 1 | **Spine** | `spine_sites.parquet` | — | — | Base table; one row per site. |
| 2 | Census ACS | `acs_tract.parquet` | `tract_fips` | left | Tract-level demographics; spine must have `tract_fips` (from geocoder). |
| 3 | BLS LAUS | `bls_laus.parquet` | `county_fips` (+ optional date) | left | County unemployment; build county_fips from spine. |
| 4 | HUD SAFMR | `hud_safmr.parquet` | `zip_code` (or ZCTA) | left | SAFMR by bedroom count; align ZIP to ZCTA if needed. |
| 5 | FHFA HPI | `fhfa_hpi.parquet` | `zip_code` or CBSA + `as_of_date` | left | Time-series; join on geography + date. |
| 6 | FRED | `fred_macro.parquet` | — | cross / broadcast | National/monthly; no site key — attach same macro row to all sites (or by date only). |
| 7 | FCC ASR | `fcc_asr.parquet` | `asr_number` or nearest-tower match | left | If spine has ASR number, direct join; else spatial match (nearest tower to lat/lon). |
| 8 | OpenCelliD | (aggregates) | `latitude`/`longitude` or bbox | left | Pre-aggregate counts by tract or small grid; join spine to grid/tract. |
| 9 | FEMA flood | `fema_flood.parquet` | Point-in-polygon (lat/lon) | left | Spatial: site (lat, lon) in flood zone polygon → zone code. |
| 10 | USGS elevation | `usgs_elevation.parquet` | `site_id` or (lat, lon) | left | Point elevation per site. |
| 11 | WRLURI | `wrluri.parquet` | jurisdiction (e.g. county or place) | left | If available by county/place; join on county_fips or place FIPS. |

**Critical join keys:**

- **Tract** → `tract_fips`: ACS, and optionally OpenCelliD/FEMA if aggregated to tract.
- **County** → `county_fips`: BLS LAUS, WRLURI (if county-level).
- **ZIP/ZCTA** → `zip_code`: HUD SAFMR, FHFA HPI (ZIP).
- **Time** → `as_of_date` (or observation date): FRED, BLS, FHFA so that macro/time-series align to the snapshot or forecast period.
- **FCC** → `asr_number` or spatial match: FCC ASR.
- **Spatial** → (lat, lon): FEMA (point-in-polygon), elevation (point), OpenCelliD (pre-aggregated to area).

---

## 4. Assimilation flow: from raw/processed to one unified dataset

High-level steps:

1. **Spine**
   - Input: Internal site master or `data/synthetic/synthetic_5k_sites.parquet`.
   - Enrich spine with `tract_fips`, `zip_code` (and optionally `county_fips`) via **Census Geocoder** (lat/lon → geographies).
   - Write `data/processed/spine_sites.parquet`.

2. **Fetch and write processed tables**
   - Run ingestion (notebook `00_data_enrichment_sources.ipynb` or equivalent scripts):
     - Census ACS → `data/processed/acs_tract.parquet` (key: tract_fips).
     - BLS LAUS → `data/processed/bls_laus.parquet` (key: county_fips, date).
     - HUD SAFMR → `data/processed/hud_safmr.parquet` (key: zip_code / ZCTA).
     - FHFA HPI → `data/processed/fhfa_hpi.parquet` (key: geography, date).
     - FRED → `data/processed/fred_macro.parquet` (date, series_id, value).
     - FCC ASR → `data/processed/fcc_asr.parquet` (asr_number, lat, lon, height, status, …).
     - OpenCelliD → aggregate to tract or grid → `data/processed/opencellid_*.parquet`.
     - FEMA → point-in-polygon or pre-joined by tract → `data/processed/fema_flood.parquet`.
     - USGS → elevation by site or (lat, lon) → `data/processed/usgs_elevation.parquet`.

3. **Unified join (single pipeline)**
   - Start with `spine_sites.parquet`.
   - Left-join in order (or in one merge tree):
     - ACS on `tract_fips`
     - BLS on `county_fips` (+ date if time-varying)
     - HUD SAFMR on `zip_code`
     - FHFA on `zip_code` (or CBSA) + date
     - FRED: add macro columns by date (no site key)
     - FCC ASR on `asr_number` or spatial
     - OpenCelliD aggregates on tract or spatial key
     - FEMA on site_id or (lat, lon) if pre-joined
     - USGS elevation on site_id or (lat, lon)
   - Result: **one row per site**, all attributes in one table.

4. **Write unified dataset**
   - Output: `data/unified/sites_enriched.parquet`.
   - Use this file for EDA (e.g. `01_eda.ipynb`), clustering, modeling, and forecasting.

---

## 5. Unified dataset schema (summary)

**Path:** `data/unified/sites_enriched.parquet`

**Grain:** One row per cell site (same as spine).

**Columns (conceptual groups):**

- **Identity:** `site_id`, `latitude`, `longitude`, `address`, `state_fips`, `county_fips`, `tract_fips`, `zip_code`, `asr_number`, `as_of_date`
- **Contract / internal (if present):** lease terms, base rent, escalator, term dates, etc.
- **Demographics (ACS):** `census_population`, `census_median_income`, `census_median_home_value`, `census_median_rent`, `census_vacancy_rate`, …
- **Macro (FRED/BLS):** `cpi_all_urban`, `treasury_10yr_yield`, `unemployment_rate_local`, …
- **Local housing (HUD/FHFA):** `hud_safmr`, `fhfa_hpi`, …
- **Physical (FCC/USGS):** `tower_height_ft`, `structure_type`, `ground_elevation_ft`, `fcc_asr_status`, …
- **Competition / network (FCC/OpenCelliD):** `fcc_tower_count`, `opencellid_tower_density`, `opencellid_tech_distribution`, …
- **Hazard (FEMA):** flood zone, or composite hazard flag.
- **Zoning (WRLURI if used):** `wrluri_index`, …

Exact column names should match the **Cell-Site FMV Data Dictionary** and the attribute list in `docs/DATA_DICTIONARY_OPEN_SOURCES.md`.

---

## 6. Configuration and .env

- **API keys** are read from a **`.env`** file in the project root.
- **Copy** `.env.example` to `.env` and fill in keys (see `.env.example` for which keys are needed).
- **Do not commit** `.env` (it is in `.gitignore`).
- **Data paths** can be set in a config (e.g. `configs/model_config.yaml`) or as constants at the top of the assimilation script:

  - `DATA_ROOT = "data"`
  - `RAW_DIR = "data/raw"`
  - `PROCESSED_DIR = "data/processed"`
  - `UNIFIED_DIR = "data/unified"`
  - `UNIFIED_FILE = "data/unified/sites_enriched.parquet"`

This keeps the **location of the data** and the **unified dataset** explicit and consistent across notebooks and scripts.

---

## 7. Automated ingestion pipeline (no manual download)

Data is **ingested in real time** (on each run) via APIs or bulk download — no manual download required.

### Run the pipeline

From the **project root**:

```bash
# Ingest all enabled sources (see configs/ingestion_config.yaml)
python scripts/ingest_data.py

# Ingest only selected sources
python scripts/ingest_data.py --sources census_acs,fred,bls,hud_safmr

# After ingest, build the unified table
python scripts/ingest_data.py --build-unified

# Ingest all then build unified in one go
python scripts/ingest_data.py --sources census_acs,fred,bls,fcc_asr,hud_safmr,fema_flood,fhfa_hpi --build-unified
```

### What runs per source

| Source | Method | Output | Refresh note |
|--------|--------|--------|--------------|
| Census ACS | REST API (loop states) | `processed/acs_tract.parquet` | Annual; run weekly or on-demand |
| FRED | `fredapi` (API key) | `processed/fred_macro.parquet` | Monthly/daily; run daily |
| BLS LAUS | REST POST (state-level) | `processed/bls_laus.parquet` | Monthly; run monthly |
| FCC ASR | HTTP download zip | `raw/fcc/*.zip` + optional `processed/fcc_asr.parquet` | Weekly full; run weekly |
| HUD SAFMR | ArcGIS REST query | `processed/hud_safmr.parquet` | Annual; run quarterly |
| FEMA NFHL | ArcGIS REST query | `processed/fema_flood.parquet` | Updated continuously; run monthly |
| FHFA HPI | HTTP download zip/CSV | `raw/fhfa/` + `processed/fhfa_hpi.parquet` | Quarterly; run quarterly |

### Configuration

- **API keys:** `.env` (see `.env.example`). Required for FRED; optional for Census/BLS; OpenCelliD optional and not in default pipeline.
- **Which sources run:** `configs/ingestion_config.yaml` → `sources.census_acs`, `sources.fred`, etc. (true/false).
- **ACS year, FRED series, FCC URLs:** same file under `census_acs`, `fred`, `fcc_asr`, `fhfa_hpi`.

### Scheduling (real-time / automated refresh)

Run the pipeline on a schedule so data stays current without manual steps:

- **Windows (Task Scheduler):** Create a task that runs `python C:\path\to\pj_feb\scripts\ingest_data.py` daily (or weekly). Set "Start in" to project root; use same Python env as notebooks.
- **Linux / macOS (cron):**  
  - Daily macro (FRED, BLS): `0 6 * * * cd /path/to/pj_feb && python scripts/ingest_data.py --sources fred,bls`  
  - Weekly full ingest: `0 6 * * 0 cd /path/to/pj_feb && python scripts/ingest_data.py --build-unified`
- **CI/CD:** Add a job that runs `scripts/ingest_data.py` (and optionally `--build-unified`) on a schedule; ensure `.env` is available (secrets).

After each run, **processed** and **unified** paths are updated; downstream notebooks (EDA, modeling, forecasting) read from `data/processed/` and `data/unified/sites_enriched.parquet` with no manual download.
