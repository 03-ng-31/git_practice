import json
with open("notebooks/06_census_api_test_and_map_executed.ipynb", "r", encoding="utf-8") as f:
    nb = json.load(f)

cc = [c for c in nb["cells"] if c["cell_type"] == "code"]

# Print stream output for FRED cells (cells 14-18 = indices 27-31 in code cells)
# and OpenCelliD cells and final summary
# Just check the last ~10 code cells which are the new ones
for i in range(max(0, len(cc)-12), len(cc)):
    c = cc[i]
    src = c.get("source", "")
    if isinstance(src, list):
        src = "".join(src)
    first_line = src.split("\n")[0][:70]
    stream = ""
    for o in c.get("outputs", []):
        if o.get("output_type") == "stream":
            stream += "".join(o.get("text", []))
    short = stream[:500].strip()
    print(f"\n=== Code Cell {i} ===")
    print(f"  {first_line}")
    if short:
        for line in short.split("\n")[:10]:
            print(f"  {line}")
    else:
        has_display = any(o.get("output_type") == "display_data" for o in c.get("outputs", []))
        print(f"  [{'chart/display output' if has_display else 'no output'}]")
