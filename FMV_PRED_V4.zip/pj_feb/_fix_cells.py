import json

with open("notebooks/06_census_api_test_and_map.ipynb", "r", encoding="utf-8") as f:
    nb = json.load(f)

# Fix 1: Update FRED ZCTA mapping cell (currently says "ZCTA geo data not available")
# Find the cell with "Map 12: FRED Unemployment mapped to ZIP code level"
for i, c in enumerate(nb["cells"]):
    src = c.get("source", "")
    if isinstance(src, list):
        src = "".join(src)
    if "Map 12: FRED Unemployment mapped to ZIP code level" in src:
        c["source"] = (
            '# ---- Map 12: FRED Unemployment mapped to ZIP code level ----\n'
            '# Map state unemployment to each ZCTA using Gazetteer state column\n'
            '# The Gazetteer df_gaz was loaded in section 7 (ZCTA centroid download)\n'
            '\n'
            'try:\n'
            '    gaz_cols = df_gaz.columns.tolist()\n'
            '    # Find state abbreviation column in Gazetteer\n'
            '    state_col = None\n'
            '    for col in gaz_cols:\n'
            '        if col.upper() in ("USPS", "STATE"):\n'
            '            state_col = col\n'
            '            break\n'
            '    \n'
            '    if state_col:\n'
            '        df_zcta_state = df_gaz[["zcta", state_col, "lat", "lon"]].copy()\n'
            '        df_zcta_state.rename(columns={state_col: "state_abbr"}, inplace=True)\n'
            '        df_zcta_state["state_abbr"] = df_zcta_state["state_abbr"].str.strip()\n'
            '    else:\n'
            '        print("Gazetteer columns:", gaz_cols)\n'
            '        raise ValueError("No state column found in Gazetteer")\n'
            '    \n'
            '    # Merge unemployment rates onto ZCTAs\n'
            '    df_zcta_ur = df_zcta_state.merge(df_state_ur, on="state_abbr", how="inner")\n'
            '    df_zcta_ur = df_zcta_ur.merge(\n'
            '        df_zcta[["zcta", "population", "median_income"]],\n'
            '        on="zcta", how="inner"\n'
            '    )\n'
            '    # Filter to continental US\n'
            '    df_zcta_ur = df_zcta_ur[\n'
            '        (df_zcta_ur["lat"].between(24, 50)) &\n'
            '        (df_zcta_ur["lon"].between(-125, -66)) &\n'
            '        (df_zcta_ur["population"] > 0)\n'
            '    ].copy()\n'
            '    \n'
            '    print(f"Mapped FRED unemployment to {len(df_zcta_ur):,} ZCTAs")\n'
            '    \n'
            '    fig_zcta_ur = px.scatter_geo(\n'
            '        df_zcta_ur,\n'
            '        lat="lat", lon="lon",\n'
            '        color="unemployment_rate",\n'
            '        size="population",\n'
            '        size_max=7,\n'
            '        hover_data={\n'
            '            "zcta": True,\n'
            '            "state_abbr": True,\n'
            '            "unemployment_rate": ":.1f",\n'
            '            "population": ":,.0f",\n'
            '            "median_income": ":$,.0f",\n'
            '            "lat": False, "lon": False,\n'
            '        },\n'
            '        color_continuous_scale="RdYlGn_r",\n'
            '        scope="usa",\n'
            '        title=f"FRED State Unemployment Mapped to ZIP Code Level -- {len(df_zcta_ur):,} ZCTAs",\n'
            '        labels={"unemployment_rate": "Unemp Rate (%)", "zcta": "ZCTA"},\n'
            '        opacity=0.5,\n'
            '    )\n'
            '    fig_zcta_ur.update_layout(\n'
            '        geo=dict(bgcolor="rgba(0,0,0,0)", lakecolor="rgb(200,220,240)"),\n'
            '        margin=dict(l=0, r=0, t=50, b=0),\n'
            '        width=1100, height=650,\n'
            '    )\n'
            '    fig_zcta_ur.show()\n'
            'except NameError:\n'
            '    print("df_gaz not available -- make sure to run ZCTA section (Section 7) first")\n'
            'except Exception as e:\n'
            '    print(f"Error mapping FRED to ZCTA: {e}")\n'
        )
        c["outputs"] = []
        c["execution_count"] = None
        print(f"Fixed cell {i}: FRED ZCTA mapping")
        break

# Fix 2: Update OpenCelliD cell with smaller bounding boxes and BBOX parameter
for i, c in enumerate(nb["cells"]):
    src = c.get("source", "")
    if isinstance(src, list):
        src = "".join(src)
    if "OpenCelliD: Pull cell towers for major US metro areas" in src:
        c["source"] = (
            '# ---- OpenCelliD: Pull cell towers for major US metro areas ----\n'
            'import time as _time\n'
            '\n'
            'OPENCELLID_API_KEY = os.environ.get("OPENCELLID_API_KEY", "")\n'
            'print("OpenCelliD API key:", "SET" if OPENCELLID_API_KEY else "NOT SET")\n'
            '\n'
            'all_towers = []\n'
            'df_towers = pd.DataFrame()\n'
            '\n'
            'if not OPENCELLID_API_KEY:\n'
            '    print("Set OPENCELLID_API_KEY in .env to run this section")\n'
            'else:\n'
            '    # OpenCelliD limits bbox to ~4 sq km (~0.02 x 0.02 degrees)\n'
            '    # Use small downtown bboxes centered on major metros\n'
            '    # Each bbox is ~0.01 lat x 0.01 lon (approx 1km x 1km)\n'
            '    metro_bboxes = [\n'
            '        ("NYC - Midtown",        40.748, -73.990, 40.758, -73.980),\n'
            '        ("NYC - Downtown",       40.708, -74.015, 40.718, -74.005),\n'
            '        ("LA - Downtown",        34.047, -118.260, 34.057, -118.250),\n'
            '        ("LA - Hollywood",       34.098, -118.340, 34.108, -118.330),\n'
            '        ("Chicago - Loop",       41.878, -87.635, 41.888, -87.625),\n'
            '        ("Chicago - North",      41.940, -87.655, 41.950, -87.645),\n'
            '        ("Houston - Downtown",   29.755, -95.370, 29.765, -95.360),\n'
            '        ("Phoenix - Downtown",   33.445, -112.080, 33.455, -112.070),\n'
            '        ("Philly - Center",      39.950, -75.170, 39.960, -75.160),\n'
            '        ("Dallas - Downtown",    32.775, -96.802, 32.785, -96.792),\n'
            '        ("SF - Financial",       37.790, -122.405, 37.800, -122.395),\n'
            '        ("DC - Capitol",         38.888, -77.015, 38.898, -77.005),\n'
            '        ("Miami - Downtown",     25.770, -80.200, 25.780, -80.190),\n'
            '        ("Atlanta - Downtown",   33.748, -84.395, 33.758, -84.385),\n'
            '        ("Boston - Downtown",    42.355, -71.065, 42.365, -71.055),\n'
            '    ]\n'
            '    \n'
            '    url_oci = "https://opencellid.org/cell/getInArea"\n'
            '    \n'
            '    print(f"\\nFetching cell towers for {len(metro_bboxes)} metro areas...")\n'
            '    print("(Using ~1km x 1km bounding boxes -- OpenCelliD limit is ~4 sq km)\\n")\n'
            '    \n'
            '    for name, min_lat, min_lon, max_lat, max_lon in metro_bboxes:\n'
            '        bbox_str = f"{min_lat},{min_lon},{max_lat},{max_lon}"\n'
            '        params_oci = {"key": OPENCELLID_API_KEY, "BBOX": bbox_str, "format": "json", "limit": 1000}\n'
            '        try:\n'
            '            r_oci = requests.get(url_oci, params=params_oci, timeout=30)\n'
            '            if r_oci.status_code == 200:\n'
            '                data_oci = r_oci.json()\n'
            '                if "error" in data_oci:\n'
            '                    print(f"  [ERR] {name:25s} | {data_oci[\'error\']}")\n'
            '                    continue\n'
            '                cells_list = data_oci.get("cells", data_oci if isinstance(data_oci, list) else [])\n'
            '                for cell in cells_list:\n'
            '                    cell["metro"] = name\n'
            '                all_towers.extend(cells_list)\n'
            '                radios = pd.Series([c.get("radio", "") for c in cells_list]).value_counts()\n'
            '                radio_str = ", ".join([f"{k}:{v}" for k, v in radios.items()])\n'
            '                print(f"  [OK] {name:25s} | {len(cells_list):>4} towers | {radio_str}")\n'
            '            else:\n'
            '                print(f"  [ERR] {name:25s} | HTTP {r_oci.status_code}: {r_oci.text[:100]}")\n'
            '        except Exception as e:\n'
            '            print(f"  [ERR] {name:25s} | {e}")\n'
            '        _time.sleep(1)  # Rate limit courtesy\n'
            '    \n'
            '    print(f"\\nTotal towers retrieved: {len(all_towers)}")\n'
            '    \n'
            '    if all_towers:\n'
            '        df_towers = pd.DataFrame(all_towers)\n'
            '        if "lng" in df_towers.columns and "lon" not in df_towers.columns:\n'
            '            df_towers.rename(columns={"lng": "lon"}, inplace=True)\n'
            '        print(f"\\nRadio technology distribution (all metros):")\n'
            '        print(df_towers["radio"].value_counts().to_string())\n'
            '        print(f"\\nTowers per metro area:")\n'
            '        print(df_towers["metro"].value_counts().to_string())\n'
        )
        c["outputs"] = []
        c["execution_count"] = None
        print(f"Fixed cell {i}: OpenCelliD smaller bboxes")
        break

# Clear all outputs
for c in nb["cells"]:
    if c["cell_type"] == "code":
        c["outputs"] = []
        c["execution_count"] = None

with open("notebooks/06_census_api_test_and_map.ipynb", "w", encoding="utf-8") as f:
    json.dump(nb, f, indent=1, ensure_ascii=False)

print("Done. Notebook fixed and outputs cleared.")
