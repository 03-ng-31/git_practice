# Cognitive Agentic AI — Agentic RAG with LangGraph

A production-ready, modular Retrieval-Augmented Generation (RAG) system built with **LangGraph**, **LangChain**, and **ChromaDB**. Retrieval is governed by an iterative evaluator loop — a "Critic" LLM that assesses context quality and triggers retries when the retrieved information is insufficient.

## Workflow

```
START → memory_lookup
          ├── (cache HIT)  → generate_answer → END
          └── (cache MISS) → decomposition → router → transformation → retrieval → evaluator
                                                           ↑                           │
                                                           └── (irrelevant, iter < 3) ─┘
                                                               (relevant) → generate_answer → END
```

## Project Structure

```
pyproject.toml       Project metadata & dependencies (uv)
.python-version      Pinned Python version
main.py              CLI entry-point (query / ingest / chat)
chat_ui.py           Chainlit interactive demo (web UI)
chainlit.md          Welcome screen for the Chainlit UI
.chainlit/
  config.toml        Chainlit theme & feature config
app/
  state.py           GraphState TypedDict & Pydantic models
  config.py          Centralised config, LLM & vector-store factories
  nodes.py           All graph node functions
  edges.py           Conditional edge logic
  tools.py           Retrieval & web-search tool wrappers
  graph.py           LangGraph StateGraph assembly
  ingest.py          Document ingestion pipeline
```

## Quick Start

This project uses **[uv](https://docs.astral.sh/uv/)** for fast, reproducible dependency management.

```bash
# 1. Install uv (if you don't have it)
# macOS / Linux:
curl -LsSf https://astral.sh/uv/install.sh | sh
# Windows (PowerShell):
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"

# 2. Install dependencies (creates .venv and uv.lock automatically)
uv sync

# 3. Configure environment
cp .env.example .env
# Edit .env with your OPENAI_API_KEY, TAVILY_API_KEY, etc.

# 4. Ingest documents
uv run python main.py ingest ./your_docs_folder

# 5. Query
uv run python main.py query "What are the key benefits of microservices?"

# 6. Interactive chat (terminal)
uv run python main.py chat

# 7. Interactive demo (web UI)
uv run chainlit run chat_ui.py -w
# Open http://localhost:8000
```

### Adding / removing dependencies

```bash
uv add some-package          # add a runtime dependency
uv add --dev pytest-cov      # add a dev dependency
uv remove some-package       # remove a dependency
uv lock --upgrade             # upgrade all to latest compatible versions
```

## Configuration

All settings live in `.env` (see `.env.example`):

| Variable | Default | Description |
|---|---|---|
| `OPENAI_API_KEY` | — | OpenAI API key (required) |
| `TAVILY_API_KEY` | — | Tavily web-search key (required for web search) |
| `LLM_MODEL` | `gpt-4o` | Model name for all LLM calls |
| `LLM_TEMPERATURE` | `0.0` | Temperature for deterministic outputs |
| `CHROMA_PERSIST_DIR` | `./chroma_db` | ChromaDB persistence directory |
| `CHROMA_COLLECTION_NAME` | `rag_documents` | Primary document collection |
| `CACHE_COLLECTION_NAME` | `semantic_cache` | Semantic cache collection |
| `CACHE_SIMILARITY_THRESHOLD` | `0.92` | Minimum score for a cache hit |
| `MAX_EVAL_ITERATIONS` | `3` | Evaluator retry budget |

## Web UI (Chainlit)

The project includes a full interactive demo powered by [Chainlit](https://docs.chainlit.io/). It streams the entire LangGraph pipeline into the chat interface, showing each node transition as an expandable step card.

```bash
uv run chainlit run chat_ui.py -w
```

Features:
- Real-time step-by-step pipeline visualization
- Expandable cards showing sub-queries, routing decisions, retrieval results, evaluator verdicts
- Dark theme with auto-reload during development
- Session-scoped graph compilation (compiled once per chat session)

## Architecture Details

### Nodes

- **memory_lookup** — Checks a semantic cache (separate ChromaDB collection) for a high-similarity match. On a hit, the pipeline short-circuits to answer generation.
- **decomposition** — Uses a structured-output LLM call to break complex queries into atomic sub-questions.
- **router** — Classifies query intent and selects the optimal data source: `vectorstore`, `websearch`, or `internal_docs`.
- **transformation** — Rewrites the current sub-query into a search-optimised string and extracts metadata filters (dates, categories).
- **retrieval** — Dispatches to the tool chosen by the router (ChromaDB, Tavily, or internal connector).
- **evaluator** — A "Critic" LLM that assesses whether the retrieved context is sufficient, returning `relevant`, `irrelevant`, or `missing_info`.
- **generate_answer** — Synthesises the final answer from the accumulated context, then caches the result.

### Conditional Edges

| Condition | Trigger | Target |
|---|---|---|
| A | `memory_hit == True` | `generate_answer` |
| B | `evaluation == "relevant"` | `generate_answer` |
| C | `evaluation == "irrelevant" AND iterations < 3` | `transformation` |
| D | `iterations >= 3` | `generate_answer` (best-effort) |
