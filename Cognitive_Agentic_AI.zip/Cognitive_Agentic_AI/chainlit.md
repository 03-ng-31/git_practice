# Agentic RAG Demo

Welcome to the **Agentic RAG** interactive demo — retrieval-augmented generation powered by an iterative evaluator loop.

## What happens when you ask a question

1. **Memory Lookup** — checks a semantic cache for previous answers
2. **Decomposition** — breaks complex queries into atomic sub-questions
3. **Router** — selects the best data source (VectorStore / Web Search / Internal Docs)
4. **Transformation** — rewrites the query for optimal retrieval
5. **Retrieval** — fetches documents from the chosen source
6. **Evaluator** — a Critic LLM assesses whether the context is sufficient
7. **Generation** — synthesises a final answer from the accumulated context

If the evaluator finds the context **insufficient**, the pipeline loops back through transformation and retrieval (up to 3 times) before generating a best-effort answer.

Every step is shown as an expandable card in the chat so you can inspect exactly what the agent decided at each stage.

---

*Built with LangGraph, LangChain, ChromaDB, and Chainlit.*
