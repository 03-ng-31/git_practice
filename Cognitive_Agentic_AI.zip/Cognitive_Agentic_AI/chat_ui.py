"""Chainlit interactive demo for the Agentic RAG pipeline.

Run with:
    chainlit run chat_ui.py -w
"""

from __future__ import annotations

import logging
import sys

import chainlit as cl

from app.graph import build_graph
from app.state import GraphState

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    datefmt="%H:%M:%S",
    stream=sys.stderr,
)
logger = logging.getLogger("chat_ui")

NODE_LABELS: dict[str, str] = {
    "memory_lookup": "Semantic Cache Lookup",
    "decomposition": "Query Decomposition",
    "router": "Route Selection",
    "transformation": "Query Transformation",
    "retrieval": "Document Retrieval",
    "evaluator": "Context Evaluation",
    "generate_answer": "Answer Generation",
}

NODE_ICONS: dict[str, str] = {
    "memory_lookup": "brain",
    "decomposition": "split",
    "router": "route",
    "transformation": "pen-tool",
    "retrieval": "search",
    "evaluator": "check-circle",
    "generate_answer": "message-circle",
}


def _build_initial_state(query: str) -> GraphState:
    return {
        "original_query": query,
        "sub_queries": [],
        "retrieved_documents": [],
        "evaluation_status": "irrelevant",
        "iterations": 0,
        "memory_hit": False,
        "cached_answer": "",
        "route": "vectorstore",
        "current_sub_query": "",
        "generation": "",
    }


def _format_step_detail(node: str, state: dict) -> str:
    """Build a compact markdown summary for the Chainlit Step body."""
    parts: list[str] = []

    if node == "memory_lookup":
        hit = state.get("memory_hit", False)
        parts.append(f"**Cache hit:** {'Yes — skipping to answer' if hit else 'No — entering full pipeline'}")

    elif node == "decomposition":
        subs = state.get("sub_queries", [])
        if subs:
            parts.append("**Sub-queries:**")
            for i, sq in enumerate(subs, 1):
                parts.append(f"{i}. {sq}")

    elif node == "router":
        route = state.get("route", "?")
        parts.append(f"**Selected source:** `{route}`")

    elif node == "transformation":
        parts.append(f"**Optimised query:** {state.get('current_sub_query', '?')}")

    elif node == "retrieval":
        docs = state.get("retrieved_documents", [])
        parts.append(f"**Documents retrieved:** {len(docs)}")
        for i, doc in enumerate(docs[:3], 1):
            src = doc.metadata.get("source", "unknown")
            preview = doc.page_content[:120].replace("\n", " ")
            parts.append(f"  {i}. `{src}` — {preview}...")
        if len(docs) > 3:
            parts.append(f"  ... and {len(docs) - 3} more")

    elif node == "evaluator":
        status = state.get("evaluation_status", "?")
        iters = state.get("iterations", 0)
        status_display = {
            "relevant": "Relevant",
            "irrelevant": "Irrelevant — will retry",
            "missing_info": "Missing info — will retry",
        }.get(status, status)
        parts.append(f"**Verdict:** {status_display}")
        parts.append(f"**Iteration:** {iters}")

    elif node == "generate_answer":
        if state.get("memory_hit"):
            parts.append("*Served from semantic cache*")
        else:
            docs = state.get("retrieved_documents", [])
            parts.append(f"Synthesised from **{len(docs)}** documents")

    return "\n".join(parts) if parts else ""


@cl.on_chat_start
async def on_chat_start():
    """Greet the user and compile the graph once per session."""
    graph = build_graph()
    cl.user_session.set("graph", graph)

    await cl.Message(
        content=(
            "**Welcome to the Agentic RAG Demo**\n\n"
            "Ask me anything. I'll walk you through each pipeline step "
            "— memory lookup, decomposition, routing, retrieval, evaluation, "
            "and answer generation — in real time.\n\n"
            "Each step is shown as an expandable card so you can inspect "
            "exactly what the agent is doing."
        ),
    ).send()


@cl.on_message
async def on_message(message: cl.Message):
    """Stream the LangGraph pipeline and surface every node transition."""
    graph = cl.user_session.get("graph")
    query = message.content.strip()
    if not query:
        return

    initial_state = _build_initial_state(query)

    root_step = cl.Step(name="Agentic RAG Pipeline", type="run")
    root_step.input = query
    await root_step.send()

    final_state: dict = {}
    async for event in graph.astream(initial_state, stream_mode="updates"):
        for node_name, node_output in event.items():
            if node_name == "__end__":
                continue

            final_state.update(node_output)
            merged = {**initial_state, **final_state}

            label = NODE_LABELS.get(node_name, node_name)
            detail = _format_step_detail(node_name, merged)

            step = cl.Step(name=label, type="tool")
            step.output = detail or f"Completed `{node_name}`"
            await step.send()

            logger.info("UI step: %s", node_name)

    answer = final_state.get("generation", "(no answer generated)")
    root_step.output = "Pipeline complete"
    await root_step.update()

    await cl.Message(content=answer).send()
