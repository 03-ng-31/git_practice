"""Async CLI entry-point for the Agentic RAG application."""

from __future__ import annotations

import asyncio
import argparse
import logging
import sys
from pathlib import Path

from app.graph import build_graph
from app.ingest import ingest_directory
from app.state import GraphState


def _setup_logging(verbose: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
        datefmt="%H:%M:%S",
        stream=sys.stderr,
    )


# ---------------------------------------------------------------------------
# Query
# ---------------------------------------------------------------------------

async def run_query(query: str) -> str:
    """Execute a single query through the Agentic RAG graph."""
    graph = build_graph()

    initial_state: GraphState = {
        "original_query": query,
        "sub_queries": [],
        "retrieved_documents": [],
        "evaluation_status": "irrelevant",
        "iterations": 0,
        "memory_hit": False,
        "cached_answer": "",
        "route": "vectorstore",
        "current_sub_query": "",
        "generation": "",
    }

    final_state = await graph.ainvoke(initial_state)
    return final_state.get("generation", "(no answer generated)")


# ---------------------------------------------------------------------------
# Ingest
# ---------------------------------------------------------------------------

async def run_ingest(directory: str, chunk_size: int, chunk_overlap: int) -> None:
    count = await ingest_directory(
        directory,
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )
    print(f"\nIngested {count} chunks from {directory}")


# ---------------------------------------------------------------------------
# Interactive REPL
# ---------------------------------------------------------------------------

async def run_interactive() -> None:
    """Run an interactive query loop."""
    graph = build_graph()
    print("Agentic RAG — interactive mode  (type 'exit' or 'quit' to stop)\n")

    while True:
        try:
            query = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye!")
            break

        if not query or query.lower() in {"exit", "quit"}:
            print("Bye!")
            break

        initial_state: GraphState = {
            "original_query": query,
            "sub_queries": [],
            "retrieved_documents": [],
            "evaluation_status": "irrelevant",
            "iterations": 0,
            "memory_hit": False,
            "cached_answer": "",
            "route": "vectorstore",
            "current_sub_query": "",
            "generation": "",
        }

        final_state = await graph.ainvoke(initial_state)
        answer = final_state.get("generation", "(no answer generated)")
        print(f"\nAssistant: {answer}\n")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Agentic RAG — retrieval-augmented generation with an evaluator loop",
    )
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable debug logging")
    sub = parser.add_subparsers(dest="command")

    # --- query sub-command ---
    q_parser = sub.add_parser("query", help="Run a single query")
    q_parser.add_argument("question", help="The question to answer")

    # --- ingest sub-command ---
    i_parser = sub.add_parser("ingest", help="Ingest documents into ChromaDB")
    i_parser.add_argument("directory", help="Path to the documents directory")
    i_parser.add_argument("--chunk-size", type=int, default=1000)
    i_parser.add_argument("--chunk-overlap", type=int, default=200)

    # --- interactive sub-command ---
    sub.add_parser("chat", help="Start an interactive REPL")

    args = parser.parse_args()
    _setup_logging(args.verbose)

    if args.command == "query":
        answer = asyncio.run(run_query(args.question))
        print(f"\n{answer}")
    elif args.command == "ingest":
        asyncio.run(run_ingest(args.directory, args.chunk_size, args.chunk_overlap))
    elif args.command == "chat":
        asyncio.run(run_interactive())
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
