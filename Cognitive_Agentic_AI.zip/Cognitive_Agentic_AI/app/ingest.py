"""Document ingestion pipeline — load, split, and index into ChromaDB."""

from __future__ import annotations

import logging
from pathlib import Path

from langchain_community.document_loaders import (
    DirectoryLoader,
    TextLoader,
    PyPDFLoader,
)
from langchain_text_splitters import RecursiveCharacterTextSplitter

from app.config import get_vectorstore

logger = logging.getLogger(__name__)

LOADER_MAP: dict[str, type] = {
    ".txt": TextLoader,
    ".md": TextLoader,
    ".pdf": PyPDFLoader,
}

DEFAULT_CHUNK_SIZE = 1000
DEFAULT_CHUNK_OVERLAP = 200


async def ingest_directory(
    path: str | Path,
    *,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
    glob_pattern: str = "**/*.*",
) -> int:
    """Recursively load documents from *path*, split, and index them.

    Returns the number of chunks indexed.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Ingestion path does not exist: {path}")

    logger.info("Ingesting documents from %s …", path)

    loader = DirectoryLoader(
        str(path),
        glob=glob_pattern,
        loader_cls=TextLoader,
        loader_kwargs={"autodetect_encoding": True},
        show_progress=True,
        use_multithreading=True,
    )
    raw_docs = loader.load()
    logger.info("Loaded %d raw documents", len(raw_docs))

    if not raw_docs:
        logger.warning("No documents found in %s — nothing to ingest.", path)
        return 0

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", ". ", " ", ""],
    )
    chunks = splitter.split_documents(raw_docs)
    logger.info("Split into %d chunks (size=%d, overlap=%d)", len(chunks), chunk_size, chunk_overlap)

    store = get_vectorstore()
    await store.aadd_documents(chunks)
    logger.info("Indexed %d chunks into ChromaDB", len(chunks))
    return len(chunks)
