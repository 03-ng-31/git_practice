"""Conditional edge functions that govern transitions in the StateGraph."""

from __future__ import annotations

import logging
from typing import Literal

from app.config import MAX_EVAL_ITERATIONS
from app.state import GraphState

logger = logging.getLogger(__name__)


def after_memory_lookup(
    state: GraphState,
) -> Literal["generate_answer", "decomposition"]:
    """Condition A — skip straight to generation when the cache has a hit."""
    if state.get("memory_hit"):
        logger.info("Edge: memory HIT → generate_answer")
        return "generate_answer"
    logger.info("Edge: memory MISS → decomposition")
    return "decomposition"


def after_evaluation(
    state: GraphState,
) -> Literal["generate_answer", "transformation"]:
    """Conditions B & C — route based on evaluator verdict + iteration budget.

    * relevant / missing_info at budget → generate_answer
    * irrelevant AND iterations < MAX   → transformation (retry loop)
    """
    status = state.get("evaluation_status", "irrelevant")
    iterations = state.get("iterations", 0)

    if status == "relevant":
        logger.info("Edge: evaluation RELEVANT → generate_answer")
        return "generate_answer"

    if iterations >= MAX_EVAL_ITERATIONS:
        logger.warning(
            "Edge: evaluation %s but max iterations (%d) reached → generate_answer",
            status,
            MAX_EVAL_ITERATIONS,
        )
        return "generate_answer"

    logger.info(
        "Edge: evaluation %s (iter %d/%d) → transformation (retry)",
        status,
        iterations,
        MAX_EVAL_ITERATIONS,
    )
    return "transformation"
