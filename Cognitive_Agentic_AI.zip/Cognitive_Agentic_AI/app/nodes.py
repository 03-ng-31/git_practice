"""LangGraph node functions — each accepts and returns GraphState."""

from __future__ import annotations

import logging

from langchain_core.messages import SystemMessage, HumanMessage

from app.config import get_llm, MAX_EVAL_ITERATIONS
from app.state import (
    GraphState,
    QueryDecomposition,
    RouteDecision,
    TransformedQuery,
    EvaluationResult,
)
from app.tools import (
    cache_lookup,
    cache_store,
    retrieve_from_vectorstore,
    web_search,
    retrieve_internal_docs,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# 1. Memory / semantic-cache lookup
# ---------------------------------------------------------------------------

async def memory_lookup_node(state: GraphState) -> GraphState:
    """Check the semantic cache; short-circuit to generation on a hit."""
    query = state["original_query"]
    logger.info("--- MEMORY LOOKUP ---  query=%s", query[:80])

    hit, cached_answer = await cache_lookup(query)
    return {
        **state,
        "memory_hit": hit,
        "cached_answer": cached_answer if hit else "",
        "iterations": state.get("iterations", 0),
    }


# ---------------------------------------------------------------------------
# 2. Query decomposition
# ---------------------------------------------------------------------------

async def decomposition_node(state: GraphState) -> GraphState:
    """Break the original query into atomic sub-questions."""
    query = state["original_query"]
    logger.info("--- DECOMPOSITION ---  query=%s", query[:80])

    llm = get_llm().with_structured_output(QueryDecomposition)
    result: QueryDecomposition = await llm.ainvoke([
        SystemMessage(content=(
            "You are a query decomposition specialist. Break the user's question "
            "into the smallest possible set of independent, atomic sub-questions "
            "whose answers, combined, fully address the original question. "
            "If the question is already atomic, return it as a single sub-question."
        )),
        HumanMessage(content=query),
    ])

    sub_qs = [sq.query for sq in result.sub_queries]
    logger.info("Decomposed into %d sub-queries: %s", len(sub_qs), sub_qs)
    return {**state, "sub_queries": sub_qs}


# ---------------------------------------------------------------------------
# 3. Router — pick the best data source for the current sub-query
# ---------------------------------------------------------------------------

async def router_node(state: GraphState) -> GraphState:
    """Select between vectorstore, websearch, or internal_docs."""
    sub_queries = state.get("sub_queries", [state["original_query"]])
    current = sub_queries[0] if sub_queries else state["original_query"]
    logger.info("--- ROUTER ---  sub_query=%s", current[:80])

    llm = get_llm().with_structured_output(RouteDecision)
    decision: RouteDecision = await llm.ainvoke([
        SystemMessage(content=(
            "You are a routing agent. Given a user query, decide which data source "
            "is most appropriate:\n"
            "- 'vectorstore' — the query is about domain-specific knowledge likely "
            "  stored in our indexed documents.\n"
            "- 'websearch' — the query requires real-time or very recent information "
            "  not likely in our knowledge base.\n"
            "- 'internal_docs' — the query is about internal company processes, "
            "  policies, or proprietary information.\n"
            "Return your decision as structured JSON."
        )),
        HumanMessage(content=current),
    ])

    logger.info("Route decision: %s (%s)", decision.route, decision.reasoning)
    return {**state, "route": decision.route, "current_sub_query": current}


# ---------------------------------------------------------------------------
# 4. Query transformation — rewrite for optimal retrieval
# ---------------------------------------------------------------------------

async def transformation_node(state: GraphState) -> GraphState:
    """Rewrite the current sub-query into a search-optimised string."""
    current = state.get("current_sub_query", state["original_query"])
    iteration = state.get("iterations", 0)
    logger.info(
        "--- TRANSFORMATION (iter %d) ---  sub_query=%s",
        iteration,
        current[:80],
    )

    llm = get_llm().with_structured_output(TransformedQuery)

    eval_context = ""
    if state.get("evaluation_status") == "irrelevant":
        eval_context = (
            "\nThe previous retrieval was evaluated as IRRELEVANT. "
            "Rewrite the query with different keywords, broader scope, or "
            "alternative phrasing so the next retrieval succeeds."
        )

    result: TransformedQuery = await llm.ainvoke([
        SystemMessage(content=(
            "You are a search-query optimisation expert. Rewrite the user's "
            "question into a form that will maximise recall from a vector "
            "database or search engine. Extract any implicit metadata filters "
            "(dates, categories, product names) into the metadata_filters dict."
            f"{eval_context}"
        )),
        HumanMessage(content=current),
    ])

    logger.info("Transformed query: %s | filters: %s", result.optimized_query, result.metadata_filters)
    return {**state, "current_sub_query": result.optimized_query}


# ---------------------------------------------------------------------------
# 5. Retrieval dispatcher — calls the tool selected by the router
# ---------------------------------------------------------------------------

async def retrieval_node(state: GraphState) -> GraphState:
    """Fetch documents from the data source chosen by the router."""
    route = state.get("route", "vectorstore")
    query = state.get("current_sub_query", state["original_query"])
    logger.info("--- RETRIEVAL (%s) ---  query=%s", route, query[:80])

    if route == "websearch":
        docs = await web_search(query)
    elif route == "internal_docs":
        docs = await retrieve_internal_docs(query)
    else:
        docs = await retrieve_from_vectorstore(query)

    existing = list(state.get("retrieved_documents", []))
    existing.extend(docs)
    return {**state, "retrieved_documents": existing}


# ---------------------------------------------------------------------------
# 6. Evaluator (Critic) — assess retrieved context quality
# ---------------------------------------------------------------------------

async def evaluator_node(state: GraphState) -> GraphState:
    """Evaluate whether the retrieved context is sufficient."""
    query = state["original_query"]
    docs = state.get("retrieved_documents", [])
    iteration = state.get("iterations", 0)
    logger.info(
        "--- EVALUATOR (iter %d) ---  #docs=%d",
        iteration,
        len(docs),
    )

    context = "\n\n---\n\n".join(d.page_content for d in docs) if docs else "(no documents retrieved)"

    llm = get_llm().with_structured_output(EvaluationResult)
    result: EvaluationResult = await llm.ainvoke([
        SystemMessage(content=(
            "You are a retrieval quality critic. Given the user's original query "
            "and the retrieved context, assess whether the context contains enough "
            "information to produce a complete, accurate answer.\n"
            "Return 'relevant' if the context is sufficient.\n"
            "Return 'irrelevant' if the context does not address the query.\n"
            "Return 'missing_info' if the context partially addresses it but "
            "important details are missing."
        )),
        HumanMessage(content=(
            f"ORIGINAL QUERY:\n{query}\n\n"
            f"RETRIEVED CONTEXT:\n{context}"
        )),
    ])

    logger.info(
        "Evaluation: status=%s | reasoning=%s",
        result.status,
        result.reasoning[:120],
    )
    return {
        **state,
        "evaluation_status": result.status,
        "iterations": iteration + 1,
    }


# ---------------------------------------------------------------------------
# 7. Answer generation
# ---------------------------------------------------------------------------

async def generate_answer_node(state: GraphState) -> GraphState:
    """Synthesise a final answer from the retrieved context (or cache)."""
    query = state["original_query"]

    if state.get("memory_hit"):
        logger.info("--- GENERATE (from cache) ---")
        return {**state, "generation": state.get("cached_answer", "")}

    docs = state.get("retrieved_documents", [])
    context = "\n\n---\n\n".join(d.page_content for d in docs) if docs else ""
    logger.info("--- GENERATE ---  #docs=%d", len(docs))

    llm = get_llm()
    response = await llm.ainvoke([
        SystemMessage(content=(
            "You are a knowledgeable assistant. Using ONLY the provided context, "
            "answer the user's question thoroughly. If the context is insufficient, "
            "state clearly what information is missing. Cite sources where possible."
        )),
        HumanMessage(content=f"CONTEXT:\n{context}\n\nQUESTION:\n{query}"),
    ])

    answer = response.content
    await cache_store(query, answer)
    return {**state, "generation": answer}
