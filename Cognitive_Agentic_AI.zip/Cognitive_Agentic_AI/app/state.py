"""Graph state definition and Pydantic models for structured LLM outputs."""

from __future__ import annotations

from typing import Literal

from langchain_core.documents import Document
from pydantic import BaseModel, Field
from typing_extensions import TypedDict


# ---------------------------------------------------------------------------
# Graph state flowing through every node
# ---------------------------------------------------------------------------

class GraphState(TypedDict, total=False):
    original_query: str
    sub_queries: list[str]
    current_sub_query: str
    retrieved_documents: list[Document]
    evaluation_status: Literal["relevant", "irrelevant", "missing_info"]
    iterations: int
    memory_hit: bool
    cached_answer: str
    route: Literal["vectorstore", "websearch", "internal_docs"]
    generation: str


# ---------------------------------------------------------------------------
# Pydantic models for structured LLM outputs
# ---------------------------------------------------------------------------

class SubQuery(BaseModel):
    """A single atomic sub-question derived from the original query."""

    query: str = Field(description="An atomic, self-contained sub-question.")
    reasoning: str = Field(description="Why this sub-question is needed.")


class QueryDecomposition(BaseModel):
    """Structured output from the decomposition LLM call."""

    sub_queries: list[SubQuery] = Field(
        description="List of atomic sub-questions that together answer the original query.",
    )


class RouteDecision(BaseModel):
    """Structured routing decision from the router LLM call."""

    route: Literal["vectorstore", "websearch", "internal_docs"] = Field(
        description="The data source best suited for this query.",
    )
    reasoning: str = Field(description="Brief justification for the chosen route.")


class TransformedQuery(BaseModel):
    """Search-optimized rewrite of a sub-query."""

    optimized_query: str = Field(
        description="A rewritten version of the query optimized for retrieval.",
    )
    metadata_filters: dict[str, str] = Field(
        default_factory=dict,
        description="Optional metadata filters extracted from the query (e.g. date, category).",
    )


class EvaluationResult(BaseModel):
    """Structured output from the evaluator (critic) LLM call."""

    status: Literal["relevant", "irrelevant", "missing_info"] = Field(
        description="Assessment of how well the retrieved context answers the query.",
    )
    reasoning: str = Field(description="Detailed explanation for the evaluation.")
    missing_aspects: list[str] = Field(
        default_factory=list,
        description="Specific aspects of the query not covered by the retrieved context.",
    )
