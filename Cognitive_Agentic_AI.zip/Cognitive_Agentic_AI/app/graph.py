"""Assemble the LangGraph StateGraph and compile the runnable workflow."""

from __future__ import annotations

import logging

from langgraph.graph import StateGraph, END

from app.state import GraphState
from app.nodes import (
    memory_lookup_node,
    decomposition_node,
    router_node,
    transformation_node,
    retrieval_node,
    evaluator_node,
    generate_answer_node,
)
from app.edges import after_memory_lookup, after_evaluation

logger = logging.getLogger(__name__)


def build_graph() -> StateGraph:
    """Construct and return the compiled Agentic RAG graph.

    Workflow
    --------
    START
      → memory_lookup
        ──(hit)──────────────────────────────→ generate_answer → END
        ──(miss)→ decomposition
                   → router
                     → transformation
                       → retrieval
                         → evaluator
                           ──(relevant)───→ generate_answer → END
                           ──(irrelevant, iter < max)─→ transformation  (loop)
                           ──(budget exhausted)───────→ generate_answer → END
    """
    workflow = StateGraph(GraphState)

    # --- register nodes ---
    workflow.add_node("memory_lookup", memory_lookup_node)
    workflow.add_node("decomposition", decomposition_node)
    workflow.add_node("router", router_node)
    workflow.add_node("transformation", transformation_node)
    workflow.add_node("retrieval", retrieval_node)
    workflow.add_node("evaluator", evaluator_node)
    workflow.add_node("generate_answer", generate_answer_node)

    # --- entry point ---
    workflow.set_entry_point("memory_lookup")

    # --- conditional edges ---
    workflow.add_conditional_edges(
        "memory_lookup",
        after_memory_lookup,
        {
            "generate_answer": "generate_answer",
            "decomposition": "decomposition",
        },
    )

    workflow.add_edge("decomposition", "router")
    workflow.add_edge("router", "transformation")
    workflow.add_edge("transformation", "retrieval")
    workflow.add_edge("retrieval", "evaluator")

    workflow.add_conditional_edges(
        "evaluator",
        after_evaluation,
        {
            "generate_answer": "generate_answer",
            "transformation": "transformation",
        },
    )

    workflow.add_edge("generate_answer", END)

    compiled = workflow.compile()
    logger.info("Agentic RAG graph compiled successfully")
    return compiled
