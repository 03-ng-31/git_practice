"""Retrieval and web-search tool wrappers used by graph nodes."""

from __future__ import annotations

import logging
from typing import Any

from langchain_core.documents import Document

from app.config import get_vectorstore, get_cache_store, CACHE_SIMILARITY_THRESHOLD, _env

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Vector-store retrieval
# ---------------------------------------------------------------------------

async def retrieve_from_vectorstore(
    query: str,
    k: int = 5,
    metadata_filters: dict[str, str] | None = None,
) -> list[Document]:
    """Return top-k documents from the primary ChromaDB collection."""
    try:
        store = get_vectorstore()
        filter_dict: dict[str, Any] | None = metadata_filters or None
        docs = await store.asimilarity_search(query, k=k, filter=filter_dict)
        logger.info("VectorStore returned %d documents for query: %s", len(docs), query[:80])
        return docs
    except Exception:
        logger.exception("VectorStore retrieval failed")
        return []


# ---------------------------------------------------------------------------
# Web search via Tavily
# ---------------------------------------------------------------------------

async def web_search(query: str, max_results: int = 5) -> list[Document]:
    """Run a Tavily web search and return results wrapped as Documents."""
    try:
        from tavily import AsyncTavilyClient

        client = AsyncTavilyClient(api_key=_env("TAVILY_API_KEY"))
        response = await client.search(query=query, max_results=max_results)

        docs: list[Document] = []
        for result in response.get("results", []):
            docs.append(
                Document(
                    page_content=result.get("content", ""),
                    metadata={
                        "source": result.get("url", ""),
                        "title": result.get("title", ""),
                        "type": "web_search",
                    },
                )
            )
        logger.info("WebSearch returned %d results for query: %s", len(docs), query[:80])
        return docs
    except Exception:
        logger.exception("Web search failed")
        return []


# ---------------------------------------------------------------------------
# Internal-docs stub (swap for your own connector)
# ---------------------------------------------------------------------------

async def retrieve_internal_docs(query: str, k: int = 5) -> list[Document]:
    """Placeholder for an internal knowledge-base connector.

    By default this falls back to the primary vector store.  Replace the
    implementation with your own connector (Confluence, Notion, etc.).
    """
    logger.info("InternalDocs lookup (falling back to vectorstore): %s", query[:80])
    return await retrieve_from_vectorstore(query, k=k)


# ---------------------------------------------------------------------------
# Semantic cache helpers
# ---------------------------------------------------------------------------

async def cache_lookup(query: str) -> tuple[bool, str]:
    """Check the semantic cache for a high-similarity hit.

    Returns (hit, cached_answer).
    """
    try:
        store = get_cache_store()
        results = await store.asimilarity_search_with_relevance_scores(query, k=1)
        if results:
            doc, score = results[0]
            if score >= CACHE_SIMILARITY_THRESHOLD:
                logger.info("Cache HIT (score=%.3f) for: %s", score, query[:80])
                return True, doc.metadata.get("answer", "")
        logger.info("Cache MISS for: %s", query[:80])
        return False, ""
    except Exception:
        logger.exception("Semantic cache lookup failed")
        return False, ""


async def cache_store(query: str, answer: str) -> None:
    """Persist a query-answer pair in the semantic cache."""
    try:
        store = get_cache_store()
        await store.aadd_documents(
            [Document(page_content=query, metadata={"answer": answer})],
        )
        logger.info("Cached answer for: %s", query[:80])
    except Exception:
        logger.exception("Failed to write to semantic cache")
