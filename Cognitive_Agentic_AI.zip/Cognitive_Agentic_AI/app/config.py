"""Centralised configuration, LLM client, and vector-store factory."""

from __future__ import annotations

import os
import logging

from dotenv import load_dotenv
from langchain_chroma import Chroma
from langchain_openai import ChatOpenAI, OpenAIEmbeddings

load_dotenv()

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Environment helpers
# ---------------------------------------------------------------------------

def _env(key: str, default: str | None = None) -> str:
    val = os.getenv(key, default)
    if val is None:
        raise EnvironmentError(f"Required environment variable {key!r} is not set.")
    return val


# ---------------------------------------------------------------------------
# LLM
# ---------------------------------------------------------------------------

LLM_MODEL: str = _env("LLM_MODEL", "gpt-4o")
LLM_TEMPERATURE: float = float(_env("LLM_TEMPERATURE", "0.0"))

def get_llm() -> ChatOpenAI:
    return ChatOpenAI(
        model=LLM_MODEL,
        temperature=LLM_TEMPERATURE,
        api_key=_env("OPENAI_API_KEY"),
    )


# ---------------------------------------------------------------------------
# Embeddings
# ---------------------------------------------------------------------------

def get_embeddings() -> OpenAIEmbeddings:
    return OpenAIEmbeddings(api_key=_env("OPENAI_API_KEY"))


# ---------------------------------------------------------------------------
# ChromaDB vector stores
# ---------------------------------------------------------------------------

CHROMA_PERSIST_DIR: str = _env("CHROMA_PERSIST_DIR", "./chroma_db")
CHROMA_COLLECTION: str = _env("CHROMA_COLLECTION_NAME", "rag_documents")
CACHE_COLLECTION: str = _env("CACHE_COLLECTION_NAME", "semantic_cache")
CACHE_SIMILARITY_THRESHOLD: float = float(
    _env("CACHE_SIMILARITY_THRESHOLD", "0.92"),
)
MAX_EVAL_ITERATIONS: int = int(_env("MAX_EVAL_ITERATIONS", "3"))


def get_vectorstore() -> Chroma:
    return Chroma(
        collection_name=CHROMA_COLLECTION,
        embedding_function=get_embeddings(),
        persist_directory=CHROMA_PERSIST_DIR,
    )


def get_cache_store() -> Chroma:
    return Chroma(
        collection_name=CACHE_COLLECTION,
        embedding_function=get_embeddings(),
        persist_directory=CHROMA_PERSIST_DIR,
    )
