"""
Unified Data Enrichment Pipeline
Combines all data sources (Census, FCC, OpenCelliD, FEMA, USGS) into single enrichment workflow
"""
import pandas as pd
from typing import Dict, List, Optional
from loguru import logger
from tqdm import tqdm
import os
from dotenv import load_dotenv

from ..api_clients import (
    FCCClient,
    OpenCelliDClient,
    CensusClient,
    FEMAFloodClient,
    USGSEarthquakeClient,
    WildfireRiskClient,
    HurricaneRiskClient,
    TornadoRiskClient
)


class DataEnrichmentPipeline:
    """Pipeline for enriching tower sites with external data"""
    
    def __init__(
        self,
        census_api_key: Optional[str] = None,
        opencellid_api_key: Optional[str] = None,
        fcc_database_path: str = "data/raw/fcc/asr_database.db"
    ):
        """
        Initialize enrichment pipeline with all API clients
        
        Args:
            census_api_key: Census API key
            opencellid_api_key: OpenCelliD API key
            fcc_database_path: Path to FCC database
        """
        logger.info("Initializing Data Enrichment Pipeline")
        
        # Load environment variables if keys not provided
        if not census_api_key or not opencellid_api_key:
            load_dotenv()
            census_api_key = census_api_key or os.getenv('CENSUS_API_KEY')
            opencellid_api_key = opencellid_api_key or os.getenv('OPENCELLID_API_KEY')
        
        # Initialize clients
        self.fcc_client = FCCClient(database_path=fcc_database_path)
        self.fema_client = FEMAFloodClient()
        self.usgs_client = USGSEarthquakeClient()
        self.wildfire_client = WildfireRiskClient()
        self.hurricane_client = HurricaneRiskClient()
        self.tornado_client = TornadoRiskClient()
        
        # Initialize clients that require API keys
        self.census_client = None
        self.opencellid_client = None
        
        if census_api_key:
            self.census_client = CensusClient(api_key=census_api_key)
            logger.info("Census client initialized")
        else:
            logger.warning("Census API key not provided - demographic features will be skipped")
        
        if opencellid_api_key:
            self.opencellid_client = OpenCelliDClient(api_key=opencellid_api_key)
            logger.info("OpenCelliD client initialized")
        else:
            logger.warning("OpenCelliD API key not provided - cell tower features will be skipped")
        
        logger.info("Data Enrichment Pipeline initialized successfully")
    
    def enrich_site(
        self,
        site: Dict,
        include_demographics: bool = True,
        include_competitors: bool = True,
        include_hazards: bool = True,
        demographic_radius_km: float = 3.0,
        tower_radius_km: float = 5.0,
        earthquake_radius_km: float = 50.0
    ) -> Dict:
        """
        Enrich a single tower site with all available data sources
        
        Args:
            site: Dictionary with at minimum 'latitude' and 'longitude'
            include_demographics: Include Census demographic data
            include_competitors: Include FCC and OpenCelliD tower data
            include_hazards: Include FEMA flood and USGS earthquake data
            demographic_radius_km: Radius for demographic queries
            tower_radius_km: Radius for tower density queries
            earthquake_radius_km: Radius for earthquake queries
            
        Returns:
            Dictionary with all enrichment features
        """
        lat = site.get('latitude')
        lon = site.get('longitude')
        
        if lat is None or lon is None:
            logger.error("Site missing latitude or longitude")
            return {}
        
        logger.info(f"Enriching site at ({lat}, {lon})")
        
        # Start with original site data
        enriched = site.copy()
        
        # Add demographic features
        if include_demographics and self.census_client:
            try:
                demo_features = self.census_client.get_enrichment_features(
                    lat, lon, radius_km=demographic_radius_km
                )
                enriched.update(demo_features)
                logger.debug(f"Added {len(demo_features)} demographic features")
            except Exception as e:
                logger.error(f"Error getting demographic features: {e}")
        
        # Add competitor density features
        if include_competitors:
            # FCC towers
            try:
                fcc_count = self.fcc_client.count_towers_nearby(lat, lon, tower_radius_km)
                fcc_density = self.fcc_client.get_tower_density(lat, lon, tower_radius_km)
                enriched['fcc_tower_count'] = fcc_count
                enriched['fcc_tower_density'] = fcc_density
                logger.debug(f"Added FCC features: {fcc_count} towers")
            except Exception as e:
                logger.error(f"Error getting FCC features: {e}")
            
            # OpenCelliD towers
            if self.opencellid_client:
                try:
                    opencellid_features = self.opencellid_client.get_enrichment_features(
                        lat, lon, radius_km=demographic_radius_km
                    )
                    enriched.update(opencellid_features)
                    logger.debug(f"Added {len(opencellid_features)} OpenCelliD features")
                except Exception as e:
                    logger.error(f"Error getting OpenCelliD features: {e}")
        
        # Add hazard features
        if include_hazards:
            # FEMA flood data
            try:
                flood_features = self.fema_client.get_enrichment_features(lat, lon)
                enriched.update(flood_features)
                logger.debug(f"Added {len(flood_features)} FEMA flood features")
            except Exception as e:
                logger.error(f"Error getting FEMA features: {e}")
            
            # USGS earthquake data
            try:
                earthquake_features = self.usgs_client.get_enrichment_features(
                    lat, lon, radius_km=earthquake_radius_km
                )
                enriched.update(earthquake_features)
                logger.debug(f"Added {len(earthquake_features)} USGS earthquake features")
            except Exception as e:
                logger.error(f"Error getting USGS features: {e}")
            
            # Wildfire risk data
            try:
                wildfire_features = self.wildfire_client.get_enrichment_features(lat, lon)
                enriched.update(wildfire_features)
                logger.debug(f"Added {len(wildfire_features)} wildfire features")
            except Exception as e:
                logger.error(f"Error getting wildfire features: {e}")
            
            # Hurricane risk data
            try:
                hurricane_features = self.hurricane_client.get_enrichment_features(lat, lon)
                enriched.update(hurricane_features)
                logger.debug(f"Added {len(hurricane_features)} hurricane features")
            except Exception as e:
                logger.error(f"Error getting hurricane features: {e}")
            
            # Tornado risk data
            try:
                tornado_features = self.tornado_client.get_enrichment_features(lat, lon)
                enriched.update(tornado_features)
                logger.debug(f"Added {len(tornado_features)} tornado features")
            except Exception as e:
                logger.error(f"Error getting tornado features: {e}")
        
        # Calculate derived features
        enriched = self._calculate_derived_features(enriched)
        
        logger.info(f"Site enrichment complete: {len(enriched)} total features")
        return enriched
    
    def _calculate_derived_features(self, enriched: Dict) -> Dict:
        """
        Calculate derived features from enriched data
        
        Args:
            enriched: Dictionary with enriched features
            
        Returns:
            Dictionary with additional derived features
        """
        # Tower saturation index (towers per capita)
        if 'fcc_tower_count' in enriched and 'census_population' in enriched:
            pop = enriched['census_population']
            if pop and pop > 0:
                enriched['tower_per_capita'] = enriched['fcc_tower_count'] / (pop / 10000)
        
        # Composite risk score (all hazards)
        risk_components = []
        if 'fema_flood_risk_score' in enriched:
            risk_components.append(enriched['fema_flood_risk_score'] * 0.20)
        if 'usgs_seismic_hazard_score' in enriched:
            risk_components.append(enriched['usgs_seismic_hazard_score'] * 0.20)
        if 'wildfire_risk_score' in enriched:
            risk_components.append(enriched['wildfire_risk_score'] * 0.20)
        if 'hurricane_risk_score' in enriched:
            risk_components.append(enriched['hurricane_risk_score'] * 0.20)
        if 'tornado_risk_score' in enriched:
            risk_components.append(enriched['tornado_risk_score'] * 0.20)
        
        if risk_components:
            enriched['composite_hazard_score'] = sum(risk_components)
        
        # Market opportunity score (population / tower density)
        if 'census_population' in enriched and 'fcc_tower_density' in enriched:
            pop = enriched.get('census_population', 0)
            density = enriched.get('fcc_tower_density', 0.01)
            if pop and density:
                # Higher population and lower tower density = higher opportunity
                enriched['market_opportunity_score'] = min((pop / 10000) / (density + 0.1), 10)
        
        return enriched
    
    def enrich_batch(
        self,
        sites: List[Dict],
        show_progress: bool = True,
        **kwargs
    ) -> pd.DataFrame:
        """
        Enrich multiple sites with progress tracking
        
        Args:
            sites: List of site dictionaries
            show_progress: Show progress bar
            **kwargs: Additional arguments passed to enrich_site
            
        Returns:
            DataFrame with enriched data
        """
        logger.info(f"Starting batch enrichment for {len(sites)} sites")
        
        enriched_sites = []
        
        iterator = tqdm(sites, desc="Enriching sites") if show_progress else sites
        
        for site in iterator:
            try:
                enriched = self.enrich_site(site, **kwargs)
                enriched_sites.append(enriched)
            except Exception as e:
                logger.error(f"Error enriching site {site.get('site_id', 'unknown')}: {e}")
                # Add site with error flag
                site['enrichment_error'] = str(e)
                enriched_sites.append(site)
        
        df = pd.DataFrame(enriched_sites)
        logger.info(f"Batch enrichment complete: {len(df)} sites processed")
        
        return df
    
    def get_feature_summary(self) -> Dict:
        """
        Get summary of available features from all data sources
        
        Returns:
            Dictionary with feature counts by source
        """
        summary = {
            'total_sources': 0,
            'sources': {}
        }
        
        # FCC features
        summary['sources']['FCC'] = {
            'available': True,
            'features': ['fcc_tower_count', 'fcc_tower_density']
        }
        summary['total_sources'] += 1
        
        # FEMA features
        summary['sources']['FEMA'] = {
            'available': True,
            'features': [
                'fema_flood_zone', 'fema_flood_risk_score',
                'fema_flood_risk_category', 'fema_base_flood_elevation'
            ]
        }
        summary['total_sources'] += 1
        
        # USGS features
        summary['sources']['USGS'] = {
            'available': True,
            'features': [
                'usgs_earthquake_count_total', 'usgs_earthquake_count_3plus',
                'usgs_max_magnitude', 'usgs_seismic_hazard_score',
                'usgs_seismic_risk_category'
            ]
        }
        summary['total_sources'] += 1
        
        # Census features
        if self.census_client:
            summary['sources']['Census'] = {
                'available': True,
                'features': [
                    'census_population', 'census_median_income',
                    'census_housing_units', 'census_vacancy_rate',
                    'census_population_density'
                ]
            }
            summary['total_sources'] += 1
        else:
            summary['sources']['Census'] = {'available': False, 'reason': 'API key not provided'}
        
        # OpenCelliD features
        if self.opencellid_client:
            summary['sources']['OpenCelliD'] = {
                'available': True,
                'features': [
                    'opencellid_tower_count', 'opencellid_tower_density',
                    'opencellid_carrier_count'
                ]
            }
            summary['total_sources'] += 1
        else:
            summary['sources']['OpenCelliD'] = {'available': False, 'reason': 'API key not provided'}
        
        # Derived features
        summary['sources']['Derived'] = {
            'available': True,
            'features': [
                'tower_per_capita', 'composite_risk_score',
                'market_opportunity_score'
            ]
        }
        
        return summary
    
    def export_enriched_data(
        self,
        df: pd.DataFrame,
        output_path: str,
        format: str = 'csv'
    ):
        """
        Export enriched data to file
        
        Args:
            df: DataFrame with enriched data
            output_path: Output file path
            format: Output format ('csv', 'parquet', 'excel')
        """
        logger.info(f"Exporting enriched data to {output_path}")
        
        if format == 'csv':
            df.to_csv(output_path, index=False)
        elif format == 'parquet':
            df.to_parquet(output_path, index=False)
        elif format == 'excel':
            df.to_excel(output_path, index=False)
        else:
            raise ValueError(f"Unsupported format: {format}")
        
        logger.info(f"Export complete: {len(df)} records saved to {output_path}")
