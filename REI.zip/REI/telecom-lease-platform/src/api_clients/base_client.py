"""
Base API Client with rate limiting, caching, and error handling
"""
from abc import ABC, abstractmethod
import requests
import requests_cache
from typing import Dict, Any, Optional
from loguru import logger
from tenacity import retry, stop_after_attempt, wait_exponential
import time
from pathlib import Path


class BaseAPIClient(ABC):
    """Abstract base class for all API clients"""
    
    def __init__(
        self,
        base_url: str,
        rate_limit_calls: int = 100,
        rate_limit_period: int = 3600,
        cache_enabled: bool = True,
        cache_expire_after: int = 2592000,
        cache_dir: str = "data/cache"
    ):
        """
        Initialize base API client
        
        Args:
            base_url: Base URL for the API
            rate_limit_calls: Number of calls allowed per period
            rate_limit_period: Time period in seconds
            cache_enabled: Whether to enable response caching
            cache_expire_after: Cache expiration time in seconds
            cache_dir: Directory for cache storage
        """
        self.base_url = base_url.rstrip('/')
        self.rate_limit_calls = rate_limit_calls
        self.rate_limit_period = rate_limit_period
        self.cache_enabled = cache_enabled
        
        # Rate limiting tracking
        self._call_times = []
        
        # Setup caching
        if cache_enabled:
            cache_path = Path(cache_dir)
            cache_path.mkdir(parents=True, exist_ok=True)
            cache_name = cache_path / f"{self.__class__.__name__}_cache"
            
            requests_cache.install_cache(
                cache_name=str(cache_name),
                backend='sqlite',
                expire_after=cache_expire_after
            )
            logger.info(f"Cache enabled for {self.__class__.__name__} at {cache_name}")
        
        logger.info(f"Initialized {self.__class__.__name__} with base URL: {base_url}")
    
    def _check_rate_limit(self):
        """Check and enforce rate limiting"""
        current_time = time.time()
        
        # Remove old call times outside the rate limit period
        self._call_times = [
            t for t in self._call_times 
            if current_time - t < self.rate_limit_period
        ]
        
        # Check if we've exceeded the rate limit
        if len(self._call_times) >= self.rate_limit_calls:
            oldest_call = self._call_times[0]
            sleep_time = self.rate_limit_period - (current_time - oldest_call)
            
            if sleep_time > 0:
                logger.warning(
                    f"Rate limit reached ({self.rate_limit_calls} calls per "
                    f"{self.rate_limit_period}s). Sleeping for {sleep_time:.2f}s"
                )
                time.sleep(sleep_time)
        
        # Record this call
        self._call_times.append(current_time)
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10)
    )
    def _make_request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        data: Optional[Dict[str, Any]] = None,
        timeout: int = 30
    ) -> requests.Response:
        """
        Make HTTP request with rate limiting and retries
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint (will be appended to base_url)
            params: Query parameters
            headers: HTTP headers
            data: Request body data
            timeout: Request timeout in seconds
            
        Returns:
            Response object
        """
        # Check rate limit before making request
        self._check_rate_limit()
        
        # Build full URL
        url = f"{self.base_url}/{endpoint.lstrip('/')}" if endpoint else self.base_url
        
        # Make request
        logger.debug(f"Making {method} request to {url}")
        
        try:
            response = requests.request(
                method=method,
                url=url,
                params=params,
                headers=headers,
                json=data,
                timeout=timeout
            )
            
            # Check if response was from cache
            if hasattr(response, 'from_cache') and response.from_cache:
                logger.debug(f"Response retrieved from cache")
            
            # Raise exception for bad status codes
            response.raise_for_status()
            
            return response
            
        except requests.exceptions.HTTPError as e:
            logger.error(f"HTTP error: {e}")
            raise
        except requests.exceptions.ConnectionError as e:
            logger.error(f"Connection error: {e}")
            raise
        except requests.exceptions.Timeout as e:
            logger.error(f"Timeout error: {e}")
            raise
        except requests.exceptions.RequestException as e:
            logger.error(f"Request error: {e}")
            raise
    
    def _handle_error(self, error: Exception, context: str = ""):
        """
        Handle and log errors
        
        Args:
            error: The exception that occurred
            context: Additional context about the error
        """
        error_msg = f"Error in {self.__class__.__name__}"
        if context:
            error_msg += f" ({context})"
        error_msg += f": {str(error)}"
        
        logger.error(error_msg)
        raise
