"""
FCC Client for Antenna Structure Registration (ASR) data
Downloads and parses FCC tower database
"""
import pandas as pd
import sqlite3
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from loguru import logger
import requests
from io import BytesIO
import zipfile
from geopy.distance import geodesic
from .base_client import BaseAPIClient


class FCCClient(BaseAPIClient):
    """Client for FCC Antenna Structure Registration data"""
    
    def __init__(self, database_path: str = "data/raw/fcc/asr_database.db"):
        """
        Initialize FCC client
        
        Args:
            database_path: Path to SQLite database for storing ASR data
        """
        # FCC doesn't have a REST API, so we use a placeholder base URL
        super().__init__(
            base_url="https://www.fcc.gov",
            rate_limit_calls=100,
            rate_limit_period=60,
            cache_enabled=False  # Disable caching for FCC since we use local DB
        )
        
        self.database_path = Path(database_path)
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"FCC Client initialized with database at {database_path}")
    
    def download_asr_data(self, output_dir: str = "data/raw/fcc") -> str:
        """
        Download FCC ASR database files
        
        Note: FCC provides bulk downloads of ASR data as pipe-delimited files
        URL: https://www.fcc.gov/uls/transactions/daily-weekly
        
        Args:
            output_dir: Directory to save downloaded files
            
        Returns:
            Path to downloaded file
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # FCC ASR data URL (this is a sample - actual URL may vary)
        # In production, you would download from the official FCC site
        asr_url = "https://www.fcc.gov/uls/transactions/daily-weekly"
        
        logger.info(f"Downloading FCC ASR data from {asr_url}")
        logger.warning(
            "Note: FCC data download requires manual steps. "
            "Please download the ASR database from https://www.fcc.gov/uls/transactions/daily-weekly"
        )
        
        # For now, return the expected file path
        # In production, implement actual download logic
        return str(output_path / "asr_data.zip")
    
    def parse_asr_file(self, file_path: str) -> pd.DataFrame:
        """
        Parse FCC ASR pipe-delimited file
        
        Args:
            file_path: Path to ASR data file
            
        Returns:
            DataFrame with parsed ASR data
        """
        logger.info(f"Parsing FCC ASR file: {file_path}")
        
        # FCC ASR file format (pipe-delimited)
        # Columns: Registration Number|Structure Type|Height|Latitude|Longitude|...
        
        try:
            df = pd.read_csv(
                file_path,
                sep='|',
                encoding='latin-1',
                low_memory=False
            )
            
            logger.info(f"Parsed {len(df)} records from ASR file")
            return df
            
        except Exception as e:
            logger.error(f"Error parsing ASR file: {e}")
            raise
    
    def load_to_database(self, df: pd.DataFrame, table_name: str = "asr_towers"):
        """
        Load ASR data into SQLite database
        
        Args:
            df: DataFrame with ASR data
            table_name: Name of database table
        """
        logger.info(f"Loading {len(df)} records to database: {self.database_path}")
        
        try:
            conn = sqlite3.connect(self.database_path)
            df.to_sql(table_name, conn, if_exists='replace', index=False)
            conn.close()
            
            logger.info(f"Successfully loaded data to {table_name} table")
            
        except Exception as e:
            logger.error(f"Error loading data to database: {e}")
            raise
    
    def create_sample_database(self):
        """
        Create a sample database with mock tower data for testing
        This is useful when actual FCC data is not available
        """
        logger.info("Creating sample FCC tower database")
        
        # Sample tower data (realistic US locations)
        sample_data = {
            'registration_number': ['1234567', '1234568', '1234569', '1234570', '1234571'],
            'structure_type': ['GUYED', 'MONOPOLE', 'GUYED', 'LATTICE', 'MONOPOLE'],
            'height_feet': [150, 120, 180, 200, 100],
            'latitude': [37.7749, 37.7850, 37.7650, 37.7950, 37.7550],
            'longitude': [-122.4194, -122.4094, -122.4294, -122.3994, -122.4394],
            'owner_name': ['AMERICAN TOWER', 'CROWN CASTLE', 'SBA COMMUNICATIONS', 'VERTICAL BRIDGE', 'T-MOBILE'],
            'construction_date': ['2010-05-15', '2012-08-20', '2008-03-10', '2015-11-05', '2018-07-22'],
            'city': ['San Francisco', 'San Francisco', 'San Francisco', 'San Francisco', 'San Francisco'],
            'state': ['CA', 'CA', 'CA', 'CA', 'CA']
        }
        
        df = pd.DataFrame(sample_data)
        self.load_to_database(df)
        
        logger.info(f"Sample database created with {len(df)} towers")
        return df
    
    def get_towers_in_radius(
        self,
        lat: float,
        lon: float,
        radius_km: float,
        table_name: str = "asr_towers"
    ) -> pd.DataFrame:
        """
        Get all towers within a radius of a location
        
        Args:
            lat: Latitude of center point
            lon: Longitude of center point
            radius_km: Radius in kilometers
            table_name: Database table name
            
        Returns:
            DataFrame with towers within radius
        """
        logger.debug(f"Querying towers within {radius_km}km of ({lat}, {lon})")
        
        try:
            conn = sqlite3.connect(self.database_path)
            
            # Read all towers (in production, use spatial index for efficiency)
            query = f"SELECT * FROM {table_name}"
            df = pd.read_sql_query(query, conn)
            conn.close()
            
            if df.empty:
                logger.warning("No towers found in database")
                return df
            
            # Calculate distances
            center_point = (lat, lon)
            df['distance_km'] = df.apply(
                lambda row: geodesic(
                    center_point,
                    (row['latitude'], row['longitude'])
                ).kilometers,
                axis=1
            )
            
            # Filter by radius
            result = df[df['distance_km'] <= radius_km].copy()
            result = result.sort_values('distance_km')
            
            logger.info(f"Found {len(result)} towers within {radius_km}km")
            return result
            
        except Exception as e:
            logger.error(f"Error querying towers: {e}")
            raise
    
    def get_tower_by_registration(
        self,
        registration_number: str,
        table_name: str = "asr_towers"
    ) -> Optional[Dict]:
        """
        Get tower details by registration number
        
        Args:
            registration_number: FCC registration number
            table_name: Database table name
            
        Returns:
            Dictionary with tower details or None if not found
        """
        logger.debug(f"Looking up tower with registration: {registration_number}")
        
        try:
            conn = sqlite3.connect(self.database_path)
            query = f"SELECT * FROM {table_name} WHERE registration_number = ?"
            df = pd.read_sql_query(query, conn, params=(registration_number,))
            conn.close()
            
            if df.empty:
                logger.warning(f"Tower {registration_number} not found")
                return None
            
            return df.iloc[0].to_dict()
            
        except Exception as e:
            logger.error(f"Error looking up tower: {e}")
            raise
    
    def count_towers_nearby(
        self,
        lat: float,
        lon: float,
        radius_km: float
    ) -> int:
        """
        Count towers within radius
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius in kilometers
            
        Returns:
            Number of towers within radius
        """
        df = self.get_towers_in_radius(lat, lon, radius_km)
        return len(df)
    
    def get_tower_density(
        self,
        lat: float,
        lon: float,
        radius_km: float
    ) -> float:
        """
        Calculate tower density (towers per square km)
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius in kilometers
            
        Returns:
            Tower density (towers per sq km)
        """
        count = self.count_towers_nearby(lat, lon, radius_km)
        area_sq_km = 3.14159 * (radius_km ** 2)
        density = count / area_sq_km if area_sq_km > 0 else 0
        
        logger.debug(f"Tower density at ({lat}, {lon}): {density:.4f} towers/sq km")
        return density
