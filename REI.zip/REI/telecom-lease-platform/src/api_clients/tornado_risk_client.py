"""
Tornado Risk API Client for NOAA Storm Prediction Center data
API Documentation: https://www.spc.noaa.gov/wcm/
"""
import pandas as pd
from typing import Dict, Optional, List, Tuple
from loguru import logger
from datetime import datetime
from .base_client import BaseAPIClient


class TornadoRiskClient(BaseAPIClient):
    """Client for NOAA Tornado risk data"""
    
    BASE_URL = "https://www.spc.noaa.gov"
    
    def __init__(self):
        """Initialize Tornado Risk client"""
        super().__init__(
            base_url=self.BASE_URL,
            rate_limit_calls=100,
            rate_limit_period=60,
            cache_enabled=True,
            cache_expire_after=2592000  # 30 days
        )
        logger.info("Tornado Risk Client initialized")
    
    def get_tornado_risk(self, lat: float, lon: float) -> Dict:
        """
        Get tornado risk for a location
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            Dictionary with tornado risk data
        """
        logger.debug(f"Querying tornado risk for ({lat}, {lon})")
        
        try:
            # Calculate risk based on location
            risk_score = self._estimate_tornado_risk(lat, lon)
            
            # Check if in Tornado Alley
            tornado_alley = self._is_tornado_alley(lat, lon)
            
            return {
                'tornado_risk_score': risk_score,
                'tornado_risk_category': self._get_risk_category(risk_score),
                'tornado_alley_indicator': tornado_alley,
                'data_source': 'NOAA SPC (estimated)',
                'query_date': datetime.now().strftime('%Y-%m-%d')
            }
            
        except Exception as e:
            logger.error(f"Error querying tornado risk: {e}")
            return self._get_default_tornado_data()
    
    def _estimate_tornado_risk(self, lat: float, lon: float) -> float:
        """
        Estimate tornado risk based on location
        
        Tornado Alley and Dixie Alley have highest risk.
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            Risk score (0-1)
        """
        # Tornado Alley (Very High risk): OK, KS, NE, northern TX
        if -102 < lon < -94 and 33 < lat < 41:
            return 0.85
        
        # Dixie Alley (High risk): MS, AL, TN, AR
        elif -92 < lon < -85 and 31 < lat < 37:
            return 0.75
        
        # Southern Plains (High risk): TX, OK
        elif -100 < lon < -94 and 29 < lat < 37:
            return 0.70
        
        # Midwest (Moderate to High risk): MO, IA, IL, IN, OH
        elif -95 < lon < -80 and 37 < lat < 43:
            return 0.55
        
        # Southeast (Moderate risk): GA, SC, NC, FL panhandle
        elif -88 < lon < -78 and 28 < lat < 36:
            return 0.45
        
        # Great Plains (Moderate risk): SD, ND, MT
        elif -105 < lon < -95 and 41 < lat < 49:
            return 0.40
        
        # Northeast (Low risk): NY, PA, NJ, New England
        elif -80 < lon < -66 and 39 < lat < 47:
            return 0.25
        
        # West Coast (Very Low risk): CA, OR, WA
        elif lon < -115 and 32 < lat < 49:
            return 0.10
        
        # Mountain West (Low risk): CO, WY, MT, ID
        elif -115 < lon < -102 and 36 < lat < 49:
            return 0.20
        
        else:
            # Other areas
            return 0.30
    
    def _is_tornado_alley(self, lat: float, lon: float) -> bool:
        """
        Check if location is in traditional Tornado Alley
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            True if in Tornado Alley, False otherwise
        """
        # Traditional Tornado Alley: OK, KS, NE, northern TX, eastern CO
        return -102 < lon < -94 and 33 < lat < 41
    
    def _get_risk_category(self, risk_score: float) -> str:
        """
        Convert risk score to category
        
        Args:
            risk_score: Risk score (0-1)
            
        Returns:
            Risk category string
        """
        if risk_score >= 0.75:
            return 'Very High Risk'
        elif risk_score >= 0.55:
            return 'High Risk'
        elif risk_score >= 0.35:
            return 'Moderate Risk'
        elif risk_score >= 0.15:
            return 'Low Risk'
        else:
            return 'Minimal Risk'
    
    def _get_default_tornado_data(self) -> Dict:
        """Return default tornado data"""
        return {
            'tornado_risk_score': 0.3,
            'tornado_risk_category': 'Moderate Risk',
            'tornado_alley_indicator': False,
            'data_source': 'Default',
            'query_date': datetime.now().strftime('%Y-%m-%d')
        }
    
    def get_historic_tornadoes(
        self,
        lat: float,
        lon: float,
        radius_km: float = 50,
        years: int = 30
    ) -> List[Dict]:
        """
        Get historic tornadoes in area
        
        Note: This is a placeholder. In production, query NOAA Storm Events database.
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius in kilometers
            years: Number of years to look back
            
        Returns:
            List of historic tornadoes
        """
        logger.debug(f"Querying historic tornadoes within {radius_km}km of ({lat}, {lon})")
        
        # Placeholder: return empty list
        # In production, query NOAA NCEI Storm Events Database
        return []
    
    def estimate_tornado_frequency(self, lat: float, lon: float) -> Dict:
        """
        Estimate tornado frequency for location
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            Dictionary with frequency estimates
        """
        risk_score = self._estimate_tornado_risk(lat, lon)
        
        # Estimate annual tornado count based on risk
        # Very high risk areas: 1-2 per year within 50km
        # High risk: 0.5-1 per year
        # Moderate: 0.2-0.5 per year
        # Low: 0.05-0.2 per year
        # Minimal: <0.05 per year
        
        if risk_score >= 0.75:
            avg_per_year = 1.5
            count_30yr = 45
        elif risk_score >= 0.55:
            avg_per_year = 0.75
            count_30yr = 22
        elif risk_score >= 0.35:
            avg_per_year = 0.35
            count_30yr = 10
        elif risk_score >= 0.15:
            avg_per_year = 0.12
            count_30yr = 4
        else:
            avg_per_year = 0.03
            count_30yr = 1
        
        return {
            'avg_tornadoes_per_year': avg_per_year,
            'estimated_count_30yr': count_30yr
        }
    
    def get_enrichment_features(
        self,
        lat: float,
        lon: float,
        radius_km: float = 50
    ) -> Dict:
        """
        Get all tornado features for data enrichment
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius for historic tornado queries
            
        Returns:
            Dictionary with tornado-related features
        """
        logger.info(f"Getting tornado features for ({lat}, {lon})")
        
        # Get risk data
        risk_data = self.get_tornado_risk(lat, lon)
        
        # Get historic tornadoes
        historic_tornadoes = self.get_historic_tornadoes(lat, lon, radius_km, years=30)
        
        # Get frequency estimates
        frequency = self.estimate_tornado_frequency(lat, lon)
        
        # Estimate max EF rating based on risk
        if risk_data['tornado_risk_score'] >= 0.75:
            max_ef_rating = 5
        elif risk_data['tornado_risk_score'] >= 0.55:
            max_ef_rating = 4
        elif risk_data['tornado_risk_score'] >= 0.35:
            max_ef_rating = 3
        else:
            max_ef_rating = 2
        
        features = {
            'tornado_risk_score': risk_data['tornado_risk_score'],
            'tornado_risk_category': risk_data['tornado_risk_category'],
            'tornado_alley_indicator': risk_data['tornado_alley_indicator'],
            'tornado_count_30yr': frequency['estimated_count_30yr'],
            'tornado_avg_per_year': frequency['avg_tornadoes_per_year'],
            'tornado_max_ef_rating': max_ef_rating
        }
        
        logger.info(
            f"Tornado features extracted: risk={features['tornado_risk_score']:.2f}, "
            f"category={features['tornado_risk_category']}"
        )
        
        return features
    
    def is_high_risk_tornado_area(self, lat: float, lon: float) -> bool:
        """
        Check if location is in high tornado risk area
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            True if high risk, False otherwise
        """
        risk_data = self.get_tornado_risk(lat, lon)
        return risk_data['tornado_risk_score'] >= 0.65
    
    def batch_tornado_lookup(
        self,
        locations: List[Tuple[float, float]]
    ) -> pd.DataFrame:
        """
        Batch lookup tornado risk for multiple locations
        
        Args:
            locations: List of (lat, lon) tuples
            
        Returns:
            DataFrame with tornado data for all locations
        """
        logger.info(f"Batch tornado lookup for {len(locations)} locations")
        
        results = []
        for i, (lat, lon) in enumerate(locations):
            logger.debug(f"Processing location {i+1}/{len(locations)}")
            
            features = self.get_enrichment_features(lat, lon)
            features['latitude'] = lat
            features['longitude'] = lon
            results.append(features)
        
        df = pd.DataFrame(results)
        logger.info(f"Batch lookup complete: {len(df)} records")
        
        return df
