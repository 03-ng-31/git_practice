"""
Hurricane Risk API Client for NOAA National Hurricane Center data
API Documentation: https://www.nhc.noaa.gov/gis/
"""
import pandas as pd
from typing import Dict, Optional, List, Tuple
from loguru import logger
from datetime import datetime
import math
from .base_client import BaseAPIClient


class HurricaneRiskClient(BaseAPIClient):
    """Client for NOAA Hurricane/Tropical Storm data"""
    
    BASE_URL = "https://mapservices.weather.noaa.gov/tropical/rest/services"
    
    def __init__(self):
        """Initialize Hurricane Risk client"""
        super().__init__(
            base_url=self.BASE_URL,
            rate_limit_calls=100,
            rate_limit_period=60,
            cache_enabled=True,
            cache_expire_after=2592000  # 30 days
        )
        logger.info("Hurricane Risk Client initialized")
    
    def get_hurricane_risk(self, lat: float, lon: float) -> Dict:
        """
        Get hurricane risk for a location
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            Dictionary with hurricane risk data
        """
        logger.debug(f"Querying hurricane risk for ({lat}, {lon})")
        
        try:
            # Calculate risk based on location
            risk_score = self._estimate_hurricane_risk(lat, lon)
            
            # Get distance to coast
            distance_to_coast = self._estimate_distance_to_coast(lat, lon)
            
            return {
                'hurricane_risk_score': risk_score,
                'hurricane_risk_category': self._get_risk_category(risk_score),
                'distance_to_coast_km': distance_to_coast,
                'coastal_location': distance_to_coast < 100,
                'data_source': 'NOAA (estimated)',
                'query_date': datetime.now().strftime('%Y-%m-%d')
            }
            
        except Exception as e:
            logger.error(f"Error querying hurricane risk: {e}")
            return self._get_default_hurricane_data()
    
    def _estimate_hurricane_risk(self, lat: float, lon: float) -> float:
        """
        Estimate hurricane risk based on location
        
        Coastal areas in hurricane-prone regions have higher risk.
        Gulf Coast and Atlantic Coast from Texas to Maine.
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            Risk score (0-1)
        """
        distance_to_coast = self._estimate_distance_to_coast(lat, lon)
        
        # Not coastal = low risk
        if distance_to_coast > 200:
            return 0.1
        
        # Gulf Coast (High risk): TX, LA, MS, AL, FL panhandle
        if -97 < lon < -80 and 25 < lat < 31:
            if distance_to_coast < 50:
                return 0.9
            elif distance_to_coast < 100:
                return 0.7
            else:
                return 0.4
        
        # South Florida (Very High risk)
        elif -82 < lon < -80 and 24 < lat < 28:
            if distance_to_coast < 50:
                return 0.95
            elif distance_to_coast < 100:
                return 0.8
            else:
                return 0.5
        
        # Atlantic Coast (Moderate to High risk): FL to NC
        elif -81 < lon < -75 and 28 < lat < 36:
            if distance_to_coast < 50:
                return 0.7
            elif distance_to_coast < 100:
                return 0.5
            else:
                return 0.3
        
        # Mid-Atlantic (Moderate risk): VA to NY
        elif -76 < lon < -71 and 36 < lat < 41:
            if distance_to_coast < 50:
                return 0.5
            else:
                return 0.3
        
        # New England (Low to Moderate risk)
        elif -72 < lon < -66 and 41 < lat < 45:
            if distance_to_coast < 50:
                return 0.4
            else:
                return 0.2
        
        # Pacific Coast (Low risk - rare hurricanes)
        elif lon < -115 and 32 < lat < 49:
            return 0.1
        
        else:
            # Inland or other areas
            return 0.1
    
    def _estimate_distance_to_coast(self, lat: float, lon: float) -> float:
        """
        Estimate distance to nearest coast
        
        This is a rough approximation. In production, use actual coastline data.
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            Estimated distance to coast in km
        """
        # Atlantic Coast approximation
        if lon > -100:
            # East of -100 longitude
            # Rough Atlantic coastline
            if 25 < lat < 31:
                # Gulf Coast
                coast_lon = -97 if lon < -97 else -80
            elif 31 < lat < 36:
                # Southeast Atlantic
                coast_lon = -81
            elif 36 < lat < 41:
                # Mid-Atlantic
                coast_lon = -76
            elif 41 < lat < 45:
                # New England
                coast_lon = -71
            else:
                # Not near coast
                return 500
            
            # Calculate distance
            lon_diff = abs(lon - coast_lon)
            distance = lon_diff * 111  # Rough km per degree longitude
            return distance
        
        # Pacific Coast approximation
        elif lon < -115:
            coast_lon = -124 if 32 < lat < 49 else lon
            lon_diff = abs(lon - coast_lon)
            distance = lon_diff * 111
            return distance
        
        else:
            # Inland
            return 500
    
    def _get_risk_category(self, risk_score: float) -> str:
        """
        Convert risk score to category
        
        Args:
            risk_score: Risk score (0-1)
            
        Returns:
            Risk category string
        """
        if risk_score >= 0.8:
            return 'Very High Risk'
        elif risk_score >= 0.6:
            return 'High Risk'
        elif risk_score >= 0.4:
            return 'Moderate Risk'
        elif risk_score >= 0.2:
            return 'Low Risk'
        else:
            return 'Minimal Risk'
    
    def _get_default_hurricane_data(self) -> Dict:
        """Return default hurricane data"""
        return {
            'hurricane_risk_score': 0.1,
            'hurricane_risk_category': 'Minimal Risk',
            'distance_to_coast_km': 500,
            'coastal_location': False,
            'data_source': 'Default',
            'query_date': datetime.now().strftime('%Y-%m-%d')
        }
    
    def get_historic_hurricanes(
        self,
        lat: float,
        lon: float,
        radius_km: float = 100,
        years: int = 50
    ) -> List[Dict]:
        """
        Get historic hurricanes that passed within radius
        
        Note: This is a placeholder. In production, query NOAA IBTrACS database.
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius in kilometers
            years: Number of years to look back
            
        Returns:
            List of historic hurricanes
        """
        logger.debug(f"Querying historic hurricanes within {radius_km}km of ({lat}, {lon})")
        
        # Placeholder: return empty list
        # In production, query NOAA International Best Track Archive
        return []
    
    def get_storm_surge_risk(self, lat: float, lon: float) -> Dict:
        """
        Get storm surge inundation risk
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            Dictionary with storm surge risk
        """
        distance_to_coast = self._estimate_distance_to_coast(lat, lon)
        
        # Storm surge risk only for coastal areas
        if distance_to_coast > 50:
            return {
                'storm_surge_risk_score': 0.0,
                'storm_surge_risk_category': 'No Risk'
            }
        
        # Coastal areas - estimate based on location
        hurricane_risk = self._estimate_hurricane_risk(lat, lon)
        
        # Storm surge risk correlates with hurricane risk
        surge_risk = hurricane_risk * 0.8  # Slightly lower than hurricane risk
        
        if surge_risk >= 0.7:
            category = 'High Risk'
        elif surge_risk >= 0.4:
            category = 'Moderate Risk'
        elif surge_risk >= 0.2:
            category = 'Low Risk'
        else:
            category = 'Minimal Risk'
        
        return {
            'storm_surge_risk_score': surge_risk,
            'storm_surge_risk_category': category
        }
    
    def get_hurricane_wind_zone(self, lat: float, lon: float) -> str:
        """
        Get ASCE 7 hurricane wind zone
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            Wind zone designation
        """
        risk_score = self._estimate_hurricane_risk(lat, lon)
        
        if risk_score >= 0.8:
            return 'Wind Zone IV'
        elif risk_score >= 0.6:
            return 'Wind Zone III'
        elif risk_score >= 0.4:
            return 'Wind Zone II'
        else:
            return 'Wind Zone I'
    
    def get_enrichment_features(
        self,
        lat: float,
        lon: float,
        radius_km: float = 100
    ) -> Dict:
        """
        Get all hurricane features for data enrichment
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius for historic hurricane queries
            
        Returns:
            Dictionary with hurricane-related features
        """
        logger.info(f"Getting hurricane features for ({lat}, {lon})")
        
        # Get risk data
        risk_data = self.get_hurricane_risk(lat, lon)
        
        # Get historic hurricanes
        historic_hurricanes = self.get_historic_hurricanes(lat, lon, radius_km, years=50)
        
        # Get storm surge risk
        surge_risk = self.get_storm_surge_risk(lat, lon)
        
        # Get wind zone
        wind_zone = self.get_hurricane_wind_zone(lat, lon)
        
        features = {
            'hurricane_risk_score': risk_data['hurricane_risk_score'],
            'hurricane_risk_category': risk_data['hurricane_risk_category'],
            'hurricane_count_50yr': len(historic_hurricanes),
            'hurricane_distance_to_coast_km': risk_data['distance_to_coast_km'],
            'hurricane_coastal_location': risk_data['coastal_location'],
            'hurricane_storm_surge_risk_score': surge_risk['storm_surge_risk_score'],
            'hurricane_wind_zone': wind_zone
        }
        
        logger.info(
            f"Hurricane features extracted: risk={features['hurricane_risk_score']:.2f}, "
            f"category={features['hurricane_risk_category']}"
        )
        
        return features
    
    def is_high_risk_hurricane_area(self, lat: float, lon: float) -> bool:
        """
        Check if location is in high hurricane risk area
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            True if high risk, False otherwise
        """
        risk_data = self.get_hurricane_risk(lat, lon)
        return risk_data['hurricane_risk_score'] >= 0.7
    
    def batch_hurricane_lookup(
        self,
        locations: List[Tuple[float, float]]
    ) -> pd.DataFrame:
        """
        Batch lookup hurricane risk for multiple locations
        
        Args:
            locations: List of (lat, lon) tuples
            
        Returns:
            DataFrame with hurricane data for all locations
        """
        logger.info(f"Batch hurricane lookup for {len(locations)} locations")
        
        results = []
        for i, (lat, lon) in enumerate(locations):
            logger.debug(f"Processing location {i+1}/{len(locations)}")
            
            features = self.get_enrichment_features(lat, lon)
            features['latitude'] = lat
            features['longitude'] = lon
            results.append(features)
        
        df = pd.DataFrame(results)
        logger.info(f"Batch lookup complete: {len(df)} records")
        
        return df
