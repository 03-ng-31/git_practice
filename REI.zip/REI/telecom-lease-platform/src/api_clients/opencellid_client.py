"""
OpenCelliD Client for cell tower location data
API Documentation: https://wiki.opencellid.org/wiki/API
"""
import pandas as pd
from typing import List, Dict, Optional, Tuple
from loguru import logger
import math
from .base_client import BaseAPIClient


class OpenCelliDClient(BaseAPIClient):
    """Client for OpenCelliD cell tower database API"""
    
    def __init__(self, api_key: str):
        """
        Initialize OpenCelliD client
        
        Args:
            api_key: OpenCelliD API key (get from https://opencellid.org/)
        """
        super().__init__(
            base_url="https://opencellid.org/cell",
            rate_limit_calls=1000,
            rate_limit_period=86400,  # 1000 calls per day
            cache_enabled=True,
            cache_expire_after=2592000  # 30 days
        )
        
        self.api_key = api_key
        logger.info("OpenCelliD Client initialized")
    
    def get_cell_position(
        self,
        mcc: int,
        mnc: int,
        lac: int,
        cellid: int
    ) -> Optional[Dict]:
        """
        Get cell tower position by cell identifiers
        
        Args:
            mcc: Mobile Country Code
            mnc: Mobile Network Code
            lac: Location Area Code
            cellid: Cell ID
            
        Returns:
            Dictionary with cell tower data or None if not found
        """
        logger.debug(f"Looking up cell: MCC={mcc}, MNC={mnc}, LAC={lac}, CellID={cellid}")
        
        try:
            params = {
                'key': self.api_key,
                'mcc': mcc,
                'mnc': mnc,
                'lac': lac,
                'cellid': cellid,
                'format': 'json'
            }
            
            response = self._make_request('GET', '/get', params=params)
            data = response.json()
            
            if data and 'lat' in data and 'lon' in data:
                logger.debug(f"Found cell at ({data['lat']}, {data['lon']})")
                return data
            else:
                logger.warning(f"Cell not found in database")
                return None
                
        except Exception as e:
            logger.error(f"Error getting cell position: {e}")
            return None
    
    def get_cells_in_area(
        self,
        lat: float,
        lon: float,
        radius: int = 5000
    ) -> List[Dict]:
        """
        Get all cell towers in a circular area
        
        Args:
            lat: Latitude of center point
            lon: Longitude of center point
            radius: Radius in meters (max 10000)
            
        Returns:
            List of cell tower dictionaries
        """
        logger.debug(f"Querying cells within {radius}m of ({lat}, {lon})")
        
        # Limit radius to API maximum
        radius = min(radius, 10000)
        
        try:
            params = {
                'key': self.api_key,
                'lat': lat,
                'lon': lon,
                'radius': radius,
                'format': 'json'
            }
            
            response = self._make_request('GET', '/getInArea', params=params)
            data = response.json()
            
            if isinstance(data, list):
                logger.info(f"Found {len(data)} cells in area")
                return data
            else:
                logger.warning("No cells found in area")
                return []
                
        except Exception as e:
            logger.error(f"Error getting cells in area: {e}")
            return []
    
    def count_towers_in_radius(
        self,
        lat: float,
        lon: float,
        radius_km: float
    ) -> int:
        """
        Count cell towers within radius
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius in kilometers
            
        Returns:
            Number of towers within radius
        """
        radius_meters = int(radius_km * 1000)
        radius_meters = min(radius_meters, 10000)  # API limit
        
        cells = self.get_cells_in_area(lat, lon, radius_meters)
        return len(cells)
    
    def get_tower_density(
        self,
        lat: float,
        lon: float,
        radius_km: float
    ) -> float:
        """
        Calculate cell tower density (towers per square km)
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius in kilometers
            
        Returns:
            Tower density (towers per sq km)
        """
        count = self.count_towers_in_radius(lat, lon, radius_km)
        
        # Calculate area
        area_sq_km = math.pi * (radius_km ** 2)
        density = count / area_sq_km if area_sq_km > 0 else 0
        
        logger.debug(f"OpenCelliD tower density at ({lat}, {lon}): {density:.4f} towers/sq km")
        return density
    
    def get_carrier_towers(
        self,
        lat: float,
        lon: float,
        radius_km: float,
        carrier_mcc_mnc: Optional[Tuple[int, int]] = None
    ) -> List[Dict]:
        """
        Get towers for a specific carrier in an area
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius in kilometers
            carrier_mcc_mnc: Tuple of (MCC, MNC) for specific carrier
            
        Returns:
            List of cell towers for the carrier
        """
        radius_meters = int(radius_km * 1000)
        radius_meters = min(radius_meters, 10000)
        
        cells = self.get_cells_in_area(lat, lon, radius_meters)
        
        if carrier_mcc_mnc:
            mcc, mnc = carrier_mcc_mnc
            cells = [
                cell for cell in cells
                if cell.get('mcc') == mcc and cell.get('mnc') == mnc
            ]
            logger.info(f"Found {len(cells)} towers for carrier MCC={mcc}, MNC={mnc}")
        
        return cells
    
    def get_coverage_overlap(
        self,
        lat: float,
        lon: float,
        radius_km: float
    ) -> Dict[str, int]:
        """
        Analyze coverage overlap by counting towers from different carriers
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius in kilometers
            
        Returns:
            Dictionary with carrier counts
        """
        radius_meters = int(radius_km * 1000)
        radius_meters = min(radius_meters, 10000)
        
        cells = self.get_cells_in_area(lat, lon, radius_meters)
        
        # Count by carrier (MCC-MNC combination)
        carrier_counts = {}
        for cell in cells:
            carrier_key = f"{cell.get('mcc', 'unknown')}-{cell.get('mnc', 'unknown')}"
            carrier_counts[carrier_key] = carrier_counts.get(carrier_key, 0) + 1
        
        logger.debug(f"Coverage overlap: {len(carrier_counts)} carriers in area")
        return carrier_counts
    
    def get_technology_distribution(
        self,
        lat: float,
        lon: float,
        radius_km: float
    ) -> Dict[str, int]:
        """
        Get distribution of cell tower technologies (2G, 3G, 4G, 5G)
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius in kilometers
            
        Returns:
            Dictionary with technology counts
        """
        radius_meters = int(radius_km * 1000)
        radius_meters = min(radius_meters, 10000)
        
        cells = self.get_cells_in_area(lat, lon, radius_meters)
        
        # Count by radio type
        tech_counts = {}
        for cell in cells:
            radio = cell.get('radio', 'unknown')
            tech_counts[radio] = tech_counts.get(radio, 0) + 1
        
        logger.debug(f"Technology distribution: {tech_counts}")
        return tech_counts
    
    def get_enrichment_features(
        self,
        lat: float,
        lon: float,
        radius_km: float = 3.0
    ) -> Dict[str, any]:
        """
        Get all OpenCelliD features for a location (for data enrichment)
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius in kilometers
            
        Returns:
            Dictionary with all features
        """
        logger.info(f"Getting OpenCelliD features for ({lat}, {lon})")
        
        features = {
            'opencellid_tower_count': self.count_towers_in_radius(lat, lon, radius_km),
            'opencellid_tower_density': self.get_tower_density(lat, lon, radius_km),
            'opencellid_carrier_count': len(self.get_coverage_overlap(lat, lon, radius_km)),
            'opencellid_tech_distribution': self.get_technology_distribution(lat, lon, radius_km)
        }
        
        logger.info(f"OpenCelliD features extracted: {features['opencellid_tower_count']} towers")
        return features
