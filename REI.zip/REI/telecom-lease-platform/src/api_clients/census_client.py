"""
US Census Bureau API Client for demographic data
API Documentation: https://www.census.gov/data/developers/guidance/api-user-guide.html
"""
import pandas as pd
from typing import List, Dict, Optional, Tuple
from loguru import logger
import math
from .base_client import BaseAPIClient


class CensusClient(BaseAPIClient):
    """Client for US Census Bureau API"""
    
    BASE_URL = "https://api.census.gov/data"
    GEOCODER_URL = "https://geocoding.geo.census.gov/geocoder"
    
    # Common ACS variables
    VARIABLES = {
        'population': 'B01003_001E',
        'median_income': 'B19013_001E',
        'housing_units': 'B25001_001E',
        'vacant_housing': 'B25002_003E',
        'bachelors_degree': 'B15003_022E',
        'median_age': 'B01002_001E',
        'median_home_value': 'B25077_001E',
        'median_rent': 'B25064_001E',
        'unemployment_rate': 'B23025_005E',
        'poverty_rate': 'B17001_002E'
    }
    
    def __init__(self, api_key: str, default_year: int = 2022, default_dataset: str = "acs5"):
        """
        Initialize Census API client
        
        Args:
            api_key: Census API key (get from https://api.census.gov/data/key_signup.html)
            default_year: Default year for data queries
            default_dataset: Default dataset (acs1, acs5, etc.)
        """
        super().__init__(
            base_url=self.BASE_URL,
            rate_limit_calls=500,
            rate_limit_period=86400,  # 500 calls per day
            cache_enabled=True,
            cache_expire_after=2592000  # 30 days
        )
        
        self.api_key = api_key
        self.default_year = default_year
        self.default_dataset = default_dataset
        
        logger.info(f"Census Client initialized (year={default_year}, dataset={default_dataset})")
    
    def get_acs_data(
        self,
        variables: List[str],
        geography: str,
        state: Optional[str] = None,
        county: Optional[str] = None,
        tract: Optional[str] = None,
        year: Optional[int] = None,
        dataset: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Get ACS data for specified variables and geography
        
        Args:
            variables: List of ACS variable codes
            geography: Geography level ('block group', 'tract', 'county', 'state')
            state: State FIPS code
            county: County FIPS code
            tract: Tract code
            year: Data year
            dataset: ACS dataset
            
        Returns:
            DataFrame with requested data
        """
        year = year or self.default_year
        dataset = dataset or self.default_dataset
        
        logger.debug(f"Querying ACS {dataset} data for {geography} (year={year})")
        
        # Build endpoint
        endpoint = f"/{year}/acs/{dataset}"
        
        # Build parameters
        params = {
            'get': ','.join(['NAME'] + variables),
            'key': self.api_key
        }
        
        # Build geography string
        if geography == 'block group':
            if not state or not county or not tract:
                raise ValueError("State, county, and tract required for block group")
            params['for'] = 'block group:*'
            params['in'] = f'state:{state} county:{county} tract:{tract}'
        elif geography == 'tract':
            if not state or not county:
                raise ValueError("State and county required for tract")
            params['for'] = 'tract:*'
            params['in'] = f'state:{state} county:{county}'
        elif geography == 'county':
            if not state:
                raise ValueError("State required for county")
            params['for'] = 'county:*'
            params['in'] = f'state:{state}'
        elif geography == 'state':
            params['for'] = 'state:*'
        else:
            raise ValueError(f"Invalid geography: {geography}")
        
        try:
            response = self._make_request('GET', endpoint, params=params)
            data = response.json()
            
            # Parse response
            if data and len(data) > 1:
                df = pd.DataFrame(data[1:], columns=data[0])
                logger.info(f"Retrieved {len(df)} records")
                return df
            else:
                logger.warning("No data returned from Census API")
                return pd.DataFrame()
                
        except Exception as e:
            logger.error(f"Error querying Census API: {e}")
            raise
    
    def geocode_coordinates(self, lat: float, lon: float) -> Dict:
        """
        Geocode lat/lon to Census geographies (FIPS codes)
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            Dictionary with FIPS codes
        """
        logger.debug(f"Geocoding coordinates: ({lat}, {lon})")
        
        try:
            url = f"{self.GEOCODER_URL}/geographies/coordinates"
            params = {
                'x': lon,
                'y': lat,
                'benchmark': 'Public_AR_Current',
                'vintage': 'Current_Current',
                'format': 'json'
            }
            
            response = self._make_request('GET', '', params=params)
            data = response.json()
            
            if 'result' in data and 'geographies' in data['result']:
                geographies = data['result']['geographies']
                
                # Extract FIPS codes
                fips = {}
                
                if 'Census Block Groups' in geographies and geographies['Census Block Groups']:
                    bg = geographies['Census Block Groups'][0]
                    fips = {
                        'state': bg.get('STATE'),
                        'county': bg.get('COUNTY'),
                        'tract': bg.get('TRACT'),
                        'block_group': bg.get('BLKGRP'),
                        'fips_full': bg.get('GEOID')
                    }
                
                logger.debug(f"Geocoded to: {fips}")
                return fips
            else:
                logger.warning("No geography found for coordinates")
                return {}
                
        except Exception as e:
            logger.error(f"Error geocoding coordinates: {e}")
            return {}
    
    def get_demographics_by_location(
        self,
        lat: float,
        lon: float,
        year: Optional[int] = None
    ) -> Dict:
        """
        Get demographic data for a specific location
        
        Args:
            lat: Latitude
            lon: Longitude
            year: Data year
            
        Returns:
            Dictionary with demographic data
        """
        logger.info(f"Getting demographics for location ({lat}, {lon})")
        
        # First geocode to get FIPS codes
        fips = self.geocode_coordinates(lat, lon)
        
        if not fips or 'state' not in fips:
            logger.warning("Could not geocode location")
            return {}
        
        # Query demographic data for the block group
        variables = list(self.VARIABLES.values())
        
        try:
            df = self.get_acs_data(
                variables=variables,
                geography='block group',
                state=fips['state'],
                county=fips['county'],
                tract=fips['tract'],
                year=year
            )
            
            if df.empty:
                return {}
            
            # Filter to specific block group
            result = df[df['block group'] == fips['block_group']]
            
            if result.empty:
                return {}
            
            # Build output dictionary
            row = result.iloc[0]
            output = {
                'fips_code': fips.get('fips_full'),
                'state': fips.get('state'),
                'county': fips.get('county'),
                'tract': fips.get('tract'),
                'block_group': fips.get('block_group')
            }
            
            # Add demographic variables
            for name, code in self.VARIABLES.items():
                if code in row:
                    try:
                        output[name] = float(row[code]) if row[code] not in [None, '', '-'] else None
                    except (ValueError, TypeError):
                        output[name] = None
            
            logger.info(f"Demographics retrieved: population={output.get('population')}")
            return output
            
        except Exception as e:
            logger.error(f"Error getting demographics: {e}")
            return {}
    
    def get_population_in_radius(
        self,
        lat: float,
        lon: float,
        radius_km: float
    ) -> int:
        """
        Estimate population within radius of a point
        
        Note: This is a simplified implementation that gets the block group population.
        A more accurate implementation would query multiple block groups within the radius.
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius in kilometers
            
        Returns:
            Estimated population
        """
        demographics = self.get_demographics_by_location(lat, lon)
        population = demographics.get('population', 0)
        
        if population:
            # Scale by radius (rough approximation)
            # Assume block group is ~1 sq km, scale proportionally
            area_factor = math.pi * (radius_km ** 2)
            estimated_pop = int(population * area_factor)
            logger.debug(f"Estimated population in {radius_km}km radius: {estimated_pop}")
            return estimated_pop
        
        return 0
    
    def get_enrichment_features(
        self,
        lat: float,
        lon: float,
        radius_km: float = 3.0
    ) -> Dict:
        """
        Get all Census features for a location (for data enrichment)
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius for population estimation
            
        Returns:
            Dictionary with all features
        """
        logger.info(f"Getting Census features for ({lat}, {lon})")
        
        demographics = self.get_demographics_by_location(lat, lon)
        
        if not demographics:
            logger.warning("No demographics found")
            return {}
        
        # Calculate derived features
        features = {
            'census_fips_code': demographics.get('fips_code'),
            'census_population': demographics.get('population'),
            'census_median_income': demographics.get('median_income'),
            'census_housing_units': demographics.get('housing_units'),
            'census_vacant_housing': demographics.get('vacant_housing'),
            'census_median_age': demographics.get('median_age'),
            'census_median_home_value': demographics.get('median_home_value'),
            'census_median_rent': demographics.get('median_rent'),
        }
        
        # Calculate population density (rough estimate)
        if demographics.get('population'):
            # Assume block group is approximately 1 sq km
            features['census_population_density'] = demographics.get('population', 0)
            
            # Estimate population in radius
            features[f'census_population_{int(radius_km)}km'] = self.get_population_in_radius(
                lat, lon, radius_km
            )
        
        # Calculate vacancy rate
        if demographics.get('housing_units') and demographics.get('vacant_housing'):
            features['census_vacancy_rate'] = (
                demographics['vacant_housing'] / demographics['housing_units']
            )
        
        logger.info(f"Census features extracted: population={features.get('census_population')}")
        return features
