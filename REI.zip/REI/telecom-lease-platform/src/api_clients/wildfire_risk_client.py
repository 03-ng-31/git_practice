"""
Wildfire Risk API Client for NIFC (National Interagency Fire Center) data
API Documentation: https://data-nifc.opendata.arcgis.com/
"""
import pandas as pd
from typing import Dict, Optional, List, Tuple
from loguru import logger
from datetime import datetime, timedelta
from .base_client import BaseAPIClient


class WildfireRiskClient(BaseAPIClient):
    """Client for NIFC Wildfire Hazard data"""
    
    # NIFC ArcGIS REST API
    BASE_URL = "https://services3.arcgis.com/T4QMspbfLg3qTGWY/arcgis/rest/services"
    
    # Wildfire risk rating mapping
    RISK_RATING_MAP = {
        'Very Low': 0.1,
        'Low': 0.3,
        'Moderate': 0.5,
        'High': 0.7,
        'Very High': 0.9
    }
    
    def __init__(self):
        """Initialize Wildfire Risk client"""
        super().__init__(
            base_url=self.BASE_URL,
            rate_limit_calls=100,
            rate_limit_period=60,
            cache_enabled=True,
            cache_expire_after=2592000  # 30 days
        )
        logger.info("Wildfire Risk Client initialized")
    
    def get_wildfire_risk(self, lat: float, lon: float) -> Dict:
        """
        Get wildfire risk for a location
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            Dictionary with wildfire risk data
        """
        logger.debug(f"Querying wildfire risk for ({lat}, {lon})")
        
        try:
            # Query Wildfire Hazard Potential layer
            # Note: This is a simplified implementation
            # In production, you would query the actual NIFC WHP layer
            
            # For now, use a heuristic based on location
            # Western US has higher wildfire risk
            risk_score = self._estimate_wildfire_risk(lat, lon)
            
            return {
                'wildfire_risk_score': risk_score,
                'wildfire_danger_rating': self._get_danger_rating(risk_score),
                'data_source': 'NIFC (estimated)',
                'query_date': datetime.now().strftime('%Y-%m-%d')
            }
            
        except Exception as e:
            logger.error(f"Error querying wildfire risk: {e}")
            return self._get_default_wildfire_data()
    
    def _estimate_wildfire_risk(self, lat: float, lon: float) -> float:
        """
        Estimate wildfire risk based on location
        
        This is a simplified heuristic. In production, query actual NIFC API.
        Western states (CA, OR, WA, NV, AZ, NM, CO, UT, ID, MT, WY) have higher risk.
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            Risk score (0-1)
        """
        # Western US (high risk): longitude < -100
        # Southwest (very high risk): lat 30-40, lon < -105
        # Pacific Northwest (high risk): lat > 42, lon < -115
        
        if lon < -115 and 42 < lat < 49:
            # Pacific Northwest
            return 0.7
        elif lon < -105 and 30 < lat < 40:
            # Southwest (CA, AZ, NM)
            return 0.8
        elif lon < -100 and 35 < lat < 50:
            # Mountain West
            return 0.6
        elif lon < -95:
            # Western US general
            return 0.5
        else:
            # Eastern US
            return 0.2
    
    def _get_danger_rating(self, risk_score: float) -> str:
        """
        Convert risk score to danger rating
        
        Args:
            risk_score: Risk score (0-1)
            
        Returns:
            Danger rating string
        """
        if risk_score >= 0.8:
            return 'Very High'
        elif risk_score >= 0.6:
            return 'High'
        elif risk_score >= 0.4:
            return 'Moderate'
        elif risk_score >= 0.2:
            return 'Low'
        else:
            return 'Very Low'
    
    def _get_default_wildfire_data(self) -> Dict:
        """Return default wildfire data"""
        return {
            'wildfire_risk_score': 0.3,
            'wildfire_danger_rating': 'Moderate',
            'data_source': 'Default',
            'query_date': datetime.now().strftime('%Y-%m-%d')
        }
    
    def get_historic_fires(
        self,
        lat: float,
        lon: float,
        radius_km: float = 50,
        years: int = 10
    ) -> List[Dict]:
        """
        Get historic wildfires in area
        
        Note: This is a placeholder. In production, query NIFC historic fire database.
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius in kilometers
            years: Number of years to look back
            
        Returns:
            List of historic fires
        """
        logger.debug(f"Querying historic fires within {radius_km}km of ({lat}, {lon})")
        
        # Placeholder: return empty list
        # In production, query NIFC Fire Perimeter database
        return []
    
    def get_fire_season_info(self, lat: float, lon: float) -> Dict:
        """
        Get fire season information for location
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            Dictionary with fire season info
        """
        # Simplified fire season by region
        if lon < -115 and 32 < lat < 42:
            # California/Southwest
            return {
                'fire_season_start_month': 'May',
                'fire_season_end_month': 'October',
                'fire_season_length_months': 6,
                'peak_fire_months': 'July-September'
            }
        elif lon < -100 and lat > 40:
            # Mountain West
            return {
                'fire_season_start_month': 'June',
                'fire_season_end_month': 'September',
                'fire_season_length_months': 4,
                'peak_fire_months': 'July-August'
            }
        else:
            # Other regions
            return {
                'fire_season_start_month': 'April',
                'fire_season_end_month': 'October',
                'fire_season_length_months': 7,
                'peak_fire_months': 'June-August'
            }
    
    def get_enrichment_features(
        self,
        lat: float,
        lon: float,
        radius_km: float = 50
    ) -> Dict:
        """
        Get all wildfire features for data enrichment
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius for historic fire queries
            
        Returns:
            Dictionary with wildfire-related features
        """
        logger.info(f"Getting wildfire features for ({lat}, {lon})")
        
        # Get risk data
        risk_data = self.get_wildfire_risk(lat, lon)
        
        # Get historic fires
        historic_fires = self.get_historic_fires(lat, lon, radius_km, years=10)
        
        # Get fire season info
        season_info = self.get_fire_season_info(lat, lon)
        
        features = {
            'wildfire_risk_score': risk_data['wildfire_risk_score'],
            'wildfire_danger_rating': risk_data['wildfire_danger_rating'],
            'wildfire_historic_fires_10yr': len(historic_fires),
            'wildfire_fire_season_length_months': season_info['fire_season_length_months'],
            'wildfire_peak_fire_months': season_info['peak_fire_months']
        }
        
        logger.info(
            f"Wildfire features extracted: risk={features['wildfire_risk_score']:.2f}, "
            f"rating={features['wildfire_danger_rating']}"
        )
        
        return features
    
    def is_high_risk_wildfire_area(self, lat: float, lon: float) -> bool:
        """
        Check if location is in high wildfire risk area
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            True if high risk, False otherwise
        """
        risk_data = self.get_wildfire_risk(lat, lon)
        return risk_data['wildfire_risk_score'] >= 0.7
    
    def batch_wildfire_lookup(
        self,
        locations: List[Tuple[float, float]]
    ) -> pd.DataFrame:
        """
        Batch lookup wildfire risk for multiple locations
        
        Args:
            locations: List of (lat, lon) tuples
            
        Returns:
            DataFrame with wildfire data for all locations
        """
        logger.info(f"Batch wildfire lookup for {len(locations)} locations")
        
        results = []
        for i, (lat, lon) in enumerate(locations):
            logger.debug(f"Processing location {i+1}/{len(locations)}")
            
            features = self.get_enrichment_features(lat, lon)
            features['latitude'] = lat
            features['longitude'] = lon
            results.append(features)
        
        df = pd.DataFrame(results)
        logger.info(f"Batch lookup complete: {len(df)} records")
        
        return df
