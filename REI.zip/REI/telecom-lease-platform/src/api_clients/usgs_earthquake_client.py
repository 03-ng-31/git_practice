"""
USGS Earthquake API Client for seismic hazard data
API Documentation: https://earthquake.usgs.gov/fdsnws/event/1/
"""
import pandas as pd
from typing import Dict, Optional, List, Tuple
from loguru import logger
from datetime import datetime, timedelta
import math
from .base_client import BaseAPIClient


class USGSEarthquakeClient(BaseAPIClient):
    """Client for USGS Earthquake Hazards Program API"""
    
    BASE_URL = "https://earthquake.usgs.gov/fdsnws/event/1"
    
    def __init__(self):
        """Initialize USGS Earthquake client"""
        super().__init__(
            base_url=self.BASE_URL,
            rate_limit_calls=1000,
            rate_limit_period=3600,  # 1000 calls per hour
            cache_enabled=True,
            cache_expire_after=86400  # 1 day cache for earthquake data
        )
        logger.info("USGS Earthquake Client initialized")
    
    def get_earthquakes_in_area(
        self,
        lat: float,
        lon: float,
        radius_km: float = 50,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        min_magnitude: float = 3.0,
        max_results: int = 1000
    ) -> List[Dict]:
        """
        Get earthquakes in circular area
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius in kilometers (max 20000)
            start_date: Start date (YYYY-MM-DD), defaults to 10 years ago
            end_date: End date (YYYY-MM-DD), defaults to today
            min_magnitude: Minimum magnitude
            max_results: Maximum number of results
            
        Returns:
            List of earthquake dictionaries
        """
        logger.debug(
            f"Querying earthquakes within {radius_km}km of ({lat}, {lon}), "
            f"magnitude >= {min_magnitude}"
        )
        
        # Default to 10 years of data
        if not start_date:
            start_date = (datetime.now() - timedelta(days=3650)).strftime('%Y-%m-%d')
        if not end_date:
            end_date = datetime.now().strftime('%Y-%m-%d')
        
        # Limit radius to API maximum
        radius_km = min(radius_km, 20000)
        
        try:
            endpoint = "/query"
            
            params = {
                'format': 'geojson',
                'latitude': lat,
                'longitude': lon,
                'maxradiuskm': radius_km,
                'starttime': start_date,
                'endtime': end_date,
                'minmagnitude': min_magnitude,
                'orderby': 'magnitude',
                'limit': max_results
            }
            
            response = self._make_request('GET', endpoint, params=params)
            data = response.json()
            
            earthquakes = []
            for feature in data.get('features', []):
                props = feature['properties']
                coords = feature['geometry']['coordinates']
                
                earthquakes.append({
                    'magnitude': props.get('mag'),
                    'place': props.get('place'),
                    'time': props.get('time'),
                    'time_str': datetime.fromtimestamp(
                        props.get('time', 0) / 1000
                    ).strftime('%Y-%m-%d %H:%M:%S'),
                    'latitude': coords[1],
                    'longitude': coords[0],
                    'depth_km': coords[2],
                    'type': props.get('type'),
                    'status': props.get('status')
                })
            
            logger.info(f"Found {len(earthquakes)} earthquakes")
            return earthquakes
            
        except Exception as e:
            logger.error(f"Error querying USGS earthquake data: {e}")
            return []
    
    def get_earthquake_count(
        self,
        lat: float,
        lon: float,
        radius_km: float = 50,
        years: int = 10,
        min_magnitude: float = 3.0
    ) -> int:
        """
        Count earthquakes within radius and time period
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius in kilometers
            years: Number of years to look back
            min_magnitude: Minimum magnitude
            
        Returns:
            Number of earthquakes
        """
        start_date = (datetime.now() - timedelta(days=years*365)).strftime('%Y-%m-%d')
        
        earthquakes = self.get_earthquakes_in_area(
            lat, lon, radius_km, start_date, min_magnitude=min_magnitude
        )
        
        return len(earthquakes)
    
    def get_significant_earthquakes(
        self,
        lat: float,
        lon: float,
        radius_km: float = 50,
        years: int = 10,
        min_magnitude: float = 5.0
    ) -> List[Dict]:
        """
        Get significant earthquakes (magnitude >= 5.0)
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius in kilometers
            years: Number of years to look back
            min_magnitude: Minimum magnitude (default 5.0)
            
        Returns:
            List of significant earthquakes
        """
        start_date = (datetime.now() - timedelta(days=years*365)).strftime('%Y-%m-%d')
        
        return self.get_earthquakes_in_area(
            lat, lon, radius_km, start_date, min_magnitude=min_magnitude
        )
    
    def get_largest_earthquake(
        self,
        lat: float,
        lon: float,
        radius_km: float = 50,
        years: int = 10
    ) -> Optional[Dict]:
        """
        Get largest earthquake in area
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius in kilometers
            years: Number of years to look back
            
        Returns:
            Dictionary with largest earthquake or None
        """
        earthquakes = self.get_earthquakes_in_area(
            lat, lon, radius_km, years=years, min_magnitude=2.0
        )
        
        if not earthquakes:
            return None
        
        # Find earthquake with maximum magnitude
        largest = max(earthquakes, key=lambda x: x['magnitude'])
        return largest
    
    def get_seismic_hazard_score(
        self,
        lat: float,
        lon: float,
        radius_km: float = 50,
        years: int = 10
    ) -> float:
        """
        Calculate seismic hazard score (0-1) based on earthquake activity
        
        Score is based on:
        - Frequency of earthquakes
        - Maximum magnitude observed
        - Number of significant earthquakes (mag >= 5.0)
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius in kilometers
            years: Number of years to look back
            
        Returns:
            Hazard score between 0 and 1
        """
        logger.debug(f"Calculating seismic hazard score for ({lat}, {lon})")
        
        try:
            # Get all earthquakes magnitude >= 3.0
            earthquakes = self.get_earthquakes_in_area(
                lat, lon, radius_km, years=years, min_magnitude=3.0
            )
            
            if not earthquakes:
                logger.debug("No earthquakes found - hazard score = 0")
                return 0.0
            
            # Calculate frequency score (0-0.4)
            count = len(earthquakes)
            frequency_score = min(count / 50, 0.4)  # 50+ earthquakes = max 0.4
            
            # Calculate magnitude score (0-0.4)
            max_magnitude = max([eq['magnitude'] for eq in earthquakes])
            magnitude_score = min((max_magnitude - 3) / 5, 0.4)  # Mag 8+ = max 0.4
            
            # Calculate significant earthquake score (0-0.2)
            significant = [eq for eq in earthquakes if eq['magnitude'] >= 5.0]
            significant_score = min(len(significant) / 10, 0.2)  # 10+ = max 0.2
            
            # Total score
            total_score = frequency_score + magnitude_score + significant_score
            
            logger.debug(
                f"Seismic hazard score: {total_score:.3f} "
                f"(freq={frequency_score:.3f}, mag={magnitude_score:.3f}, "
                f"sig={significant_score:.3f})"
            )
            
            return round(total_score, 3)
            
        except Exception as e:
            logger.error(f"Error calculating seismic hazard score: {e}")
            return 0.0
    
    def get_seismic_risk_category(self, hazard_score: float) -> str:
        """
        Get human-readable risk category
        
        Args:
            hazard_score: Seismic hazard score (0-1)
            
        Returns:
            Risk category string
        """
        if hazard_score >= 0.7:
            return 'Very High Risk'
        elif hazard_score >= 0.5:
            return 'High Risk'
        elif hazard_score >= 0.3:
            return 'Moderate Risk'
        elif hazard_score >= 0.1:
            return 'Low Risk'
        else:
            return 'Minimal Risk'
    
    def get_earthquake_statistics(
        self,
        lat: float,
        lon: float,
        radius_km: float = 50,
        years: int = 10
    ) -> Dict:
        """
        Get comprehensive earthquake statistics for an area
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius in kilometers
            years: Number of years to look back
            
        Returns:
            Dictionary with earthquake statistics
        """
        logger.info(f"Getting earthquake statistics for ({lat}, {lon})")
        
        earthquakes = self.get_earthquakes_in_area(
            lat, lon, radius_km, years=years, min_magnitude=2.0
        )
        
        if not earthquakes:
            return {
                'total_count': 0,
                'count_magnitude_3plus': 0,
                'count_magnitude_5plus': 0,
                'max_magnitude': 0,
                'avg_magnitude': 0,
                'most_recent_date': None,
                'earthquakes_per_year': 0
            }
        
        # Calculate statistics
        magnitudes = [eq['magnitude'] for eq in earthquakes]
        count_3plus = len([m for m in magnitudes if m >= 3.0])
        count_5plus = len([m for m in magnitudes if m >= 5.0])
        
        # Most recent earthquake
        most_recent = max(earthquakes, key=lambda x: x['time'])
        
        stats = {
            'total_count': len(earthquakes),
            'count_magnitude_3plus': count_3plus,
            'count_magnitude_5plus': count_5plus,
            'max_magnitude': max(magnitudes),
            'avg_magnitude': sum(magnitudes) / len(magnitudes),
            'most_recent_date': most_recent['time_str'],
            'earthquakes_per_year': len(earthquakes) / years
        }
        
        logger.info(
            f"Earthquake statistics: {stats['total_count']} total, "
            f"max magnitude {stats['max_magnitude']:.1f}"
        )
        
        return stats
    
    def get_enrichment_features(
        self,
        lat: float,
        lon: float,
        radius_km: float = 50,
        years: int = 10
    ) -> Dict:
        """
        Get all USGS earthquake features for data enrichment
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius in kilometers
            years: Number of years to look back
            
        Returns:
            Dictionary with earthquake-related features
        """
        logger.info(f"Getting USGS earthquake features for ({lat}, {lon})")
        
        # Get statistics
        stats = self.get_earthquake_statistics(lat, lon, radius_km, years)
        
        # Get hazard score
        hazard_score = self.get_seismic_hazard_score(lat, lon, radius_km, years)
        
        features = {
            'usgs_earthquake_count_total': stats['total_count'],
            'usgs_earthquake_count_3plus': stats['count_magnitude_3plus'],
            'usgs_earthquake_count_5plus': stats['count_magnitude_5plus'],
            'usgs_max_magnitude': stats['max_magnitude'],
            'usgs_avg_magnitude': round(stats['avg_magnitude'], 2),
            'usgs_most_recent_earthquake': stats['most_recent_date'],
            'usgs_earthquakes_per_year': round(stats['earthquakes_per_year'], 2),
            'usgs_seismic_hazard_score': hazard_score,
            'usgs_seismic_risk_category': self.get_seismic_risk_category(hazard_score)
        }
        
        logger.info(
            f"USGS features extracted: {features['usgs_earthquake_count_3plus']} earthquakes, "
            f"hazard score={hazard_score:.3f}"
        )
        
        return features
    
    def batch_earthquake_lookup(
        self,
        locations: List[Tuple[float, float]],
        radius_km: float = 50,
        years: int = 10
    ) -> pd.DataFrame:
        """
        Batch lookup earthquake data for multiple locations
        
        Args:
            locations: List of (lat, lon) tuples
            radius_km: Radius in kilometers
            years: Number of years to look back
            
        Returns:
            DataFrame with earthquake data for all locations
        """
        logger.info(f"Batch earthquake lookup for {len(locations)} locations")
        
        results = []
        for i, (lat, lon) in enumerate(locations):
            logger.debug(f"Processing location {i+1}/{len(locations)}")
            
            features = self.get_enrichment_features(lat, lon, radius_km, years)
            features['latitude'] = lat
            features['longitude'] = lon
            results.append(features)
        
        df = pd.DataFrame(results)
        logger.info(f"Batch lookup complete: {len(df)} records")
        
        return df
