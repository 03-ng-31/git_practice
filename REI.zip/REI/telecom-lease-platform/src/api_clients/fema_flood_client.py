"""
FEMA Flood API Client for National Flood Hazard Layer data
API Documentation: https://hazards.fema.gov/gis/nfhl/services/
"""
import pandas as pd
from typing import Dict, Optional, List, Tuple
from loguru import logger
from datetime import datetime
from .base_client import BaseAPIClient


class FEMAFloodClient(BaseAPIClient):
    """Client for FEMA National Flood Hazard Layer API"""
    
    # FEMA ArcGIS REST API endpoints
    BASE_URL = "https://hazards.fema.gov/gis/nfhl/rest/services/public/NFHL/MapServer"
    
    # Flood zone risk mapping
    FLOOD_ZONE_RISK = {
        'A': 0.8,    # High risk - 1% annual chance
        'AE': 0.8,   # High risk with BFE
        'AH': 0.7,   # Shallow flooding
        'AO': 0.7,   # Sheet flow flooding
        'AR': 0.6,   # Flood control system
        'A99': 0.5,  # To be protected
        'V': 0.9,    # Coastal high hazard
        'VE': 0.9,   # Coastal with BFE
        'X': 0.1,    # Minimal flood hazard
        'B': 0.2,    # Moderate flood hazard (old)
        'C': 0.1,    # Minimal flood hazard (old)
        'D': 0.3,    # Undetermined
    }
    
    def __init__(self):
        """Initialize FEMA Flood client"""
        super().__init__(
            base_url=self.BASE_URL,
            rate_limit_calls=100,
            rate_limit_period=60,
            cache_enabled=True,
            cache_expire_after=2592000  # 30 days
        )
        logger.info("FEMA Flood Client initialized")
    
    def get_flood_zone(self, lat: float, lon: float) -> Dict:
        """
        Get flood zone information for a location
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            Dictionary with flood zone data
        """
        logger.debug(f"Querying FEMA flood zone for ({lat}, {lon})")
        
        try:
            # Use FEMA identify service
            endpoint = "/identify"
            
            # Build geometry parameter
            geometry = f'{{"x":{lon},"y":{lat},"spatialReference":{{"wkid":4326}}}}'
            
            params = {
                'geometry': geometry,
                'geometryType': 'esriGeometryPoint',
                'sr': 4326,
                'layers': 'all:28',  # Layer 28 is flood hazard areas
                'tolerance': 10,
                'mapExtent': f'{lon-0.01},{lat-0.01},{lon+0.01},{lat+0.01}',
                'imageDisplay': '400,400,96',
                'returnGeometry': 'false',
                'f': 'json'
            }
            
            response = self._make_request('GET', endpoint, params=params)
            data = response.json()
            
            # Parse response
            flood_data = self._parse_flood_response(data)
            
            if flood_data:
                logger.info(f"Flood zone found: {flood_data.get('flood_zone')}")
            else:
                logger.warning("No flood zone data found - defaulting to Zone X")
                flood_data = self._get_default_flood_data()
            
            return flood_data
            
        except Exception as e:
            logger.error(f"Error querying FEMA flood data: {e}")
            # Return default low-risk zone on error
            return self._get_default_flood_data()
    
    def _parse_flood_response(self, data: Dict) -> Optional[Dict]:
        """Parse FEMA API response"""
        try:
            results = data.get('results', [])
            
            if not results:
                return None
            
            # Get first result (closest match)
            result = results[0]
            attributes = result.get('attributes', {})
            
            # Extract flood zone information
            flood_zone = attributes.get('FLD_ZONE', 'X')
            zone_subtype = attributes.get('ZONE_SUBTY', '')
            static_bfe = attributes.get('STATIC_BFE', None)
            dfirm_id = attributes.get('DFIRM_ID', '')
            
            # Calculate risk score
            risk_score = self._calculate_risk_score(flood_zone)
            
            return {
                'flood_zone': flood_zone,
                'zone_subtype': zone_subtype,
                'base_flood_elevation': static_bfe,
                'dfirm_id': dfirm_id,
                'flood_risk_score': risk_score,
                'data_source': 'FEMA NFHL',
                'query_date': datetime.now().strftime('%Y-%m-%d')
            }
            
        except Exception as e:
            logger.error(f"Error parsing FEMA response: {e}")
            return None
    
    def _calculate_risk_score(self, flood_zone: str) -> float:
        """
        Calculate flood risk score (0-1) based on zone
        
        Args:
            flood_zone: FEMA flood zone designation
            
        Returns:
            Risk score between 0 and 1
        """
        # Extract base zone (remove modifiers)
        base_zone = flood_zone.split()[0] if flood_zone else 'X'
        
        # Get risk score from mapping
        risk_score = self.FLOOD_ZONE_RISK.get(base_zone, 0.3)
        
        return risk_score
    
    def _get_default_flood_data(self) -> Dict:
        """Return default flood data for areas with no FEMA data"""
        return {
            'flood_zone': 'X',
            'zone_subtype': 'Area of Minimal Flood Hazard',
            'base_flood_elevation': None,
            'dfirm_id': None,
            'flood_risk_score': 0.1,
            'data_source': 'Default (No FEMA data)',
            'query_date': datetime.now().strftime('%Y-%m-%d')
        }
    
    def get_flood_risk_category(self, flood_zone: str) -> str:
        """
        Get human-readable risk category
        
        Args:
            flood_zone: FEMA flood zone
            
        Returns:
            Risk category string
        """
        risk_score = self._calculate_risk_score(flood_zone)
        
        if risk_score >= 0.7:
            return 'High Risk'
        elif risk_score >= 0.4:
            return 'Moderate Risk'
        else:
            return 'Low Risk'
    
    def batch_flood_lookup(
        self,
        locations: List[Tuple[float, float]]
    ) -> pd.DataFrame:
        """
        Batch lookup flood zones for multiple locations
        
        Args:
            locations: List of (lat, lon) tuples
            
        Returns:
            DataFrame with flood data for all locations
        """
        logger.info(f"Batch flood lookup for {len(locations)} locations")
        
        results = []
        for i, (lat, lon) in enumerate(locations):
            logger.debug(f"Processing location {i+1}/{len(locations)}")
            
            flood_data = self.get_flood_zone(lat, lon)
            flood_data['latitude'] = lat
            flood_data['longitude'] = lon
            results.append(flood_data)
        
        df = pd.DataFrame(results)
        logger.info(f"Batch lookup complete: {len(df)} records")
        
        return df
    
    def get_enrichment_features(
        self,
        lat: float,
        lon: float
    ) -> Dict:
        """
        Get all FEMA flood features for data enrichment
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            Dictionary with flood-related features
        """
        logger.info(f"Getting FEMA flood features for ({lat}, {lon})")
        
        flood_data = self.get_flood_zone(lat, lon)
        
        features = {
            'fema_flood_zone': flood_data.get('flood_zone'),
            'fema_flood_risk_score': flood_data.get('flood_risk_score'),
            'fema_flood_risk_category': self.get_flood_risk_category(
                flood_data.get('flood_zone', 'X')
            ),
            'fema_base_flood_elevation': flood_data.get('base_flood_elevation'),
            'fema_dfirm_id': flood_data.get('dfirm_id'),
            'fema_data_source': flood_data.get('data_source')
        }
        
        logger.info(
            f"FEMA features extracted: zone={features['fema_flood_zone']}, "
            f"risk={features['fema_flood_risk_score']:.2f}"
        )
        
        return features
    
    def is_high_risk_flood_zone(self, flood_zone: str) -> bool:
        """
        Check if flood zone is considered high risk
        
        Args:
            flood_zone: FEMA flood zone
            
        Returns:
            True if high risk, False otherwise
        """
        risk_score = self._calculate_risk_score(flood_zone)
        return risk_score >= 0.7
