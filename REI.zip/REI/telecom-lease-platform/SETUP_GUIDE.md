# Setup Guide - Telecom Lease Platform

## Step 1: Install Python 3.9+

### Option A: Download from Python.org
1. Go to https://www.python.org/downloads/
2. Download Python 3.9 or higher (3.10 or 3.11 recommended)
3. Run the installer
4. **IMPORTANT**: Check "Add Python to PATH" during installation
5. Verify installation:
   ```bash
   python --version
   ```

### Option B: Install via Microsoft Store
1. Open Microsoft Store
2. Search for "Python 3.11"
3. Click "Get" to install
4. Verify installation in PowerShell

## Step 2: Create Virtual Environment

Open PowerShell in the project directory:
```bash
cd C:\Users\hp\Desktop\REI\telecom-lease-platform
```

Create virtual environment:
```bash
python -m venv venv
```

Activate virtual environment:
```bash
.\venv\Scripts\Activate.ps1
```

If you get an execution policy error, run:
```bash
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

## Step 3: Install Dependencies

With virtual environment activated:
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

This will install all required packages including:
- requests, pandas, numpy
- geopandas, shapely
- loguru, tenacity
- census API wrapper
- and more...

## Step 4: Register for API Keys

### Census API (Required)
1. Go to: https://api.census.gov/data/key_signup.html
2. Fill out the form with your email
3. You'll receive the API key via email instantly
4. Copy the key

### OpenCelliD API (Required)
1. Go to: https://opencellid.org/register
2. Create a free account
3. Go to your dashboard: https://my.opencellid.org/dashboard
4. Copy your API token

## Step 5: Configure Environment

Create `.env` file in project root:
```bash
copy .env.example .env
```

Edit `.env` file and add your API keys:
```
CENSUS_API_KEY=your_census_api_key_here
OPENCELLID_API_KEY=your_opencellid_api_key_here
FEMA_FLOOD_API_KEY=optional_for_now
```

## Step 6: Test Installation

Run the quick test script:
```bash
python test_quick.py
```

Expected output:
```
============================================================
TELECOM LEASE PLATFORM - QUICK TEST
============================================================

============================================================
Testing FCC Client
============================================================
Creating sample FCC database...
✓ Sample database created with 5 towers
✓ Found 5 towers within 5km
✓ Tower density: 0.0637 towers/sq km

============================================================
Testing OpenCelliD Client
============================================================
✓ OpenCelliD client initialized

============================================================
Testing Census Client
============================================================
✓ Census client initialized

============================================================
TEST SUMMARY
============================================================
FCC Client: ✓ PASS
OpenCelliD Client: ✓ PASS
Census Client: ✓ PASS
```

## Step 7: Run Jupyter Notebook

Start Jupyter:
```bash
jupyter notebook
```

This will open your browser. Navigate to:
- `notebooks/01_api_testing.ipynb`

Run all cells to test the APIs with real data.

## Troubleshooting

### Python not found
- Make sure Python is added to PATH
- Restart PowerShell after Python installation
- Try `py` instead of `python` on Windows

### Virtual environment activation fails
- Run: `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser`
- Or use Command Prompt instead of PowerShell

### Module import errors
- Make sure virtual environment is activated (you should see `(venv)` in prompt)
- Reinstall dependencies: `pip install -r requirements.txt`

### API key errors
- Verify keys are correctly copied to `.env` file
- No extra spaces or quotes around keys
- Keys should be on separate lines

### FCC database errors
- The FCC client creates a sample database automatically
- Database is stored in `data/raw/fcc/asr_database.db`
- To reset: delete the database file and run again

## Project Structure

```
telecom-lease-platform/
├── src/
│   └── api_clients/
│       ├── base_client.py       # ✓ Base API client with rate limiting
│       ├── fcc_client.py        # ✓ FCC tower data
│       ├── opencellid_client.py # ✓ Cell tower locations
│       └── census_client.py     # ✓ Demographics
├── notebooks/
│   └── 01_api_testing.ipynb     # ✓ Testing notebook
├── config/
│   └── config.yaml              # ✓ Configuration
├── data/
│   ├── raw/                     # Raw data storage
│   ├── processed/               # Processed data
│   └── cache/                   # API response cache
├── requirements.txt             # ✓ Dependencies
├── .env                         # API keys (create this)
└── README.md                    # ✓ Documentation
```

## What's Implemented

✅ **Base API Client**
- Rate limiting (respects API quotas)
- Response caching (SQLite backend)
- Automatic retries with exponential backoff
- Error handling and logging

✅ **FCC Client**
- Local SQLite database for tower data
- Query towers by radius
- Calculate tower density
- Sample data generator for testing

✅ **OpenCelliD Client**
- Cell tower location lookup
- Tower count in radius
- Coverage overlap analysis
- Technology distribution (4G/5G)

✅ **Census API Client**
- Demographic data retrieval
- Geocoding (lat/lon to FIPS codes)
- Population, income, housing data
- Block group level granularity

## Next Steps

1. ✅ Install Python 3.9+
2. ✅ Create virtual environment
3. ✅ Install dependencies
4. ✅ Register for API keys
5. ✅ Configure .env file
6. ✅ Run test_quick.py
7. ✅ Open Jupyter notebook
8. ✅ Test APIs with real data
9. 📊 Analyze data structure
10. 🔧 Build cross-sectional dataset

## Support

If you encounter issues:
1. Check the troubleshooting section above
2. Review logs in `logs/` directory
3. Verify API keys are valid
4. Check internet connection for API calls

## API Rate Limits

- **Census API**: 500 calls/day per IP
- **OpenCelliD**: 1,000 calls/day (free tier)
- **FCC**: No API (local database)

Built-in rate limiting prevents exceeding these limits.
