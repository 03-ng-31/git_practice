"""
Quick test script to verify API clients are working
Run this after installing dependencies
"""
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

from src.api_clients import FCCClient, OpenCelliDClient, CensusClient
from loguru import logger
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logger
logger.add("logs/test.log", rotation="10 MB")

def test_fcc_client():
    """Test FCC client with sample data"""
    print("\n" + "="*60)
    print("Testing FCC Client")
    print("="*60)
    
    try:
        fcc = FCCClient()
        
        # Create sample database
        print("Creating sample FCC database...")
        df = fcc.create_sample_database()
        print(f"✓ Sample database created with {len(df)} towers")
        
        # Test query
        lat, lon = 37.7749, -122.4194
        towers = fcc.get_towers_in_radius(lat, lon, radius_km=5)
        print(f"✓ Found {len(towers)} towers within 5km")
        
        # Test density
        density = fcc.get_tower_density(lat, lon, radius_km=5)
        print(f"✓ Tower density: {density:.4f} towers/sq km")
        
        return True
    except Exception as e:
        print(f"✗ FCC Client Error: {e}")
        return False

def test_opencellid_client():
    """Test OpenCelliD client"""
    print("\n" + "="*60)
    print("Testing OpenCelliD Client")
    print("="*60)
    
    api_key = os.getenv('OPENCELLID_API_KEY')
    
    if not api_key:
        print("⚠ OPENCELLID_API_KEY not set in .env file")
        print("  Get your free API key from: https://opencellid.org/register")
        return False
    
    try:
        client = OpenCelliDClient(api_key=api_key)
        print("✓ OpenCelliD client initialized")
        
        # Note: Actual API calls may fail if key is invalid or rate limited
        print("  (Skipping live API test - use notebook for full testing)")
        
        return True
    except Exception as e:
        print(f"✗ OpenCelliD Client Error: {e}")
        return False

def test_census_client():
    """Test Census client"""
    print("\n" + "="*60)
    print("Testing Census Client")
    print("="*60)
    
    api_key = os.getenv('CENSUS_API_KEY')
    
    if not api_key:
        print("⚠ CENSUS_API_KEY not set in .env file")
        print("  Get your free API key from: https://api.census.gov/data/key_signup.html")
        return False
    
    try:
        client = CensusClient(api_key=api_key)
        print("✓ Census client initialized")
        
        # Note: Actual API calls may fail if key is invalid or rate limited
        print("  (Skipping live API test - use notebook for full testing)")
        
        return True
    except Exception as e:
        print(f"✗ Census Client Error: {e}")
        return False

def main():
    """Run all tests"""
    print("\n" + "="*60)
    print("TELECOM LEASE PLATFORM - QUICK TEST")
    print("="*60)
    
    results = {
        'FCC Client': test_fcc_client(),
        'OpenCelliD Client': test_opencellid_client(),
        'Census Client': test_census_client()
    }
    
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    
    for name, passed in results.items():
        status = "✓ PASS" if passed else "✗ FAIL"
        print(f"{name}: {status}")
    
    print("\n" + "="*60)
    print("NEXT STEPS")
    print("="*60)
    print("1. Set up API keys in .env file (if not done)")
    print("2. Run: jupyter notebook")
    print("3. Open: notebooks/01_api_testing.ipynb")
    print("4. Run all cells to test with real API calls")
    print("="*60 + "\n")

if __name__ == "__main__":
    main()
