"""
Setup script for telecom-lease-platform
"""
from setuptools import setup, find_packages

setup(
    name="telecom-lease-platform",
    version="0.1.0",
    description="API integration platform for telecom lease data enrichment",
    author="Your Name",
    packages=find_packages(),
    install_requires=[
        "requests>=2.28.0",
        "requests-cache>=0.9.0",
        "python-dotenv>=0.20.0",
        "pyyaml>=6.0",
        "pandas>=1.5.0",
        "numpy>=1.23.0",
        "geopandas>=0.12.0",
        "shapely>=2.0.0",
        "pydantic>=1.10.0",
        "ratelimit>=2.2.1",
        "tenacity>=8.1.0",
        "loguru>=0.6.0",
        "census>=0.8.19",
        "httpx>=0.23.0",
        "sqlalchemy>=1.4.0",
        "geopy>=2.3.0",
    ],
    python_requires=">=3.9",
)
