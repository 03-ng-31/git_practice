# Telecom Lease Data Platform

API integration platform for enriching telecom tower sites with external data sources including demographics, competitor density, and geospatial features.

## Features

### Data Sources (6 APIs)
- **FCC Client**: Query antenna structure registration data for competitor tower analysis
- **OpenCelliD Client**: Access cell tower location database for coverage analysis
- **Census API Client**: Retrieve demographic data (population, income, housing)
- **FEMA Flood Client**: Get flood zone data and risk scoring
- **USGS Earthquake Client**: Analyze seismic hazard and earthquake history
- **Unified Pipeline**: Combine all sources into single enrichment workflow

### Core Capabilities
- **Rate Limiting**: Built-in rate limiting to respect API quotas
- **Caching**: SQLite-based response caching to minimize API calls
- **Error Handling**: Automatic retries with exponential backoff
- **Batch Processing**: Enrich multiple sites with progress tracking
- **70+ Features**: Comprehensive feature set for modeling

## Installation

### 1. Clone or navigate to the project
```bash
cd C:\Users\hp\Desktop\REI\telecom-lease-platform
```

### 2. Create virtual environment (Python 3.9+)
```bash
python -m venv venv
venv\Scripts\activate
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Setup API Keys

Register for free API keys:
- **Census API**: https://api.census.gov/data/key_signup.html
- **OpenCelliD API**: https://opencellid.org/register

Create `.env` file:
```bash
copy .env.example .env
```

Edit `.env` and add your API keys:
```
CENSUS_API_KEY=your_census_key_here
OPENCELLID_API_KEY=your_opencellid_key_here
```

## Quick Start

### Test FCC Client (Local Database)
```python
from src.api_clients import FCCClient

# Initialize client
fcc = FCCClient()

# Create sample database for testing
fcc.create_sample_database()

# Query towers near San Francisco
towers = fcc.get_towers_in_radius(
    lat=37.7749,
    lon=-122.4194,
    radius_km=5
)

print(f"Found {len(towers)} towers")
print(towers[['owner_name', 'height_feet', 'distance_km']])
```

### Test OpenCelliD Client
```python
from src.api_clients import OpenCelliDClient
import os

# Initialize with API key
client = OpenCelliDClient(api_key=os.getenv('OPENCELLID_API_KEY'))

# Get tower count
count = client.count_towers_in_radius(
    lat=37.7749,
    lon=-122.4194,
    radius_km=3
)

print(f"OpenCelliD towers in 3km radius: {count}")

# Get enrichment features
features = client.get_enrichment_features(37.7749, -122.4194)
print(features)
```

### Test Census Client
```python
from src.api_clients import CensusClient
import os

# Initialize with API key
client = CensusClient(api_key=os.getenv('CENSUS_API_KEY'))

# Get demographics for a location
demographics = client.get_demographics_by_location(
    lat=37.7749,
    lon=-122.4194
)

print(f"Population: {demographics.get('population')}")
print(f"Median Income: ${demographics.get('median_income')}")

# Get enrichment features
features = client.get_enrichment_features(37.7749, -122.4194)
print(features)
```

### Test FEMA Flood Client
```python
from src.api_clients import FEMAFloodClient

# Initialize client (no API key required)
fema = FEMAFloodClient()

# Get flood zone
flood_data = fema.get_flood_zone(lat=29.9511, lon=-90.0715)  # New Orleans

print(f"Flood Zone: {flood_data['flood_zone']}")
print(f"Risk Score: {flood_data['flood_risk_score']}")
print(f"Risk Category: {fema.get_flood_risk_category(flood_data['flood_zone'])}")
```

### Test USGS Earthquake Client
```python
from src.api_clients import USGSEarthquakeClient

# Initialize client (no API key required)
usgs = USGSEarthquakeClient()

# Get earthquake statistics
stats = usgs.get_earthquake_statistics(
    lat=37.7749,
    lon=-122.4194,
    radius_km=50,
    years=10
)

print(f"Earthquakes (10 years): {stats['total_count']}")
print(f"Max Magnitude: {stats['max_magnitude']}")

# Get seismic hazard score
hazard_score = usgs.get_seismic_hazard_score(37.7749, -122.4194)
print(f"Seismic Hazard Score: {hazard_score:.3f}")
```

### Use Unified Enrichment Pipeline
```python
from src.pipeline.data_enrichment import DataEnrichmentPipeline

# Initialize pipeline (loads API keys from .env)
pipeline = DataEnrichmentPipeline()

# Enrich a single site
site = {
    'site_id': 'TOWER001',
    'latitude': 37.7749,
    'longitude': -122.4194
}

enriched = pipeline.enrich_site(site)
print(f"Total features: {len(enriched)}")

# Batch enrich multiple sites
sites = [
    {'site_id': 'TOWER001', 'latitude': 37.7749, 'longitude': -122.4194},
    {'site_id': 'TOWER002', 'latitude': 34.0522, 'longitude': -118.2437},
]

enriched_df = pipeline.enrich_batch(sites)
print(enriched_df.head())
```

## Project Structure

```
telecom-lease-platform/
├── src/
│   ├── api_clients/          # API client implementations
│   │   ├── base_client.py    # Base class with rate limiting
│   │   ├── fcc_client.py     # FCC tower data
│   │   ├── opencellid_client.py  # Cell tower locations
│   │   ├── census_client.py  # Demographics
│   │   ├── fema_flood_client.py  # Flood hazard data ⭐ NEW
│   │   └── usgs_earthquake_client.py  # Seismic data ⭐ NEW
│   ├── models/               # Data models
│   ├── utils/                # Utilities
│   └── pipeline/             # Data enrichment pipeline ⭐ NEW
│       └── data_enrichment.py  # Unified enrichment
├── tests/                    # Unit tests
├── notebooks/                # Jupyter notebooks
│   ├── 01_api_testing.ipynb  # Basic API tests
│   └── 02_hazard_data_testing.ipynb  # Hazard data tests ⭐ NEW
├── config/                   # Configuration files
├── data/                     # Data storage
│   ├── raw/                  # Raw data
│   ├── processed/            # Processed data
│   └── cache/                # API response cache
└── logs/                     # Log files
```

## API Rate Limits

- **Census API**: 500 calls per day per IP
- **OpenCelliD**: 1,000 calls per day (free tier)
- **FCC**: No API (bulk download + local database)
- **FEMA Flood**: 100 calls per minute (free)
- **USGS Earthquake**: 1,000 calls per hour (free)

## Data Enrichment Features (70+ Total)

### Demographics (Census) - 10 features
- Population (3km radius)
- Median household income
- Housing units
- Vacancy rate
- Median age
- Median home value
- Median rent
- Population density
- Education levels

### Competitor Density (FCC + OpenCelliD) - 8 features
- FCC tower count in radius
- FCC tower density (towers per sq km)
- OpenCelliD tower count
- OpenCelliD tower density
- Carrier coverage overlap
- Technology distribution (4G/5G)
- Carrier count

### Hazard Data (FEMA + USGS) - 15 features ⭐ NEW
**FEMA Flood:**
- Flood zone (A, AE, X, etc.)
- Flood risk score (0-1)
- Flood risk category
- Base flood elevation
- DFIRM panel ID

**USGS Earthquake:**
- Earthquake count (10 years)
- Earthquake count magnitude 3.0+
- Earthquake count magnitude 5.0+
- Maximum magnitude
- Average magnitude
- Most recent earthquake date
- Earthquakes per year
- Seismic hazard score (0-1)
- Seismic risk category

### Geospatial - 8 features
- FIPS codes (state, county, tract, block group)
- Latitude, longitude
- Distance calculations
- Radius-based aggregations

### Derived Features - 5 features
- Tower per capita
- Tower saturation index
- Composite risk score (flood + seismic)
- Market opportunity score
- Rent-to-income ratio (if rent data available)

## Next Steps

1. **Test Basic APIs**: Run `notebooks/01_api_testing.ipynb`
2. **Test Hazard Data**: Run `notebooks/02_hazard_data_testing.ipynb` ⭐ NEW
3. **Analyze Data**: Explore feature distributions and correlations
4. **Build Dataset**: Create cross-sectional dataset for modeling
5. **Develop Models**: Fair rent estimation and forecasting

## Troubleshooting

### API Key Issues
- Verify keys are set in `.env` file
- Check key validity at provider websites
- Ensure no extra spaces in key values

### Rate Limit Errors
- Built-in rate limiting should prevent this
- If errors occur, increase `rate_limit_period` in config

### Cache Issues
- Clear cache: delete `data/cache/*.sqlite`
- Disable cache: set `cache_enabled: false` in config

## License

MIT License
