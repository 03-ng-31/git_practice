# Telecom Lease Rent Decomposition Framework

A comprehensive data-driven methodology to decompose inflated telecom lease rents into constituent components, enabling precise ML target design and ground truth synthesis for fair market rent estimation.

## Executive Summary

Develop a mathematical framework to decompose observed rent payments into interpretable components: Base Market Rent, Contractual Escalations, Network Premium, Location Premium, Temporal Adjustments, and Noise. This decomposition enables creation of clean ML targets by isolating market-driven components from contractual artifacts and legacy pricing distortions.

## 1. Rent Decomposition Mathematical Framework

### 1.1 Core Decomposition Formula

```
Observed_Rent(t) = Base_Market_Rent(t) × Escalation_Factor(t) × Network_Premium × 
                   Location_Premium × Temporal_Adjustment(t) × Legal_Factor + 
                   Noise(t)
```

### 1.2 Component Definitions

#### A. Base Market Rent (BMR)
**Definition**: Theoretical rent for standard commercial land use without telecom premium
**Mathematical Form**: 
```
BMR(t) = Land_Value_per_sqft(t) × Site_Area × Base_Multiplier × CRE_Market_Factor(t)
```

**Data Sources**:
- County assessor land values
- Commercial real estate transaction data (CoStar, LoopNet)
- Comparable property lease rates
- Zoning-based land use multipliers

#### B. Contractual Escalation Factor (CEF)
**Definition**: Cumulative effect of all contractual rent increases since lease inception
**Mathematical Form**:
```
CEF(t) = ∏(i=1 to t) [1 + Fixed_Escalator(i) + CPI_Escalator(i) + Revenue_Share_Escalator(i)]
```

**Components**:
- **Fixed Escalators**: Annual percentage increases (typically 2-5%)
- **CPI Escalators**: Consumer Price Index adjustments
- **Revenue Share Escalators**: Percentage of operator revenue increases
- **Compound Effects**: Escalator stacking over decades

#### C. Network Premium (NP)
**Definition**: Premium paid for strategic network value beyond standard land use
**Mathematical Form**:
```
NP = f(Traffic_Volume, Coverage_Criticality, Colocation_Value, Technology_Layers)
```

**Sub-components**:
- **Traffic Premium**: Based on data volume and subscriber density
- **Coverage Premium**: Value for filling coverage gaps
- **Colocation Premium**: Value from hosting multiple carriers
- **Technology Premium**: 5G, small cell deployment value

#### D. Location Premium (LP)
**Definition**: Site-specific location advantages beyond base land value
**Mathematical Form**:
```
LP = f(Zoning_Flexibility, Visibility, Access_Rights, Development_Potential)
```

**Sub-components**:
- **Zoning Premium**: Restrictive zoning creating scarcity
- **Visibility Premium**: High-traffic area visibility value
- **Access Premium**: Easement and infrastructure access rights
- **Development Premium**: Future development potential

#### E. Temporal Adjustment Factor (TAF)
**Definition**: Market timing and economic cycle adjustments
**Mathematical Form**:
```
TAF(t) = Market_Cycle_Factor(t) × Interest_Rate_Factor(t) × Regulatory_Factor(t)
```

**Sub-components**:
- **Market Cycle**: Real estate market boom/bust cycles
- **Interest Rate**: Impact of financing costs on land values
- **Regulatory**: Zoning changes, tower restrictions, 5G policies

#### F. Legal/Contract Factor (LCF)
**Definition**: Legal constraints and contract-specific terms affecting rent
**Mathematical Form**:
```
LCF = Renewal_Option_Value + Termination_Penalty + Assignment_Rights + Early_Exit_Clauses
```

#### G. Noise Component (NC)
**Definition**: Random variations, data errors, and unexplained factors
**Mathematical Form**:
```
NC(t) ~ N(0, σ²) + Measurement_Error + Data_Quality_Issues
```

## 2. Data-Driven Component Separation Techniques

### 2.1 Multi-Stage Decomposition Pipeline

#### Stage 1: Contractual Component Extraction
**Objective**: Remove deterministic contractual elements

**Method 1: Contractual Timeline Reconstruction**
```python
def extract_contractual_component(lease_data):
    # Reconstruct escalation path from contract terms
    base_rent = lease_data['initial_rent']
    escalation_schedule = parse_escalation_terms(lease_data['contract'])
    
    contractual_rent = []
    current_rent = base_rent
    
    for year in range(lease_data['lease_start'], lease_data['current_year']):
        # Apply fixed escalators
        current_rent *= (1 + escalation_schedule['fixed_rate'][year])
        
        # Apply CPI adjustments
        current_rent *= (1 + cpi_adjustment[year])
        
        # Apply revenue share if applicable
        if escalation_schedule['revenue_share']:
            current_rent += revenue_share_calculation(year)
            
        contractual_rent.append(current_rent)
    
    return contractual_rent
```

**Method 2: Pattern Recognition for Escalation Detection**
```python
def detect_escalation_patterns(rent_timeseries):
    # Use change point detection to identify escalation events
    from ruptures import Pelt
    
    model = Pelt(model="rbf").fit(rent_timeseries)
    breakpoints = model.predict(pen=10)
    
    # Analyze patterns between breakpoints
    escalation_rates = []
    for i in range(len(breakpoints)-1):
        segment = rent_timeseries[breakpoints[i]:breakpoints[i+1]]
        rate = calculate_compound_rate(segment)
        escalation_rates.append(rate)
    
    return escalation_rates, breakpoints
```

#### Stage 2: Market Component Isolation
**Objective**: Separate market-driven rent from contractual artifacts

**Method 1: Comparable Properties Benchmarking**
```python
def isolate_market_component(site_data, comparable_data):
    # Find comparable properties within radius
    comparables = find_spatial_comparables(
        site_data['location'], 
        radius_miles=3,
        property_types=['commercial', 'industrial']
    )
    
    # Calculate market-implied rent
    market_rent = []
    for year in range(analysis_period):
        # Weight comparables by similarity
        weights = calculate_similarity_weights(site_data, comparables)
        
        # Market rent = weighted average of comparables
        market_rent_year = np.average(
            [comp['rent_per_sqft'][year] for comp in comparables],
            weights=weights
        ) * site_data['area']
        
        market_rent.append(market_rent_year)
    
    return market_rent
```

**Method 2: Economic Indicator Regression**
```python
def extract_market_component_regression(rent_data, economic_indicators):
    # Regress rent against economic indicators
    from sklearn.linear_model import Ridge
    
    features = pd.DataFrame({
        'land_value_index': economic_indicators['land_value'],
        'cre_transaction_volume': economic_indicators['cre_volume'],
        'population_growth': economic_indicators['population'],
        'gdp_growth': economic_indicators['gdp'],
        'construction_costs': economic_indicators['construction']
    })
    
    # Time-varying coefficients using rolling regression
    market_component = []
    window_size = 36  # 3 years
    
    for i in range(window_size, len(rent_data)):
        X = features.iloc[i-window_size:i]
        y = rent_data[i-window_size:i]
        
        model = Ridge(alpha=0.1).fit(X, y)
        market_rent = model.predict(features.iloc[i:i+1])[0]
        market_component.append(market_rent)
    
    return market_component
```

#### Stage 3: Network Premium Quantification
**Objective**: Isolate telecom-specific value components

**Method 1: Traffic-Based Premium Calculation**
```python
def calculate_network_premium(site_data, network_metrics):
    # Base premium calculation
    traffic_premium = np.log1p(network_metrics['monthly_gb']) * 0.1
    
    # Coverage criticality premium
    coverage_gap = calculate_coverage_gap(site_data['location'])
    coverage_premium = min(coverage_gap * 0.05, 0.3)  # Cap at 30%
    
    # Colocation premium (diminishing returns)
    colocation_count = site_data['colocation_count']
    colocation_premium = 0.15 * np.log1p(colocation_count)
    
    # Technology layer premium
    tech_layers = site_data['technology_count']  # 2G, 3G, 4G, 5G
    tech_premium = tech_layers * 0.08
    
    total_premium = 1 + traffic_premium + coverage_premium + colocation_premium + tech_premium
    
    return {
        'total_premium': total_premium,
        'components': {
            'traffic': traffic_premium,
            'coverage': coverage_premium,
            'colocation': colocation_premium,
            'technology': tech_premium
        }
    }
```

**Method 2: Instrumental Variable Approach**
```python
def estimate_network_premium_iv(rent_data, instruments, controls):
    # Use 2SLS to estimate causal effect of network metrics on rent
    from statsmodels.sandbox.regression.gmm import IV2SLS
    
    # First stage: Network metrics ~ Instruments
    # Instruments: Population density, competitor tower density
    first_stage = sm.OLS(
        endog=network_metrics['traffic_volume'],
        exog=instruments[['population_density', 'competitor_density']]
    ).fit()
    
    # Second stage: Rent ~ Predicted Network Metrics + Controls
    predicted_traffic = first_stage.fittedvalues
    
    second_stage = sm.OLS(
        endog=rent_data,
        exog=pd.concat([predicted_traffic, controls], axis=1)
    ).fit()
    
    network_premium_coefficient = second_stage.params['predicted_traffic']
    return network_premium_coefficient
```

### 2.2 Advanced Denoising Techniques

#### Technique 1: Kalman Filter for State Estimation
```python
from pykalman import KalmanFilter

def denoise_rent_kalman(rent_timeseries, economic_indicators):
    # State: [market_rent, growth_rate, noise_level]
    # Observation: observed_rent
    
    n_timesteps = len(rent_timeseries)
    
    # Transition matrices
    transition_matrices = np.array([
        [1.0, 1.0, 0.0],  # rent(t) = rent(t-1) + growth_rate(t-1)
        [0.0, 0.9, 0.0],  # growth_rate(t) = 0.9 * growth_rate(t-1) (AR process)
        [0.0, 0.0, 0.8]   # noise_level(t) = 0.8 * noise_level(t-1)
    ])
    
    # Observation matrix
    observation_matrices = np.array([[1.0, 0.0, 1.0]])  # observed = market + noise
    
    kf = KalmanFilter(
        transition_matrices=transition_matrices,
        observation_matrices=observation_matrices
    )
    
    # Fit and smooth
    state_means, _ = kf.em(rent_timeseries).smooth()[0]
    
    denoised_rent = state_means[:, 0]  # Extract market rent component
    return denoised_rent
```

#### Technique 2: Wavelet Decomposition for Multi-Scale Analysis
```python
import pywt

def wavelet_decomposition_rent(rent_timeseries, wavelet='db4', levels=4):
    # Decompose rent into different frequency components
    coeffs = pywt.wavedec(rent_timeseries, wavelet, level=levels)
    
    # Reconstruct components
    components = {
        'trend': pywt.waverec([coeffs[0]] + [None] * levels, wavelet),
        'long_term_cycles': pywt.waverec([None, coeffs[1]] + [None] * (levels-1), wavelet),
        'medium_term_cycles': pywt.waverec([None, None, coeffs[2]] + [None] * (levels-2), wavelet),
        'short_term_variations': pywt.waverec([None] * (levels-1) + [coeffs[-1]], wavelet),
        'noise': pywt.waverec([None] * levels + [coeffs[-1]], wavelet)
    }
    
    return components
```

#### Technique 3: Robust Principal Component Analysis (RPCA)
```python
from sklearn.decomposition import PCA
import numpy as np

def rpca_decomposition(rent_matrix, lambda_reg=0.1):
    """
    Decompose rent matrix into low-rank (systematic) and sparse (anomalous) components
    rent_matrix: sites x time matrix
    """
    def soft_threshold(X, threshold):
        return np.sign(X) * np.maximum(np.abs(X) - threshold, 0)
    
    def singular_value_threshold(X, threshold):
        U, s, Vt = np.linalg.svd(X, full_matrices=False)
        s_thresh = soft_threshold(s, threshold)
        return np.dot(U * s_thresh, Vt)
    
    # Initialize
    L = np.zeros_like(rent_matrix)  # Low-rank component
    S = np.zeros_like(rent_matrix)  # Sparse component
    Y = np.zeros_like(rent_matrix)  # Lagrange multiplier
    
    mu = 1.25 / np.linalg.norm(rent_matrix, 2)
    rho = 1.6
    
    for iteration in range(100):
        # Update L (low-rank component)
        L = singular_value_threshold(rent_matrix - S + Y/mu, 1/mu)
        
        # Update S (sparse component)
        S = soft_threshold(rent_matrix - L + Y/mu, lambda_reg/mu)
        
        # Update Y (Lagrange multiplier)
        Y = Y + mu * (rent_matrix - L - S)
        
        # Check convergence
        if np.linalg.norm(rent_matrix - L - S, 'fro') < 1e-6:
            break
    
    return L, S  # L = systematic patterns, S = anomalies/outliers
```

### 2.3 Cross-Validation and Component Validation

#### Method 1: Hold-Out Validation by Component
```python
def validate_decomposition(rent_data, decomposed_components, validation_split=0.2):
    # Split data temporally
    split_point = int(len(rent_data) * (1 - validation_split))
    
    train_data = rent_data[:split_point]
    val_data = rent_data[split_point:]
    
    # Fit decomposition on training data
    train_components = decompose_rent(train_data)
    
    # Predict validation period
    predicted_components = forecast_components(train_components, len(val_data))
    
    # Reconstruct total rent
    predicted_rent = reconstruct_rent(predicted_components)
    
    # Calculate component-wise errors
    errors = {
        'total_mape': mean_absolute_percentage_error(val_data, predicted_rent),
        'component_mse': {}
    }
    
    for component_name in predicted_components.keys():
        if component_name in decomposed_components:
            true_component = decomposed_components[component_name][split_point:]
            pred_component = predicted_components[component_name]
            errors['component_mse'][component_name] = mean_squared_error(true_component, pred_component)
    
    return errors
```

## 3. Implementation Architecture

### 3.1 Modular Pipeline Design

```python
class RentDecomposer:
    def __init__(self, config):
        self.config = config
        self.components = {
            'contractual': ContractualExtractor(),
            'market': MarketComponentEstimator(), 
            'network_premium': NetworkPremiumCalculator(),
            'location_premium': LocationPremiumEstimator(),
            'temporal_adjustment': TemporalAdjustmentModel(),
            'noise': NoiseEstimator()
        }
    
    def decompose(self, lease_data, external_data):
        results = {}
        
        # Stage 1: Extract contractual component
        results['contractual'] = self.components['contractual'].extract(
            lease_data['rent_history'], 
            lease_data['contract_terms']
        )
        
        # Stage 2: Estimate market component
        results['market'] = self.components['market'].estimate(
            lease_data, 
            external_data['comparable_properties'],
            external_data['economic_indicators']
        )
        
        # Stage 3: Calculate network premium
        results['network_premium'] = self.components['network_premium'].calculate(
            lease_data['site_data'],
            external_data['network_metrics']
        )
        
        # Stage 4: Estimate location premium
        results['location_premium'] = self.components['location_premium'].estimate(
            lease_data['site_data'],
            external_data['geospatial_data']
        )
        
        # Stage 5: Calculate temporal adjustments
        results['temporal_adjustment'] = self.components['temporal_adjustment'].calculate(
            lease_data['rent_history'],
            external_data['market_cycles']
        )
        
        # Stage 6: Estimate noise component
        observed_rent = lease_data['rent_history']
        reconstructed_rent = self.reconstruct_rent(results)
        results['noise'] = observed_rent - reconstructed_rent
        
        return results
    
    def reconstruct_rent(self, components):
        return (components['market'] * 
                components['contractual'] * 
                components['network_premium'] * 
                components['location_premium'] * 
                components['temporal_adjustment']) + components.get('noise', 0)
```

### 3.2 Component-Specific Estimators

#### Contractual Extractor
```python
class ContractualExtractor:
    def extract(self, rent_history, contract_terms):
        # Parse contract escalation terms
        escalation_schedule = self.parse_escalation_terms(contract_terms)
        
        # Reconstruct contractual path
        base_rent = rent_history[0]
        contractual_rent = [base_rent]
        
        for year in range(1, len(rent_history)):
            # Apply escalations
            escalated_rent = self.apply_escalations(
                contractual_rent[-1], 
                escalation_schedule, 
                year
            )
            contractual_rent.append(escalated_rent)
        
        # Calculate escalation factor
        escalation_factor = np.array(contractual_rent) / base_rent
        
        return escalation_factor
    
    def parse_escalation_terms(self, contract_terms):
        # Extract escalation parameters from contract text/data
        pass
    
    def apply_escalations(self, current_rent, schedule, year):
        # Apply year-specific escalations
        pass
```

#### Market Component Estimator
```python
class MarketComponentEstimator:
    def __init__(self):
        self.models = {
            'comparable': ComparableAnalysisModel(),
            'economic_regression': EconomicRegressionModel(),
            'spatial_interpolation': SpatialInterpolationModel()
        }
    
    def estimate(self, lease_data, comparable_data, economic_data):
        # Ensemble of market estimation methods
        estimates = {}
        
        # Method 1: Comparable analysis
        estimates['comparable'] = self.models['comparable'].predict(
            lease_data, comparable_data
        )
        
        # Method 2: Economic regression
        estimates['regression'] = self.models['economic_regression'].predict(
            lease_data, economic_data
        )
        
        # Method 3: Spatial interpolation
        estimates['spatial'] = self.models['spatial_interpolation'].predict(
            lease_data, comparable_data
        )
        
        # Weighted ensemble
        weights = self.calculate_confidence_weights(estimates, lease_data)
        market_estimate = np.average(
            [estimates[method] for method in estimates.keys()], 
            weights=weights, 
            axis=0
        )
        
        return market_estimate
```

## 4. Validation and Quality Assurance

### 4.1 Component Coherence Tests
```python
def validate_component_coherence(decomposed_components):
    tests = {}
    
    # Test 1: Reconstruction accuracy
    reconstructed = reconstruct_rent(decomposed_components)
    original = decomposed_components['original_rent']
    reconstruction_error = np.mean(np.abs(reconstructed - original) / original)
    tests['reconstruction_mape'] = reconstruction_error
    
    # Test 2: Component magnitude reasonableness
    total_premium = (decomposed_components['network_premium'] * 
                    decomposed_components['location_premium'])
    tests['premium_range_valid'] = np.all((total_premium >= 0.8) & (total_premium <= 3.0))
    
    # Test 3: Escalation factor monotonicity
    escalation_factor = decomposed_components['contractual']
    tests['escalation_monotonic'] = np.all(np.diff(escalation_factor) >= -0.01)
    
    # Test 4: Noise component properties
    noise = decomposed_components['noise']
    tests['noise_zero_mean'] = np.abs(np.mean(noise)) < 0.05 * np.mean(original)
    tests['noise_stationarity'] = check_stationarity(noise)
    
    return tests
```

### 4.2 External Validation Methods
```python
def validate_against_external_benchmarks(decomposed_components, benchmark_data):
    # Validate market component against external market data
    market_correlation = np.corrcoef(
        decomposed_components['market'], 
        benchmark_data['market_index']
    )[0, 1]
    
    # Validate network premium against industry standards
    network_premium_stats = {
        'mean': np.mean(decomposed_components['network_premium']),
        'std': np.std(decomposed_components['network_premium']),
        'range': (np.min(decomposed_components['network_premium']), 
                 np.max(decomposed_components['network_premium']))
    }
    
    # Check against industry benchmarks (1.2-2.5x typical range)
    premium_valid = (1.0 <= network_premium_stats['mean'] <= 3.0)
    
    return {
        'market_correlation': market_correlation,
        'network_premium_valid': premium_valid,
        'premium_stats': network_premium_stats
    }
```

## 5. Expected Outputs for ML Target Design

### 5.1 Clean Target Variables
1. **Market-Adjusted Rent**: Rent stripped of contractual escalations
2. **Network-Adjusted Rent**: Rent with network premium normalized
3. **Location-Adjusted Rent**: Rent with location premium normalized
4. **Time-Adjusted Rent**: Rent adjusted for temporal market effects

### 5.2 Feature Engineering Outputs
1. **Escalation Rate Features**: Historical and projected escalation rates
2. **Premium Quantification**: Network and location premium magnitudes
3. **Market Timing Features**: Market cycle position and timing effects
4. **Volatility Measures**: Component-specific volatility and stability metrics

### 5.3 Model Training Targets
1. **Fair Market Rent Target**: Market + Location components only
2. **Network Value Target**: Network premium component
3. **Escalation Prediction Target**: Future escalation factor
4. **Renewal Rent Target**: Predicted rent at renewal (all components)

## 6. Implementation Timeline

### Week 1-2: Foundation
- Set up data ingestion pipeline
- Implement basic decomposition framework
- Develop contractual component extractor

### Week 3-4: Market Components  
- Implement comparable analysis methods
- Build economic regression models
- Develop spatial interpolation techniques

### Week 5-6: Premium Quantification
- Build network premium calculator
- Implement location premium estimator
- Develop temporal adjustment models

### Week 7-8: Advanced Denoising
- Implement Kalman filtering
- Add wavelet decomposition
- Build RPCA anomaly detection

### Week 9-10: Validation & Refinement
- Component coherence testing
- External benchmark validation
- Model refinement and tuning

This framework provides a rigorous, data-driven approach to decomposing rent into interpretable components, enabling the creation of clean ML targets while preserving the ability to understand and validate each component's contribution to the final rent prediction.
