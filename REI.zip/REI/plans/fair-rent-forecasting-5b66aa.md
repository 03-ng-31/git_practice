# Fair Rent Forecasting & Optimization Strategy for Telecom Leases

This plan outlines a data science approach to estimate "Fair Market Rent" for cell tower sites, specifically addressing the challenge of biased historical data (overpayment) by using Stochastic Frontier Analysis (SFA) and Vintage-Based Benchmarking.

## 1. Problem Decomposition & "Ground Truth" Strategy
Since historical rent contains "inefficiency" (overpayment), we cannot use standard regression on raw historical data. We must disentangle the "Market Value" from the "Legacy Premium".

### Proposed Approaches to Synthesize Ground Truth:
- **Approach A: Stochastic Frontier Analysis (SFA)**
  - *Concept:* Econometric technique used to estimate production/cost functions.
  - *Equation:* $ActualRent = f(Features) + Noise + Inefficiency$
  - *Goal:* The model statistically separates random error (Noise) from systematic overpayment (Inefficiency). The estimated frontier $f(Features)$ becomes the "Fair Rent".
- **Approach B: "Recent Vintage" Shadow Model**
  - *Concept:* Assume leases signed in the last 3-5 years represent closer-to-market rates than 25-year-old leases.
  - *Action:* Train a Gradient Boosting model (XGBoost/LightGBM) *only* on recent/renegotiated leases. Use this model to predict fair rent for legacy sites.
- **Approach C: Unsupervised Peer Benchmarking**
  - *Concept:* Group sites into high-dimensional clusters using the geospatial, technical, and network features.
  - *Action:* Within each cluster, calculate the 25th or 30th percentile of rent. This "Efficient Frontier" becomes the target for all sites in that cluster.

## 2. Feature Engineering & Data Preparation
Leverage the 8 identified parameter categories to build a robust feature set.

- **Geospatial:** Geohashes, distance to city center, zoning classification (Residential vs Commercial).
- **Network Criticality:** Traffic volume log-transforms, coverage overlap index.
- **Contractual:** One-hot encode "Termination Rights" and "Renewal Options".
- **Interaction Terms:** Create "High Traffic x Urban", "Rooftop x Commercial" to capture non-linear value drivers.

## 3. Modeling Pipeline
1.  **Data Segmentation:** Split data into "Legacy" (training target for anomaly detection) and "Market" (training target for fair price).
2.  **Model Training:**
    -   Train **SFA Model** to estimate the theoretical minimum rent curve.
    -   Train **Clustering Model (K-Means/DBSCAN)** to identify peer groups.
3.  **Validation:** Since we lack ground truth, validate using "hold-out" recent leases (where we likely have better market alignment).

## 4. Optimization & Output
- **Fair Rent Range:** Output a predicted interval (e.g., \$1,200 - \$1,400) rather than a point estimate.
- **Gap Analysis:** Calculate `Delta = Current_Rent - Predicted_Fair_Rent`.
- **Negotiation Levers:** Map the specific "weak" parameters (e.g., "High Overlap") to negotiation scripts to justify lower offers.
