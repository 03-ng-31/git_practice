# External Data Sources & API Guide for Telecom Lease Optimization

This guide identifies data sources and APIs for acquiring external high-leverage parameters needed for fair rent forecasting in the telecom lease optimization project.

---

## 1. Land/CRE Value Proxies

### 🟢 **ATTOM Data Solutions** (Assessor Data)
- **What:** Property tax assessor data covering 158M+ properties across 3,000+ counties
- **Data:** Property values, tax assessments, ownership, land use, sale history
- **API:** Yes - RESTful API with JSON responses
- **Access:** Commercial subscription required
- **URL:** https://www.attomdata.com/data/property-data/assessor-data/
- **Use Case:** Ground truth for land value, replacement cost baseline

### 🟢 **Regrid (formerly Loveland)** 
- **What:** Nationwide parcel boundaries and property records
- **Data:** Parcel boundaries, ownership, assessed values, zoning, land use
- **API:** Yes - Parcel API with geocoding, search, and tile services
- **Access:** 30-day free trial, then subscription
- **URL:** https://regrid.com/api
- **Use Case:** Geospatial analysis, parcel-level property attributes

### 🟡 **Zillow Public Data APIs**
- **What:** Residential property data (Zestimates, public records)
- **Data:** Property values, neighborhood data, real estate metrics
- **API:** Limited - Public Records API requires approval
- **Access:** Request access via developer portal
- **URL:** https://www.zillowgroup.com/developers/
- **Use Case:** Residential property benchmarking (limited for commercial)
- **Note:** Zillow has restricted API access; consider third-party scrapers

### 🟢 **First American DataTree**
- **What:** Property research platform with 7B+ document images
- **Data:** Public records, tax data, title plants, recorded documents
- **API:** Yes - API-JSON delivery option
- **Access:** Commercial subscription
- **URL:** https://dna.firstam.com/
- **Use Case:** Comprehensive property history, tax data, ownership chains

### 🟡 **CoreLogic**
- **What:** Parcel-level real estate data with 200+ fields
- **Data:** Property values, ownership, land use, tax assessments
- **API:** Yes - Trestle API (WebAPI and RETS)
- **Access:** Enterprise licensing
- **URL:** https://trestle-documentation.corelogic.com/
- **Use Case:** High-quality property attributes, valuation models

### 🔴 **CoStar** (Commercial Real Estate)
- **What:** Premium CRE database with 6M+ properties
- **Data:** Commercial lease comps, property attributes, market analytics
- **API:** No public API - proprietary platform only
- **Access:** Expensive subscription ($5K-$15K/year)
- **URL:** https://www.costar.com/
- **Use Case:** Commercial property benchmarking (no API, manual exports only)

### 🟢 **Construction Cost Indices**
- **RS Means Data:** https://www.rsmeans.com/ - Construction Cost Index (CCI) by city/region
- **ENR Cost Data:** https://www.enr.com/economics - Building Cost Index (BCI) and Construction Cost Index
- **Access:** Subscription-based, no direct API but downloadable reports
- **Use Case:** Replacement cost inflation adjustments

---

## 2. Zoning/Permitting Restrictiveness & Hazard Layers

### 🟢 **Wharton Residential Land Use Regulatory Index (WRLURI)**
- **What:** Academic dataset measuring zoning restrictiveness across 2,500+ jurisdictions
- **Data:** 11 subindices measuring regulatory burden (density restrictions, approval processes, etc.)
- **API:** No - Static dataset download
- **Access:** Free academic research data
- **URL:** https://realestate.wharton.upenn.edu/
- **Use Case:** Zoning restrictiveness proxy for supply constraints

### 🟡 **Zoneomics**
- **What:** Commercial zoning data aggregator
- **Data:** Zoning codes, land use regulations, permitted uses
- **API:** Likely available (contact for enterprise access)
- **Access:** Commercial subscription
- **URL:** https://www.zoneomics.com/
- **Use Case:** Automated zoning lookup by parcel

### 🟢 **USGS National Land Cover Database (NLCD)**
- **What:** Land cover/land use classification for entire US
- **Data:** 30m resolution raster data (developed, forest, wetland, etc.)
- **API:** Yes - USGS APIs for geospatial data
- **Access:** Free public data
- **URL:** https://www.usgs.gov/centers/eros/science/national-land-cover-database
- **Use Case:** Land use classification, development density

### 🟢 **FEMA National Flood Hazard Layer (NFHL)**
- **What:** Flood zone maps and hazard data
- **Data:** Flood zones (A, AE, X, etc.), base flood elevations, floodways
- **API:** Yes - Multiple options:
  - **National Flood Data API:** https://docs.nationalflooddata.com/dataservice/v3/index.html (requires API key)
  - **FEMA GIS Web Services:** https://hazards.fema.gov/femaportal/wps/portal/NFHLWMS
- **Access:** Free (National Flood Data charges for commercial use)
- **Use Case:** Flood risk assessment, insurance cost proxy

### 🟢 **USGS Earthquake Hazards API**
- **What:** Real-time and historical earthquake data
- **Data:** Seismic hazard maps, earthquake catalogs
- **API:** Yes - FDSN Event Web Service
- **Access:** Free public API
- **URL:** https://earthquake.usgs.gov/fdsnws/event/1/
- **Use Case:** Seismic risk scoring for tower sites

### 🟡 **Wildfire Risk Data**
- **USGS Wildfire Hazards:** Limited API, mostly static datasets
- **NOAA Climate Data:** https://www.ncdc.noaa.gov/cdo-web/webservices/v2 (weather/climate API)
- **Use Case:** Environmental hazard scoring

---

## 3. Competitor/Tower Density (FCC + Commercial)

### 🟢 **FCC Antenna Structure Registration (ASR) Database**
- **What:** Official registry of all antenna structures >200 feet or near airports
- **Data:** Tower location (lat/lon), height, owner, registration number, construction date
- **API:** No REST API, but bulk downloads available
- **Access:** Free public data
- **Download:** https://www.fcc.gov/wireless/data/public-access-files-database-downloads
- **Search Tool:** https://wireless2.fcc.gov/UlsApp/AsrSearch/asrAdvancedSearch.jsp
- **Use Case:** Competitor tower density, tower age, structural attributes

### 🟢 **FCC Universal Licensing System (ULS)**
- **What:** Wireless license database (includes cell carrier licenses)
- **Data:** License holder, service area, frequencies, antenna locations
- **API:** No REST API - bulk database downloads (weekly/daily)
- **Access:** Free public data
- **URL:** https://www.fcc.gov/wireless/universal-licensing-system
- **Use Case:** Identify carrier presence, spectrum holdings by geography

### 🟢 **OpenCelliD**
- **What:** Open-source cell tower location database (crowdsourced)
- **Data:** Cell tower locations (lat/lon), MCC/MNC codes, radio type (LTE/5G)
- **API:** Yes - RESTful API for cell position lookup and area queries
- **Access:** Free API with registration (rate limits apply)
- **Documentation:** https://wiki.opencellid.org/wiki/API
- **URL:** https://opencellid.org/
- **Use Case:** Cell tower density heatmaps, carrier coverage overlap
- **Note:** Data quality varies; best for supplementary analysis

### 🟡 **AntennaSearch.com**
- **What:** Commercial aggregator of FCC/FAA tower data
- **Data:** Tower locations, heights, owners
- **API:** No public API - web interface only
- **Access:** Free web search, no bulk access
- **URL:** https://www.antennasearch.com/
- **Use Case:** Manual lookup for specific sites

### 🔴 **Commercial Tower Databases** (No Public APIs)
- **American Tower / Crown Castle / SBA Communications:** Proprietary data, no public access
- **Alternative:** Use FCC ASR + OpenCelliD as proxies

---

## 4. Industry Benchmarks (Tower Lease Surveys / Broker Comps)

### 🟢 **CompStak**
- **What:** Crowdsourced commercial real estate lease comps
- **Data:** Lease rates, TI allowances, free rent, lease terms (Office/Retail/Industrial)
- **API:** Yes - Commercial Real Estate API
- **Access:** Expensive subscription ($10K+/year), API requires enterprise plan
- **URL:** https://compstak.com/data-api
- **Use Case:** Commercial lease benchmarking (limited tower-specific data)
- **Note:** Primarily office/retail; tower leases are niche

### 🟡 **Cell Tower Lease Consultants** (Industry Reports)
- **Tower Genius:** https://www.towergenius.com/cell-tower-lease-rates/
- **Cell Tower Leases:** https://www.cell-tower-leases.com/
- **Data:** Published ranges ($1,200-$18,000/month depending on carriers, location)
- **API:** No - manual research only
- **Use Case:** Sanity check for model outputs

### 🟡 **IBISWorld Industry Reports**
- **What:** Market research reports on "Cell Site Operation and Leasing" industry
- **Data:** Industry KPIs, revenue trends, market size
- **API:** No - purchased reports
- **URL:** https://www.ibisworld.com/
- **Use Case:** Macro-level industry benchmarks

### 🔴 **Proprietary Tower Management Systems** (No Public Access)
- **Sitetracker, Crowe Tower Accelerator:** Used by TowerCos internally
- **No public data or API access**

---

## 5. Implementation Roadmap

### Phase 1: Free/Low-Cost Data Acquisition (Weeks 1-2)
1. **FCC ASR Database:** Download bulk data, parse into structured format
2. **OpenCelliD API:** Set up API integration for tower density calculations
3. **FEMA Flood API:** Integrate flood zone lookups by lat/lon
4. **USGS APIs:** Add earthquake/hazard scoring
5. **Wharton WRLURI:** Download static dataset, join by jurisdiction

### Phase 2: Commercial Data Partnerships (Weeks 3-4)
1. **Regrid API:** 30-day trial for parcel data (then evaluate ROI)
2. **ATTOM Data:** Request demo/trial for assessor data
3. **First American DataTree:** Evaluate API pricing for tax data
4. **National Flood Data API:** Purchase API key if FEMA free tier insufficient

### Phase 3: Premium Data (Optional, Weeks 5+)
1. **CoreLogic/CoStar:** Evaluate if budget allows ($50K+/year combined)
2. **CompStak API:** Consider if commercial lease comps add value

---

## 6. Data Integration Architecture

### Recommended Tech Stack
- **Geospatial Processing:** PostGIS, GeoPandas, H3 (Uber's hexagonal grid)
- **API Orchestration:** Python (requests, aiohttp for async calls)
- **Data Storage:** PostgreSQL with PostGIS extension
- **Rate Limiting:** Respect API limits (e.g., OpenCelliD: 1,000 calls/day free tier)

### Sample Workflow
```python
# Pseudocode for data enrichment pipeline
for site in tower_sites:
    # 1. Get parcel data
    parcel = regrid_api.get_parcel(lat=site.lat, lon=site.lon)
    
    # 2. Get flood zone
    flood_zone = fema_api.get_flood_zone(lat=site.lat, lon=site.lon)
    
    # 3. Count nearby towers (3km radius)
    nearby_towers = opencellid_api.get_cells_in_radius(
        lat=site.lat, lon=site.lon, radius=3000
    )
    
    # 4. Get zoning restrictiveness (join by county FIPS)
    zoning_score = wrluri_data[parcel.county_fips]
    
    # 5. Merge into feature vector
    site.features = {
        'assessed_value': parcel.assessed_value,
        'flood_zone': flood_zone.zone,
        'tower_density_3km': len(nearby_towers),
        'zoning_restrictiveness': zoning_score
    }
```

---

## 7. Cost Estimate (Annual)

| Data Source | Cost | Priority |
|-------------|------|----------|
| FCC ASR/ULS | Free | High |
| OpenCelliD API | Free (limited) | High |
| FEMA Flood (free tier) | Free | High |
| USGS APIs | Free | Medium |
| Wharton WRLURI | Free | Medium |
| **Regrid API** | $5K-$15K | High |
| **ATTOM Data** | $10K-$30K | High |
| **First American DataTree** | $15K-$40K | Medium |
| **National Flood Data API** | $2K-$5K | Low |
| CoreLogic | $30K-$50K | Low |
| CoStar | $10K-$15K | Low |
| CompStak API | $10K-$20K | Low |
| **Total (Recommended)** | **$30K-$90K** | - |

**Recommended Tier 1 Budget:** $30K-$50K (Regrid + ATTOM + Free sources)

---

## 8. Key Takeaways

✅ **Free Data Available:** FCC tower data, FEMA flood zones, USGS hazards, academic zoning indices  
✅ **Critical Commercial APIs:** Regrid (parcels), ATTOM (assessor data), First American (tax data)  
⚠️ **No Direct Tower Lease Comps:** Industry benchmarks are fragmented; rely on consultants' published ranges  
⚠️ **CoStar Has No API:** Manual exports only for CRE comps  
🔄 **OpenCelliD Quality:** Crowdsourced data has gaps; use as supplement to FCC data  

**Next Step:** Prioritize FCC + free APIs for MVP, then add Regrid/ATTOM for production model.
