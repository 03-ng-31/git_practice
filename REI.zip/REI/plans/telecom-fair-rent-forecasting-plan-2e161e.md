# Telecom Lease “Fair Rent” Forecasting (No Ground-Truth) – Plan

This plan estimates **site-level fair market rent** (FMR) and a **renewal rent recommendation** when historical paid rent is biased by legacy overpayment.

## 0) Confirmed business framing (from initial answers)
- **Decisions supported**: negotiation targets, budget/cashflow forecasting, and relocate-vs-renew
- **Rent objective**: **lowest achievable** rent and **risk-adjusted optimal** rent (conditioned on network criticality)
- **Optimization**: minimize **NPV of total occupancy cost** (rent + one-time costs + risk costs)
- **Horizon/granularity**: **annual** projections for the next **10 years**
- **Scope**: all asset types
- **Segmentation**: multivariate segmentation with **zip code** as the base level and a hierarchy upward (zip → city/county → market/MSA → state → national)

## 1) Define the target clearly (what you will predict)
- **As‑Is Rent Forecast** (deterministic): what you will pay if you do nothing (contract + escalators).
- **Fair Market Rent (FMR)** (latent): what a “reasonable market” rent would be today for the same site rights.
- **Achievable Renewal Rent Distribution**: what you are likely to end up paying after renewal/renegotiation.
- **Recommended Rent Target / Walk‑Away**: decision output using savings vs. network/relocation risk.

## 2) Data inventory (minimum viable)
- **Internal**
  - Contract terms: base rent, escalators, options, ROFR/termination, amendment history
  - Payments: billed vs paid, deltas, one‑offs, buyouts
  - Renewal outcomes: pre/post renewal rent, dates, concessions
  - Site attributes: type (rooftop/ground), footprint, height, capacity, structural limits
  - Network: traffic, overlap %, redundancy distance, backhaul/tech layers, upgrade history
  - Negotiation metadata (if available): landlord ask, counteroffers, time to close
- **External (high leverage)**
  - Land/CRE value proxies (assessor, Zillow/CoStar, construction cost indices)
  - Zoning/permitting restrictiveness, hazard layers
  - Competitor/tower density (FCC + commercial datasets)
  - Industry benchmarks (tower lease surveys / broker comps)

## 3) “Ground truth” strategy (work even when labels are scarce)
Use **multiple independent weak-label sources**, each producing an FMR estimate + confidence score.
- **Anchor Labels (best)**
  - Recent competitive new leases / amended leases
  - Post‑renewal “reset” rents (when negotiation clearly corrected pricing)
  - Third‑party appraisals / arbitration / litigation values (if any)
- **Comparable Surface (geo KNN / similarity search)**
  - Nearby recent deals adjusted for site/type/rights (produces explainable comps)
- **Lower‑Envelope / Frontier methods (internal-only option)**
  - Conditional **quantile regression** (e.g., P20–P30) to estimate market baseline
  - **Stochastic frontier / mixture model**: observed rent = FMR × exp(markup + noise), with markup more likely for older vintages
- **Expert-in-the-loop + Active learning**
  - Small expert labeling (e.g., 300–1000 sites) focused on high-impact / high-uncertainty segments

## 4) Modeling architecture (separate contract determinism from market learning)
- **Contract Engine**: reproduce rent schedule from lease terms (no ML).
- **Market/FMR Model** (cross-sectional): predict `FMR_today` from geo + site + network + legal + macro.
  - Recommended: Gradient boosting + geospatial features + hierarchical effects (region/market)
  - Output: P10/P50/P90 (quantiles), not just a point estimate.
- **Renewal/Event Model**
  - Survival/hazard: P(renewal/termination/relocation) vs time-to-expiry
  - Uplift model: distribution of rent change conditional on renewal and leverage features
- **Decision Layer (optimization)**
  - Expected NPV savings vs **relocation/build cost** and **coverage impact** constraints
  - Produces: target rent, concession strategy, and “walk-away” threshold

## 5) Validation when truth is uncertain
- **Backtest on known “resets”**: FMR should be closer to post-renewal than pre-renewal.
- **Rank validation**: sites predicted most overpriced should show higher realized savings when negotiated.
- **External alignment checks**: compare FMR vs independent benchmarks/comp surfaces.
- **Calibration**: predicted quantiles should match realized outcomes on renewed cohort.
- **Segment stress tests**: urban vs rural, rooftop vs ground, high vs low criticality.

## 6) Deliverables to the business (site-level output)
- **As‑Is rent path** (contract)
- **FMR estimate + confidence** (comps + model explanation)
- **Achievable renewal range** (P10/P50/P90)
- **Savings estimate** and **risk flags** (criticality, redundancy, zoning friction)
- **Recommended negotiation target + walk-away**

## 7) Pilot rollout (pragmatic)
- Start with **50–200 upcoming renewals** across diverse geographies.
- Run **shadow mode**: generate targets; compare vs negotiation outcomes.
- Convert outcomes into new labels → quarterly retrain.

## 8) Key open questions (to confirm before building)
- What **discount rate / WACC** should we use for NPV (single corporate rate or varies by business/asset)?
- How should we monetize/represent **network risk** (e.g., coverage KPI impact, churn risk, regulatory obligations) for the optimization layer?
- What is the **relocation cost and lead-time model** (and can we estimate it by market/asset type)?
- What “anchor label” sources exist today (recent competitive deals, post-renewal resets, appraisals/arbitration, towerco/broker comps)?
- What governance constraints exist (acceptable dispute rate, legal/compliance rules for using model outputs in negotiation packets)?

## 9) Questions to ask business & data owners (use case + data)

### A) Business objective, scope, and success criteria
- **Primary decision**: Is this intended to recommend negotiation targets, forecast budget/forecast cashflows, decide relocate-vs-renew, or all three?
- **Definition of “right rent”**: Do you mean fair market rent, lowest achievable rent, or risk-adjusted optimal rent given network criticality?
- **Optimization goal**: Are we optimizing NPV of total occupancy cost, near-term cash savings, or savings subject to service/coverage constraints?
- **Time horizon**: Are decisions centered on renewal date only, or do you need multi-year (e.g., 10-year) scenario forecasts?
- **In-scope assets**: Which asset types are included (ground leases, rooftops, easements, shelters, DAS/small cells)? Any excluded classes (govt/municipal, strategic sites)?
- **Segmentation**: Should outputs be tailored by region/market, property type, landlord type, or network layer (macro vs small cell)?
- **Success metrics**: What KPIs define success (realized savings, % renewals closed, cycle time, dispute rate, churn/coverage incidents)?
- **Risk tolerance**: What is the acceptable probability of escalation to dispute/arbitration, or risk of site loss/relocation?

### B) Renewal and negotiation process (how decisions are made)
- **Renewal timeline**: How far ahead do teams start (e.g., 6/12/18 months) and what are the key milestones?
- **Negotiation workflow**: What are the steps from landlord notice → internal analysis → counteroffer → approval → execution?
- **Negotiation levers**: Besides rent, what levers matter (term length, access rights, additional space, easements, revenue share, one-time payments)?
- **Landlord asks and counteroffers**: Do we capture landlord initial ask, our counter, and intermediate rounds (or only final outcome)?
- **Approval rules**: What thresholds require escalation/approval (e.g., savings > $X, rent > $Y, litigation risk)?
- **Standard playbooks**: Are there established negotiation strategies by landlord type or region that the model must align with?
- **Relocation decisioning**: Who decides relocate vs renew, and what inputs are required (cost, lead time, permitting, coverage impact)?

### C) Data availability and systems of record
- **System of record for leases**: Where do contract attributes live (CLM, ERP, SharePoint PDFs)? Are key fields structured or only in documents?
- **Lease identifiers**: Is there a stable `site_id` / `lease_id` that joins contracts, payments, engineering, and network data?
- **Payment granularity**: Do we have invoice-level and line-item detail (base rent, taxes, CAM, pass-throughs, one-offs), or only totals?
- **Expected vs paid**: Do we store contract-expected amounts separately from what was actually paid (credits, disputes, late fees)?
- **Amendment/version history**: Can we reconstruct the lease state as-of a past date (important for backtesting)?
- **Renewal outcomes dataset**: Do we have reliable pre/post renewal rent, effective dates, and terms for historical renewals?
- **Negotiation metadata**: Where are notes/asks/counteroffers stored (emails, CRM, ticketing)? Can they be extracted?

### D) Network, technical, and relocation cost inputs
- **Network criticality measures**: What is available and at what grain (traffic, KPIs, overlap %, redundancy distance, layer/tech dependencies)?
- **Engineering attributes**: Where do you store tower/rooftop specs (height, load, footprint, access constraints, upgrades)?
- **Relocation cost model**: Do you have historical relocation costs/time-to-build by market (permitting, construction, backhaul)?
- **Constraints inventory**: Are there markets with moratoria, zoning/power limits, or known permitting friction that raise move-cost?

### E) “Ground truth” anchors and benchmarks (critical)
- **Trusted-market cohorts**: Which deals are considered “clean” market-priced (recent competitive bids, new builds, post-reset renewals)?
- **Appraisals/arbitration**: Do we have third-party valuations or arbitration outcomes that can be used as anchor labels?
- **Benchmark sources**: Do you already subscribe to benchmark providers (CoStar/CoreLogic/assessor feeds/tower lease surveys)?
- **Comparable deal sharing**: Are we allowed to use internal deals across regions as comps, or are there policy/market differences?
- **Outcome feedback loop**: Can we tag negotiations as “model used” vs “not used” to evaluate impact?

### F) Output requirements (what the business needs to see)
- **Outputs per site**: What minimum outputs are needed (FMR P50, P10/P90, recommended target, walk-away, key drivers, comps list)?
- **Explainability**: What level of explanation is required for negotiation/legal (SHAP drivers, comparable sites, adjustment logic)?
- **Delivery format**: Dashboard, PDF “negotiation packet”, batch file, API integration—what fits the workflow?
- **Refresh cadence**: How often must predictions update (monthly, quarterly, pre-renewal only)?

### G) Governance, legal, and operating constraints
- **Usage constraints**: Any legal/compliance limitations on using ML-generated numbers in negotiations?
- **Data access**: Who can access network metrics, contract docs, and external datasets (PII, security tiers)?
- **Auditability**: Do we need audit trails for every prediction (inputs, model version, explanation snapshot)?

### H) Validation and rollout
- **Pilot design**: Which upcoming renewals can be used as a pilot set (volume, diversity, timeline)?
- **Acceptance criteria**: What is the minimum improvement needed to adopt (savings %, close rate, reduced cycle time)?
- **Post-deploy monitoring**: Who owns ongoing monitoring and retraining signals (new renewals, market shifts, drift alerts)?

## 10) KPI framework (proposed)

### A) Financial value (primary)
- **NPV Savings vs Baseline**: NPV(as-is occupancy cost) − NPV(actual/optimized outcome) over 10 years (discounted).
- **Realized annual savings**: (baseline annual cost − realized annual cost) aggregated by portfolio/region/asset.
- **Savings capture rate**: realized savings ÷ model-predicted savings (measures execution gap).
- **ROI of negotiations**: savings ÷ (internal labor + legal + external data costs).

### B) Negotiation outcomes (execution quality)
- **Renewal closure rate**: % renewals closed by required deadline.
- **Negotiated-to-target ratio**: final rent ÷ recommended target (median + tails).
- **Cycle time**: days from first notice to execution.
- **Dispute/arbitration rate**: % that escalate + associated legal cost.

### C) Network/service guardrails (risk)
- **Critical site loss count**: #/rate of terminations or forced relocations in high-criticality tiers.
- **Coverage/service impact**: tracked changes in agreed KPI set pre/post action (e.g., overlap, traffic offload, complaints, outage minutes).
- **Time-to-recover**: for relocations, time to restore target performance.

### D) Model quality (must be tracked even with weak labels)
- **Anchor-label accuracy**: error metrics on trusted cohorts (recent competitive deals, post-reset renewals).
- **Calibration**: quantile coverage for predicted P10/P50/P90 vs realized outcomes on renewed cohort.
- **Ranking quality**: do “most overpriced” predictions translate into higher realized savings (lift curves)?
- **Stability / drift**: feature distribution drift and prediction drift by zip/market/asset type.

### E) Adoption and operations
- **Usage rate**: % of renewals where model outputs were used in the negotiation packet.
- **Override rate**: % where negotiators materially overrode recommendation + documented reason.
- **Analyst productivity**: cycle time reduction / # sites supported per analyst.

## 11) Risk tolerance (recommended methods)

### A) Tiered risk appetite driven by network criticality
- Build a **site criticality score** and segment into tiers (e.g., Tier 1 strategic → Tier 4 low).
- Define policy by tier:
  - Tier 1: favor renewal; conservative targets; relocation only under extreme conditions
  - Tier 4: aggressive targets; relocation is a viable lever

### B) Convert risk into the NPV objective (preferred when possible)
- Estimate expected costs for failure modes:
  - negotiation failure/dispute (legal + delay)
  - relocation/build (capex/opex + time)
  - service degradation (revenue/churn/regulatory proxies)
- Optimize: **Expected NPV cost + tail-risk penalty** rather than using arbitrary thresholds.

### C) Chance constraints / guardrails (when policy requires hard limits)
- Examples:
  - P(forced relocation for Tier 1) ≤ α
  - P(dispute/arbitration) ≤ β
  - P(coverage KPI drop > threshold) ≤ γ
- These require predictive risk models for dispute, permitting delays, and relocation feasibility.

### D) Tail-risk control (CVaR / robust optimization)
- Use **CVaR** on total occupancy cost or service-impact cost to avoid strategies that have small expected savings but catastrophic downside.
- Increase risk aversion for higher criticality tiers.

### E) Portfolio risk budgets
- Limit the number/percentage of “high-risk” negotiations running simultaneously by market or quarter.
- Allocate a risk budget by tier/region to keep operational load and exposure controlled.

## 12) Rent de-noising / component decomposition (recommended strategy)

### A) Normalize the payment ledger into interpretable components (accounting de-noise)
Goal: make sure we are modeling **rent**, not billing artifacts.

1) Standardize amounts to a consistent grain (monthly → annual) and clean:
- prorations
- partial periods
- late fees/interest
- credits/reversals
- retro true-ups

2) Split what is paid into buckets (as available):
- **Rent** (base + escalators)
- **Pass-throughs** (tax, CAM, utilities, insurance)
- **One-time payments** (signing bonus, amendments, legal reimbursements)
- **Revenue-share / sublease share**

If line-item detail is not available, build a best-effort classifier using invoice descriptors + GL codes, and keep an “unknown/other” bucket.

### B) Build a deterministic “contract rent engine” (structural decomposition)
Reconstruct the contract-implied rent schedule from lease terms and amendments.

Outputs per site/year:
- `Contract_Expected_Rent(i,t)`
- `Contract_Escalation_Factor(i,t)` (fixed %, CPI, step-ups)
- option/renewal timing flags

This becomes your **baseline** (what should be paid if the lease were followed mechanically).

### C) Compute the residual series and separate noise vs structure
Define an adjusted rent series and residual:

- `Paid_Rent_Adj(i,t) = Paid_Rent(i,t) − PassThrough(i,t) − OneOff(i,t)`
- `Residual(i,t) = Paid_Rent_Adj(i,t) − Contract_Expected_Rent(i,t)`

Interpretation:
- Residual near 0: payments track the contract
- Positive residual: over-contract payments (leakage, concessions, non-modeled terms)
- Negative residual: credits/disputes/temporary abatements

### D) Detect structural breaks (amendments, renewals, dispute resolutions)
Run change-point detection on `Residual(i,t)` to identify step changes.

Recommended methods:
- PELT / binary segmentation for offline change points
- Bayesian change-point for probabilistic break confidence

This is essential because renewals/amendments create **jumps**, not smooth drift.

### E) Decompose the residual into market drift vs persistent markup
For each site, model the residual with an unobserved-components / state-space model:

`Residual(i,t) = LocalMarket(zip,t) + SitePremium(i) + Jump(i,t) + ε(i,t)`

Where:
- `LocalMarket(zip,t)` captures time-varying market drift (zip → higher hierarchy)
- `SitePremium(i)` captures persistent site-specific premium (network/technical/legal leverage)
- `Jump(i,t)` captures renewal/amendment step changes from Section D
- `ε(i,t)` is remaining noise

Implementation notes:
- Use hierarchical shrinkage so zip-level signals borrow strength from county/MSA/state when data is sparse.
- Include macro regressors (CPI, land/CRE indices, construction costs) inside `LocalMarket`.

### F) Identify “overpayment markup” under explicit assumptions (optional but powerful)
If you want a **lowest-achievable** target, you can introduce an explicit non-negative markup component:

`Paid_Rent_Adj = FMR × exp(Markup) × exp(Noise)` with `Markup ≥ 0`

Practical estimators:
- **Stochastic frontier analysis** (separates baseline from one-sided markup)
- **Conditional quantile regression** (treat P20–P30 as a proxy for “market/efficient” baseline; markup = observed − baseline)

These approaches operationalize your hypothesis: “many leases are above market, but not below market by much.”

### G) What you get out of decomposition (usable downstream)
Per site/year you can produce:
- **Deterministic contract rent** (as-is)
- **Market drift estimate** (zip/market time-varying)
- **Persistent premium estimate** (site/network/legal)
- **Event-driven jumps** (renewal/amendment)
- **Noise/outliers** (billing artifacts)

This decomposition is the best starting point to create:
- features for renewal probability and renewal rent models
- weak labels/priors for fair-rent estimation
- guardrails for budget forecasting (e.g., separate pass-through inflation from rent changes)

## 13) How to start the project (phased delivery with gates)

### Phase 0: Kickoff + feasibility (1–2 weeks)
- Align on:
  - NPV discount rate (WACC) and cost accounting boundaries (what counts as occupancy cost)
  - risk policy (criticality tiers + what is “unacceptable”)
  - the first pilot cohort (50–200 upcoming renewals) and the decision cadence
- Data audit:
  - identify systems of record and join keys (`site_id`/`lease_id`)
  - quantify completeness for contract terms, payment line items, renewal outcomes, network features
- Gate to proceed:
  - ability to compute a consistent **Paid_Total** series and link it to a site
  - ability to reconstruct at least a majority of **Contract_Expected_Rent** fields for the pilot

### Phase 1: “Truthful baseline” build (2–4 weeks)
Deliverables (portfolio + pilot):
- Payment de-noising (Section 12A) and a clean **Rent-only** series
- Contract rent engine (Section 12B) producing **as-is 10-year annual forecast**
- Residualization vs contract (Section 12C) + first overpayment/leakage ranking

Why this phase matters:
- it produces immediate budget-quality forecasts
- it isolates the problem into an interpretable residual signal

Gate:
- finance/lease ops agree the baseline is auditable (site-by-site reconciliation)

### Phase 2: “Lowest-achievable” baseline (4–8 weeks)
Deliverables:
- First-pass market/lowest-achievable model using internal-only methods (peer groups + quantile/frontier)
- Comparable retrieval framework where comps exist (internal + any external sources available)
- Uncertainty scoring by site (data completeness + model confidence)

Gate:
- business validation on a sample: outputs are directionally credible and provide negotiation-ready explanations

### Phase 3: Renewal/relocation decision engine (6–12 weeks, overlaps Phase 2)
Deliverables:
- Renewal/termination timing model (survival/hazard)
- Renewal outcome model (uplift distribution)
- Relocation cost and lead-time model (even if initially coarse by market/asset)
- Optimization layer to select action/target that minimizes expected NPV subject to risk policy

Gate:
- negotiation teams can use the target + walk-away + rationale in a live renewal cycle

### Phase 4: Pilot execution + learning loop (ongoing)
Deliverables:
- “Negotiation packet” outputs per renewal (as-is path, target, walk-away, drivers, comps, risk flags)
- Outcome capture (ask/counter/final, cycle time, disputes, success) to create new anchor labels
- Monitoring (drift, calibration, realized savings vs predicted)

Gate:
- demonstrate measurable improvement vs historical/control process on defined KPIs (Section 10)

## 14) If internal data is primarily lease agreements (documents)

### A) Clarify what “payment data” means inside the lease
- **Contract schedule** (most common): a table/clauses that state what rent *should be* (base + escalators).
- **Actual payment history** (less common): evidence of what was *actually paid* (invoices, receipts, ledger extracts).

This distinction matters because “de-noising” and residual analysis require **actual paid** amounts, not just the schedule.

### B) Minimum structured schema to extract from leases
- **Identifiers**: `lease_id`, `site_id` (or a reliable surrogate), landlord name, address/ZIP
- **Dates**: lease start, expiry, option windows, amendment effective dates
- **Rent economics**:
  - base rent amount + payment frequency
  - escalator type (fixed %, CPI-linked, step-up schedule)
  - CPI definition (index name, base period, floor/cap, reset rules)
  - pass-through obligations (tax/CAM/insurance/utilities) if specified
- **Rights/constraints** (for negotiation leverage): termination rights, ROFR, assignment/sublease rights, access restrictions

### C) Extraction pipeline (document → structured → contract engine)
1) **Ingest** PDFs/Word/scans and classify document type (original vs amendment vs notice).
2) **OCR** (only if scanned) and normalize text (headers/footers, tables).
3) **Locate clauses/tables** for:
   - rent + escalators
   - term/renewal options
   - pass-throughs
4) **Extract** amounts, dates, frequencies using a hybrid approach:
   - deterministic parsing (regex + rules) for money/dates
   - ML/LLM extraction for clause interpretation (with confidence scoring)
5) **Validate** on a sample with human review; create an error taxonomy and iterate.
6) **Compute** `Contract_Expected_Rent(i,t)` via the contract rent engine (Section 12B).

### D) What you can deliver with leases alone (early value)
- **As-is 10-year annual forecast** (contract schedule)
- Portfolio segmentation and prioritization using:
  - rent levels and escalation steepness
  - rights/constraints (leverage features)
  - geography (ZIP rollups)

### E) Key data gaps (needed for full “risk-adjusted lowest achievable”)
- **Actual paid ledger** (AP/ERP) to compute true residual leakage vs contract
- **Network criticality** metrics (traffic/overlap/redundancy) to set risk tiers
- **Relocation cost + lead time** to support relocate-vs-renew NPV decisions
- **Outcome labels** (negotiation asks/counters/final) to train “achievable” targets

## 15) Attribute-driven plan (leveraging the full attribute list)

### A) Build a “site-year” modeling table (the backbone)
Because your horizon is **annual for 10 years**, the most practical modeling grain is:

- One row per **site × year**: `SiteYear(i,t)`

Core columns:
- `site_id`, `lease_id`, `zip`, `lat`, `lon`
- `year` (relative year index or calendar year)
- `Contract_Expected_Rent(i,t)` (from lease schedule)
- `Paid_Rent_Adj(i,t)` (if actual paid is available)

All attributes you listed become:
- static features (do not change much) OR
- time-varying features (macro + network + competitive)

### B) Map each attribute category to: source → feature engineering → model usage

#### 1) Contractual & lifecycle architecture
- **Primary source**: lease agreements + amendments
- **Key extracted fields**:
  - base rent, escalator type/rate/frequency, term remaining, options, renewal adjustment clauses
  - termination/ROFR/assignment rights
- **Feature engineering**:
  - `time_to_expiry_years`
  - `renewal_window_flag`
  - `escalator_path(t)` (deterministic series)
  - `tenant_rights_index` and `landlord_rights_index` (from clause presence)
- **Used for**:
  - as-is rent forecast (contract engine)
  - renewal probability (hazard features)
  - bounds / risk flags (decision layer)

#### 2) Payment & financial data
- **Primary source**: lease schedules (contract rent); actual paid ideally from AP/ERP; sometimes embedded in documents
- **Key derived fields**:
  - `Paid_Rent_Adj` and `Residual = Paid_Rent_Adj − Contract_Expected_Rent`
  - `payment_delta_ratio`
  - one-off payment indicators (signing bonus / amendment payment)
- **Used for**:
  - residual learning (detect leakage/overpayment vs contract)
  - training weak labels (where post-reset outcomes exist)

#### 3) Geospatial & spatial intelligence
- **Sources**:
  - internal site location (lat/lon, address)
  - external: zoning/permitting datasets, hazard layers, development indices
- **Feature engineering**:
  - `zoning_restrictiveness_score`
  - `permit_complexity_score`
  - hazard exposure index (flood/fire/wind)
  - spatial aggregation by ZIP with hierarchical rollup
- **Used for**:
  - fair/lowest-achievable baseline (cross-sectional rent drivers)
  - renewal outcomes (supply constraint impacts leverage)

#### 4) Competitive landscape & multi-tenancy
- **Sources**:
  - internal tenancy/colocation (if available)
  - external: competitor tower locations (e.g., FCC + commercial) and tower density
- **Feature engineering**:
  - `alt_site_density` in search ring
  - `nearby_tower_density`
  - `colocation_count` with diminishing returns transform
- **Used for**:
  - lowest-achievable baseline (substitution pressure)
  - renewal uplift (landlord leverage proxy)

#### 5) Technical & structural attributes
- **Sources**: internal engineering inventories (tower type, height, footprint, load, age)
- **Feature engineering**:
  - interactions: `height × terrain`, `load × age`, `footprint × tenants`
  - relocation friction proxy (bigger/complex sites → harder to move)
- **Used for**:
  - renewal probability (exit friction)
  - relocate-vs-renew NPV (cost and feasibility)

#### 6) Network criticality & coverage
- **Sources**: internal network KPIs (traffic, overlap %, redundancy distance, tech layers)
- **Feature engineering**:
  - `criticality_score` composite
  - `redundancy_distance`, `coverage_overlap_pct`
  - tiering: Tier 1–4 (policy)
- **Used for**:
  - risk-adjusted targets (how aggressive can we be)
  - constraints in optimization (avoid actions that endanger Tier 1)

#### 7) Micro & macro economic drivers
- **Sources**: external macro data (CPI, construction cost, CRE indices, census/pop growth)
- **Feature engineering**:
  - `land_value_cagr_5y` by ZIP/county/MSA
  - `replacement_cost_inflation`
  - population/telecom demand growth proxies
- **Used for**:
  - time-varying market drift (zip → hierarchy)
  - long-horizon (years 6–10) forecast stabilization

#### 8) Legal & contract enforcement
- **Sources**: lease clauses + internal legal outcomes (if available)
- **Feature engineering**:
  - binary clause flags
  - `landlord_control_score` / `tenant_flex_score`
  - tail-risk modifier (wider P90 where landlord control is high)
- **Used for**:
  - shaping prediction intervals (P10/P90)
  - dispute probability modeling and optimization guardrails

### C) How this turns into the 3 required outputs

1) **Forecast budget/cashflows (annual, 10 years)**
- Start from `Contract_Expected_Rent(i,t)`
- Add modeled drift for pass-throughs (if included in “occupancy cost”)

2) **Recommend negotiation targets (lowest achievable, risk-adjusted)**
- Compute a baseline using:
  - peer groups + quantile/frontier (internal-only) OR
  - comps + external anchoring (when available)
- Adjust aggressiveness using criticality tier + dispute risk

3) **Relocate vs renew decision**
- Compare actions by expected NPV cost using relocation cost/lead time + risk penalties/constraints

### D) Practical gating given your current internal data
- With **leases alone**, you can fully deliver (1) and parts of (2) (contract schedule + legal leverage).
- To deliver (2) credibly and (3) correctly, you will need at least:
  - network criticality
  - relocation cost/lead time
  - some benchmark/comparable signal (internal “good deals” or external)
