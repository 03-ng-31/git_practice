# API Integration Implementation Plan for Telecom Lease Data Platform

This plan outlines the development of Python API wrappers for all open-source data platforms identified for the telecom lease optimization project, including US demographic data sources.

---

## 1. US Demographic Data Sources (NEW)

### 🟢 **US Census Bureau API**
- **What:** Official source for US demographic, economic, and housing data
- **Key Datasets:**
  - **American Community Survey (ACS) 5-Year:** Block-group level data (population, income, education, housing)
  - **ACS 1-Year:** County/metro-level data (more current, less granular)
  - **Population Estimates:** Annual population estimates by county/state
  - **Decennial Census:** 10-year comprehensive population counts
- **API:** RESTful API with JSON responses
- **Access:** Free with API key (register at https://api.census.gov/data/key_signup.html)
- **Rate Limits:** 500 queries per IP per day
- **Documentation:** https://www.census.gov/data/developers/guidance/api-user-guide.html
- **Use Case:** Population density, income levels, housing units, demographic trends

### 🟢 **Data USA API**
- **What:** Open-source platform aggregating Census, BLS, and other federal data
- **Data:** Population, employment, wages, education, health, trade
- **API:** RESTful API with simple query syntax
- **Access:** Free, no API key required
- **Documentation:** https://datausa.io/about/api/
- **Use Case:** Simplified access to demographic/economic data with pre-computed metrics

### 🟢 **Census Geocoder API**
- **What:** Convert addresses to lat/lon and Census geographies (FIPS codes)
- **API:** RESTful API for single/batch geocoding
- **Access:** Free, no API key required
- **Use Case:** Map tower addresses to Census block groups for demographic joins

---

## 2. Project Structure

```
telecom-lease-data-platform/
├── src/
│   ├── api_clients/
│   │   ├── __init__.py
│   │   ├── census_client.py          # US Census Bureau API
│   │   ├── datausa_client.py         # Data USA API
│   │   ├── fcc_client.py              # FCC ASR/ULS data
│   │   ├── opencellid_client.py       # OpenCelliD API
│   │   ├── fema_flood_client.py       # FEMA Flood API
│   │   ├── usgs_earthquake_client.py  # USGS Earthquake API
│   │   ├── regrid_client.py           # Regrid Parcel API (commercial)
│   │   └── attom_client.py            # ATTOM Data API (commercial)
│   ├── models/
│   │   ├── __init__.py
│   │   ├── tower_site.py              # Tower site data model
│   │   ├── demographic_data.py        # Demographic features
│   │   ├── geospatial_data.py         # Geospatial features
│   │   └── hazard_data.py             # Hazard/risk features
│   ├── utils/
│   │   ├── __init__.py
│   │   ├── geocoding.py               # Geocoding utilities
│   │   ├── rate_limiter.py            # API rate limiting
│   │   └── cache.py                   # Response caching
│   └── pipeline/
│       ├── __init__.py
│       ├── data_enrichment.py         # Main enrichment pipeline
│       └── feature_engineering.py     # Feature extraction
├── tests/
│   ├── test_census_client.py
│   ├── test_fcc_client.py
│   └── ...
├── config/
│   ├── api_keys.yaml                  # API credentials (gitignored)
│   └── config.yaml                    # Configuration settings
├── data/
│   ├── raw/                           # Raw downloaded data
│   ├── processed/                     # Processed features
│   └── cache/                         # API response cache
├── notebooks/
│   ├── 01_data_exploration.ipynb
│   └── 02_api_testing.ipynb
├── requirements.txt
├── setup.py
├── .env.example
└── README.md
```

---

## 3. Implementation Phases

### **Phase 1: Core Infrastructure (Week 1)**
**Goal:** Set up project structure and base API client framework

#### Tasks:
1. **Project Initialization**
   - Create directory structure
   - Set up virtual environment
   - Initialize git repository
   - Create `.gitignore` (exclude API keys, cache, data)

2. **Base API Client Class**
   - Create abstract `BaseAPIClient` class with:
     - Rate limiting (using `ratelimit` library)
     - Response caching (using `requests-cache`)
     - Error handling and retries (using `tenacity`)
     - Logging (using `loguru`)
   
3. **Configuration Management**
   - YAML-based config files
   - Environment variable support (using `python-dotenv`)
   - API key management

4. **Dependencies**
   ```
   requests>=2.31.0
   requests-cache>=1.1.0
   ratelimit>=2.2.1
   tenacity>=8.2.3
   loguru>=0.7.2
   python-dotenv>=1.0.0
   pyyaml>=6.0.1
   pandas>=2.1.0
   geopandas>=0.14.0
   shapely>=2.0.0
   pydantic>=2.5.0
   ```

---

### **Phase 2: Free API Clients (Week 2)**
**Goal:** Implement all free/open-source API clients

#### 2.1 US Census Bureau Client
**File:** `src/api_clients/census_client.py`

**Features:**
- ACS 5-Year data retrieval by geography (block group, tract, county)
- Variable lookup and metadata
- Batch geography queries
- Support for multiple years
- Automatic FIPS code handling

**Key Methods:**
```python
class CensusClient(BaseAPIClient):
    def get_acs_data(self, variables: List[str], geography: str, 
                     year: int = 2022, dataset: str = "acs5") -> pd.DataFrame
    def get_population_by_location(self, lat: float, lon: float) -> Dict
    def get_income_by_fips(self, fips_code: str) -> Dict
    def batch_query(self, locations: List[Dict]) -> pd.DataFrame
```

**Python Library:** Use `census` library (https://github.com/datamade/census) as wrapper

#### 2.2 Data USA Client
**File:** `src/api_clients/datausa_client.py`

**Features:**
- Simplified demographic queries
- Pre-aggregated metrics
- Time-series data retrieval

**Key Methods:**
```python
class DataUSAClient(BaseAPIClient):
    def get_population(self, geo_level: str, geo_id: str, year: str = "latest") -> Dict
    def get_income_data(self, geo_level: str, geo_id: str) -> Dict
    def get_employment_data(self, geo_level: str, geo_id: str) -> Dict
```

#### 2.3 FCC Data Client
**File:** `src/api_clients/fcc_client.py`

**Features:**
- Download and parse FCC ASR bulk data
- Query towers by radius
- Extract tower attributes (height, owner, age)

**Key Methods:**
```python
class FCCClient(BaseAPIClient):
    def download_asr_database(self, output_dir: str) -> str
    def parse_asr_data(self, file_path: str) -> pd.DataFrame
    def get_towers_in_radius(self, lat: float, lon: float, radius_km: float) -> pd.DataFrame
    def get_tower_by_registration(self, asrn: str) -> Dict
```

**Note:** FCC data is bulk download (no REST API), so this client will:
1. Download weekly ZIP files from FCC
2. Parse pipe-delimited text files
3. Load into SQLite/PostgreSQL for querying

#### 2.4 OpenCelliD Client
**File:** `src/api_clients/opencellid_client.py`

**Features:**
- Cell tower location lookup
- Towers in radius query
- Carrier identification (MCC/MNC)

**Key Methods:**
```python
class OpenCelliDClient(BaseAPIClient):
    def get_cell_position(self, mcc: int, mnc: int, lac: int, cellid: int) -> Dict
    def get_cells_in_area(self, lat: float, lon: float, radius: int) -> List[Dict]
    def count_towers_nearby(self, lat: float, lon: float, radius_km: float) -> int
```

**Python Library:** Use `opencellid` PyPI package or build custom wrapper

#### 2.5 FEMA Flood Client
**File:** `src/api_clients/fema_flood_client.py`

**Features:**
- Flood zone lookup by lat/lon
- Base flood elevation retrieval
- Batch queries

**Key Methods:**
```python
class FEMAFloodClient(BaseAPIClient):
    def get_flood_zone(self, lat: float, lon: float) -> Dict
    def get_base_flood_elevation(self, lat: float, lon: float) -> float
    def batch_flood_lookup(self, locations: List[Tuple[float, float]]) -> pd.DataFrame
```

**API:** National Flood Data API (requires paid key) or FEMA free GIS services

#### 2.6 USGS Earthquake Client
**File:** `src/api_clients/usgs_earthquake_client.py`

**Features:**
- Seismic hazard scoring
- Historical earthquake query

**Key Methods:**
```python
class USGSEarthquakeClient(BaseAPIClient):
    def get_earthquakes_in_area(self, lat: float, lon: float, 
                                 radius_km: float, start_date: str) -> List[Dict]
    def get_seismic_hazard_score(self, lat: float, lon: float) -> float
```

---

### **Phase 3: Commercial API Clients (Week 3)**
**Goal:** Implement commercial API clients (Regrid, ATTOM)

#### 3.1 Regrid Parcel Client
**File:** `src/api_clients/regrid_client.py`

**Features:**
- Parcel lookup by lat/lon or address
- Property attributes (assessed value, zoning, land use)
- Parcel boundary retrieval

**Key Methods:**
```python
class RegridClient(BaseAPIClient):
    def get_parcel_by_location(self, lat: float, lon: float) -> Dict
    def get_parcel_by_address(self, address: str) -> Dict
    def get_assessed_value(self, parcel_id: str) -> float
```

#### 3.2 ATTOM Data Client
**File:** `src/api_clients/attom_client.py`

**Features:**
- Property tax assessor data
- Sale history
- Property characteristics

**Key Methods:**
```python
class ATTOMClient(BaseAPIClient):
    def get_property_details(self, address: str) -> Dict
    def get_tax_assessment(self, apn: str) -> Dict
    def get_sale_history(self, property_id: str) -> List[Dict]
```

---

### **Phase 4: Data Models & Pipeline (Week 4)**
**Goal:** Create data models and enrichment pipeline

#### 4.1 Data Models
**File:** `src/models/tower_site.py`

```python
from pydantic import BaseModel
from typing import Optional

class TowerSite(BaseModel):
    site_id: str
    latitude: float
    longitude: float
    address: Optional[str]
    current_rent: float
    lease_start_date: str
    # ... other fields

class DemographicFeatures(BaseModel):
    population_3km: int
    median_income_3km: float
    housing_units_3km: int
    population_density: float
    # ... other fields

class GeospatialFeatures(BaseModel):
    parcel_assessed_value: float
    zoning_classification: str
    flood_zone: str
    tower_density_3km: int
    # ... other fields
```

#### 4.2 Enrichment Pipeline
**File:** `src/pipeline/data_enrichment.py`

```python
class DataEnrichmentPipeline:
    def __init__(self, config: Dict):
        self.census_client = CensusClient(config['census_api_key'])
        self.fcc_client = FCCClient()
        self.opencellid_client = OpenCelliDClient(config['opencellid_key'])
        # ... initialize all clients
    
    def enrich_site(self, site: TowerSite) -> Dict:
        """Enrich a single tower site with all external data"""
        features = {}
        
        # 1. Demographic data
        features.update(self._get_demographic_features(site))
        
        # 2. Geospatial data
        features.update(self._get_geospatial_features(site))
        
        # 3. Competitor density
        features.update(self._get_competitor_features(site))
        
        # 4. Hazard data
        features.update(self._get_hazard_features(site))
        
        return features
    
    def enrich_batch(self, sites: List[TowerSite]) -> pd.DataFrame:
        """Enrich multiple sites with rate limiting and caching"""
        # Implement batch processing with progress bar
        pass
```

---

### **Phase 5: Testing & Documentation (Week 5)**
**Goal:** Comprehensive testing and documentation

#### 5.1 Unit Tests
- Test each API client independently
- Mock API responses for offline testing
- Test rate limiting and error handling

#### 5.2 Integration Tests
- Test full enrichment pipeline
- Test with real API calls (limited)

#### 5.3 Documentation
- API client usage examples
- Configuration guide
- Troubleshooting guide
- Jupyter notebook tutorials

---

## 4. Sample Code: Census Client Implementation

```python
# src/api_clients/census_client.py
import requests
from typing import List, Dict, Optional
import pandas as pd
from .base_client import BaseAPIClient

class CensusClient(BaseAPIClient):
    """Client for US Census Bureau API"""
    
    BASE_URL = "https://api.census.gov/data"
    
    def __init__(self, api_key: str):
        super().__init__(
            base_url=self.BASE_URL,
            rate_limit_calls=500,
            rate_limit_period=86400  # 24 hours
        )
        self.api_key = api_key
    
    def get_acs_data(
        self, 
        variables: List[str], 
        geography: str,
        state: Optional[str] = None,
        county: Optional[str] = None,
        year: int = 2022,
        dataset: str = "acs5"
    ) -> pd.DataFrame:
        """
        Retrieve ACS data for specified variables and geography.
        
        Args:
            variables: List of ACS variable codes (e.g., ['B01003_001E', 'B19013_001E'])
            geography: Geography level ('block group', 'tract', 'county', 'state')
            state: State FIPS code (required for sub-state geographies)
            county: County FIPS code (required for sub-county geographies)
            year: Data year (default: 2022)
            dataset: ACS dataset ('acs1' or 'acs5')
        
        Returns:
            DataFrame with requested variables by geography
        """
        # Build API endpoint
        endpoint = f"/{year}/acs/{dataset}"
        
        # Build query parameters
        params = {
            'get': ','.join(['NAME'] + variables),
            'key': self.api_key
        }
        
        # Build geography string
        if geography == 'block group':
            params['for'] = 'block group:*'
            params['in'] = f'state:{state} county:{county}'
        elif geography == 'tract':
            params['for'] = 'tract:*'
            params['in'] = f'state:{state} county:{county}'
        elif geography == 'county':
            params['for'] = 'county:*'
            params['in'] = f'state:{state}'
        elif geography == 'state':
            params['for'] = 'state:*'
        
        # Make request with rate limiting
        response = self._make_request('GET', endpoint, params=params)
        
        # Parse response
        data = response.json()
        df = pd.DataFrame(data[1:], columns=data[0])
        
        return df
    
    def get_population_by_location(self, lat: float, lon: float) -> Dict:
        """
        Get population data for a specific lat/lon location.
        
        This method:
        1. Geocodes lat/lon to Census block group
        2. Retrieves population data for that block group
        """
        # First, geocode to get FIPS codes
        fips = self._geocode_to_fips(lat, lon)
        
        # Then retrieve population data
        variables = ['B01003_001E']  # Total population
        df = self.get_acs_data(
            variables=variables,
            geography='block group',
            state=fips['state'],
            county=fips['county']
        )
        
        # Filter to specific block group
        result = df[
            (df['state'] == fips['state']) &
            (df['county'] == fips['county']) &
            (df['tract'] == fips['tract']) &
            (df['block group'] == fips['block_group'])
        ]
        
        return {
            'population': int(result['B01003_001E'].iloc[0]),
            'fips': fips
        }
    
    def _geocode_to_fips(self, lat: float, lon: float) -> Dict:
        """Use Census Geocoder to convert lat/lon to FIPS codes"""
        geocoder_url = "https://geocoding.geo.census.gov/geocoder/geographies/coordinates"
        params = {
            'x': lon,
            'y': lat,
            'benchmark': 'Public_AR_Current',
            'vintage': 'Current_Current',
            'format': 'json'
        }
        
        response = requests.get(geocoder_url, params=params)
        data = response.json()
        
        geographies = data['result']['geographies']['Census Block Groups'][0]
        
        return {
            'state': geographies['STATE'],
            'county': geographies['COUNTY'],
            'tract': geographies['TRACT'],
            'block_group': geographies['BLKGRP']
        }
```

---

## 5. Configuration Example

```yaml
# config/config.yaml
api_keys:
  census: ${CENSUS_API_KEY}
  opencellid: ${OPENCELLID_API_KEY}
  fema_flood: ${FEMA_API_KEY}
  regrid: ${REGRID_API_KEY}
  attom: ${ATTOM_API_KEY}

rate_limits:
  census: 500  # per day
  opencellid: 1000  # per day
  fema_flood: 10000  # per month

cache:
  enabled: true
  backend: sqlite
  expire_after: 2592000  # 30 days

logging:
  level: INFO
  file: logs/api_client.log

features:
  demographic_radius_km: 3
  tower_density_radius_km: 5
  earthquake_lookback_years: 10
```

---

## 6. Usage Example

```python
# Example: Enrich tower sites with all external data
from src.pipeline.data_enrichment import DataEnrichmentPipeline
from src.models.tower_site import TowerSite
import pandas as pd

# Load configuration
config = load_config('config/config.yaml')

# Initialize pipeline
pipeline = DataEnrichmentPipeline(config)

# Load tower sites
sites_df = pd.read_csv('data/tower_sites.csv')
sites = [TowerSite(**row) for row in sites_df.to_dict('records')]

# Enrich all sites
enriched_df = pipeline.enrich_batch(sites)

# Save results
enriched_df.to_csv('data/processed/enriched_sites.csv', index=False)
```

---

## 7. Timeline & Milestones

| Week | Milestone | Deliverables |
|------|-----------|--------------|
| 1 | Core Infrastructure | Project structure, base client, config management |
| 2 | Free API Clients | Census, Data USA, FCC, OpenCelliD, FEMA, USGS clients |
| 3 | Commercial Clients | Regrid, ATTOM clients (if budget approved) |
| 4 | Pipeline & Models | Data models, enrichment pipeline, feature engineering |
| 5 | Testing & Docs | Unit tests, integration tests, documentation, notebooks |

---

## 8. Next Steps

1. **Review this plan** and confirm the approach
2. **Set up API keys:**
   - Register for Census API key: https://api.census.gov/data/key_signup.html
   - Register for OpenCelliD API key: https://opencellid.org/
   - Evaluate commercial API trials (Regrid, ATTOM)
3. **Confirm budget** for commercial APIs
4. **Start implementation** with Phase 1 (Core Infrastructure)

---

## 9. Estimated Costs

### Development Time
- **Phase 1-2 (Free APIs):** 2-3 weeks (1 developer)
- **Phase 3 (Commercial APIs):** 1 week
- **Phase 4-5 (Pipeline & Testing):** 2 weeks
- **Total:** 5-6 weeks

### API Costs (Annual)
- Census API: **Free**
- Data USA: **Free**
- FCC Data: **Free**
- OpenCelliD: **Free** (up to 1,000 calls/day)
- FEMA Flood: **$0-$5K** (depending on volume)
- USGS: **Free**
- Regrid: **$5K-$15K**
- ATTOM: **$10K-$30K**

**Total API Budget:** $15K-$50K/year (depending on commercial tier)

---

## 10. Key Takeaways

✅ **Free demographic data available** via Census Bureau and Data USA APIs  
✅ **All open-source APIs have Python wrappers** or can be easily implemented  
✅ **Modular architecture** allows incremental development and testing  
✅ **Rate limiting and caching** built into base client for reliability  
✅ **Pydantic models** ensure type safety and data validation  
⚠️ **FCC data requires bulk download** (no REST API) - needs custom parser  
⚠️ **Commercial APIs require budget approval** before implementation  

**Recommendation:** Start with Phase 1-2 (free APIs) to build MVP, then add commercial APIs based on ROI analysis.
