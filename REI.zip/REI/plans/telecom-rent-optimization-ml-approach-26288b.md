# Telecom Cell Tower Rent Optimization - ML Approach

A machine learning framework to forecast fair market rent for cell tower leases, addressing the challenge of inflated historical rents as ground truth.

---

## 1. Problem Reframing

**Core Challenge**: Current rent cannot be used as ground truth because the hypothesis is systematic overpayment.

**Reframed Objective**: Estimate what rent *should* be paid (Fair Market Rent - FMR), then use this to:
- Identify overpaid sites (prioritize for renegotiation)
- Forecast rent at renewal under different scenarios
- Build negotiation leverage with data-driven benchmarks

---

## 2. Proposed Architecture: Multi-Stage Modeling Framework

### Stage 1: Fair Market Rent (FMR) Estimation

**Approach A: Hedonic Pricing Model**
```
FMR = f(Land Value Proxy, Site Characteristics, Network Value, Market Conditions)
```

| Component | Data Sources | Model Role |
|-----------|--------------|------------|
| Land Value Proxy | County assessor data, Zillow/CoStar API, USDA land values | Opportunity cost anchor |
| Site Characteristics | Zoning, permit complexity, topography | Supply constraint premium |
| Network Value | Traffic volume, coverage criticality, redundancy | "Must-have" premium |
| Market Conditions | Local CRE CAGR, population density, telecom demand | Demand-driven adjustment |

**Approach B: Efficient Frontier Benchmarking**
1. Segment sites by: region × site_type × network_criticality
2. Identify "efficient" sites per segment (bottom 25th percentile of rent/value ratio)
3. Train model on efficient sites only
4. Predict FMR for all sites

**Approach C: External Benchmark Anchoring**
- Use published tower lease rate benchmarks (Steel in the Air, Wireless Estimator)
- Adjust for site-specific factors
- Cross-validate with internal "good deals"

### Stage 2: Rent Trajectory Forecasting

Once FMR baseline is established:

```
Rent(t) = FMR(t) + Contractual_Escalation(t) + Market_Drift(t) + Renewal_Jump(t) + ε(t)
```

**Components:**
- **Contractual Escalation**: Deterministic (fixed %, CPI-linked) - hard-coded, not learned
- **Market Drift**: Learned from macro variables (land CAGR, inflation, demand growth)
- **Renewal Jump**: Modeled as step-change with probability from survival model
- **ε(t)**: Stochastic component with site-specific volatility

---

## 3. Feature Engineering Strategy

### Tier 1: High-Impact Features (include in all models)

| Feature | Category | Expected Impact |
|---------|----------|-----------------|
| Search Ring Alternative Density | Geospatial | Strong negative (↓ rent) |
| Traffic Volume | Network Criticality | Strong positive (↑ rent) |
| Coverage Overlap % | Network Criticality | Strong negative |
| Zoning Restrictiveness Index | Geospatial | Strong positive |
| Tenancy Ratio | Competitive | Positive (diminishing) |
| Lease Term Remaining | Contractual | Volatility modifier |
| Local Land Value ($/sqft) | Economic | Baseline anchor |

### Tier 2: Interaction Features

| Interaction | Rationale |
|-------------|-----------|
| Traffic × Redundancy Distance | Monopoly power amplification |
| Zoning × Urban/Rural | Supply constraint context |
| Tower Age × Structure Type | Depreciation curve varies |
| Antenna Height × Terrain | RF value modifier |

### Tier 3: Derived / Engineered

- **Overpayment Ratio (OPR)**: `Actual Rent / Predicted FMR` (target for Stage 1 validation)
- **Renewal Probability**: From survival model on lease maturity
- **Network Criticality Score**: Composite of traffic, overlap, redundancy
- **Landlord Leverage Index**: From ROFR, termination rights, sublease provisions

---

## 4. Ground Truth Construction Methods

### Method 1: Semi-Supervised with Expert Labels

1. Domain experts label ~500-1000 sites as:
   - "Fair priced" (recent negotiation, competitive market)
   - "Overpaid" (known bad deals)
   - "Unknown"
2. Train classifier on labeled data
3. Use predictions to weight training samples

### Method 2: Instrumental Variable Approach

**Idea**: Find variables that affect rent but NOT overpayment.

Candidate instruments:
- Year of original lease signing (pre-2000 vs post-2010 = different market dynamics)
- Competitor tower presence at signing (exogenous market condition)
- Local regulatory changes (zoning law amendments)

### Method 3: Renewal-Based Calibration

1. Collect pre-renewal and post-renewal rents for completed renegotiations
2. `Correction Factor = Post-Renewal Rent / Pre-Renewal Rent`
3. Model: `Correction Factor = f(site features, market conditions)`
4. Apply predicted correction to non-renewed sites

### Method 4: External Market Anchor + Adjustment

```
FMR = Base_Market_Rate × Site_Premium_Multiplier

Base_Market_Rate = f(land value, region, site type) ← from external data
Site_Premium_Multiplier = f(network criticality, scarcity, improvements) ← learned
```

---

## 5. Model Selection Recommendations

### For FMR Estimation (Cross-sectional)

| Model | Pros | Cons | Use When |
|-------|------|------|----------|
| **Gradient Boosting (XGBoost/LightGBM)** | Handles non-linearity, feature interactions | Black-box | Primary workhorse |
| **Quantile Regression Forest** | Provides prediction intervals | Computationally heavier | Need uncertainty bounds |
| **Bayesian Regression** | Interpretable coefficients, uncertainty | Requires prior specification | Executive reporting |
| **Neural Network (Tabular)** | Can capture complex patterns | Data hungry | Large dataset (>50k sites) |

### For Rent Trajectory (Time Series)

| Model | Use Case |
|-------|----------|
| **Hybrid Deterministic + ML** | Short-term (0-3 years) with known escalators |
| **Prophet with Regressors** | Medium-term (3-7 years) with macro drivers |
| **Monte Carlo Simulation** | Long-term (7-10 years) scenario analysis |
| **Survival Model (Cox PH)** | Renewal timing & probability |

---

## 6. Implementation Roadmap

### Phase 1: Data Foundation (Weeks 1-4)
- [ ] Consolidate lease data (contractual terms, payment history)
- [ ] Acquire external data (land values, CRE indices, competitor locations)
- [ ] Build site-level feature store
- [ ] Create "efficient site" labels with domain experts

### Phase 2: FMR Model Development (Weeks 5-10)
- [ ] Implement hedonic pricing baseline
- [ ] Train efficient frontier model
- [ ] Validate against renewal outcomes
- [ ] Compute Overpayment Ratio for all sites

### Phase 3: Forecasting Engine (Weeks 11-16)
- [ ] Build deterministic escalation calculator
- [ ] Train market drift model
- [ ] Implement survival model for renewal events
- [ ] Create scenario simulation framework

### Phase 4: Operationalization (Weeks 17-20)
- [ ] Build rent optimization dashboard
- [ ] Create negotiation support tool (site-level reports)
- [ ] Integrate with renewal workflow
- [ ] Document and train stakeholders

---

## 7. Key Risks & Mitigations

| Risk | Impact | Mitigation |
|------|--------|------------|
| External data quality | FMR accuracy | Multiple data sources, cross-validation |
| Label noise in "efficient" sites | Model bias | Ensemble of labeling methods |
| Concept drift (market changes) | Stale predictions | Rolling retraining, monitoring |
| Explainability for negotiations | Adoption | SHAP values, interpretable sub-models |
| Data leakage from escalators | Overfit | Explicit separation of contractual vs. market components |

---

## 8. Success Metrics

| Metric | Definition | Target |
|--------|------------|--------|
| FMR Model R² | Variance explained in efficient-site rent | > 0.70 |
| Renewal Prediction Accuracy | Actual vs. predicted post-renewal rent | MAPE < 15% |
| Overpayment Identification | Sites flagged as overpaid that get rent reduction | Precision > 60% |
| Portfolio Savings | Actual rent reduction from renegotiations | Track over 12-24 months |

---

## 9. Alternative Approaches Considered

### Unsupervised Anomaly Detection
- Cluster sites, identify rent outliers within clusters
- **Limitation**: Doesn't provide "fair" rent estimate, only flags anomalies

### Pure Time Series Forecasting
- ARIMA/Prophet on historical rent
- **Limitation**: Would perpetuate overpayment patterns

### Causal ML (Double ML, Uplift Modeling)
- Estimate treatment effect of lease characteristics on rent
- **Potential Use**: Understand which contract terms drive overpayment

---

## 10. Data Requirements Summary

### Internal Data
- Lease contracts (all terms, escalation clauses)
- Payment history (actual rent paid monthly/annually)
- Site technical specs (tower type, height, footprint, equipment)
- Network data (traffic, coverage, redundancy mapping)
- Renewal history (pre/post renegotiation rents)

### External Data
- Land value indices (county assessor, Zillow, CoStar)
- Commercial real estate benchmarks
- Tower lease rate benchmarks (industry sources)
- Population and economic data (Census, BLS)
- Zoning and permit databases
- Competitor tower locations (FCC database)

---

## Next Steps

1. **Confirm approach alignment** with stakeholders
2. **Data audit** - assess availability of required features
3. **Pilot selection** - choose 2-3 regions for initial model development
4. **Expert engagement** - identify domain experts for efficient site labeling
