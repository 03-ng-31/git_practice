# Rent Decomposition POC Implementation Plan

Create a simple proof-of-concept for rent decomposition with basic techniques and synthetic data, establishing foundation before implementing advanced methods from the comprehensive framework.

## Project Structure

### New POC Directory: `rent-decomposition-poc/`
```
c:\Users\hp\Desktop\REI\rent-decomposition-poc\
├── src/
│   ├── __init__.py
│   ├── decomposer/
│   │   ├── __init__.py
│   │   ├── basic_decomposer.py        # Core decomposition logic
│   │   ├── contractual_extractor.py   # Extract escalation patterns
│   │   ├── market_estimator.py        # Simple market estimation
│   │   └── components.py              # Component definitions
│   ├── data/
│   │   ├── __init__.py
│   │   ├── sample_generator.py        # Generate synthetic data
│   │   └── validators.py              # Data validation
│   └── utils/
│       ├── __init__.py
│       ├── plotting.py                # Visualization utilities
│       └── metrics.py                 # Performance metrics
├── notebooks/
│   ├── 01_poc_demo.ipynb             # Main demonstration
│   ├── 02_component_analysis.ipynb   # Component deep dive
│   └── 03_validation.ipynb           # Validation results
├── tests/
│   ├── __init__.py
│   ├── test_decomposer.py
│   └── test_components.py
├── data/
│   ├── synthetic/                     # Generated test data
│   └── results/                       # Analysis outputs
├── config/
│   └── poc_config.yaml               # Configuration
├── requirements.txt
└── README.md
```

## Implementation Checklist

### Phase 1: Foundation (Week 1)
- [ ] **Project Setup**
  - Create directory structure
  - Setup requirements.txt with basic dependencies
  - Initialize git repository
  - Create README with POC objectives

- [ ] **Synthetic Data Generator**
  - Generate realistic lease histories with known components
  - Include various escalation patterns (fixed, CPI, revenue-share)
  - Add market cycle variations
  - Include network and location premiums with known values

- [ ] **Basic Component Models**
  - Contractual escalation extractor (deterministic)
  - Simple market trend estimator (linear regression)
  - Network premium calculator (rule-based)
  - Basic noise model (Gaussian)

### Phase 2: Core Decomposer (Week 2)
- [ ] **Basic Decomposition Engine**
  - Implement sequential component extraction
  - Simple reconstruction validation
  - Component coherence checks
  - Basic error metrics

- [ ] **Validation Framework**
  - Compare decomposed vs. true components (synthetic data)
  - Reconstruction accuracy metrics
  - Component isolation quality metrics
  - Visual validation plots

### Phase 3: Testing & Demo (Week 3)
- [ ] **Unit Tests**
  - Test each component extractor
  - Test decomposition pipeline
  - Test data generator
  - Test validation metrics

- [ ] **Demonstration Notebook**
  - Show end-to-end decomposition workflow
  - Visualize component separation
  - Validate against ground truth
  - Performance metrics and insights

## Simplified Technical Approach

### 1. Basic Rent Decomposition Formula
```
Observed_Rent(t) = Base_Rent × Escalation_Factor(t) × Market_Factor(t) × Premium_Factor + Noise(t)
```

### 2. Component Extraction Methods

#### A. Contractual Escalation (Rule-Based)
```python
def extract_escalation_factor(rent_history, contract_terms):
    """Extract escalation using contract parameters"""
    base_rent = rent_history[0]
    escalation_factor = [1.0]
    
    for year in range(1, len(rent_history)):
        # Apply known escalation rate
        factor = escalation_factor[-1] * (1 + contract_terms['annual_escalation'])
        escalation_factor.append(factor)
    
    return np.array(escalation_factor)
```

#### B. Market Factor (Trend Analysis)
```python
def estimate_market_factor(rent_history, economic_indicators):
    """Estimate market component using economic trends"""
    # Remove escalation effects
    detrended_rent = rent_history / extract_escalation_factor(rent_history)
    
    # Fit to economic indicators
    from sklearn.linear_model import LinearRegression
    model = LinearRegression()
    model.fit(economic_indicators.reshape(-1, 1), detrended_rent)
    
    market_factor = model.predict(economic_indicators.reshape(-1, 1))
    return market_factor / market_factor[0]  # Normalize to base year
```

#### C. Premium Factor (Static Multiplier)
```python
def calculate_premium_factor(site_characteristics):
    """Calculate network and location premiums"""
    network_premium = 1.0
    location_premium = 1.0
    
    # Network premium based on traffic/coverage
    if site_characteristics.get('high_traffic', False):
        network_premium += 0.3
    if site_characteristics.get('coverage_critical', False):
        network_premium += 0.2
    
    # Location premium based on zoning/visibility
    if site_characteristics.get('premium_location', False):
        location_premium += 0.25
    
    return network_premium * location_premium
```

### 3. Synthetic Data Generation
```python
def generate_synthetic_lease_data(n_sites=100, years=15):
    """Generate realistic synthetic lease data with known components"""
    sites_data = []
    
    for site_id in range(n_sites):
        # Base parameters
        base_rent = np.random.uniform(2000, 8000)
        escalation_rate = np.random.uniform(0.02, 0.05)  # 2-5% annual
        
        # Market cycles (sine wave with noise)
        market_cycle = 1 + 0.1 * np.sin(np.linspace(0, 2*np.pi, years))
        market_noise = np.random.normal(0, 0.05, years)
        market_factor = market_cycle + market_noise
        
        # Network/location premiums
        network_premium = np.random.uniform(1.1, 2.0)
        location_premium = np.random.uniform(1.0, 1.5)
        total_premium = network_premium * location_premium
        
        # Generate rent history
        rent_history = []
        escalation_factor = 1.0
        
        for year in range(years):
            escalation_factor *= (1 + escalation_rate)
            true_rent = (base_rent * escalation_factor * 
                        market_factor[year] * total_premium)
            
            # Add noise
            noise = np.random.normal(0, 0.02 * true_rent)
            observed_rent = true_rent + noise
            
            rent_history.append(observed_rent)
        
        sites_data.append({
            'site_id': f'SITE_{site_id:03d}',
            'rent_history': rent_history,
            'true_components': {
                'base_rent': base_rent,
                'escalation_rate': escalation_rate,
                'market_factor': market_factor,
                'network_premium': network_premium,
                'location_premium': location_premium
            }
        })
    
    return sites_data
```

### 4. Simple Validation Metrics
```python
def validate_decomposition(true_components, estimated_components):
    """Calculate validation metrics for decomposition quality"""
    metrics = {}
    
    for component in true_components.keys():
        if component in estimated_components:
            true_vals = true_components[component]
            est_vals = estimated_components[component]
            
            # Mean Absolute Percentage Error
            mape = np.mean(np.abs((true_vals - est_vals) / true_vals)) * 100
            
            # Correlation
            correlation = np.corrcoef(true_vals, est_vals)[0, 1]
            
            metrics[component] = {
                'mape': mape,
                'correlation': correlation,
                'rmse': np.sqrt(np.mean((true_vals - est_vals) ** 2))
            }
    
    return metrics
```

## Expected POC Deliverables

### 1. Working Decomposer
- Extract 4 main components: Base, Escalation, Market, Premium
- Handle 100+ synthetic lease histories
- Achieve <15% MAPE on component extraction

### 2. Validation Results
- Component-wise accuracy metrics
- Reconstruction quality assessment  
- Visual validation plots showing component separation

### 3. Demonstration Notebook
- End-to-end workflow example
- Component visualization and analysis
- Performance benchmarking results

### 4. Technical Foundation
- Clean, modular codebase
- Unit test coverage >80%
- Documentation for each component

## Success Criteria

### Minimum Viable POC
- [ ] Successfully decompose synthetic rent data into 4 components
- [ ] Achieve reconstruction accuracy >90% (MAPE <10%)
- [ ] Component extraction accuracy >85% for known synthetic data
- [ ] Working demonstration notebook with visualizations

### Stretch Goals
- [ ] Handle different escalation patterns (fixed, CPI, revenue-share)
- [ ] Detect escalation pattern changes automatically
- [ ] Implement basic outlier detection
- [ ] Add simple market cycle detection

## Dependencies (requirements.txt)
```
numpy>=1.21.0
pandas>=1.3.0
scikit-learn>=1.0.0
matplotlib>=3.4.0
seaborn>=0.11.0
scipy>=1.7.0
jupyter>=1.0.0
pytest>=6.0.0
PyYAML>=5.4.0
```

## Timeline
- **Week 1**: Project setup + synthetic data generation
- **Week 2**: Core decomposer implementation + basic validation
- **Week 3**: Testing, documentation, demonstration notebook

## Next Steps After POC Success
1. **Real Data Integration**: Connect to actual lease data
2. **Advanced Components**: Add temporal adjustments, legal factors
3. **Sophisticated Methods**: Implement Kalman filters, RPCA, wavelets
4. **ML Integration**: Use decomposed components as clean ML targets
5. **Production Pipeline**: Scale for full portfolio processing

This POC focuses on proving the core concept with simple, interpretable methods before advancing to the comprehensive framework outlined in the previous plan.
