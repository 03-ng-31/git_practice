# Telecom Lease Rent Optimization – Methodologies (Math + Examples)

This document lists candidate **data-science methodologies** to (1) de-noise current paid rent, (2) estimate lowest-achievable / risk-adjusted rent, (3) forecast renewal outcomes, and (4) optimize decisions using NPV—each with data requirements, formulas, and worked examples.

---

## A. Rent de-noising & decomposition (make the data usable)

## Method A1 / Algorithm: Payment Ledger De-noising (Accounting Normalization)

### Data / attributes
- Invoice/payment ledger with dates (monthly/quarterly)
- Line item descriptors (rent, tax, CAM, utilities, insurance, reimbursements)
- GL codes / vendor codes
- Credit/reversal flags
- Lease/site identifiers (`site_id`, `lease_id`)

### Process and formulas
1) Convert all payments to a consistent time grain.

If monthly to annual:

```
Paid_Total(i, year) = Σ_{m in year} Paid_Total(i, m)
```

2) Bucket payments into interpretable components:

```
Paid_Total = Paid_Rent + Paid_PassThrough + Paid_OneOff + Paid_Other
```

3) Define adjusted paid rent (removes non-rent artifacts):

```
Paid_Rent_Adj(i,t) = Paid_Total(i,t)
                   − Paid_PassThrough(i,t)
                   − Paid_OneOff(i,t)
```

### Example (data-driven)
Suppose (site A, Jan 2025 invoice):

- Rent line: $2,000
- Property tax pass-through: $300
- One-time “amendment fee reimbursement”: $5,000

Then:

```
Paid_Total = 2,000 + 300 + 5,000 = 7,300
Paid_Rent_Adj = 7,300 − 300 − 5,000 = 2,000
```
Interpretation: for rent modeling, use $2,000 (not $7,300).

---

## Method A2 / Algorithm: Contract Rent Engine (Deterministic Baseline)

### Data / attributes
- Base rent at lease start or latest amendment (`R0`)
- Escalator definition (fixed %, CPI-linked, step-ups, schedules)
- Effective dates (lease start, amendment dates, option start/end)
- CPI series (if escalator depends on CPI)

### Process and formulas
The contract-implied rent is deterministic given the clause.

1) Simple fixed annual escalator (rate `g`):

```
Contract_Rent(i, year t) = R0(i) × (1+g)^(t)
```

2) CPI-linked escalator (illustrative):

```
Contract_Rent(i, t) = R0(i) × CPI(t) / CPI(0)
```

3) Step-up schedule:

```
Contract_Rent(i,t) = R0(i) × Π_{k=1..t} (1 + e_k)
```
where `e_k` can be 0 for years with no change, and positive at step-up years.

### Example (data-driven)
Base rent `R0 = $1,000/month` in Year 0, fixed escalator `g = 3%` annually.

Year 3 contract rent:

```
Contract_Rent(Year 3) = 1000 × 1.03^3 = 1000 × 1.092727 = $1,092.73/month
```

---

## Method A3 / Algorithm: Residualization vs Contract (Leakage/Markup Signal)

### Data / attributes
- `Paid_Rent_Adj(i,t)` from Method A1
- `Contract_Rent(i,t)` from Method A2

### Process and formulas
Define the residual:

```
Residual(i,t) = Paid_Rent_Adj(i,t) − Contract_Rent(i,t)
```
Optionally also use a ratio:

```
Residual_Ratio(i,t) = Paid_Rent_Adj(i,t) / Contract_Rent(i,t)
```

### Example (data-driven)
If contract expects $1,500/month but adjusted paid rent is $1,650/month:

```
Residual = 1,650 − 1,500 = +150
Residual_Ratio = 1,650 / 1,500 = 1.10
```
Interpretation: you’re paying ~10% above the contract baseline (could be concessions, leakage, or non-modeled economics).

---

## Method A4 / Algorithm: Change-Point Detection on Residuals (Renewals/Amendments as Jumps)

### Data / attributes
- Time series `Residual(i,t)` (monthly/annual)
- Amendment/renewal dates (optional but helpful for validation)

### Process and formulas
Model the residual as piecewise-stationary segments and detect breakpoints.

A standard offline objective (PELT-style) is:

```
min_{τ_1,...,τ_K}  Σ_{k=0..K} Cost( Residual_{(τ_k+1):τ_{k+1}} ) + K × penalty
```
where `Cost(·)` is often SSE (sum of squared errors) within a segment.

### Example (data-driven)
Residuals by year: `[20, 15, 30, 25, 18, 220, 210, 205]`

- Years 1–5: residuals near ~20
- Years 6–8: residuals near ~210

A change-point detector will likely flag a breakpoint at **Year 5→6**, consistent with a renewal/amendment that introduced a step increase.

---

## Method A5 / Algorithm: Hierarchical Market Drift + Site Premium (State-Space / Mixed Effects)

### Data / attributes
- `Residual(i,t)` (or `Paid_Rent_Adj`) over time
- Geography hierarchy: ZIP → county/city → MSA/market → state
- Macro drivers: CPI, land/CRE indices, construction cost indices
- Site attributes: network criticality, zoning restrictiveness, etc.

### Process and formulas
One useful decomposition:

```
Residual(i,t) = LocalMarket(zip(i),t) + SitePremium(i) + Jump(i,t) + ε(i,t)
```

A simple random-walk market component:

```
LocalMarket(z,t) = LocalMarket(z,t−1) + η(z,t)
```

Hierarchical shrinkage (conceptual):

```
LocalMarket(zip,t) ~ Normal(LocalMarket(county,t), σ_zip^2)
LocalMarket(county,t) ~ Normal(LocalMarket(MSA,t), σ_county^2)
...
```

### Example (data-driven)
Two ZIPs in the same county:
- ZIP 1 has 3 sites (noisy)
- ZIP 2 has 40 sites (stable)

Hierarchical modeling prevents ZIP 1 from overreacting to noise by partially pooling its estimate toward the county/MSA trend.

---

## B. Fair / lowest-achievable rent estimation (when current paid rent is biased)

## Method B1 / Algorithm: Comparable-Based Benchmarking (Geo Similarity / KNN)

### Data / attributes
- A set of comparable deals (recent leases, renewals, “clean” market-priced sites)
- Site characteristics for distance metric:
  - geography (lat/long, ZIP)
  - asset type (rooftop/ground)
  - zoning/permitting score
  - colocation count / tower density
  - network criticality

### Process and formulas
Define a distance `d(i,j)` between target site `i` and comp `j`. Weight comps by similarity.

Example weighting:

```
w_j = exp(−d(i,j)/τ) / Σ_k exp(−d(i,k)/τ)
FMR_hat(i) = Σ_j w_j × Rent_comp(j)
```

### Example (data-driven)
Target site has 3 comps:

| Comp | Rent | Distance d |
|------|------|------------|
| 1    | 1,800 | 0.5 |
| 2    | 2,000 | 1.0 |
| 3    | 2,400 | 2.0 |

Let `τ=1`.

Weights:

```
exp(−0.5)=0.607
exp(−1.0)=0.368
exp(−2.0)=0.135
Sum=1.110
w1=0.547, w2=0.331, w3=0.122

FMR_hat = 0.547×1800 + 0.331×2000 + 0.122×2400
        = 984.6 + 662.0 + 292.8
        = $1,939.4
```

---

## Method B2 / Algorithm: Hedonic Pricing Model (Regression / Gradient Boosting)

### Data / attributes
- Anchor labels for rent that is believed close to market (recent competitive leases, post-reset renewals, appraisals)
- Features:
  - land value proxy
  - zoning restrictiveness
  - competitor density / substitutes
  - network criticality
  - structural attributes (height, load)
  - landlord leverage index

### Process and formulas
A common starting point is log-linear hedonic regression:

```
log(FMR_i) = β0 + β1 log(LandValue_i) + β2 Zoning_i + β3 Criticality_i + ... + ε_i
```

Then:

```
FMR_hat_i = exp(β0 + β1 log(LandValue_i) + ...)
```

Tree models (XGBoost/LightGBM) generalize this by learning non-linearities, but the above is a good mathematical baseline.

### Example (data-driven)
Assume coefficients:
- `β0 = 2.0`
- `β1 = 0.6`
- `β2 = 0.1`
- `β3 = 0.3`

For a site with:
- `LandValue = 100` (index)
- `Zoning = 4` (1–5)
- `Criticality = 0.7` (0–1)

Compute:

```
log(FMR) = 2.0 + 0.6 log(100) + 0.1×4 + 0.3×0.7
         = 2.0 + 0.6×4.605 + 0.4 + 0.21
         = 2.0 + 2.763 + 0.61
         = 5.373
FMR_hat = exp(5.373) = 215.9  (units depend on how labels were scaled)
```
In real implementation, you’d set units so FMR outputs dollars/month.

---

## Method B3 / Algorithm: Efficient Frontier / Conditional Quantile Regression (Lowest-Achievable Baseline)

### Data / attributes
- Large internal dataset of leases with features (even if labels are noisy)
- Site/market features excluding contract escalator leakage

### Process and formulas
Instead of modeling the mean rent, model a lower quantile (e.g., 20th–30th percentile) as an approximation of “efficient / lowest-achievable” rent.

Quantile regression objective for quantile `τ`:

```
β_hat = argmin_β Σ_i ρ_τ( y_i − x_i^T β )

ρ_τ(u) = u(τ − 1[u < 0])
```

Then baseline:

```
FMR_low_hat(i) = Q_τ( Rent | X=x_i )
```

### Example (data-driven)
If two sites have identical features but observed rents are $1,500 and $2,200, the **median** is $1,850, but the **P25** is closer to $1,500—more aligned with “lowest achievable” when you believe many deals are overpriced.

---

## Method B4 / Algorithm: Stochastic Frontier Analysis (One-Sided Markup Decomposition)

### Data / attributes
- Rent observations (even if biased)
- Strong feature set capturing market fundamentals

### Process and formulas
A standard frontier model:

```
log(Paid_Rent_Adj_i) = x_i^T β + v_i + u_i

v_i ~ Normal(0, σ_v^2)
 u_i ≥ 0  (markup / inefficiency)
```

Interpretation:
- `exp(xβ)` ≈ baseline rent (frontier)
- `u_i` captures non-negative markup above baseline

### Example (data-driven)
If the model estimates baseline `FMR_hat = $1,000` and observed adjusted rent is `$1,300`:

```
MarkupFactor = 1,300 / 1,000 = 1.30
u = log(1.30) = 0.262
```
You can treat 30% as a markup signal (subject to confidence and feature adequacy).

---

## Method B5 / Algorithm: Peer Group Benchmarking (Clustering + Within-Cluster Baselines)

### Data / attributes
- Feature vectors for sites (geo, network, zoning, structure)
- (Optional) rents, for within-cluster statistics

### Process and formulas
1) Cluster sites: `cluster(i) = kmeans(x_i)` (or hierarchical clustering).
2) Within each cluster, define a baseline such as median or P25:

```
Baseline(cluster c) = median( Rent_j : cluster(j)=c )
```
(or P25 for “lowest achievable”).

### Example (data-driven)
Cluster C rents: `[1500, 1600, 1550, 2400]`
- Median = 1575
- P25 ≈ 1525

If a site in cluster C pays 2400, it’s a strong outlier for negotiation focus.

---

## Method B6 / Algorithm: External Market Surface Anchoring + Premium Multiplier

### Data / attributes
- External base rates by geography (land/CRE proxies, tower lease surveys, comps)
- Site/network features to learn premium multiplier

### Process and formulas
Separate base market rate from site premium:

```
FMR(i,t) = BaseRate(zip(i),t) × Premium(i)
```

Where `BaseRate` can be built via spatial interpolation or hierarchical time series.

### Example (data-driven)
If:
- `BaseRate(zip,t) = $1,000/month`
- `Premium(i) = 1.20` due to high criticality + zoning friction

Then:

```
FMR = 1,000 × 1.20 = $1,200/month
```

---

## C. Renewal, relocation, and rent outcome modeling

## Method C1 / Algorithm: Renewal/Termination Timing Model (Survival / Hazard)

### Data / attributes
- Lease maturity timeline: start date, expiry date, options
- Renewal outcome labels (renewed / terminated / relocated) and event dates
- Covariates: criticality, redundancy, landlord leverage, zoning, substitute density

### Process and formulas
Cox proportional hazards model:

```
h(t | x) = h0(t) × exp(γ^T x)
```

Survival function:

```
S(t|x) = exp( −∫_0^t h(u|x) du )
```

### Example (data-driven)
If two sites are identical except one has high criticality (x_high) and the model has `γ_criticality > 0`, then:

- high criticality → higher hazard of renewal (or lower hazard of exit, depending on how you define event)

You can compute relative risk:

```
RiskRatio = exp(γ^T(x_high − x_low))
```

---

## Method C2 / Algorithm: Renewal Outcome Model (Two-Stage: Event Type + Rent Change)

### Data / attributes
- Pre-renewal features + lease phase
- Event outcome: renew / relocate / terminate (classification)
- If renew: post-renew rent (regression target)

### Process and formulas
Stage 1 (multiclass choice):

```
P(Event=k | x) = softmax_k( W_k^T x )
```

Stage 2 (conditional rent uplift):

```
Δ_i = (Rent_post_i − Rent_pre_i) / Rent_pre_i
Δ_hat = f(x)
Rent_post_hat = Rent_pre × (1 + Δ_hat)
```

### Example (data-driven)
If the model predicts:
- `P(renew)=0.8, P(relocate)=0.15, P(terminate)=0.05`
- and conditional uplift `Δ_hat = −0.10` (10% reduction)

For `Rent_pre = $2,000`:

```
Rent_post_hat = 2,000 × (1 − 0.10) = $1,800
```

---

## Method C3 / Algorithm: 10-Year Annual Rent Forecast (Hybrid Deterministic + Learned Drift + Renewal Jumps)

### Data / attributes
- Contract engine outputs
- Market drift estimates (Section A5) or macro covariates
- Renewal timing and renewal uplift models

### Process and formulas
A hybrid annual forecast:

```
Rent_hat(i,t) = Contract_Rent(i,t)
              + MarketDrift_hat(zip(i),t)
              + Jump_hat(i,t)
```

Where `Jump_hat` is activated probabilistically near renewal dates:

```
Jump_hat(i,t) = 1[Renewal at t] × (Rent_post_hat(i,t) − Rent_pre_hat(i,t))
```

### Example (data-driven)
- Contract rent at Year 5: $2,100
- Market drift estimate: +$50
- Renewal expected at Year 6 with predicted reduction of $200

Then:
- Year 5 forecast: $2,150
- Year 6 forecast: $2,150 − 200 = $1,950

---

## D. Decision optimization (lowest achievable, risk-adjusted, NPV-driven)

## Method D1 / Algorithm: Action Optimization via Expected NPV

### Data / attributes
- Candidate actions per site:
  - renew at target rent (possibly multiple targets)
  - accept landlord ask
  - relocate (cost + lead time + new rent)
- Discount rate `d` (WACC)
- Risk models: dispute probability, relocation feasibility/lead time, service-impact proxies

### Process and formulas
Define an action `a` and annual cost `Cost(i,t,a)`.

Objective:

```
NPV(i,a) = Σ_{t=1..10} E[Cost(i,t,a)] / (1+d)^t + OneTimeCost(i,a)
Choose a* = argmin_a NPV(i,a)
```

### Example (data-driven)
Two actions for a site:

- **Renew**: pay $2,000/year for 10 years (ignore inflation for simplicity)
- **Relocate**: pay one-time $5,000 now, then $1,400/year for 10 years
- Discount rate `d = 10%`

NPV of renew:

```
NPV_renew = 2000 × Σ_{t=1..10} 1/(1.1)^t = 2000 × 6.145 = 12,290
```

NPV of relocate:

```
NPV_reloc = 5,000 + 1,400 × 6.145 = 5,000 + 8,603 = 13,603
```
Renew is cheaper in NPV here.

---

## Method D2 / Algorithm: Chance Constraints (Hard Risk Limits)

### Data / attributes
- Predicted probabilities:
  - `P(dispute | target)`
  - `P(forced relocation | target)`
  - `P(coverage impact > threshold | action)`

### Process and formulas
Optimize NPV subject to constraints, e.g.:

```
min_a NPV(i,a)
subject to P(dispute | a) ≤ β
           P(forced_reloc | a) ≤ α   (especially for Tier 1)
```

### Example (data-driven)
If target rent $1,600 yields `P(dispute)=0.25` and β=0.10, then $1,600 is infeasible; you must select a less aggressive target.

---

## Method D3 / Algorithm: CVaR / Tail-Risk Robust Optimization

### Data / attributes
- Distribution of total cost outcomes under action `a` (Monte Carlo using uncertainty in renewal outcomes, delays, disputes)

### Process and formulas
Define random total cost `Z(a)`.

VaR at level α:

```
VaR_α(Z) = smallest z such that P(Z ≤ z) ≥ α
```

CVaR (expected tail cost):

```
CVaR_α(Z) = E[ Z | Z ≥ VaR_α(Z) ]
```

Optimize:

```
min_a  E[Z(a)] + λ × CVaR_α(Z(a))
```

### Example (data-driven)
If Action A and Action B have similar expected cost, but Action B has rare outcomes with huge service-impact costs, CVaR will penalize B—especially for Tier 1 critical sites.

---

## Notes on how to choose among methods
- If contract terms and invoices are messy: prioritize **A1–A3** first.
- If you have strong external comps: **B1/B6** become high-credibility anchors.
- If you lack ground truth: **B3/B4/B5** provide “lowest-achievable” baselines using internal-only signals.
- For production decisions: you ultimately need **C + D** (renewal modeling + NPV optimization).
