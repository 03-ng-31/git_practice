# API Platform Implementation & Testing Plan

This plan covers the implementation of the telecom lease data platform with free API integrations only (Census, FCC, OpenCelliD, FEMA, USGS), comprehensive API testing, data analysis, and cross-sectional dataset creation.

---

## Phase 1: Project Setup & Core Infrastructure

### 1.1 Project Structure Creation
**Location:** `C:\Users\hp\Desktop\REI\telecom-lease-platform\`

```
telecom-lease-platform/
├── src/
│   ├── __init__.py
│   ├── api_clients/
│   │   ├── __init__.py
│   │   ├── base_client.py           # Base API client with rate limiting
│   │   ├── census_client.py         # US Census Bureau API
│   │   ├── fcc_client.py            # FCC ASR/ULS data parser
│   │   ├── opencellid_client.py     # OpenCelliD API
│   │   ├── fema_flood_client.py     # FEMA Flood API
│   │   └── usgs_client.py           # USGS Earthquake API
│   ├── models/
│   │   ├── __init__.py
│   │   ├── tower_site.py            # Tower site data model
│   │   └── enriched_features.py     # Feature data models
│   ├── utils/
│   │   ├── __init__.py
│   │   ├── rate_limiter.py          # Rate limiting utility
│   │   ├── cache_manager.py         # Caching utility
│   │   └── geocoding.py             # Geocoding helpers
│   └── pipeline/
│       ├── __init__.py
│       └── data_enrichment.py       # Main enrichment pipeline
├── tests/
│   ├── __init__.py
│   ├── test_census_client.py
│   ├── test_fcc_client.py
│   ├── test_opencellid_client.py
│   └── test_api_integration.py
├── notebooks/
│   ├── 01_api_testing.ipynb         # API testing & validation
│   ├── 02_data_analysis.ipynb       # Data structure analysis
│   └── 03_cross_sectional_demo.ipynb # Cross-sectional dataset demo
├── config/
│   ├── config.yaml                  # Configuration
│   └── api_keys.yaml.example        # API key template
├── data/
│   ├── raw/                         # Raw API responses
│   ├── processed/                   # Processed features
│   └── sample/                      # Sample tower sites
├── logs/
├── requirements.txt
├── setup.py
├── .env.example
├── .gitignore
└── README.md
```

### 1.2 Dependencies (Python 3.9+)
```txt
# Core
requests>=2.28.0
requests-cache>=0.9.0
python-dotenv>=0.20.0
pyyaml>=6.0

# Data Processing
pandas>=1.5.0
numpy>=1.23.0
geopandas>=0.12.0
shapely>=2.0.0

# Validation
pydantic>=1.10.0

# Rate Limiting & Retries
ratelimit>=2.2.1
tenacity>=8.1.0

# Logging
loguru>=0.6.0

# Testing
pytest>=7.2.0
pytest-cov>=4.0.0
responses>=0.22.0

# Jupyter
jupyter>=1.0.0
matplotlib>=3.6.0
seaborn>=0.12.0

# Census API wrapper
census>=0.8.19

# HTTP client
httpx>=0.23.0
```

---

## Phase 2: Core Implementation

### 2.1 Base API Client
**File:** `src/api_clients/base_client.py`

**Features:**
- Abstract base class for all API clients
- Built-in rate limiting
- Response caching (SQLite backend)
- Automatic retries with exponential backoff
- Request/response logging
- Error handling

**Key Components:**
```python
class BaseAPIClient(ABC):
    - __init__(base_url, rate_limit, cache_expire)
    - _make_request(method, endpoint, params, headers)
    - _handle_rate_limit()
    - _handle_errors(response)
    - _cache_response(key, data)
    - _get_cached(key)
```

### 2.2 Census API Client
**File:** `src/api_clients/census_client.py`

**Endpoints to Implement:**
1. ACS 5-Year Data (block group level)
2. Population Estimates
3. Geocoder (address to FIPS)

**Key Variables:**
- `B01003_001E` - Total Population
- `B19013_001E` - Median Household Income
- `B25001_001E` - Total Housing Units
- `B25002_003E` - Vacant Housing Units
- `B15003_022E` - Bachelor's Degree or Higher
- `B08303_001E` - Travel Time to Work

**Methods:**
```python
- get_acs_data(variables, geography, state, county, year)
- get_population_by_location(lat, lon, radius_km)
- get_demographics_by_fips(state, county, tract, block_group)
- geocode_address(address)
- geocode_coordinates(lat, lon)
```

### 2.3 FCC Data Client
**File:** `src/api_clients/fcc_client.py`

**Data Source:** FCC ASR Database (bulk download)
- URL: https://www.fcc.gov/uls/transactions/daily-weekly
- Format: Pipe-delimited text files

**Implementation:**
1. Download weekly ASR data
2. Parse into structured format
3. Load into SQLite database
4. Query by location/radius

**Methods:**
```python
- download_asr_data(output_dir)
- parse_asr_file(file_path)
- load_to_database(df, db_path)
- get_towers_in_radius(lat, lon, radius_km)
- get_tower_by_asrn(registration_number)
- count_towers_nearby(lat, lon, radius_km)
```

### 2.4 OpenCelliD Client
**File:** `src/api_clients/opencellid_client.py`

**API Endpoint:** `https://opencellid.org/cell/get`

**Methods:**
```python
- get_cell_position(mcc, mnc, lac, cellid)
- get_cells_in_area(lat, lon, radius)
- count_towers_in_radius(lat, lon, radius_km)
- get_carrier_towers(lat, lon, carrier_mcc_mnc)
```

### 2.5 FEMA Flood Client
**File:** `src/api_clients/fema_flood_client.py`

**API Options:**
1. FEMA GIS Services (free, limited)
2. National Flood Data API (commercial, better)

**For MVP: Use FEMA free GIS service**

**Methods:**
```python
- get_flood_zone(lat, lon)
- get_flood_risk_score(lat, lon)
- batch_flood_lookup(locations)
```

### 2.6 USGS Earthquake Client
**File:** `src/api_clients/usgs_client.py`

**API Endpoint:** `https://earthquake.usgs.gov/fdsnws/event/1/query`

**Methods:**
```python
- get_earthquakes_in_area(lat, lon, radius_km, start_date, min_magnitude)
- get_seismic_hazard_score(lat, lon)
- count_significant_earthquakes(lat, lon, radius_km, years)
```

---

## Phase 3: API Testing & Validation

### 3.1 Individual API Tests
**Notebook:** `notebooks/01_api_testing.ipynb`

**Test Cases:**

#### Census API Test
```python
# Test 1: Get population for a specific location
lat, lon = 37.7749, -122.4194  # San Francisco
result = census_client.get_population_by_location(lat, lon, radius_km=3)

# Expected output:
{
    'total_population': 123456,
    'median_income': 87654,
    'housing_units': 45678,
    'fips_code': '06075012345'
}

# Test 2: Get ACS data for multiple variables
variables = ['B01003_001E', 'B19013_001E', 'B25001_001E']
df = census_client.get_acs_data(
    variables=variables,
    geography='tract',
    state='06',
    county='075'
)

# Validate:
- Check DataFrame shape
- Verify all variables present
- Check for missing values
- Validate data types
```

#### FCC Data Test
```python
# Test 1: Download and parse ASR data
fcc_client.download_asr_data('data/raw/fcc/')
df = fcc_client.parse_asr_file('data/raw/fcc/asr_data.dat')

# Test 2: Query towers in radius
towers = fcc_client.get_towers_in_radius(
    lat=37.7749,
    lon=-122.4194,
    radius_km=5
)

# Expected output:
[
    {
        'asrn': '1234567',
        'latitude': 37.7800,
        'longitude': -122.4100,
        'height_feet': 150,
        'structure_type': 'GUYED',
        'owner': 'AMERICAN TOWER',
        'construction_date': '2010-05-15'
    },
    ...
]

# Validate:
- Check tower count > 0
- Verify all towers within radius
- Check data completeness
```

#### OpenCelliD Test
```python
# Test 1: Get cell towers in area
cells = opencellid_client.get_cells_in_area(
    lat=37.7749,
    lon=-122.4194,
    radius=5000  # meters
)

# Test 2: Count towers
count = opencellid_client.count_towers_in_radius(
    lat=37.7749,
    lon=-122.4194,
    radius_km=3
)

# Validate:
- Check API response format
- Verify coordinates within radius
- Check for duplicate towers
```

#### FEMA Flood Test
```python
# Test 1: Get flood zone
flood_data = fema_client.get_flood_zone(
    lat=37.7749,
    lon=-122.4194
)

# Expected output:
{
    'flood_zone': 'X',  # Minimal flood hazard
    'fema_panel': '06075C1234F',
    'effective_date': '2015-03-15'
}

# Validate:
- Check flood zone classification
- Verify valid zone codes (A, AE, X, etc.)
```

#### USGS Earthquake Test
```python
# Test 1: Get earthquakes in last 10 years
earthquakes = usgs_client.get_earthquakes_in_area(
    lat=37.7749,
    lon=-122.4194,
    radius_km=50,
    start_date='2015-01-01',
    min_magnitude=3.0
)

# Test 2: Calculate seismic hazard score
score = usgs_client.get_seismic_hazard_score(lat=37.7749, lon=-122.4194)

# Validate:
- Check earthquake count
- Verify magnitude values
- Check date ranges
```

### 3.2 Integration Test
**Notebook:** `notebooks/02_data_analysis.ipynb`

**Test Scenario:** Enrich a sample tower site with all data sources

```python
# Sample tower site
sample_site = {
    'site_id': 'TOWER_001',
    'latitude': 37.7749,
    'longitude': -122.4194,
    'address': '123 Market St, San Francisco, CA',
    'current_rent': 2500,
    'lease_start_date': '2010-01-01'
}

# Enrich with all data sources
enriched = pipeline.enrich_site(sample_site)

# Expected output structure:
{
    # Original site data
    'site_id': 'TOWER_001',
    'latitude': 37.7749,
    'longitude': -122.4194,
    
    # Demographic features (Census)
    'population_3km': 45678,
    'median_income_3km': 87654,
    'housing_units_3km': 23456,
    'population_density': 15234.5,
    
    # Competitor density (FCC + OpenCelliD)
    'fcc_towers_5km': 12,
    'opencellid_towers_3km': 8,
    'tower_density_5km': 0.38,  # towers per sq km
    
    # Hazard data
    'flood_zone': 'X',
    'earthquake_count_10yr': 5,
    'seismic_hazard_score': 0.65,
    
    # Geospatial
    'fips_code': '06075012345',
    'census_tract': '012345',
    'urban_rural_code': 'urban'
}
```

---

## Phase 4: Data Analysis & Cross-Sectional Dataset Creation

### 4.1 Data Structure Analysis
**Notebook:** `notebooks/02_data_analysis.ipynb`

**Analysis Tasks:**

1. **Data Completeness Check**
   - % of sites with complete demographic data
   - % of sites with tower density data
   - Missing value patterns

2. **Data Distribution Analysis**
   - Population distribution across sites
   - Income distribution
   - Tower density distribution
   - Rent distribution

3. **Correlation Analysis**
   - Correlation between features
   - Identify multicollinearity
   - Feature importance ranking

4. **Geospatial Patterns**
   - Map sites by rent level
   - Overlay demographic data
   - Identify geographic clusters

### 4.2 Cross-Sectional Dataset Creation
**Notebook:** `notebooks/03_cross_sectional_demo.ipynb`

**Objective:** Create a panel dataset structure for modeling

**Dataset Structure:**
```
site_id | year | month | rent | population_3km | median_income | tower_density | flood_zone | ...
--------|------|-------|------|----------------|---------------|---------------|------------|----
SITE001 | 2024 |   1   | 2500 |    45678       |    87654      |     0.38      |     X      | ...
SITE001 | 2024 |   2   | 2500 |    45678       |    87654      |     0.38      |     X      | ...
SITE002 | 2024 |   1   | 3200 |    67890       |    95432      |     0.52      |     AE     | ...
```

**Key Features:**

1. **Time-Invariant Features** (site characteristics)
   - Latitude, longitude
   - Structure type
   - Initial construction date
   - Flood zone (mostly static)

2. **Slowly-Changing Features** (updated annually)
   - Population (Census estimates)
   - Median income
   - Housing units
   - Tower density

3. **Time-Varying Features** (updated monthly/quarterly)
   - Current rent
   - Number of tenants
   - Technology deployed (4G/5G)

4. **Derived Features**
   - Rent per capita
   - Rent as % of median income
   - Tower saturation index
   - Market competitiveness score

### 4.3 Feature Engineering Examples

```python
# 1. Population Density
df['population_density'] = df['population_3km'] / (np.pi * 3**2)

# 2. Tower Saturation Index
df['tower_saturation'] = df['tower_density_5km'] / df['population_density']

# 3. Income-Adjusted Rent
df['rent_income_ratio'] = df['rent'] / df['median_income_3km']

# 4. Competitive Pressure Score
df['competition_score'] = (
    df['tower_density_5km'] * 0.4 +
    df['opencellid_towers_3km'] * 0.3 +
    df['fcc_towers_5km'] * 0.3
)

# 5. Risk Score (composite)
df['risk_score'] = (
    (df['flood_zone'] == 'AE').astype(int) * 0.5 +
    (df['seismic_hazard_score'] > 0.7).astype(int) * 0.5
)

# 6. Market Opportunity Score
df['market_opportunity'] = (
    df['population_3km'] / 10000 * 0.3 +
    df['median_income_3km'] / 100000 * 0.3 +
    (1 / (df['tower_density_5km'] + 0.1)) * 0.4
)
```

### 4.4 Sample Output Analysis

**Summary Statistics:**
```python
enriched_df.describe()

#              rent  population_3km  median_income  tower_density_5km
# count     1000.00        1000.00       1000.00            1000.00
# mean      2847.50       52341.23      78456.89               0.42
# std        892.34       23456.78      21234.56               0.18
# min       1200.00       12345.00      35678.00               0.05
# 25%       2100.00       34567.00      62345.00               0.28
# 50%       2650.00       48901.00      75432.00               0.39
# 75%       3400.00       67890.00      91234.00               0.53
# max       5800.00      123456.00     145678.00               0.95
```

**Correlation Matrix:**
```python
correlation_matrix = enriched_df[[
    'rent', 'population_3km', 'median_income', 
    'tower_density_5km', 'housing_units_3km'
]].corr()

# Expected insights:
# - Rent positively correlated with population (0.45-0.65)
# - Rent positively correlated with income (0.55-0.75)
# - Rent negatively correlated with tower density (-0.30 to -0.50)
```

---

## Phase 5: Documentation & Deliverables

### 5.1 README.md
- Project overview
- Installation instructions
- API key setup guide
- Quick start examples
- Architecture diagram

### 5.2 API Documentation
- Each client's methods
- Parameter descriptions
- Return value formats
- Error handling
- Rate limits

### 5.3 Jupyter Notebooks
1. **01_api_testing.ipynb** - Test each API individually
2. **02_data_analysis.ipynb** - Analyze enriched data structure
3. **03_cross_sectional_demo.ipynb** - Build cross-sectional dataset

### 5.4 Sample Outputs
- `data/sample/sample_tower_sites.csv` - 10 sample sites
- `data/processed/enriched_sites.csv` - Enriched sample data
- `data/processed/cross_sectional_dataset.csv` - Panel dataset

---

## Implementation Timeline

| Day | Tasks | Deliverables |
|-----|-------|--------------|
| 1 | Project setup, dependencies, base client | Working base infrastructure |
| 2 | Census API client + tests | Census integration working |
| 3 | FCC data parser + OpenCelliD client | Tower density data working |
| 4 | FEMA + USGS clients | Hazard data working |
| 5 | Integration pipeline + testing notebook | Full enrichment pipeline |
| 6 | Data analysis + cross-sectional demo | Analysis notebooks complete |
| 7 | Documentation + cleanup | Production-ready codebase |

---

## Success Criteria

✅ All API clients successfully retrieve data  
✅ Rate limiting prevents API quota exhaustion  
✅ Caching reduces redundant API calls by >80%  
✅ Sample sites enriched with all external data  
✅ Cross-sectional dataset created with >50 features  
✅ Correlation analysis identifies key rent drivers  
✅ Notebooks demonstrate end-to-end workflow  
✅ Code passes all unit tests  
✅ Documentation complete and clear  

---

## Next Steps After Plan Approval

1. Create project directory structure
2. Set up virtual environment (Python 3.9+)
3. Install dependencies
4. Implement base API client
5. Register for API keys (Census, OpenCelliD)
6. Implement Census client first (highest value)
7. Test with real API calls
8. Iterate through remaining clients
9. Build enrichment pipeline
10. Create analysis notebooks

**Estimated Time:** 5-7 days for full implementation and testing
