# Additional Hazards & Zoning Restrictions Implementation Plan

This plan covers implementing additional hazard data sources (wildfires, hurricanes, tornadoes, storm surge) and zoning/regulatory restrictions for cell tower siting.

---

## 1. Additional Hazard Data Sources

### 1.1 Wildfire Risk Data

**Primary Source: USGS Wildfire Hazard Potential (WHP)**
- **URL:** https://www.usgs.gov/tools/usgs-wildfire-hazard-and-risk-assessment-clearinghouse
- **Data Type:** Raster/GIS layers
- **API:** ArcGIS REST API via USGS
- **Cost:** Free
- **Coverage:** Continental US

**Alternative: NIFC (National Interagency Fire Center)**
- **URL:** https://data-nifc.opendata.arcgis.com/
- **Data Type:** Active fires, historic fire perimeters
- **API:** ArcGIS REST API
- **Cost:** Free
- **Features:**
  - Active wildfire locations
  - Historic fire perimeters (1878-present)
  - Fire danger ratings
  - Wildfire potential index

**Implementation Approach:**
```python
class WildfireRiskClient(BaseAPIClient):
    """Client for wildfire hazard data"""
    
    # NIFC ArcGIS REST API
    BASE_URL = "https://services3.arcgis.com/T4QMspbfLg3qTGWY/arcgis/rest/services"
    
    def get_wildfire_risk(self, lat, lon) -> Dict:
        """Get wildfire risk score for location"""
        # Query NIFC wildfire potential index
        # Returns: risk_score (0-1), fire_danger_rating, historic_fire_count
    
    def get_historic_fires(self, lat, lon, radius_km, years) -> List[Dict]:
        """Get historic fires in area"""
        # Query fire perimeter database
    
    def get_enrichment_features(self, lat, lon) -> Dict:
        """Return wildfire features for enrichment"""
        return {
            'wildfire_risk_score': float,
            'wildfire_danger_rating': str,
            'historic_fires_10yr': int,
            'distance_to_nearest_fire': float,
            'fire_season_months': str
        }
```

**Data Fields:**
- `wildfire_risk_score` (0-1): Composite risk based on vegetation, climate, topography
- `wildfire_danger_rating`: Low, Moderate, High, Very High, Extreme
- `historic_fires_10yr`: Count of fires within radius in last 10 years
- `distance_to_nearest_historic_fire`: Distance in km
- `fire_season_length`: Number of months with elevated risk

---

### 1.2 Hurricane/Tropical Storm Data

**Primary Source: NOAA National Hurricane Center (NHC)**
- **URL:** https://www.nhc.noaa.gov/gis/
- **Data Type:** GIS shapefiles, KML, JSON
- **API:** NOAA GIS REST Services
- **Cost:** Free
- **Coverage:** Atlantic, Gulf of Mexico, Eastern Pacific

**Data Available:**
- Historical hurricane tracks (1851-present)
- Storm surge inundation maps
- Hurricane probability zones
- Wind speed probability

**Implementation Approach:**
```python
class HurricaneRiskClient(BaseAPIClient):
    """Client for hurricane/tropical storm data"""
    
    BASE_URL = "https://mapservices.weather.noaa.gov/tropical/rest/services"
    
    def get_hurricane_risk(self, lat, lon) -> Dict:
        """Get hurricane risk for location"""
        # Query historical hurricane database
        # Calculate risk based on frequency and intensity
    
    def get_historic_hurricanes(self, lat, lon, radius_km, years) -> List[Dict]:
        """Get historic hurricanes that passed within radius"""
        # Query NOAA IBTrACS database
    
    def get_storm_surge_risk(self, lat, lon) -> Dict:
        """Get storm surge inundation risk"""
        # Query NOAA storm surge maps
    
    def get_enrichment_features(self, lat, lon) -> Dict:
        return {
            'hurricane_risk_score': float,
            'hurricane_count_50yr': int,
            'max_hurricane_category': int,
            'storm_surge_risk_score': float,
            'hurricane_wind_zone': str
        }
```

**Data Fields:**
- `hurricane_risk_score` (0-1): Based on frequency and intensity
- `hurricane_count_50yr`: Number of hurricanes within 100km in 50 years
- `max_hurricane_category`: Highest Saffir-Simpson category observed
- `storm_surge_risk_score` (0-1): Coastal flooding risk
- `hurricane_wind_zone`: ASCE 7 wind zone designation
- `distance_to_coast`: Distance to coastline (km)

---

### 1.3 Tornado Risk Data

**Primary Source: NOAA Storm Prediction Center (SPC)**
- **URL:** https://www.spc.noaa.gov/wcm/
- **Data Type:** Historical tornado database
- **API:** No direct API, but data downloadable
- **Cost:** Free
- **Coverage:** US

**Alternative: NOAA Storm Events Database**
- **URL:** https://www.ncdc.noaa.gov/stormevents/
- **API:** NOAA NCEI API
- **Cost:** Free

**Implementation Approach:**
```python
class TornadoRiskClient(BaseAPIClient):
    """Client for tornado risk data"""
    
    def get_tornado_risk(self, lat, lon) -> Dict:
        """Calculate tornado risk based on historic data"""
        # Query NOAA storm events database
        # Calculate risk based on frequency and EF rating
    
    def get_historic_tornadoes(self, lat, lon, radius_km, years) -> List[Dict]:
        """Get historic tornadoes in area"""
    
    def get_enrichment_features(self, lat, lon) -> Dict:
        return {
            'tornado_risk_score': float,
            'tornado_count_30yr': int,
            'max_tornado_ef_rating': int,
            'tornado_alley_indicator': bool,
            'avg_tornadoes_per_year': float
        }
```

**Data Fields:**
- `tornado_risk_score` (0-1): Based on frequency and intensity
- `tornado_count_30yr`: Number of tornadoes within 50km in 30 years
- `max_tornado_ef_rating`: Highest Enhanced Fujita scale rating (0-5)
- `tornado_alley_indicator`: Boolean if in high-risk "Tornado Alley"
- `avg_tornadoes_per_year`: Average annual tornado count

---

### 1.4 Additional Flooding Data (Beyond FEMA)

**Source: NOAA Coastal Flooding**
- Sea level rise projections
- Storm surge models
- Coastal flood frequency

**Source: USGS StreamStats**
- Riverine flood risk
- 100-year flood plains
- Stream flow data

**Implementation:**
- Enhance existing FEMA client with additional flood types
- Add coastal vs riverine flood differentiation
- Include sea level rise projections for coastal sites

---

## 2. Zoning & Regulatory Restrictions

### 2.1 Wharton Residential Land Use Regulatory Index (WRLURI)

**Source:** Wharton Real Estate Center
- **URL:** https://realestate.wharton.upenn.edu/
- **Data Type:** Static dataset (CSV/Excel)
- **API:** No API - manual download
- **Cost:** Free (academic research data)
- **Coverage:** 2,500+ US jurisdictions

**Data Available:**
- Overall regulatory restrictiveness index (-2 to +2 scale)
- 11 subindices:
  1. Local Political Pressure
  2. State Political Involvement
  3. State Court Involvement
  4. Local Zoning Approval
  5. Local Project Approval
  6. Local Assembly
  7. Supply Restrictions
  8. Density Restrictions
  9. Open Space Requirements
  10. Exactions
  11. Approval Delay Time

**Implementation Approach:**
```python
class ZoningRestrictivenessLoader:
    """Loader for Wharton WRLURI data"""
    
    def __init__(self, data_file_path: str):
        """Load WRLURI dataset"""
        self.wrluri_data = pd.read_csv(data_file_path)
    
    def get_restrictiveness_by_fips(self, county_fips: str) -> Dict:
        """Get zoning restrictiveness for county"""
        return {
            'wrluri_overall_index': float,
            'wrluri_density_restrictions': float,
            'wrluri_approval_delay_months': float,
            'wrluri_supply_restrictions': float
        }
    
    def get_restrictiveness_by_location(self, lat: float, lon: float) -> Dict:
        """Get restrictiveness by geocoding to county"""
        # Geocode to county FIPS, then lookup
```

**Data Fields:**
- `wrluri_overall_index`: Overall restrictiveness (-2 to +2, higher = more restrictive)
- `wrluri_density_restrictions`: Density control index
- `wrluri_approval_delay_months`: Average approval time
- `wrluri_supply_restrictions`: Supply constraint index
- `wrluri_open_space_requirements`: Open space mandate index

---

### 2.2 FCC Tower Construction Notification System (TCNS)

**Source:** FCC
- **URL:** https://www.fcc.gov/wireless/bureau-divisions/competition-infrastructure-policy-division/tower-and-antenna-siting
- **Data Type:** Regulatory database
- **API:** No public API
- **Access:** Password-protected system

**Information Available:**
- Tribal notification requirements
- Historic preservation requirements
- Environmental review requirements
- FAA notification requirements

**Implementation:**
- Manual data collection from FCC resources
- Create lookup table for regulatory requirements by state/county
- Flag sites requiring special approvals

---

### 2.3 Local Zoning Ordinances (Cell Tower Specific)

**Challenge:** No centralized database exists

**Data Sources:**
1. **Municipal Code Corporation (Municode)**
   - Aggregates local ordinances
   - No API, web scraping required
   - Paid service for bulk access

2. **State-Level Databases**
   - Some states maintain tower siting databases
   - Varies by state

3. **Manual Collection**
   - Survey major metro areas
   - Create lookup table

**Implementation Approach:**
```python
class CellTowerZoningLoader:
    """Loader for cell tower zoning restrictions"""
    
    def __init__(self, zoning_database_path: str):
        """Load cell tower zoning database"""
        self.zoning_data = pd.read_csv(zoning_database_path)
    
    def get_zoning_restrictions(self, lat: float, lon: float) -> Dict:
        """Get cell tower zoning restrictions for location"""
        # Geocode to jurisdiction
        # Lookup restrictions
        return {
            'tower_height_limit_feet': int,
            'setback_requirement_feet': int,
            'residential_proximity_restriction': bool,
            'special_use_permit_required': bool,
            'aesthetic_requirements': str,
            'colocation_preference': bool
        }
```

**Data Fields to Collect:**
- `tower_height_limit_feet`: Maximum allowed height
- `setback_requirement_feet`: Distance from property line
- `residential_proximity_restriction`: Distance from residential areas
- `special_use_permit_required`: Boolean
- `aesthetic_requirements`: Stealth/camouflage requirements
- `colocation_preference`: Preference for shared towers
- `environmental_review_required`: NEPA/CEQA requirements
- `historic_district_restrictions`: Additional restrictions in historic areas

---

## 3. Implementation Priority

### Phase 1: High Priority (Implement First)
1. ✅ **Wildfire Risk Client** - NIFC API available, high impact
2. ✅ **Hurricane Risk Client** - NOAA API available, coastal areas
3. ✅ **Wharton WRLURI Loader** - Static data, easy to implement

### Phase 2: Medium Priority
4. **Tornado Risk Client** - NOAA data available
5. **Enhanced Flood Data** - Extend FEMA client
6. **Cell Tower Zoning Database** - Manual collection required

### Phase 3: Low Priority (Future Enhancement)
7. Storm surge detailed modeling
8. Sea level rise projections
9. Comprehensive local ordinance database

---

## 4. Data Schema Extensions

### Extended Hazard Features (Add 20+ features)

**Wildfire (5 features):**
- `wildfire_risk_score`
- `wildfire_danger_rating`
- `historic_fires_10yr`
- `distance_to_nearest_fire`
- `fire_season_length_months`

**Hurricane (6 features):**
- `hurricane_risk_score`
- `hurricane_count_50yr`
- `max_hurricane_category`
- `storm_surge_risk_score`
- `hurricane_wind_zone`
- `distance_to_coast_km`

**Tornado (5 features):**
- `tornado_risk_score`
- `tornado_count_30yr`
- `max_tornado_ef_rating`
- `tornado_alley_indicator`
- `avg_tornadoes_per_year`

**Zoning/Regulatory (8 features):**
- `wrluri_overall_index`
- `wrluri_density_restrictions`
- `wrluri_approval_delay_months`
- `tower_height_limit_feet`
- `setback_requirement_feet`
- `special_use_permit_required`
- `colocation_preference`
- `environmental_review_required`

**Total New Features: ~24**
**Grand Total Features: 95+**

---

## 5. Composite Risk Scores

### Multi-Hazard Risk Score
Combine all hazard sources into single composite:

```python
def calculate_composite_hazard_score(features: Dict) -> float:
    """Calculate overall hazard risk score"""
    hazards = [
        features.get('fema_flood_risk_score', 0) * 0.20,
        features.get('usgs_seismic_hazard_score', 0) * 0.20,
        features.get('wildfire_risk_score', 0) * 0.15,
        features.get('hurricane_risk_score', 0) * 0.25,
        features.get('tornado_risk_score', 0) * 0.20
    ]
    return sum(hazards)
```

### Regulatory Complexity Score
Combine zoning restrictions:

```python
def calculate_regulatory_complexity_score(features: Dict) -> float:
    """Calculate regulatory burden score"""
    components = [
        features.get('wrluri_overall_index', 0) / 4,  # Normalize to 0-1
        1 if features.get('special_use_permit_required') else 0,
        1 if features.get('environmental_review_required') else 0,
        features.get('wrluri_approval_delay_months', 0) / 24  # Normalize
    ]
    return sum(components) / len(components)
```

---

## 6. Implementation Code Examples

### Wildfire Risk Client

```python
class WildfireRiskClient(BaseAPIClient):
    """Client for wildfire hazard data from NIFC"""
    
    BASE_URL = "https://services3.arcgis.com/T4QMspbfLg3qTGWY/arcgis/rest/services"
    
    def __init__(self):
        super().__init__(
            base_url=self.BASE_URL,
            rate_limit_calls=100,
            rate_limit_period=60,
            cache_enabled=True
        )
    
    def get_wildfire_risk(self, lat: float, lon: float) -> Dict:
        """Get wildfire risk for location"""
        # Query NIFC Wildfire Potential Index layer
        endpoint = "/Wildfire_Hazard_Potential/FeatureServer/0/query"
        
        params = {
            'geometry': f'{lon},{lat}',
            'geometryType': 'esriGeometryPoint',
            'spatialRel': 'esriSpatialRelIntersects',
            'outFields': '*',
            'returnGeometry': 'false',
            'f': 'json'
        }
        
        response = self._make_request('GET', endpoint, params=params)
        data = response.json()
        
        # Parse wildfire potential
        if data.get('features'):
            attrs = data['features'][0]['attributes']
            return {
                'wildfire_potential': attrs.get('WHP_Rating'),
                'wildfire_risk_score': self._convert_to_risk_score(attrs.get('WHP_Rating')),
                'vegetation_type': attrs.get('VEG_TYPE')
            }
        
        return {'wildfire_risk_score': 0.0}
    
    def _convert_to_risk_score(self, rating: str) -> float:
        """Convert WHP rating to 0-1 score"""
        rating_map = {
            'Very Low': 0.1,
            'Low': 0.3,
            'Moderate': 0.5,
            'High': 0.7,
            'Very High': 0.9
        }
        return rating_map.get(rating, 0.0)
```

### Hurricane Risk Client

```python
class HurricaneRiskClient(BaseAPIClient):
    """Client for hurricane/tropical storm data from NOAA"""
    
    BASE_URL = "https://mapservices.weather.noaa.gov/tropical/rest/services"
    
    def get_hurricane_risk(self, lat: float, lon: float) -> Dict:
        """Calculate hurricane risk based on historical data"""
        # Query NOAA historical hurricane tracks
        hurricanes = self._get_historic_hurricanes(lat, lon, radius_km=100, years=50)
        
        if not hurricanes:
            return {'hurricane_risk_score': 0.0}
        
        # Calculate risk based on frequency and intensity
        count = len(hurricanes)
        max_category = max([h['category'] for h in hurricanes if h['category']])
        
        # Risk formula
        frequency_score = min(count / 10, 0.5)  # 10+ hurricanes = max 0.5
        intensity_score = (max_category / 5) * 0.5  # Category 5 = max 0.5
        
        return {
            'hurricane_risk_score': frequency_score + intensity_score,
            'hurricane_count_50yr': count,
            'max_hurricane_category': max_category
        }
```

---

## 7. Testing Strategy

### Test Locations for New Hazards

**Wildfire Risk:**
- California (High): 34.0522, -118.2437 (Los Angeles)
- Colorado (Moderate): 39.7392, -104.9903 (Denver)
- Florida (Low): 25.7617, -80.1918 (Miami)

**Hurricane Risk:**
- Florida (Very High): 25.7617, -80.1918 (Miami)
- Louisiana (High): 29.9511, -90.0715 (New Orleans)
- Texas (Moderate): 29.7604, -95.3698 (Houston)
- California (Low): 37.7749, -122.4194 (San Francisco)

**Tornado Risk:**
- Oklahoma (Very High): 35.4676, -97.5164 (Oklahoma City)
- Kansas (High): 39.0997, -94.5786 (Kansas City)
- Texas (Moderate): 32.7767, -96.7970 (Dallas)
- California (Low): 37.7749, -122.4194 (San Francisco)

---

## 8. Timeline

| Week | Task | Deliverable |
|------|------|-------------|
| 1 | Implement Wildfire Risk Client | Working wildfire API integration |
| 2 | Implement Hurricane Risk Client | Hurricane risk scoring |
| 3 | Implement Tornado Risk Client | Tornado risk scoring |
| 4 | Implement Wharton WRLURI Loader | Zoning restrictiveness data |
| 5 | Create cell tower zoning database | Manual data collection |
| 6 | Update enrichment pipeline | All hazards integrated |
| 7 | Testing & validation | Comprehensive testing |
| 8 | Documentation | Updated docs and notebooks |

---

## 9. Cost Summary

### Free Data Sources
- ✅ NIFC Wildfire Data: Free
- ✅ NOAA Hurricane Data: Free
- ✅ NOAA Tornado Data: Free
- ✅ Wharton WRLURI: Free (academic)
- ✅ FCC Tower Data: Free

**Total Cost: $0**

### Optional Commercial Sources
- Municode (local ordinances): $5K-$10K/year
- Zoning data aggregators: $10K-$20K/year

---

## 10. Success Criteria

✅ Wildfire risk client retrieves risk scores for any US location  
✅ Hurricane risk client calculates coastal storm risk  
✅ Tornado risk client provides tornado frequency data  
✅ Wharton WRLURI data integrated for zoning restrictiveness  
✅ Cell tower zoning database covers top 50 metro areas  
✅ Composite hazard score combines all risk factors  
✅ Regulatory complexity score quantifies approval difficulty  
✅ All new features integrated into enrichment pipeline  
✅ Testing notebook demonstrates all new capabilities  
✅ Documentation updated with examples  

---

## 11. Next Steps After Plan Approval

1. Download Wharton WRLURI dataset
2. Implement Wildfire Risk Client (NIFC API)
3. Implement Hurricane Risk Client (NOAA API)
4. Implement Tornado Risk Client (NOAA API)
5. Create cell tower zoning database (manual collection)
6. Update enrichment pipeline with new clients
7. Create testing notebook
8. Update documentation

**Estimated Total Implementation Time: 6-8 weeks**
**New Features Added: 24+**
**Total Platform Features: 95+**
