# Telecom Lease Platform — Summary (Problem, Data, Features, Modeling)

This document summarizes the problem statement, data attributes/sources, feature engineering, and modeling approaches discussed and implemented across `telecom-lease-platform` and the `rent-decomposition-poc`.

---

## 1) Problem statement (what we are solving)

### Business objective
- **Optimize telecom lease rent outcomes** by estimating the **lowest achievable, risk-adjusted optimal rent** given a site’s market, competitive environment, hazards, and network criticality.

### Decision outputs (what the models should drive)
- **Negotiation target recommendations** (what “fair rent” should be, plus defensible bounds).
- **Budget / cashflow forecasting** for total occupancy cost.
- **Relocate-vs-renew** decisions.

### Optimization objective
- **Minimize NPV of total occupancy cost** (rent + escalation + adders + operational impacts), typically on a **10-year annual horizon**.

### Analytics strategy
- Build a **cross-sectional enriched site dataset** (one row per site per time snapshot, or per-year panel).
- Use **rent decomposition** to separate observed rent into interpretable components (contract/market/premium/noise) and a **predictive “fair rent” model** for negotiation.
- Segment at **ZIP** and roll up hierarchically **ZIP → city/county → MSA/market → state → national**.

### Refined objective (risk-adjusted, multivariate, decision-driven)

At a minimum, this is a **multivariate prediction problem** (what rent should be, given many drivers). At full maturity, it becomes a **prescriptive optimization problem** (what action + target should we choose to minimize risk-adjusted NPV, subject to constraints).

**Core observable:**
- `Rent_{i,t}` = rent paid (or total occupancy cost) for site `i` at time `t`.

**Multivariate drivers (feature groups):**
- **Contract / legal** (`K_i`): escalators, renewal options, term remaining, rent structure, adders.
- **Market** (`M_{g,t}`): macro + local real estate/telecom market conditions for geography segment `g`.
- **Competition / supply** (`C_{i,t}`): nearby tower/cell density, carrier overlap, colocation intensity.
- **Hazards / resiliency** (`H_i`): flood/seismic/wildfire/hurricane/tornado risk; composite hazard score.
- **Regulatory friction (planned)** (`R_g`): zoning restrictiveness (WRLURI proxy) and siting constraints.
- **Network criticality** (`N_{i,t}`): traffic, redundancy, outage impact proxy (internal).

**Decomposition view (interpretable components):**
- A practical production form is log-additive:
  - `log(Rent_{i,t}) = Base_i + Escalation(K_i,t) + Market(g,t) + Premium(X_{i,t}) + Noise_{i,t}`
  - where `X_{i,t}` is the combined multivariate feature vector from the groups above.

**Risk-adjusted optimization view (decision):**
- Choose a decision `d_i` (renew / amend / relocate) and negotiation target `r_i` to minimize:
  - `min_{d_i,r_i}  E[ Σ_{t=1..T} δ^t · Cost_{i,t}(d_i,r_i) ]  +  λ · RiskPenalty_i(H_i, N_{i,t}, R_g)`
- Subject to constraints such as:
  - coverage/service constraints (must maintain network performance)
  - contractual constraints (escalator floors, notice periods)
  - regulatory constraints (permitting feasibility)
  - negotiation feasibility constraints (e.g., acceptance probability above a threshold)

**“Lowest achievable” clarification:**
- “Fair rent” alone is not enough; you typically also need a **negotiation/acceptance model**.
- One useful framing is: pick `r_i` that minimizes *expected* NPV given a probability of acceptance:
  - `E[NPV] = P_accept(r_i|X)·NPV_if_accepted(r_i) + (1-P_accept)·NPV_if_not_accepted(d_i)`

### Data science framing (targets, dataset grain, validation)

**Target variable options (choose one per model family):**
- **Gross rent**: base rent + escalators (contractual) — simplest but can hide pass-throughs.
- **Net rent / rent-to-landlord**: excludes pass-throughs (preferred for “fair rent” if available).
- **Total occupancy cost (TOC)**: rent + adders + opex/pass-throughs — best for NPV optimization.

**Recommended transformations:**
- Model `y_{i,t} = log(TOC_{i,t})` (or `log(Rent_{i,t})`) to:
  - stabilize variance,
  - keep multiplicative decomposition additive,
  - make percent errors more meaningful.
- Add inflation normalization if mixing long histories: `real_y = y / CPI_t` (or include CPI as a feature).

**Dataset grain (how we build the modeling table):**
- **Cross-sectional snapshot:** 1 row per site at reference date `t0`.
  - Good for: “fair rent now”, negotiation targets.
- **Panel (recommended):** 1 row per site per period (month or year).
  - Good for: decomposition + forecasting + causal analysis.

**Canonical supervised learning setup:**
- Features `X_{i,t}` are the union of:
  - `K_i` (contract terms), `M_{g,t}` (market), `C_{i,t}` (competition), `H_i` (hazards), `R_g` (regulation), `N_{i,t}` (criticality).
- Fit `ŷ_{i,t} = f_θ(X_{i,t})` where `f_θ` could be linear/GBM/GAM.

**Uncertainty / bounds (critical for negotiation):**
- Quantile models: estimate `Q_τ(y|X)` for τ ∈ {0.25, 0.50, 0.75, 0.90}.
- Conformal intervals: calibrated prediction bands around any base model.

**Validation and leakage control (non-negotiable in this domain):**
- **Group leakage:** split by `site_id` (GroupKFold) to avoid learning site identity.
- **Time leakage:** out-of-time holdout (train on ≤T0, test on >T0) for forecasting.
- **Geographic leakage:** optional “leave-market-out” tests (hold out an MSA) to check generalization.
- Keep feature timestamps aligned (no future hazard events, no post-negotiation variables).

**Interpretable “premium” isolation:**
- If you want a defensible “overpayment / underpayment” metric, estimate a market baseline and define:
  - `PremiumResidual_{i,t} = y_{i,t} - ŷ_{i,t}` (or exp-space ratio).
- In panel form, use fixed/random effects to separate:
  - `site premium` vs `market` vs `time`.

### Multivariate, data-driven approaches considered

**A) Cross-sectional fair-rent estimation (many variables → rent distribution)**
- **Interpretable baselines:** OLS / ElasticNet with segmented effects.
- **Nonlinear ML:** Gradient Boosting (LightGBM/XGBoost), Random Forest.
- **Smooth effect models:** GAMs for monotonic/curved relationships.
- **Uncertainty + bounds:** quantile regression (P50/P75/P90), conformal prediction for calibrated intervals.

**B) Panel / hierarchical modeling (ZIP→MSA→state pooling)**
- Mixed effects / hierarchical Bayes to capture:
  - market-level trends (`Market(g,t)`) and
  - stable site-level premiums (`Base_i`), while borrowing strength across sparse geographies.

**C) Rent decomposition & forecasting (time series)**
- State-space / Kalman filter or structural time series to isolate:
  - contractual escalation vs market drift vs idiosyncratic site premium.
- Panel fixed effects to estimate persistent “premium” after controlling for observables.

**D) Causal / quasi-causal analysis (when we need “drivers”, not just prediction)**
- Difference-in-differences around contract events, policy/zoning changes, or hazard-related shocks.
- Causal forests / double ML for heterogeneous treatment effect estimates (e.g., regulatory friction impact).

**E) Prescriptive optimization & scenario analysis**
- NPV optimizer using forecast distributions + acceptance probability models.
- Scenario stress-tests for hazards (e.g., hurricane coastal risk) and regulatory delays.

### Success metrics (model + decision)

**Model performance:**
- Out-of-sample error: MAPE / RMSE on rent or log-rent.
- Calibration: prediction interval coverage (e.g., 90% PI contains truth ~90% of the time).

**Decision performance:**
- NPV savings vs baseline strategy.
- Negotiation “hit rate” (acceptance frequency at proposed targets).
- Forecast accuracy for budget planning over 1–10 years.
- Risk-adjusted outcomes (reduced hazard exposure / improved resiliency where relevant).

---

## 2) What has been built (current platform scope)

### Codebase: `telecom-lease-platform`
- **Goal:** Enrich tower sites (lat/lon) with free external data.
- **Core infrastructure:** `BaseAPIClient` with **rate limiting**, **caching**, and **retry/error handling**.
- **Clients implemented:**
  - `FCCClient` (local ASR SQLite)
  - `OpenCelliDClient` (API)
  - `CensusClient` (API)
  - `FEMAFloodClient` (API)
  - `USGSEarthquakeClient` (API)
  - `WildfireRiskClient` (heuristic placeholder)
  - `HurricaneRiskClient` (heuristic placeholder)
  - `TornadoRiskClient` (heuristic placeholder)
- **Pipeline:** `DataEnrichmentPipeline` produces a **single enriched feature dictionary / DataFrame per site**.

### Codebase: `rent-decomposition-poc`
- **Goal:** Prove rent decomposition concept with synthetic data.
- **POC formula:**
  - `Observed_Rent(t) = Base_Rent × Escalation_Factor(t) × Market_Factor(t) × Premium_Factor + Noise(t)`
- **Success metrics:** reconstruction accuracy and component separation accuracy.

---

## 3) Data attributes & sources (tabulated)

### 3.1 Required *internal* data (not implemented yet, but essential)

| Domain | Example attributes (non-exhaustive) | Typical grain | Notes / purpose |
|---|---|---:|---|
| **Site master** | `site_id`, `lat`, `lon`, address, ZIP/county/MSA, site type (macro/rooftop/DAS), tower height, ground lease vs rooftop | site | Key join keys to all enrichment |
| **Lease contract terms** | base rent, start/end dates, escalator type (fixed %, CPI), amendment history, renewal options, termination clauses, landlord type, colocation revenue share | contract / year | Feeds escalation factor + negotiation constraints |
| **Payment history** | monthly/annual rent paid, CAM/opex, pass-throughs, one-time fees | month/year | Target variable; also detects anomalies |
| **Network criticality** | traffic/load, coverage criticality, redundancy, backhaul, outage cost proxy | site / time | Drives “premium factor” and risk-adjusted objective |
| **Competitive / co-tenancy** | tenants on tower, nearby competitor carriers, spectrum holdings (if available) | site / time | Explains premium & negotiation leverage |

### 3.2 External data sources already integrated (free)

| Category | Source | Docs / API links | Access | Key needed | Spatial resolution | Example attributes produced | Status |
|---|---|---|---|---|---|---|---|
| **Demographics** | US Census ACS | [API guide](https://www.census.gov/data/developers/guidance/api-user-guide.html), [Key signup](https://api.census.gov/data/key_signup.html), [Geocoder](https://geocoding.geo.census.gov/geocoder/) | API | Yes | tract/block group (via geocoding) | population, median income, housing units, vacancy rate, density, etc. | Implemented (`CensusClient`) |
| **Competitor towers** | FCC ASR | [Daily/weekly downloads](https://www.fcc.gov/uls/transactions/daily-weekly) | local SQLite | No | point data | tower count, density; plus tower metadata from DB | Implemented (`FCCClient`) |
| **Cell sites** | OpenCelliD | [API docs](https://wiki.opencellid.org/wiki/API) | API | Yes | point data | tower count/density, carrier count, tech distribution | Implemented (`OpenCelliDClient`) |
| **Flood hazard** | FEMA NFHL | [NFHL services](https://hazards.fema.gov/gis/nfhl/services/), [MapServer](https://hazards.fema.gov/gis/nfhl/rest/services/public/NFHL/MapServer) | API (ArcGIS REST) | No | polygon/zone | flood zone, flood risk score, risk category, BFE, DFIRM info | Implemented (`FEMAFloodClient`) |
| **Earthquakes** | USGS FDSN event API | [FDSN Event API](https://earthquake.usgs.gov/fdsnws/event/1/) | API | No | events → aggregates | earthquake counts by magnitude, max/avg magnitude, per-year, hazard score/category | Implemented (`USGSEarthquakeClient`) |
| **Wildfire risk** | NIFC / USGS | [NIFC open data](https://data-nifc.opendata.arcgis.com/), [ArcGIS services](https://services3.arcgis.com/T4QMspbfLg3qTGWY/arcgis/rest/services), [USGS clearinghouse](https://www.usgs.gov/tools/usgs-wildfire-hazard-and-risk-assessment-clearinghouse) | (planned API) | No | raster/polygon | wildfire risk score, danger rating, seasonality | **Heuristic placeholder** (`WildfireRiskClient`) |
| **Hurricane risk** | NOAA NHC | [NHC GIS](https://www.nhc.noaa.gov/gis/), [NOAA tropical MapServer](https://mapservices.weather.noaa.gov/tropical/rest/services) | (planned API) | No | tracks/polygons | hurricane risk score, surge risk score, distance to coast, wind zone | **Heuristic placeholder** (`HurricaneRiskClient`) |
| **Tornado risk** | NOAA SPC / NCEI | [SPC WCM](https://www.spc.noaa.gov/wcm/), [Storm Events DB](https://www.ncdc.noaa.gov/stormevents/) | (planned API) | No | events/polygons | tornado risk score, frequency, max EF estimate | **Heuristic placeholder** (`TornadoRiskClient`) |

### 3.3 Planned zoning / restriction sources (not yet implemented)

| Category | Candidate source | Docs / links | Access | Coverage | What it gives | Notes |
|---|---|---|---|---|---|---|
| **Zoning restrictiveness (proxy)** | Wharton WRLURI | [Working paper](https://realestate.wharton.upenn.edu/working-papers/a-new-measure-of-the-local-regulatory-environment-for-housing-markets-the-wharton-residential-land-use-regulatory-index/), [PDF](https://realestate.wharton.upenn.edu/wp-content/uploads/2017/03/558.pdf) | Static dataset (CSV) | ~2,500 jurisdictions | regulatory index, approval delays, density/supply restrictions | Strong proxy for permitting friction; not tower-specific |
| **Tower siting regulatory flags** | FCC TCNS info + state rules | [TCNS overview](https://www.fcc.gov/wireless/systems-utilities/tower-construction-notifications/tower-construction-notifications-0), [Tower & antenna siting](https://www.fcc.gov/wireless/bureau-divisions/competition-infrastructure-policy-division/tower-and-antenna-siting) | docs/manual | US | tribal notification, historic preservation triggers, etc. | No public API; can build lookup tables |
| **Local cell-tower ordinances** | municipal codes (Municode, etc.) | [Municode](https://library.municode.com/) | mostly manual / paid bulk | varies | height limits, setbacks, stealth requirements, SUP requirements | Hardest dataset; build metro-first |

---

## 4) Feature engineering (how raw data becomes model-ready)

### 4.1 Core joining & normalization
- **Geocoding → FIPS**: map lat/lon to tract/county/state for Census joins.
- **Spatial radii**: compute counts/densities within set radii (e.g., 3km demographics; 5km towers; 50km earthquakes).
- **Categorical encoding**: flood zone category, seismic category, wind zone → ordinal or one-hot.

### 4.2 Derived features (already in pipeline)

| Feature family | Raw inputs | Transform | Output examples | Purpose |
|---|---|---|---|---|
| **Tower density** | FCC/OpenCelliD points | count / area | `fcc_tower_density`, `opencellid_tower_density` | competition / saturation |
| **Tower per capita** | `fcc_tower_count`, `census_population` | normalize | `tower_per_capita` | demand vs supply |
| **Hazard scoring** | FEMA/USGS (+ heuristic hazards) | scoring maps | `fema_flood_risk_score`, `usgs_seismic_hazard_score`, etc. | risk premium / insurance / hardening |
| **Composite hazard** | all hazard scores | weighted sum | `composite_hazard_score` | single risk index for modeling |
| **Market opportunity** | population + tower density | ratio | `market_opportunity_score` | growth / leverage proxy |

### 4.3 Rent decomposition features (POC → production)
- Transform multiplicative model into additive in log space:
  - `log Rent(t) = log Base + log Escalation(t) + log Market(t) + log Premium + noise`
- Contract terms → explicit `Escalation_Factor(t)`
- External features (market/hazards/competition) → drivers for `Market_Factor(t)` and `Premium_Factor`

---

## 5) Modeling approaches (tabulated)

### 5.1 Modeling tasks

| Task | Target/output | Data structure | Candidate methods | Notes |
|---|---|---|---|---|
| **Fair rent estimation (cross-sectional)** | expected fair rent or rent band | site snapshot (or year) | linear/elastic net, Gradient Boosting (XGBoost/LightGBM), Random Forest, GAMs | Fast MVP; interpretable with SHAP/coeffs |
| **Rent decomposition (time series)** | base, escalation, market, premium components | per-site time series | log-additive regression, Kalman/state-space, structural time series, RPCA | Directly aligns to POC; yields explainability |
| **Forecasting (10y)** | rent path + uncertainty | panel over time | state-space, hierarchical time series, ML + scenario drivers | Needed for NPV budgeting |
| **Negotiation bounds** | P50/P75/P90 fair rent | site snapshot/panel | quantile regression, conformal prediction | Gives “ask” + “walk-away” |
| **Relocate vs renew** | classification + expected NPV delta | site snapshot + constraints | logistic/GBM classifier + prescriptive NPV model | Uses forecast + capex relocation cost |
| **Efficiency / frontier** | “efficient rent frontier” & slack | cross-sectional | **Stochastic Frontier Analysis (SFA)** | Fits the “overpayment vs efficient” narrative |

### 5.2 Practical modeling roadmap
1. **MVP**: cross-sectional fair-rent model (GBM + explainability).
2. **Add decomposition**: state-space decomposition per site; premium factor explained by enriched features.
3. **Portfolio decisions**: NPV optimizer with renewal/relocate decision constraints.

---

## 6) Open questions (to finalize the next phase)

1. Should “fair rent” be modeled as **monthly** or **annual** rent (given escalators and accounting)?
2. What is the **primary target**: gross rent, net rent, or rent-per-capacity metric (e.g., rent per traffic / MHz-pop)?
3. What internal attributes are available today (contract terms, payment history, criticality)?
4. Should hazard scores affect rent via:
   - (a) direct premium/discount,
   - (b) outage risk (cost),
   - (c) insurance/hardening capex,
   - or all three?
