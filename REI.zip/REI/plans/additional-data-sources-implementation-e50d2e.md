# Additional Data Sources Implementation Plan

This plan covers implementing API clients for all remaining data sources identified for the telecom lease optimization project, including hazard layers, property value proxies, and creating a unified data enrichment pipeline.

---

## Data Requirements Analysis by Category

### 1. Land/CRE Value Proxies

**Data Needed:**
- Property assessed values
- Land values
- Tax assessment data
- Parcel boundaries
- Zoning classifications
- Sale history
- Construction cost indices

**Implementation Priority:**
- ⚠️ **Commercial APIs** (Regrid, ATTOM, CoreLogic) - Require paid subscriptions
- 🟢 **Free Alternative:** Use Census median home values as proxy
- 📊 **Construction Indices:** Manual data entry or CSV import (no APIs)

**Decision:** Start with Census data as baseline, add commercial APIs later if budget approved

---

### 2. Zoning & Hazard Layers

**Data Needed:**
- Flood zones (A, AE, X, etc.)
- Base flood elevations
- Earthquake hazard scores
- Historical earthquake data
- Wildfire risk zones
- Zoning restrictiveness indices

**Implementation Priority:**
- ✅ **FEMA Flood API** - Free GIS services available
- ✅ **USGS Earthquake API** - Free public API
- ✅ **Wharton WRLURI** - Static dataset download
- 🟡 **National Flood Data API** - Commercial but better quality

**Decision:** Implement free FEMA and USGS APIs immediately

---

### 3. Competitor/Tower Density

**Data Needed:**
- Tower locations (lat/lon)
- Tower heights
- Owner information
- Construction dates
- Cell tower counts by carrier
- Technology types (4G/5G)

**Implementation Status:**
- ✅ **FCC Client** - Already implemented
- ✅ **OpenCelliD Client** - Already implemented
- ⚠️ **No additional sources** with free APIs

**Decision:** Current implementation sufficient

---

### 4. Industry Benchmarks

**Data Needed:**
- Lease rate comparables
- Market rent ranges
- Tower lease terms
- Revenue share percentages

**Implementation Status:**
- ⚠️ **No free APIs available**
- 📊 **Manual data entry** from published reports
- 🟡 **CompStak API** - Expensive commercial option

**Decision:** Create manual data entry template, implement CompStak later if needed

---

## Implementation Plan

### Phase 1: FEMA Flood API Client

**File:** `src/api_clients/fema_flood_client.py`

**API Options:**
1. **FEMA GIS Services** (Free)
   - URL: `https://hazards.fema.gov/gis/nfhl/services/`
   - Format: ArcGIS REST API
   - Data: Flood zones, panel info

2. **National Flood Data API** (Commercial)
   - URL: `https://nationalflooddata.com/`
   - Better quality, requires API key
   - Fallback option

**Methods to Implement:**
```python
class FEMAFloodClient(BaseAPIClient):
    - get_flood_zone(lat, lon) -> Dict
    - get_base_flood_elevation(lat, lon) -> float
    - get_flood_panel_info(lat, lon) -> Dict
    - batch_flood_lookup(locations) -> pd.DataFrame
    - get_enrichment_features(lat, lon) -> Dict
```

**Data Fields:**
- `flood_zone` (A, AE, AH, AO, X, etc.)
- `flood_zone_subtype`
- `base_flood_elevation` (feet)
- `fema_panel_number`
- `effective_date`
- `flood_risk_score` (derived: 0-1 scale)

---

### Phase 2: USGS Earthquake/Hazard API Client

**File:** `src/api_clients/usgs_earthquake_client.py`

**API Endpoint:**
- URL: `https://earthquake.usgs.gov/fdsnws/event/1/query`
- Format: JSON, CSV, GeoJSON
- Free public API

**Methods to Implement:**
```python
class USGSEarthquakeClient(BaseAPIClient):
    - get_earthquakes_in_area(lat, lon, radius_km, start_date, min_magnitude) -> List[Dict]
    - get_earthquake_count(lat, lon, radius_km, years, min_magnitude) -> int
    - get_seismic_hazard_score(lat, lon) -> float
    - get_largest_earthquake(lat, lon, radius_km, years) -> Dict
    - get_enrichment_features(lat, lon) -> Dict
```

**Data Fields:**
- `earthquake_count_10yr` (magnitude >= 3.0)
- `earthquake_count_significant` (magnitude >= 5.0)
- `max_magnitude_10yr`
- `most_recent_earthquake_date`
- `seismic_hazard_score` (0-1 scale based on frequency + magnitude)
- `distance_to_nearest_fault` (if available)

---

### Phase 3: Static Data Parsers

**File:** `src/utils/static_data_loader.py`

**Data Sources:**

1. **Wharton WRLURI (Zoning Restrictiveness)**
   - Format: CSV/Excel download
   - URL: https://realestate.wharton.upenn.edu/
   - Fields: Jurisdiction, WRLURI score, subindices
   - Join key: County/City name or FIPS code

2. **Construction Cost Indices**
   - Format: Manual CSV
   - Sources: ENR, RS Means (from reports)
   - Fields: Year, Region, CCI, BCI
   - Join key: Year + State/Metro

**Methods to Implement:**
```python
class StaticDataLoader:
    - load_wrluri_data(file_path) -> pd.DataFrame
    - get_zoning_restrictiveness(county_fips) -> float
    - load_construction_indices(file_path) -> pd.DataFrame
    - get_construction_cost_index(year, state) -> float
```

---

### Phase 4: Unified Data Enrichment Pipeline

**File:** `src/pipeline/data_enrichment.py`

**Purpose:** Combine all data sources into single enrichment function

**Class Structure:**
```python
class DataEnrichmentPipeline:
    def __init__(self, config):
        # Initialize all clients
        self.fcc_client = FCCClient()
        self.opencellid_client = OpenCelliDClient(api_key)
        self.census_client = CensusClient(api_key)
        self.fema_client = FEMAFloodClient()
        self.usgs_client = USGSEarthquakeClient()
        self.static_loader = StaticDataLoader()
    
    def enrich_site(self, site: Dict) -> Dict:
        """Enrich single tower site with all data sources"""
        
    def enrich_batch(self, sites: List[Dict]) -> pd.DataFrame:
        """Enrich multiple sites with progress tracking"""
    
    def get_feature_summary(self) -> Dict:
        """Return summary of available features"""
```

**Enrichment Features (50+ total):**

**Demographics (Census):**
- population_3km, median_income, housing_units
- vacancy_rate, median_age, median_home_value
- population_density, education_level

**Competitor Density (FCC + OpenCelliD):**
- fcc_tower_count_5km, fcc_tower_density
- opencellid_tower_count_3km, opencellid_carrier_count
- tower_saturation_index

**Hazard Data (FEMA + USGS):**
- flood_zone, flood_risk_score
- earthquake_count_10yr, seismic_hazard_score
- max_magnitude_10yr

**Geospatial:**
- fips_code, census_tract, county
- latitude, longitude
- urban_rural_classification

**Derived Features:**
- rent_per_capita, rent_income_ratio
- tower_per_capita, market_opportunity_score
- composite_risk_score

---

## Implementation Code Examples

### FEMA Flood Client

```python
class FEMAFloodClient(BaseAPIClient):
    """Client for FEMA National Flood Hazard Layer"""
    
    BASE_URL = "https://hazards.fema.gov/gis/nfhl/rest/services"
    
    def __init__(self):
        super().__init__(
            base_url=self.BASE_URL,
            rate_limit_calls=100,
            rate_limit_period=60,
            cache_enabled=True
        )
    
    def get_flood_zone(self, lat: float, lon: float) -> Dict:
        """
        Get flood zone for a location using FEMA GIS service
        
        Returns:
            {
                'flood_zone': 'X',
                'zone_subtype': 'Area of Minimal Flood Hazard',
                'fema_panel': '06075C1234F',
                'effective_date': '2015-03-15',
                'flood_risk_score': 0.1
            }
        """
        # Query FEMA ArcGIS REST API
        endpoint = "/public/NFHL/NFHL/MapServer/identify"
        
        params = {
            'geometry': f'{lon},{lat}',
            'geometryType': 'esriGeometryPoint',
            'sr': 4326,
            'layers': 'all',
            'tolerance': 1,
            'mapExtent': f'{lon-0.01},{lat-0.01},{lon+0.01},{lat+0.01}',
            'imageDisplay': '400,400,96',
            'returnGeometry': 'false',
            'f': 'json'
        }
        
        response = self._make_request('GET', endpoint, params=params)
        data = response.json()
        
        # Parse flood zone from response
        flood_zone = self._parse_flood_zone(data)
        
        return flood_zone
    
    def _parse_flood_zone(self, data: Dict) -> Dict:
        """Parse FEMA API response"""
        # Implementation details...
        pass
    
    def get_enrichment_features(self, lat: float, lon: float) -> Dict:
        """Get all flood-related features"""
        flood_data = self.get_flood_zone(lat, lon)
        
        return {
            'fema_flood_zone': flood_data.get('flood_zone'),
            'fema_flood_risk_score': flood_data.get('flood_risk_score'),
            'fema_panel_number': flood_data.get('fema_panel'),
            'fema_effective_date': flood_data.get('effective_date')
        }
```

### USGS Earthquake Client

```python
class USGSEarthquakeClient(BaseAPIClient):
    """Client for USGS Earthquake Hazards API"""
    
    BASE_URL = "https://earthquake.usgs.gov/fdsnws/event/1"
    
    def __init__(self):
        super().__init__(
            base_url=self.BASE_URL,
            rate_limit_calls=1000,
            rate_limit_period=3600,
            cache_enabled=True
        )
    
    def get_earthquakes_in_area(
        self,
        lat: float,
        lon: float,
        radius_km: float,
        start_date: str = "2015-01-01",
        min_magnitude: float = 3.0
    ) -> List[Dict]:
        """
        Get earthquakes in circular area
        
        Args:
            lat: Latitude
            lon: Longitude
            radius_km: Radius in kilometers (max 20000)
            start_date: Start date (YYYY-MM-DD)
            min_magnitude: Minimum magnitude
        
        Returns:
            List of earthquake dictionaries
        """
        endpoint = "/query"
        
        params = {
            'format': 'geojson',
            'latitude': lat,
            'longitude': lon,
            'maxradiuskm': radius_km,
            'starttime': start_date,
            'minmagnitude': min_magnitude,
            'orderby': 'magnitude'
        }
        
        response = self._make_request('GET', endpoint, params=params)
        data = response.json()
        
        earthquakes = []
        for feature in data.get('features', []):
            props = feature['properties']
            coords = feature['geometry']['coordinates']
            
            earthquakes.append({
                'magnitude': props['mag'],
                'place': props['place'],
                'time': props['time'],
                'latitude': coords[1],
                'longitude': coords[0],
                'depth_km': coords[2]
            })
        
        return earthquakes
    
    def get_seismic_hazard_score(
        self,
        lat: float,
        lon: float,
        radius_km: float = 50,
        years: int = 10
    ) -> float:
        """
        Calculate seismic hazard score (0-1)
        Based on earthquake frequency and magnitude
        """
        import datetime
        
        start_date = (datetime.datetime.now() - datetime.timedelta(days=years*365)).strftime('%Y-%m-%d')
        
        earthquakes = self.get_earthquakes_in_area(
            lat, lon, radius_km, start_date, min_magnitude=3.0
        )
        
        if not earthquakes:
            return 0.0
        
        # Calculate score based on count and max magnitude
        count = len(earthquakes)
        max_mag = max([eq['magnitude'] for eq in earthquakes])
        
        # Normalize: 0 earthquakes = 0, 10+ = 0.5, magnitude 7+ = 1.0
        count_score = min(count / 20, 0.5)
        mag_score = min((max_mag - 3) / 4, 0.5)
        
        total_score = count_score + mag_score
        
        return round(total_score, 3)
    
    def get_enrichment_features(self, lat: float, lon: float) -> Dict:
        """Get all earthquake-related features"""
        earthquakes = self.get_earthquakes_in_area(
            lat, lon, radius_km=50, min_magnitude=3.0
        )
        
        significant = [eq for eq in earthquakes if eq['magnitude'] >= 5.0]
        
        return {
            'usgs_earthquake_count_10yr': len(earthquakes),
            'usgs_earthquake_count_significant': len(significant),
            'usgs_max_magnitude_10yr': max([eq['magnitude'] for eq in earthquakes]) if earthquakes else 0,
            'usgs_seismic_hazard_score': self.get_seismic_hazard_score(lat, lon)
        }
```

---

## Testing Strategy

### Test Locations
Use diverse locations to test all scenarios:

1. **High Flood Risk:** New Orleans, LA (29.9511, -90.0715)
2. **High Seismic Risk:** San Francisco, CA (37.7749, -122.4194)
3. **Low Risk:** Denver, CO (39.7392, -104.9903)
4. **Urban Dense:** New York, NY (40.7128, -74.0060)
5. **Rural:** Rural Kansas (38.5, -98.5)

### Test Cases

**FEMA Flood Client:**
- ✓ Flood zone A (high risk)
- ✓ Flood zone X (minimal risk)
- ✓ Coastal vs inland
- ✓ Batch processing

**USGS Earthquake Client:**
- ✓ California (high seismic activity)
- ✓ East Coast (low seismic activity)
- ✓ Historical earthquake counts
- ✓ Magnitude distributions

**Integration:**
- ✓ Enrich 10 sample sites
- ✓ Verify all features present
- ✓ Check data quality
- ✓ Performance benchmarks

---

## Data Schema

### Enriched Site Schema (70+ fields)

```python
{
    # Site Identifiers
    'site_id': str,
    'latitude': float,
    'longitude': float,
    'address': str,
    
    # Demographics (Census)
    'census_population': int,
    'census_median_income': float,
    'census_housing_units': int,
    'census_vacancy_rate': float,
    'census_population_density': float,
    'census_median_age': float,
    'census_median_home_value': float,
    
    # Competitor Density (FCC + OpenCelliD)
    'fcc_tower_count_5km': int,
    'fcc_tower_density': float,
    'opencellid_tower_count_3km': int,
    'opencellid_carrier_count': int,
    'opencellid_tower_density': float,
    
    # Hazard Data (FEMA + USGS)
    'fema_flood_zone': str,
    'fema_flood_risk_score': float,
    'usgs_earthquake_count_10yr': int,
    'usgs_seismic_hazard_score': float,
    'usgs_max_magnitude_10yr': float,
    
    # Geospatial
    'census_fips_code': str,
    'census_state': str,
    'census_county': str,
    'census_tract': str,
    
    # Derived Features
    'tower_saturation_index': float,
    'market_opportunity_score': float,
    'composite_risk_score': float,
    'rent_income_ratio': float
}
```

---

## Timeline

| Day | Task | Deliverable |
|-----|------|-------------|
| 1 | Implement FEMA Flood client | Working flood zone lookup |
| 2 | Implement USGS Earthquake client | Seismic hazard scoring |
| 3 | Create static data loaders | WRLURI data integration |
| 4 | Build unified enrichment pipeline | Combined data enrichment |
| 5 | Testing & validation | All APIs tested |
| 6 | Documentation & notebook | Usage examples |

---

## Success Criteria

✅ FEMA Flood client retrieves flood zones for any US location  
✅ USGS Earthquake client calculates seismic hazard scores  
✅ Static data loaders parse WRLURI and construction indices  
✅ Unified pipeline enriches sites with 70+ features  
✅ All clients respect rate limits and use caching  
✅ Test notebook demonstrates full workflow  
✅ Documentation complete with examples  

---

## Next Steps After Implementation

1. **Data Quality Analysis**
   - Check completeness rates
   - Identify missing data patterns
   - Validate against known values

2. **Feature Engineering**
   - Create interaction terms
   - Normalize/scale features
   - Handle missing values

3. **Cross-Sectional Dataset**
   - Build panel structure
   - Add time-varying features
   - Export for modeling

4. **Model Development**
   - Fair rent estimation (SFA)
   - Rent forecasting (time series)
   - Optimization framework

---

## Cost Summary

| Data Source | Cost | Status |
|-------------|------|--------|
| FCC | Free | ✅ Implemented |
| OpenCelliD | Free | ✅ Implemented |
| Census | Free | ✅ Implemented |
| FEMA Flood | Free | 🔄 To implement |
| USGS Earthquake | Free | 🔄 To implement |
| Wharton WRLURI | Free | 🔄 To implement |
| **Total Free APIs** | **$0** | **6 sources** |

**Commercial APIs (Optional):**
- Regrid: $5K-$15K/year
- ATTOM: $10K-$30K/year
- National Flood Data: $2K-$5K/year
- CompStak: $10K-$20K/year

**Recommendation:** Start with free APIs, add commercial sources based on ROI analysis
