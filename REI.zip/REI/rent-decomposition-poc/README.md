# Rent Decomposition POC

A simple proof-of-concept for decomposing telecom lease rents into constituent components using synthetic data and basic ML techniques.

## Overview

This POC demonstrates the core concept of rent decomposition before implementing advanced techniques. It uses a simplified 4-component model:

```
Observed_Rent(t) = Base_Rent × Escalation_Factor(t) × Market_Factor(t) × Premium_Factor + Noise(t)
```

## Components

1. **Base Rent**: Initial lease rent amount
2. **Escalation Factor**: Contractual rent increases over time
3. **Market Factor**: Economic and real estate market influences
4. **Premium Factor**: Network and location-based premiums
5. **Noise**: Random variations and measurement errors

## Installation

```bash
cd c:\Users\hp\Desktop\REI\rent-decomposition-poc
pip install -r requirements.txt
```

## Quick Start

```python
from src.data.sample_generator import generate_synthetic_lease_data
from src.decomposer.basic_decomposer import RentDecomposer
from src.utils.plotting import plot_decomposition_results

# Generate synthetic data
data = generate_synthetic_lease_data(n_sites=50, years=10)

# Initialize decomposer
decomposer = RentDecomposer()

# Decompose first site
site = data[0]
results = decomposer.decompose(site['rent_history'], site.get('contract_terms', {}))

# Visualize results
plot_decomposition_results(results, site['true_components'])
```

## Project Structure

```
rent-decomposition-poc/
├── src/                    # Source code
│   ├── decomposer/         # Core decomposition logic
│   ├── data/               # Data generation and validation
│   └── utils/              # Utilities for plotting and metrics
├── notebooks/              # Jupyter demonstrations
├── tests/                  # Unit tests
├── data/                   # Generated data and results
└── config/                 # Configuration files
```

## Success Metrics

- Reconstruction accuracy >90% (MAPE <10%)
- Component extraction accuracy >85% for synthetic data
- Visual validation of component separation

## Next Steps

After POC validation:
1. Integration with real lease data
2. Advanced decomposition techniques (Kalman filters, RPCA)
3. ML integration for fair market rent prediction
4. Production pipeline development
