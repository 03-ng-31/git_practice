# Rent Decomposition POC
