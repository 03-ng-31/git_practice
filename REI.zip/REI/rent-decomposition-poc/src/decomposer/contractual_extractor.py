"""
Contractual escalation extraction component.
"""
import numpy as np
from typing import Dict, List, Optional, Tuple
from .components import ContractTerms


class ContractualExtractor:
    """Extract contractual escalation patterns from rent history."""
    
    def __init__(self, detection_threshold: float = 0.01):
        """
        Initialize contractual extractor.
        
        Args:
            detection_threshold: Minimum rate change to detect escalation events
        """
        self.detection_threshold = detection_threshold
    
    def extract_escalation_factor(
        self, 
        rent_history: np.ndarray, 
        contract_terms: Optional[ContractTerms] = None
    ) -> Tuple[np.ndarray, Dict[str, float]]:
        """
        Extract escalation factor from rent history.
        
        Args:
            rent_history: Historical rent payments
            contract_terms: Known contract terms (if available)
            
        Returns:
            Tuple of (escalation_factor, confidence_scores)
        """
        years = len(rent_history)
        
        if contract_terms and contract_terms.annual_escalation:
            # Use known contract terms
            return self._extract_with_known_terms(rent_history, contract_terms)
        else:
            # Detect escalation pattern from data
            return self._detect_escalation_pattern(rent_history)
    
    def _extract_with_known_terms(
        self, 
        rent_history: np.ndarray, 
        contract_terms: ContractTerms
    ) -> Tuple[np.ndarray, Dict[str, float]]:
        """Extract escalation using known contract terms."""
        years = len(rent_history)
        escalation_factor = np.ones(years)
        
        annual_rate = contract_terms.annual_escalation or 0.0
        start_year = contract_terms.escalation_start_year
        frequency = contract_terms.escalation_frequency
        
        # Build theoretical escalation path
        for year in range(years):
            if year >= start_year and (year - start_year) % frequency == 0:
                escalation_factor[year:] *= (1 + annual_rate)
        
        # Normalize to cumulative factors
        base_factor = escalation_factor[0]
        for year in range(1, years):
            escalation_factor[year] = escalation_factor[year] / base_factor
        
        # Calculate confidence based on fit to actual rent growth
        theoretical_rent = rent_history[0] * escalation_factor
        actual_growth = rent_history / rent_history[0]
        
        # Correlation between theoretical and actual growth patterns
        if len(theoretical_rent) > 1:
            confidence = max(0.0, np.corrcoef(escalation_factor, actual_growth)[0, 1])
        else:
            confidence = 0.5
        
        confidence_scores = {
            'escalation_fit': confidence,
            'method_confidence': 0.9  # High confidence when we have contract terms
        }
        
        return escalation_factor, confidence_scores
    
    def _detect_escalation_pattern(
        self, 
        rent_history: np.ndarray
    ) -> Tuple[np.ndarray, Dict[str, float]]:
        """Detect escalation pattern from rent data using change point detection."""
        years = len(rent_history)
        
        if years < 3:
            # Too few points for pattern detection
            return np.ones(years), {'escalation_fit': 0.0, 'method_confidence': 0.1}
        
        # Calculate year-over-year growth rates
        growth_rates = np.diff(rent_history) / rent_history[:-1]
        
        # Simple escalation detection: look for consistent growth pattern
        escalation_factor = np.ones(years)
        
        # Method 1: Detect consistent annual escalation
        if self._has_consistent_escalation(growth_rates):
            avg_rate = np.mean(growth_rates)
            for year in range(1, years):
                escalation_factor[year] = escalation_factor[year-1] * (1 + avg_rate)
            
            confidence = min(0.8, 1.0 - np.std(growth_rates))
        
        # Method 2: Detect periodic escalations (every 2-3 years)
        elif self._has_periodic_escalation(growth_rates):
            escalation_factor = self._fit_periodic_escalation(rent_history, growth_rates)
            confidence = 0.6
        
        # Method 3: Fit compound growth model
        else:
            escalation_factor = self._fit_compound_growth(rent_history)
            confidence = 0.4
        
        confidence_scores = {
            'escalation_fit': confidence,
            'method_confidence': confidence * 0.7  # Lower confidence for detection vs known terms
        }
        
        return escalation_factor, confidence_scores
    
    def _has_consistent_escalation(self, growth_rates: np.ndarray) -> bool:
        """Check if growth rates suggest consistent annual escalation."""
        if len(growth_rates) < 2:
            return False
        
        # Check if standard deviation is low and mean is positive
        mean_rate = np.mean(growth_rates)
        std_rate = np.std(growth_rates)
        
        return (mean_rate > 0.01 and  # At least 1% annual growth
                std_rate < 0.05 and  # Low variability
                np.all(growth_rates > -0.1))  # No major drops
    
    def _has_periodic_escalation(self, growth_rates: np.ndarray) -> bool:
        """Check if growth rates suggest periodic escalations."""
        if len(growth_rates) < 4:
            return False
        
        # Look for alternating high/low growth patterns
        high_growth_threshold = np.mean(growth_rates) + np.std(growth_rates)
        high_growth_years = growth_rates > high_growth_threshold
        
        # Check if high growth years are spaced regularly
        high_indices = np.where(high_growth_years)[0]
        if len(high_indices) > 1:
            spacing = np.diff(high_indices)
            return np.std(spacing) < 1.0  # Regular spacing
        
        return False
    
    def _fit_periodic_escalation(
        self, 
        rent_history: np.ndarray, 
        growth_rates: np.ndarray
    ) -> np.ndarray:
        """Fit periodic escalation model."""
        years = len(rent_history)
        escalation_factor = np.ones(years)
        
        # Simple approach: identify escalation years and fit constant rate
        high_growth_threshold = np.mean(growth_rates) + np.std(growth_rates)
        escalation_years = np.where(growth_rates > high_growth_threshold)[0]
        
        if len(escalation_years) > 0:
            avg_escalation = np.mean(growth_rates[escalation_years])
            
            # Apply escalation at detected years
            for year_idx in escalation_years:
                year = year_idx + 1  # Convert to year index
                if year < years:
                    factor = 1 + avg_escalation
                    escalation_factor[year:] *= factor
        
        return escalation_factor
    
    def _fit_compound_growth(self, rent_history: np.ndarray) -> np.ndarray:
        """Fit simple compound growth model."""
        years = len(rent_history)
        
        if years < 2:
            return np.ones(years)
        
        # Calculate overall growth rate
        total_growth = rent_history[-1] / rent_history[0]
        annual_rate = (total_growth ** (1.0 / (years - 1))) - 1
        
        # Build escalation factor
        escalation_factor = np.ones(years)
        for year in range(1, years):
            escalation_factor[year] = (1 + annual_rate) ** year
        
        return escalation_factor
    
    def validate_escalation_extraction(
        self, 
        rent_history: np.ndarray, 
        escalation_factor: np.ndarray,
        base_rent: float
    ) -> Dict[str, float]:
        """Validate escalation extraction quality."""
        # Theoretical rent from escalation only
        theoretical_rent = base_rent * escalation_factor
        
        # Calculate metrics
        mape = np.mean(np.abs((rent_history - theoretical_rent) / rent_history)) * 100
        
        if len(rent_history) > 1:
            correlation = np.corrcoef(rent_history, theoretical_rent)[0, 1]
        else:
            correlation = 0.0
        
        # Check for monotonicity (escalation should generally increase)
        monotonic = np.all(np.diff(escalation_factor) >= -0.001)  # Allow small decreases
        
        return {
            'escalation_mape': mape,
            'escalation_correlation': correlation,
            'monotonic': float(monotonic),
            'escalation_range': escalation_factor[-1] / escalation_factor[0] - 1
        }
