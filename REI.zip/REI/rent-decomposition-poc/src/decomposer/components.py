"""
Rent component definitions and data structures.
"""
import numpy as np
from dataclasses import dataclass
from typing import Dict, List, Optional, Any


@dataclass
class RentComponents:
    """Container for decomposed rent components."""
    
    # Original data
    site_id: str
    rent_history: np.ndarray
    years: int
    
    # Decomposed components
    base_rent: float
    escalation_factor: np.ndarray
    market_factor: np.ndarray
    premium_factor: float
    noise: np.ndarray
    
    # Reconstructed rent
    reconstructed_rent: np.ndarray
    
    # Metadata
    decomposition_method: str
    confidence_scores: Dict[str, float]
    
    def __post_init__(self):
        """Validate component dimensions."""
        if len(self.rent_history) != self.years:
            raise ValueError("rent_history length must match years")
        if len(self.escalation_factor) != self.years:
            raise ValueError("escalation_factor length must match years")
        if len(self.market_factor) != self.years:
            raise ValueError("market_factor length must match years")
        if len(self.noise) != self.years:
            raise ValueError("noise length must match years")
        if len(self.reconstructed_rent) != self.years:
            raise ValueError("reconstructed_rent length must match years")
    
    def get_component_summary(self) -> Dict[str, Any]:
        """Get summary statistics for each component."""
        return {
            'base_rent': self.base_rent,
            'escalation': {
                'initial': self.escalation_factor[0],
                'final': self.escalation_factor[-1],
                'total_growth': self.escalation_factor[-1] / self.escalation_factor[0] - 1,
                'avg_annual_rate': np.mean(np.diff(self.escalation_factor) / self.escalation_factor[:-1])
            },
            'market': {
                'mean': np.mean(self.market_factor),
                'std': np.std(self.market_factor),
                'min': np.min(self.market_factor),
                'max': np.max(self.market_factor),
                'trend': np.polyfit(range(self.years), self.market_factor, 1)[0]
            },
            'premium_factor': self.premium_factor,
            'noise': {
                'mean': np.mean(self.noise),
                'std': np.std(self.noise),
                'signal_to_noise_ratio': np.std(self.rent_history) / np.std(self.noise)
            },
            'reconstruction': {
                'mape': self.calculate_reconstruction_mape(),
                'correlation': np.corrcoef(self.rent_history, self.reconstructed_rent)[0, 1]
            }
        }
    
    def calculate_reconstruction_mape(self) -> float:
        """Calculate Mean Absolute Percentage Error for reconstruction."""
        return np.mean(np.abs((self.rent_history - self.reconstructed_rent) / self.rent_history)) * 100
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            'site_id': self.site_id,
            'rent_history': self.rent_history.tolist(),
            'years': self.years,
            'base_rent': self.base_rent,
            'escalation_factor': self.escalation_factor.tolist(),
            'market_factor': self.market_factor.tolist(),
            'premium_factor': self.premium_factor,
            'noise': self.noise.tolist(),
            'reconstructed_rent': self.reconstructed_rent.tolist(),
            'decomposition_method': self.decomposition_method,
            'confidence_scores': self.confidence_scores,
            'summary': self.get_component_summary()
        }


@dataclass
class ContractTerms:
    """Container for lease contract terms."""
    
    annual_escalation: Optional[float] = None  # Fixed annual escalation rate
    cpi_escalation: bool = False  # Whether CPI adjustments apply
    revenue_share_rate: Optional[float] = None  # Revenue sharing percentage
    escalation_start_year: int = 1  # When escalations begin
    escalation_frequency: int = 1  # Years between escalations
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'annual_escalation': self.annual_escalation,
            'cpi_escalation': self.cpi_escalation,
            'revenue_share_rate': self.revenue_share_rate,
            'escalation_start_year': self.escalation_start_year,
            'escalation_frequency': self.escalation_frequency
        }


@dataclass
class SiteCharacteristics:
    """Container for site characteristics affecting premiums."""
    
    # Network characteristics
    high_traffic: bool = False
    coverage_critical: bool = False
    colocation_count: int = 1
    technology_layers: int = 1  # Number of tech generations (2G, 3G, 4G, 5G)
    
    # Location characteristics
    premium_location: bool = False
    zoning_restricted: bool = False
    high_visibility: bool = False
    development_potential: bool = False
    
    # Geographic
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    urban: bool = True
    
    def calculate_network_premium(self) -> float:
        """Calculate network premium multiplier."""
        premium = 1.0
        
        if self.high_traffic:
            premium += 0.3
        if self.coverage_critical:
            premium += 0.2
        
        # Colocation premium with diminishing returns
        if self.colocation_count > 1:
            premium += 0.1 * np.log(self.colocation_count)
        
        # Technology layers premium
        if self.technology_layers > 1:
            premium += 0.05 * (self.technology_layers - 1)
        
        return premium
    
    def calculate_location_premium(self) -> float:
        """Calculate location premium multiplier."""
        premium = 1.0
        
        if self.premium_location:
            premium += 0.25
        if self.zoning_restricted:
            premium += 0.15
        if self.high_visibility:
            premium += 0.1
        if self.development_potential:
            premium += 0.1
        
        return premium
    
    def calculate_total_premium(self) -> float:
        """Calculate total premium factor."""
        return self.calculate_network_premium() * self.calculate_location_premium()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'high_traffic': self.high_traffic,
            'coverage_critical': self.coverage_critical,
            'colocation_count': self.colocation_count,
            'technology_layers': self.technology_layers,
            'premium_location': self.premium_location,
            'zoning_restricted': self.zoning_restricted,
            'high_visibility': self.high_visibility,
            'development_potential': self.development_potential,
            'latitude': self.latitude,
            'longitude': self.longitude,
            'urban': self.urban,
            'calculated_premiums': {
                'network_premium': self.calculate_network_premium(),
                'location_premium': self.calculate_location_premium(),
                'total_premium': self.calculate_total_premium()
            }
        }
