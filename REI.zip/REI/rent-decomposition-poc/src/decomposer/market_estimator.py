"""
Market component estimation using economic indicators and trend analysis.
"""
import numpy as np
from typing import Dict, List, Optional, Tuple
from sklearn.linear_model import LinearRegression, Ridge
from scipy import signal
from scipy.stats import pearsonr


class MarketEstimator:
    """Estimate market-driven rent components."""
    
    def __init__(self, method: str = "linear_regression", min_years: int = 5):
        """
        Initialize market estimator.
        
        Args:
            method: Method to use ("linear_regression", "detrend", "economic_indicators")
            min_years: Minimum years required for reliable estimation
        """
        self.method = method
        self.min_years = min_years
    
    def estimate_market_factor(
        self,
        rent_history: np.ndarray,
        escalation_factor: np.ndarray,
        economic_indicators: Optional[np.ndarray] = None,
        base_rent: float = None
    ) -> Tuple[np.ndarray, Dict[str, float]]:
        """
        Estimate market factor from rent history.
        
        Args:
            rent_history: Historical rent payments
            escalation_factor: Contractual escalation factor
            economic_indicators: Economic indicators (CPI, land values, etc.)
            base_rent: Base rent amount
            
        Returns:
            Tuple of (market_factor, confidence_scores)
        """
        years = len(rent_history)
        
        if years < self.min_years:
            # Not enough data - return neutral market factor
            return np.ones(years), {'market_fit': 0.0, 'method_confidence': 0.1}
        
        # Remove escalation effects first
        if base_rent is None:
            base_rent = rent_history[0]
        
        escalation_adjusted_rent = rent_history / (base_rent * escalation_factor)
        
        if self.method == "linear_regression":
            return self._estimate_with_trend(escalation_adjusted_rent)
        elif self.method == "detrend":
            return self._estimate_with_detrend(escalation_adjusted_rent)
        elif self.method == "economic_indicators" and economic_indicators is not None:
            return self._estimate_with_indicators(escalation_adjusted_rent, economic_indicators)
        else:
            # Fallback to trend analysis
            return self._estimate_with_trend(escalation_adjusted_rent)
    
    def _estimate_with_trend(self, adjusted_rent: np.ndarray) -> Tuple[np.ndarray, Dict[str, float]]:
        """Estimate market factor using linear trend fitting."""
        years = len(adjusted_rent)
        time_points = np.arange(years)
        
        # Fit linear trend
        slope, intercept = np.polyfit(time_points, adjusted_rent, 1)
        trend = intercept + slope * time_points
        
        # Market factor is the ratio of actual to trend
        market_factor = adjusted_rent / np.mean(adjusted_rent)
        
        # Smooth market factor to remove high-frequency noise
        if years > 7:
            market_factor = self._smooth_series(market_factor, window=3)
        
        # Calculate confidence metrics
        trend_r2 = self._calculate_r2(adjusted_rent, trend)
        volatility = np.std(market_factor)
        
        confidence = {
            'market_fit': min(0.8, max(0.1, trend_r2)),
            'method_confidence': 0.7,
            'volatility_penalty': max(0.0, 1.0 - volatility * 2)  # Penalize high volatility
        }
        
        overall_confidence = np.mean(list(confidence.values()))
        confidence['overall'] = overall_confidence
        
        return market_factor, confidence
    
    def _estimate_with_detrend(self, adjusted_rent: np.ndarray) -> Tuple[np.ndarray, Dict[str, float]]:
        """Estimate market factor using signal detrending."""
        years = len(adjusted_rent)
        
        # Detrend the series
        detrended = signal.detrend(adjusted_rent, type='linear')
        
        # Market factor is detrended component + 1 (normalized)
        market_factor = (detrended / np.mean(adjusted_rent)) + 1.0
        
        # Ensure positive values
        market_factor = np.maximum(market_factor, 0.5)
        
        # Calculate confidence
        signal_strength = np.std(detrended) / np.std(adjusted_rent)
        
        confidence = {
            'market_fit': min(0.8, signal_strength),
            'method_confidence': 0.6,
            'signal_strength': signal_strength
        }
        
        return market_factor, confidence
    
    def _estimate_with_indicators(
        self, 
        adjusted_rent: np.ndarray, 
        economic_indicators: np.ndarray
    ) -> Tuple[np.ndarray, Dict[str, float]]:
        """Estimate market factor using economic indicators."""
        years = len(adjusted_rent)
        
        if len(economic_indicators) != years:
            # Fall back to trend method if indicators don't match
            return self._estimate_with_trend(adjusted_rent)
        
        # Fit regression model
        X = economic_indicators.reshape(-1, 1)
        y = adjusted_rent
        
        # Use Ridge regression to prevent overfitting
        model = Ridge(alpha=0.1)
        model.fit(X, y)
        
        # Predict market-implied rent
        predicted_rent = model.predict(X)
        
        # Market factor is ratio of predicted to actual
        market_factor = predicted_rent / np.mean(adjusted_rent)
        
        # Calculate regression quality
        r2_score = model.score(X, y)
        correlation, p_value = pearsonr(economic_indicators.flatten(), adjusted_rent)
        
        confidence = {
            'market_fit': min(0.9, max(0.1, r2_score)),
            'method_confidence': 0.8,
            'correlation': abs(correlation),
            'p_value_significant': float(p_value < 0.05)
        }
        
        return market_factor, confidence
    
    def _smooth_series(self, series: np.ndarray, window: int = 3) -> np.ndarray:
        """Apply smoothing to reduce noise in market factor series."""
        if len(series) <= window:
            return series
        
        # Simple moving average
        smoothed = np.convolve(series, np.ones(window)/window, mode='same')
        
        # Handle edges
        for i in range(window//2):
            smoothed[i] = np.mean(series[:i+window//2+1])
            smoothed[-(i+1)] = np.mean(series[-(i+window//2+1):])
        
        return smoothed
    
    def _calculate_r2(self, actual: np.ndarray, predicted: np.ndarray) -> float:
        """Calculate R-squared coefficient."""
        ss_res = np.sum((actual - predicted) ** 2)
        ss_tot = np.sum((actual - np.mean(actual)) ** 2)
        
        if ss_tot == 0:
            return 0.0
        
        return 1 - (ss_res / ss_tot)
    
    def generate_synthetic_market_factor(
        self, 
        years: int, 
        cycle_amplitude: float = 0.1,
        trend_slope: float = 0.02,
        noise_level: float = 0.05
    ) -> np.ndarray:
        """Generate synthetic market factor for testing."""
        time_points = np.arange(years)
        
        # Base trend
        trend = 1.0 + trend_slope * time_points / years
        
        # Market cycle (sine wave)
        cycle = cycle_amplitude * np.sin(2 * np.pi * time_points / 7)  # 7-year cycle
        
        # Random noise
        noise = np.random.normal(0, noise_level, years)
        
        # Combine components
        market_factor = trend + cycle + noise
        
        # Ensure positive values
        market_factor = np.maximum(market_factor, 0.5)
        
        return market_factor
    
    def validate_market_estimation(
        self,
        true_market_factor: np.ndarray,
        estimated_market_factor: np.ndarray
    ) -> Dict[str, float]:
        """Validate market factor estimation against ground truth."""
        if len(true_market_factor) != len(estimated_market_factor):
            raise ValueError("True and estimated factors must have same length")
        
        # Calculate error metrics
        mape = np.mean(np.abs((true_market_factor - estimated_market_factor) / true_market_factor)) * 100
        
        correlation, _ = pearsonr(true_market_factor, estimated_market_factor)
        
        rmse = np.sqrt(np.mean((true_market_factor - estimated_market_factor) ** 2))
        
        # Check if trends match
        true_trend = np.polyfit(range(len(true_market_factor)), true_market_factor, 1)[0]
        est_trend = np.polyfit(range(len(estimated_market_factor)), estimated_market_factor, 1)[0]
        trend_match = 1.0 - abs(true_trend - est_trend) / max(abs(true_trend), 0.01)
        
        return {
            'market_mape': mape,
            'market_correlation': correlation,
            'market_rmse': rmse,
            'trend_match': max(0.0, trend_match)
        }
