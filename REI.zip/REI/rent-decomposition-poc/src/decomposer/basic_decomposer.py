"""
Main rent decomposition engine that coordinates component extraction.
"""
import numpy as np
from typing import Dict, List, Optional, Any, Tuple
import logging
from .components import RentComponents, ContractTerms, SiteCharacteristics
from .contractual_extractor import ContractualExtractor
from .market_estimator import MarketEstimator


class RentDecomposer:
    """Main class for decomposing rent into constituent components."""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize rent decomposer.
        
        Args:
            config: Configuration dictionary with component parameters
        """
        self.config = config or self._default_config()
        
        # Initialize component extractors
        self.contractual_extractor = ContractualExtractor(
            detection_threshold=self.config.get('escalation_detection_threshold', 0.01)
        )
        
        self.market_estimator = MarketEstimator(
            method=self.config.get('market_trend_method', 'linear_regression'),
            min_years=self.config.get('min_years_for_estimation', 5)
        )
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
    
    def _default_config(self) -> Dict[str, Any]:
        """Return default configuration."""
        return {
            'escalation_detection_threshold': 0.01,
            'market_trend_method': 'linear_regression',
            'min_years_for_estimation': 5,
            'premium_estimation_method': 'rule_based'
        }
    
    def decompose(
        self,
        rent_history: List[float],
        site_id: str = "UNKNOWN",
        contract_terms: Optional[Dict[str, Any]] = None,
        site_characteristics: Optional[Dict[str, Any]] = None,
        economic_indicators: Optional[List[float]] = None
    ) -> RentComponents:
        """
        Decompose rent history into constituent components.
        
        Args:
            rent_history: Historical rent payments
            site_id: Unique identifier for the site
            contract_terms: Contract escalation terms
            site_characteristics: Site characteristics for premium calculation
            economic_indicators: Economic indicators for market estimation
            
        Returns:
            RentComponents object with decomposed components
        """
        # Convert inputs to numpy arrays
        rent_array = np.array(rent_history)
        years = len(rent_array)
        
        if years < 2:
            raise ValueError("Need at least 2 years of rent history for decomposition")
        
        self.logger.info(f"Decomposing rent for site {site_id} with {years} years of data")
        
        # Parse contract terms
        contract_terms_obj = None
        if contract_terms:
            contract_terms_obj = ContractTerms(**contract_terms)
        
        # Parse site characteristics
        site_chars_obj = None
        if site_characteristics:
            site_chars_obj = SiteCharacteristics(**site_characteristics)
        
        # Step 1: Extract base rent (first year rent)
        base_rent = float(rent_array[0])
        
        # Step 2: Extract contractual escalation factor
        escalation_factor, escalation_confidence = self.contractual_extractor.extract_escalation_factor(
            rent_array, contract_terms_obj
        )
        
        # Step 3: Estimate market factor
        economic_array = None
        if economic_indicators:
            economic_array = np.array(economic_indicators)
        
        market_factor, market_confidence = self.market_estimator.estimate_market_factor(
            rent_array, escalation_factor, economic_array, base_rent
        )
        
        # Step 4: Calculate premium factor
        premium_factor, premium_confidence = self._calculate_premium_factor(
            rent_array, escalation_factor, market_factor, base_rent, site_chars_obj
        )
        
        # Step 5: Reconstruct rent and calculate noise
        reconstructed_rent, noise = self._reconstruct_and_calculate_noise(
            base_rent, escalation_factor, market_factor, premium_factor, rent_array
        )
        
        # Step 6: Compile confidence scores
        confidence_scores = self._compile_confidence_scores(
            escalation_confidence, market_confidence, premium_confidence
        )
        
        # Create components object
        components = RentComponents(
            site_id=site_id,
            rent_history=rent_array,
            years=years,
            base_rent=base_rent,
            escalation_factor=escalation_factor,
            market_factor=market_factor,
            premium_factor=premium_factor,
            noise=noise,
            reconstructed_rent=reconstructed_rent,
            decomposition_method="basic_sequential",
            confidence_scores=confidence_scores
        )
        
        self.logger.info(f"Decomposition complete. Reconstruction MAPE: {components.calculate_reconstruction_mape():.2f}%")
        
        return components
    
    def _calculate_premium_factor(
        self,
        rent_history: np.ndarray,
        escalation_factor: np.ndarray,
        market_factor: np.ndarray,
        base_rent: float,
        site_characteristics: Optional[SiteCharacteristics]
    ) -> Tuple[float, Dict[str, float]]:
        """Calculate premium factor using site characteristics or residual analysis."""
        
        if site_characteristics:
            # Use rule-based calculation from site characteristics
            premium_factor = site_characteristics.calculate_total_premium()
            confidence = {
                'premium_fit': 0.8,  # High confidence with site characteristics
                'method_confidence': 0.9
            }
            
        else:
            # Estimate premium from residual analysis
            # Remove escalation and market effects
            expected_rent_no_premium = base_rent * escalation_factor * market_factor
            
            # Calculate average premium as ratio of actual to expected
            premium_ratios = rent_history / expected_rent_no_premium
            
            # Use median to be robust to outliers
            premium_factor = float(np.median(premium_ratios))
            
            # Ensure reasonable bounds (0.5x to 3.0x)
            premium_factor = np.clip(premium_factor, 0.5, 3.0)
            
            # Calculate confidence based on consistency
            premium_std = np.std(premium_ratios)
            confidence = {
                'premium_fit': max(0.1, min(0.7, 1.0 - premium_std)),
                'method_confidence': 0.5  # Lower confidence for residual method
            }
        
        return premium_factor, confidence
    
    def _reconstruct_and_calculate_noise(
        self,
        base_rent: float,
        escalation_factor: np.ndarray,
        market_factor: np.ndarray,
        premium_factor: float,
        actual_rent: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Reconstruct rent from components and calculate noise residual."""
        
        # Reconstruct rent using multiplicative model
        reconstructed_rent = base_rent * escalation_factor * market_factor * premium_factor
        
        # Calculate noise as difference
        noise = actual_rent - reconstructed_rent
        
        return reconstructed_rent, noise
    
    def _compile_confidence_scores(
        self,
        escalation_confidence: Dict[str, float],
        market_confidence: Dict[str, float],
        premium_confidence: Dict[str, float]
    ) -> Dict[str, float]:
        """Compile overall confidence scores for decomposition."""
        
        confidence_scores = {}
        
        # Add component-specific confidence scores
        confidence_scores.update({f"escalation_{k}": v for k, v in escalation_confidence.items()})
        confidence_scores.update({f"market_{k}": v for k, v in market_confidence.items()})
        confidence_scores.update({f"premium_{k}": v for k, v in premium_confidence.items()})
        
        # Calculate overall confidence as weighted average
        component_confidences = [
            escalation_confidence.get('escalation_fit', 0.0) * 0.3,
            market_confidence.get('market_fit', 0.0) * 0.3,
            premium_confidence.get('premium_fit', 0.0) * 0.2,
            escalation_confidence.get('method_confidence', 0.0) * 0.1,
            market_confidence.get('method_confidence', 0.0) * 0.1
        ]
        
        confidence_scores['overall_confidence'] = sum(component_confidences)
        
        return confidence_scores
    
    def batch_decompose(
        self,
        sites_data: List[Dict[str, Any]]
    ) -> List[RentComponents]:
        """
        Decompose multiple sites in batch.
        
        Args:
            sites_data: List of site dictionaries with rent_history and metadata
            
        Returns:
            List of RentComponents objects
        """
        results = []
        
        for i, site_data in enumerate(sites_data):
            try:
                components = self.decompose(
                    rent_history=site_data['rent_history'],
                    site_id=site_data.get('site_id', f'SITE_{i:03d}'),
                    contract_terms=site_data.get('contract_terms'),
                    site_characteristics=site_data.get('site_characteristics'),
                    economic_indicators=site_data.get('economic_indicators')
                )
                results.append(components)
                
            except Exception as e:
                self.logger.error(f"Failed to decompose site {site_data.get('site_id', i)}: {e}")
                continue
        
        self.logger.info(f"Successfully decomposed {len(results)} out of {len(sites_data)} sites")
        
        return results
    
    def validate_decomposition(
        self,
        components: RentComponents,
        true_components: Optional[Dict[str, Any]] = None
    ) -> Dict[str, float]:
        """
        Validate decomposition quality.
        
        Args:
            components: Decomposed components
            true_components: Ground truth components (if available)
            
        Returns:
            Dictionary of validation metrics
        """
        validation_metrics = {}
        
        # Reconstruction quality
        reconstruction_mape = components.calculate_reconstruction_mape()
        validation_metrics['reconstruction_mape'] = reconstruction_mape
        
        rent_correlation = np.corrcoef(components.rent_history, components.reconstructed_rent)[0, 1]
        validation_metrics['reconstruction_correlation'] = rent_correlation
        
        # Component reasonableness checks
        escalation_growth = components.escalation_factor[-1] / components.escalation_factor[0] - 1
        validation_metrics['escalation_total_growth'] = escalation_growth
        validation_metrics['escalation_reasonable'] = float(0 <= escalation_growth <= 2.0)  # 0-200% total growth
        
        market_volatility = np.std(components.market_factor)
        validation_metrics['market_volatility'] = market_volatility
        validation_metrics['market_reasonable'] = float(market_volatility < 0.5)  # Not too volatile
        
        validation_metrics['premium_reasonable'] = float(0.5 <= components.premium_factor <= 3.0)
        
        noise_to_signal = np.std(components.noise) / np.std(components.rent_history)
        validation_metrics['noise_to_signal_ratio'] = noise_to_signal
        
        # If ground truth is available, compare components
        if true_components:
            validation_metrics.update(self._validate_against_ground_truth(components, true_components))
        
        # Overall quality score
        quality_components = [
            min(1.0, max(0.0, (100 - reconstruction_mape) / 100)),  # Reconstruction accuracy
            max(0.0, rent_correlation),  # Reconstruction correlation
            validation_metrics['escalation_reasonable'],
            validation_metrics['market_reasonable'],
            validation_metrics['premium_reasonable']
        ]
        
        validation_metrics['overall_quality'] = np.mean(quality_components)
        
        return validation_metrics
    
    def _validate_against_ground_truth(
        self,
        components: RentComponents,
        true_components: Dict[str, Any]
    ) -> Dict[str, float]:
        """Validate components against ground truth."""
        metrics = {}
        
        # Base rent
        if 'base_rent' in true_components:
            true_base = true_components['base_rent']
            base_error = abs(components.base_rent - true_base) / true_base * 100
            metrics['base_rent_mape'] = base_error
        
        # Escalation rate
        if 'escalation_rate' in true_components:
            true_rate = true_components['escalation_rate']
            # Estimate rate from escalation factor
            est_rate = np.mean(np.diff(components.escalation_factor) / components.escalation_factor[:-1])
            rate_error = abs(est_rate - true_rate) / max(true_rate, 0.01) * 100
            metrics['escalation_rate_mape'] = rate_error
        
        # Market factor
        if 'market_factor' in true_components:
            true_market = np.array(true_components['market_factor'])
            if len(true_market) == len(components.market_factor):
                market_mape = np.mean(np.abs((true_market - components.market_factor) / true_market)) * 100
                market_corr = np.corrcoef(true_market, components.market_factor)[0, 1]
                metrics['market_factor_mape'] = market_mape
                metrics['market_factor_correlation'] = market_corr
        
        # Premium factors
        if 'network_premium' in true_components and 'location_premium' in true_components:
            true_premium = true_components['network_premium'] * true_components['location_premium']
            premium_error = abs(components.premium_factor - true_premium) / true_premium * 100
            metrics['premium_factor_mape'] = premium_error
        
        return metrics
