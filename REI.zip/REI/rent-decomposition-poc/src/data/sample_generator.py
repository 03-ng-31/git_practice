"""
Synthetic lease data generator for testing rent decomposition algorithms.
"""
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
import yaml
import random


class SyntheticDataGenerator:
    """Generate realistic synthetic lease data with known components."""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None, seed: Optional[int] = None):
        """
        Initialize synthetic data generator.
        
        Args:
            config: Configuration parameters
            seed: Random seed for reproducible results
        """
        if seed:
            np.random.seed(seed)
            random.seed(seed)
        
        self.config = config or self._default_config()
    
    def _default_config(self) -> Dict[str, Any]:
        """Return default configuration parameters."""
        return {
            'n_sites': 100,
            'years': 15,
            'base_rent_range': [2000, 8000],
            'escalation_rate_range': [0.02, 0.05],
            'network_premium_range': [1.1, 2.0],
            'location_premium_range': [1.0, 1.5],
            'noise_level': 0.02,
            'market_cycle_amplitude': 0.1,
            'market_trend_slope': 0.01
        }
    
    def generate_lease_portfolio(
        self, 
        n_sites: Optional[int] = None, 
        years: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Generate a portfolio of synthetic lease data.
        
        Args:
            n_sites: Number of sites to generate (overrides config)
            years: Number of years of history (overrides config)
            
        Returns:
            List of site dictionaries with rent history and true components
        """
        n_sites = n_sites or self.config['n_sites']
        years = years or self.config['years']
        
        portfolio = []
        
        for site_id in range(n_sites):
            site_data = self._generate_single_site(f'SITE_{site_id:03d}', years)
            portfolio.append(site_data)
        
        return portfolio
    
    def _generate_single_site(self, site_id: str, years: int) -> Dict[str, Any]:
        """Generate data for a single site."""
        
        # 1. Generate base parameters
        base_rent = np.random.uniform(*self.config['base_rent_range'])
        escalation_rate = np.random.uniform(*self.config['escalation_rate_range'])
        
        # 2. Generate site characteristics
        site_characteristics = self._generate_site_characteristics()
        
        # 3. Calculate premiums
        network_premium = np.random.uniform(*self.config['network_premium_range'])
        location_premium = np.random.uniform(*self.config['location_premium_range'])
        
        # Adjust premiums based on site characteristics
        if site_characteristics['high_traffic']:
            network_premium *= 1.2
        if site_characteristics['coverage_critical']:
            network_premium *= 1.1
        if site_characteristics['premium_location']:
            location_premium *= 1.3
        
        total_premium = network_premium * location_premium
        
        # 4. Generate contract terms
        contract_terms = self._generate_contract_terms(escalation_rate)
        
        # 5. Generate market factor
        market_factor = self._generate_market_factor(years)
        
        # 6. Generate economic indicators (correlated with market factor)
        economic_indicators = self._generate_economic_indicators(market_factor, years)
        
        # 7. Generate rent history
        rent_history = self._generate_rent_history(
            base_rent, escalation_rate, market_factor, total_premium, years
        )
        
        # 8. Compile site data
        site_data = {
            'site_id': site_id,
            'rent_history': rent_history.tolist(),
            'years': years,
            'contract_terms': contract_terms,
            'site_characteristics': site_characteristics,
            'economic_indicators': economic_indicators.tolist(),
            'true_components': {
                'base_rent': base_rent,
                'escalation_rate': escalation_rate,
                'market_factor': market_factor.tolist(),
                'network_premium': network_premium,
                'location_premium': location_premium,
                'total_premium': total_premium
            }
        }
        
        return site_data
    
    def _generate_site_characteristics(self) -> Dict[str, Any]:
        """Generate realistic site characteristics."""
        # Urban vs rural (70% urban)
        urban = np.random.random() < 0.7
        
        # Network characteristics (more likely in urban areas)
        high_traffic = np.random.random() < (0.4 if urban else 0.2)
        coverage_critical = np.random.random() < (0.3 if urban else 0.4)  # Rural might be more critical
        colocation_count = np.random.poisson(2) + 1  # At least 1 tenant
        technology_layers = np.random.randint(1, 5)  # 1-4 tech generations
        
        # Location characteristics
        premium_location = np.random.random() < (0.3 if urban else 0.1)
        zoning_restricted = np.random.random() < (0.4 if urban else 0.2)
        high_visibility = np.random.random() < (0.5 if urban else 0.3)
        development_potential = np.random.random() < (0.3 if urban else 0.1)
        
        # Geographic coordinates (rough US bounds)
        latitude = np.random.uniform(25.0, 49.0)
        longitude = np.random.uniform(-125.0, -66.0)
        
        return {
            'high_traffic': high_traffic,
            'coverage_critical': coverage_critical,
            'colocation_count': colocation_count,
            'technology_layers': technology_layers,
            'premium_location': premium_location,
            'zoning_restricted': zoning_restricted,
            'high_visibility': high_visibility,
            'development_potential': development_potential,
            'latitude': latitude,
            'longitude': longitude,
            'urban': urban
        }
    
    def _generate_contract_terms(self, escalation_rate: float) -> Dict[str, Any]:
        """Generate contract terms based on escalation rate."""
        # Add some noise to the escalation rate
        contract_escalation = escalation_rate + np.random.normal(0, 0.005)
        
        # Some contracts have CPI escalation instead/in addition
        cpi_escalation = np.random.random() < 0.3
        
        # Some have revenue sharing
        revenue_share_rate = None
        if np.random.random() < 0.1:  # 10% chance
            revenue_share_rate = np.random.uniform(0.05, 0.15)
        
        # Escalation timing
        escalation_start_year = np.random.choice([0, 1, 2], p=[0.6, 0.3, 0.1])
        escalation_frequency = np.random.choice([1, 2, 3], p=[0.7, 0.2, 0.1])
        
        return {
            'annual_escalation': contract_escalation,
            'cpi_escalation': cpi_escalation,
            'revenue_share_rate': revenue_share_rate,
            'escalation_start_year': escalation_start_year,
            'escalation_frequency': escalation_frequency
        }
    
    def _generate_market_factor(self, years: int) -> np.ndarray:
        """Generate realistic market factor with cycles and trends."""
        time_points = np.arange(years)
        
        # Base trend (slight upward)
        trend_slope = self.config['market_trend_slope']
        trend = 1.0 + trend_slope * time_points / years
        
        # Market cycle (7-year real estate cycle)
        cycle_amplitude = self.config['market_cycle_amplitude']
        cycle = cycle_amplitude * np.sin(2 * np.pi * time_points / 7)
        
        # Add shorter-term fluctuations (3-year cycle)
        short_cycle = 0.05 * np.sin(2 * np.pi * time_points / 3)
        
        # Random noise
        noise_level = self.config['noise_level'] * 0.5  # Less noise in market factor
        noise = np.random.normal(0, noise_level, years)
        
        # Combine components
        market_factor = trend + cycle + short_cycle + noise
        
        # Ensure positive and reasonable bounds
        market_factor = np.clip(market_factor, 0.5, 2.0)
        
        return market_factor
    
    def _generate_economic_indicators(self, market_factor: np.ndarray, years: int) -> np.ndarray:
        """Generate economic indicators correlated with market factor."""
        # Base correlation with market factor
        correlation_strength = 0.7
        
        # Generate correlated series
        base_indicator = 100.0  # Starting index value
        trend = 0.02  # 2% annual growth
        
        indicators = np.zeros(years)
        indicators[0] = base_indicator
        
        for year in range(1, years):
            # Trend component
            trend_component = indicators[year-1] * (1 + trend)
            
            # Market-correlated component
            market_component = (market_factor[year] - 1.0) * 20  # Scale market factor effect
            
            # Independent noise
            noise = np.random.normal(0, 2.0)
            
            # Combine with correlation strength
            indicators[year] = (correlation_strength * (trend_component + market_component) + 
                              (1 - correlation_strength) * (trend_component + noise))
        
        return indicators
    
    def _generate_rent_history(
        self, 
        base_rent: float, 
        escalation_rate: float, 
        market_factor: np.ndarray, 
        premium_factor: float, 
        years: int
    ) -> np.ndarray:
        """Generate rent history from components."""
        
        rent_history = np.zeros(years)
        escalation_factor = 1.0
        
        for year in range(years):
            # Apply escalation
            if year > 0:
                escalation_factor *= (1 + escalation_rate)
            
            # Calculate theoretical rent
            theoretical_rent = base_rent * escalation_factor * market_factor[year] * premium_factor
            
            # Add noise
            noise_level = self.config['noise_level']
            noise = np.random.normal(0, noise_level * theoretical_rent)
            
            # Final rent (ensure positive)
            rent_history[year] = max(theoretical_rent + noise, base_rent * 0.5)
        
        return rent_history
    
    def generate_validation_split(
        self, 
        portfolio: List[Dict[str, Any]], 
        test_ratio: float = 0.2
    ) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        """Split portfolio into training and validation sets."""
        
        n_sites = len(portfolio)
        n_test = int(n_sites * test_ratio)
        
        # Randomly select test indices
        test_indices = np.random.choice(n_sites, size=n_test, replace=False)
        train_indices = [i for i in range(n_sites) if i not in test_indices]
        
        train_data = [portfolio[i] for i in train_indices]
        test_data = [portfolio[i] for i in test_indices]
        
        return train_data, test_data
    
    def save_portfolio(self, portfolio: List[Dict[str, Any]], filepath: str):
        """Save portfolio to file."""
        import json
        
        with open(filepath, 'w') as f:
            json.dump(portfolio, f, indent=2)
    
    def load_portfolio(self, filepath: str) -> List[Dict[str, Any]]:
        """Load portfolio from file."""
        import json
        
        with open(filepath, 'r') as f:
            return json.load(f)
    
    def generate_portfolio_summary(self, portfolio: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate summary statistics for a portfolio."""
        
        # Extract component statistics
        base_rents = [site['true_components']['base_rent'] for site in portfolio]
        escalation_rates = [site['true_components']['escalation_rate'] for site in portfolio]
        network_premiums = [site['true_components']['network_premium'] for site in portfolio]
        location_premiums = [site['true_components']['location_premium'] for site in portfolio]
        
        # Site characteristics
        urban_count = sum(1 for site in portfolio if site['site_characteristics']['urban'])
        high_traffic_count = sum(1 for site in portfolio if site['site_characteristics']['high_traffic'])
        
        summary = {
            'portfolio_size': len(portfolio),
            'years_per_site': portfolio[0]['years'] if portfolio else 0,
            'base_rent_stats': {
                'mean': np.mean(base_rents),
                'std': np.std(base_rents),
                'min': np.min(base_rents),
                'max': np.max(base_rents)
            },
            'escalation_rate_stats': {
                'mean': np.mean(escalation_rates),
                'std': np.std(escalation_rates),
                'min': np.min(escalation_rates),
                'max': np.max(escalation_rates)
            },
            'network_premium_stats': {
                'mean': np.mean(network_premiums),
                'std': np.std(network_premiums),
                'min': np.min(network_premiums),
                'max': np.max(network_premiums)
            },
            'location_premium_stats': {
                'mean': np.mean(location_premiums),
                'std': np.std(location_premiums),
                'min': np.min(location_premiums),
                'max': np.max(location_premiums)
            },
            'site_characteristics': {
                'urban_percentage': urban_count / len(portfolio) * 100,
                'high_traffic_percentage': high_traffic_count / len(portfolio) * 100
            }
        }
        
        return summary


# Convenience function for simple data generation
def generate_synthetic_lease_data(
    n_sites: int = 100, 
    years: int = 15, 
    seed: Optional[int] = None
) -> List[Dict[str, Any]]:
    """
    Generate synthetic lease data with default parameters.
    
    Args:
        n_sites: Number of sites to generate
        years: Number of years of history per site
        seed: Random seed for reproducible results
        
    Returns:
        List of site dictionaries with rent history and components
    """
    generator = SyntheticDataGenerator(seed=seed)
    return generator.generate_lease_portfolio(n_sites=n_sites, years=years)


if __name__ == "__main__":
    # Example usage
    generator = SyntheticDataGenerator(seed=42)
    portfolio = generator.generate_lease_portfolio(n_sites=10, years=10)
    
    # Print summary
    summary = generator.generate_portfolio_summary(portfolio)
    print("Portfolio Summary:")
    for key, value in summary.items():
        print(f"  {key}: {value}")
    
    # Print first site details
    print(f"\nFirst site details:")
    site = portfolio[0]
    print(f"  Site ID: {site['site_id']}")
    print(f"  Base rent: ${site['true_components']['base_rent']:.2f}")
    print(f"  Escalation rate: {site['true_components']['escalation_rate']:.1%}")
    print(f"  Network premium: {site['true_components']['network_premium']:.2f}x")
    print(f"  Location premium: {site['true_components']['location_premium']:.2f}x")
    print(f"  Rent history: {[f'${r:.0f}' for r in site['rent_history'][:5]]}...")
