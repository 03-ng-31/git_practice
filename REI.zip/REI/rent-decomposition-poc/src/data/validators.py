"""
Data validation utilities for rent decomposition.
"""
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Any, Tuple
from ..decomposer.components import RentComponents


class DataValidator:
    """Validate decomposition data quality and results."""
    
    def __init__(self, tolerance_config: Optional[Dict[str, float]] = None):
        """
        Initialize data validator.
        
        Args:
            tolerance_config: Configuration for validation tolerances
        """
        self.tolerance = tolerance_config or self._default_tolerances()
    
    def _default_tolerances(self) -> Dict[str, float]:
        """Default validation tolerances."""
        return {
            'reconstruction_mape_max': 15.0,  # Maximum reconstruction error
            'component_correlation_min': 0.7,  # Minimum component correlation
            'escalation_growth_max': 3.0,     # Maximum total escalation growth
            'premium_factor_min': 0.5,        # Minimum premium factor
            'premium_factor_max': 3.0,        # Maximum premium factor
            'noise_ratio_max': 0.3           # Maximum noise-to-signal ratio
        }
    
    def validate_input_data(self, rent_history: List[float]) -> Dict[str, Any]:
        """Validate input rent history data."""
        rent_array = np.array(rent_history)
        
        validation_results = {
            'valid': True,
            'errors': [],
            'warnings': []
        }
        
        # Check minimum length
        if len(rent_array) < 2:
            validation_results['valid'] = False
            validation_results['errors'].append('Need at least 2 years of rent history')
        
        # Check for non-positive values
        if np.any(rent_array <= 0):
            validation_results['valid'] = False
            validation_results['errors'].append('Rent values must be positive')
        
        # Check for extreme outliers
        if len(rent_array) > 1:
            rent_ratios = rent_array[1:] / rent_array[:-1]
            extreme_changes = (rent_ratios > 3.0) | (rent_ratios < 0.3)
            if np.any(extreme_changes):
                validation_results['warnings'].append(
                    f'Extreme rent changes detected: {np.sum(extreme_changes)} years'
                )
        
        # Check for missing values
        if np.any(np.isnan(rent_array)) or np.any(np.isinf(rent_array)):
            validation_results['valid'] = False
            validation_results['errors'].append('Missing or infinite values in rent history')
        
        # Calculate summary statistics
        validation_results['statistics'] = {
            'mean_rent': np.mean(rent_array),
            'std_rent': np.std(rent_array),
            'min_rent': np.min(rent_array),
            'max_rent': np.max(rent_array),
            'total_growth': rent_array[-1] / rent_array[0] - 1 if len(rent_array) > 1 else 0,
            'volatility': np.std(rent_array) / np.mean(rent_array)
        }
        
        return validation_results
    
    def validate_decomposition_results(self, components: RentComponents) -> Dict[str, Any]:
        """Validate decomposition results quality."""
        
        validation_results = {
            'valid': True,
            'errors': [],
            'warnings': [],
            'quality_scores': {}
        }
        
        # 1. Reconstruction accuracy
        reconstruction_mape = components.calculate_reconstruction_mape()
        validation_results['quality_scores']['reconstruction_mape'] = reconstruction_mape
        
        if reconstruction_mape > self.tolerance['reconstruction_mape_max']:
            validation_results['warnings'].append(
                f'High reconstruction error: {reconstruction_mape:.1f}% > {self.tolerance["reconstruction_mape_max"]}%'
            )
        
        # 2. Component correlation
        if len(components.rent_history) > 1:
            reconstruction_corr = np.corrcoef(components.rent_history, components.reconstructed_rent)[0, 1]
            validation_results['quality_scores']['reconstruction_correlation'] = reconstruction_corr
            
            if reconstruction_corr < self.tolerance['component_correlation_min']:
                validation_results['warnings'].append(
                    f'Low reconstruction correlation: {reconstruction_corr:.2f} < {self.tolerance["component_correlation_min"]}'
                )
        
        # 3. Escalation factor validation
        escalation_growth = components.escalation_factor[-1] / components.escalation_factor[0] - 1
        validation_results['quality_scores']['escalation_total_growth'] = escalation_growth
        
        if escalation_growth > self.tolerance['escalation_growth_max']:
            validation_results['warnings'].append(
                f'Extreme escalation growth: {escalation_growth:.1f} > {self.tolerance["escalation_growth_max"]}'
            )
        
        if escalation_growth < 0:
            validation_results['warnings'].append('Negative total escalation growth detected')
        
        # 4. Premium factor validation
        validation_results['quality_scores']['premium_factor'] = components.premium_factor
        
        if components.premium_factor < self.tolerance['premium_factor_min']:
            validation_results['warnings'].append(
                f'Low premium factor: {components.premium_factor:.2f} < {self.tolerance["premium_factor_min"]}'
            )
        
        if components.premium_factor > self.tolerance['premium_factor_max']:
            validation_results['warnings'].append(
                f'High premium factor: {components.premium_factor:.2f} > {self.tolerance["premium_factor_max"]}'
            )
        
        # 5. Market factor validation
        market_volatility = np.std(components.market_factor)
        validation_results['quality_scores']['market_volatility'] = market_volatility
        
        if market_volatility > 0.5:
            validation_results['warnings'].append(
                f'High market factor volatility: {market_volatility:.2f}'
            )
        
        # 6. Noise analysis
        noise_to_signal = np.std(components.noise) / np.std(components.rent_history)
        validation_results['quality_scores']['noise_to_signal_ratio'] = noise_to_signal
        
        if noise_to_signal > self.tolerance['noise_ratio_max']:
            validation_results['warnings'].append(
                f'High noise ratio: {noise_to_signal:.2f} > {self.tolerance["noise_ratio_max"]}'
            )
        
        # 7. Component reasonableness
        validation_results['quality_scores'].update({
            'escalation_monotonic': float(np.all(np.diff(components.escalation_factor) >= -0.01)),
            'market_bounded': float(np.all((components.market_factor >= 0.2) & (components.market_factor <= 2.0))),
            'noise_zero_mean': float(abs(np.mean(components.noise)) < 0.1 * np.std(components.noise))
        })
        
        # Overall quality score
        quality_components = [
            min(1.0, max(0.0, (100 - reconstruction_mape) / 100)),  # Reconstruction accuracy
            max(0.0, reconstruction_corr) if len(components.rent_history) > 1 else 0.5,  # Correlation
            validation_results['quality_scores']['escalation_monotonic'],
            validation_results['quality_scores']['market_bounded'],
            validation_results['quality_scores']['noise_zero_mean'],
            max(0.0, 1.0 - noise_to_signal)  # Lower noise is better
        ]
        
        validation_results['overall_quality'] = np.mean(quality_components)
        
        return validation_results
    
    def validate_ground_truth_comparison(
        self, 
        components: RentComponents, 
        true_components: Dict[str, Any]
    ) -> Dict[str, float]:
        """Validate decomposed components against ground truth."""
        
        validation_metrics = {}
        
        # Base rent validation
        if 'base_rent' in true_components:
            true_base = true_components['base_rent']
            base_error = abs(components.base_rent - true_base) / true_base * 100
            validation_metrics['base_rent_mape'] = base_error
            validation_metrics['base_rent_accurate'] = float(base_error < 5.0)  # Within 5%
        
        # Escalation rate validation
        if 'escalation_rate' in true_components:
            true_rate = true_components['escalation_rate']
            # Estimate average annual rate from escalation factor
            if components.years > 1:
                est_rate = (components.escalation_factor[-1] / components.escalation_factor[0]) ** (1.0 / (components.years - 1)) - 1
                rate_error = abs(est_rate - true_rate) / max(true_rate, 0.01) * 100
                validation_metrics['escalation_rate_mape'] = rate_error
                validation_metrics['escalation_rate_accurate'] = float(rate_error < 20.0)  # Within 20%
        
        # Market factor validation
        if 'market_factor' in true_components:
            true_market = np.array(true_components['market_factor'])
            if len(true_market) == len(components.market_factor):
                market_mape = np.mean(np.abs((true_market - components.market_factor) / true_market)) * 100
                market_corr = np.corrcoef(true_market, components.market_factor)[0, 1]
                
                validation_metrics['market_factor_mape'] = market_mape
                validation_metrics['market_factor_correlation'] = market_corr
                validation_metrics['market_factor_accurate'] = float(market_mape < 15.0 and market_corr > 0.7)
        
        # Premium factor validation
        total_premium_key = 'total_premium'
        if total_premium_key in true_components:
            true_premium = true_components[total_premium_key]
            premium_error = abs(components.premium_factor - true_premium) / true_premium * 100
            validation_metrics['premium_factor_mape'] = premium_error
            validation_metrics['premium_factor_accurate'] = float(premium_error < 10.0)  # Within 10%
        
        elif 'network_premium' in true_components and 'location_premium' in true_components:
            true_premium = true_components['network_premium'] * true_components['location_premium']
            premium_error = abs(components.premium_factor - true_premium) / true_premium * 100
            validation_metrics['premium_factor_mape'] = premium_error
            validation_metrics['premium_factor_accurate'] = float(premium_error < 10.0)
        
        # Overall accuracy score
        accuracy_components = []
        for key in ['base_rent_accurate', 'escalation_rate_accurate', 'market_factor_accurate', 'premium_factor_accurate']:
            if key in validation_metrics:
                accuracy_components.append(validation_metrics[key])
        
        if accuracy_components:
            validation_metrics['overall_accuracy'] = np.mean(accuracy_components)
        
        return validation_metrics
    
    def generate_validation_report(
        self, 
        components_list: List[RentComponents],
        true_components_list: Optional[List[Dict[str, Any]]] = None
    ) -> Dict[str, Any]:
        """Generate comprehensive validation report for multiple sites."""
        
        report = {
            'summary': {
                'total_sites': len(components_list),
                'validation_timestamp': pd.Timestamp.now().isoformat()
            },
            'quality_distribution': {},
            'error_statistics': {},
            'component_statistics': {}
        }
        
        # Collect metrics for all sites
        quality_scores = []
        reconstruction_errors = []
        component_accuracies = []
        
        for i, components in enumerate(components_list):
            # Validate decomposition quality
            validation_result = self.validate_decomposition_results(components)
            quality_scores.append(validation_result['overall_quality'])
            reconstruction_errors.append(validation_result['quality_scores']['reconstruction_mape'])
            
            # Compare against ground truth if available
            if true_components_list and i < len(true_components_list):
                ground_truth_metrics = self.validate_ground_truth_comparison(
                    components, true_components_list[i]
                )
                if 'overall_accuracy' in ground_truth_metrics:
                    component_accuracies.append(ground_truth_metrics['overall_accuracy'])
        
        # Quality distribution
        report['quality_distribution'] = {
            'mean_quality': np.mean(quality_scores),
            'std_quality': np.std(quality_scores),
            'high_quality_sites': np.sum(np.array(quality_scores) > 0.8),  # >80% quality
            'low_quality_sites': np.sum(np.array(quality_scores) < 0.5),   # <50% quality
        }
        
        # Error statistics
        report['error_statistics'] = {
            'mean_reconstruction_mape': np.mean(reconstruction_errors),
            'median_reconstruction_mape': np.median(reconstruction_errors),
            'sites_within_10pct_error': np.sum(np.array(reconstruction_errors) < 10.0),
            'sites_within_15pct_error': np.sum(np.array(reconstruction_errors) < 15.0)
        }
        
        # Component accuracy (if ground truth available)
        if component_accuracies:
            report['component_statistics'] = {
                'mean_component_accuracy': np.mean(component_accuracies),
                'sites_with_high_accuracy': np.sum(np.array(component_accuracies) > 0.85)
            }
        
        return report
