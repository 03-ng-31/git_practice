"""
Visualization utilities for rent decomposition results.
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, List, Optional, Any, Tuple
from ..decomposer.components import RentComponents


class DecompositionPlotter:
    """Create visualizations for rent decomposition analysis."""
    
    def __init__(self, style: str = "seaborn-v0_8", figsize: Tuple[int, int] = (12, 8)):
        """
        Initialize plotter with style settings.
        
        Args:
            style: Matplotlib style
            figsize: Default figure size
        """
        plt.style.use(style)
        self.figsize = figsize
        self.colors = plt.cm.Set2(np.linspace(0, 1, 8))
    
    def plot_component_decomposition(
        self, 
        components: RentComponents,
        true_components: Optional[Dict[str, Any]] = None,
        save_path: Optional[str] = None
    ) -> plt.Figure:
        """
        Plot complete component decomposition for a single site.
        
        Args:
            components: Decomposed components
            true_components: Ground truth components (if available)
            save_path: Path to save figure
            
        Returns:
            Matplotlib figure
        """
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        fig.suptitle(f'Rent Decomposition Analysis - {components.site_id}', fontsize=16)
        
        years = np.arange(components.years)
        
        # 1. Original vs Reconstructed Rent
        ax1 = axes[0, 0]
        ax1.plot(years, components.rent_history, 'o-', label='Actual Rent', color=self.colors[0], linewidth=2)
        ax1.plot(years, components.reconstructed_rent, 's-', label='Reconstructed', color=self.colors[1], linewidth=2)
        ax1.set_title('Rent History: Actual vs Reconstructed')
        ax1.set_xlabel('Years')
        ax1.set_ylabel('Rent ($)')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # Add reconstruction error text
        mape = components.calculate_reconstruction_mape()
        ax1.text(0.02, 0.98, f'MAPE: {mape:.2f}%', transform=ax1.transAxes, 
                verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
        # 2. Component Breakdown
        ax2 = axes[0, 1]
        base_line = np.full(components.years, components.base_rent)
        escalated_line = base_line * components.escalation_factor
        market_adjusted_line = escalated_line * components.market_factor
        final_line = market_adjusted_line * components.premium_factor
        
        ax2.plot(years, base_line, '-', label=f'Base Rent (${components.base_rent:.0f})', color=self.colors[0])
        ax2.plot(years, escalated_line, '-', label='+ Escalation', color=self.colors[1])
        ax2.plot(years, market_adjusted_line, '-', label='+ Market Effect', color=self.colors[2])
        ax2.plot(years, final_line, '-', label=f'+ Premium ({components.premium_factor:.2f}x)', color=self.colors[3], linewidth=2)
        ax2.plot(years, components.rent_history, 'o', label='Actual Rent', color='red', alpha=0.7)
        
        ax2.set_title('Component Buildup')
        ax2.set_xlabel('Years')
        ax2.set_ylabel('Rent ($)')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        # 3. Individual Components
        ax3 = axes[1, 0]
        ax3_twin = ax3.twinx()
        
        # Escalation factor (left axis)
        line1 = ax3.plot(years, components.escalation_factor, 'o-', label='Escalation Factor', 
                        color=self.colors[0], linewidth=2)
        ax3.set_ylabel('Escalation Factor', color=self.colors[0])
        ax3.tick_params(axis='y', labelcolor=self.colors[0])
        
        # Market factor (right axis)
        line2 = ax3_twin.plot(years, components.market_factor, 's-', label='Market Factor', 
                             color=self.colors[2], linewidth=2)
        ax3_twin.set_ylabel('Market Factor', color=self.colors[2])
        ax3_twin.tick_params(axis='y', labelcolor=self.colors[2])
        
        ax3.set_title('Escalation and Market Factors')
        ax3.set_xlabel('Years')
        ax3.grid(True, alpha=0.3)
        
        # Combined legend
        lines1, labels1 = ax3.get_legend_handles_labels()
        lines2, labels2 = ax3_twin.get_legend_handles_labels()
        ax3.legend(lines1 + lines2, labels1 + labels2, loc='upper left')
        
        # 4. Residual Analysis
        ax4 = axes[1, 1]
        ax4.plot(years, components.noise, 'o-', label='Noise/Residual', color=self.colors[4])
        ax4.axhline(y=0, color='black', linestyle='--', alpha=0.5)
        ax4.set_title('Noise/Residual Component')
        ax4.set_xlabel('Years')
        ax4.set_ylabel('Residual ($)')
        ax4.legend()
        ax4.grid(True, alpha=0.3)
        
        # Add noise statistics
        noise_std = np.std(components.noise)
        noise_mean = np.mean(components.noise)
        ax4.text(0.02, 0.98, f'Std: ${noise_std:.0f}\nMean: ${noise_mean:.0f}', 
                transform=ax4.transAxes, verticalalignment='top',
                bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.5))
        
        plt.tight_layout()
        
        if save_path:
            fig.savefig(save_path, dpi=300, bbox_inches='tight')
        
        return fig
    
    def plot_ground_truth_comparison(
        self, 
        components: RentComponents,
        true_components: Dict[str, Any],
        save_path: Optional[str] = None
    ) -> plt.Figure:
        """
        Compare decomposed components against ground truth.
        
        Args:
            components: Decomposed components
            true_components: Ground truth components
            save_path: Path to save figure
            
        Returns:
            Matplotlib figure
        """
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        fig.suptitle(f'Ground Truth Comparison - {components.site_id}', fontsize=16)
        
        years = np.arange(components.years)
        
        # 1. Market Factor Comparison
        ax1 = axes[0, 0]
        if 'market_factor' in true_components:
            true_market = np.array(true_components['market_factor'])
            ax1.plot(years, true_market, 'o-', label='True Market Factor', color=self.colors[0], linewidth=2)
            ax1.plot(years, components.market_factor, 's-', label='Estimated Market Factor', 
                    color=self.colors[1], linewidth=2)
            
            # Calculate correlation
            if len(true_market) == len(components.market_factor):
                corr = np.corrcoef(true_market, components.market_factor)[0, 1]
                ax1.text(0.02, 0.98, f'Correlation: {corr:.3f}', transform=ax1.transAxes,
                        verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
        ax1.set_title('Market Factor: True vs Estimated')
        ax1.set_xlabel('Years')
        ax1.set_ylabel('Market Factor')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # 2. Escalation Factor Comparison
        ax2 = axes[0, 1]
        if 'escalation_rate' in true_components:
            true_rate = true_components['escalation_rate']
            true_escalation = np.array([((1 + true_rate) ** year) for year in range(components.years)])
            
            ax2.plot(years, true_escalation, 'o-', label='True Escalation', color=self.colors[0], linewidth=2)
            ax2.plot(years, components.escalation_factor, 's-', label='Estimated Escalation', 
                    color=self.colors[1], linewidth=2)
            
            ax2.text(0.02, 0.98, f'True Rate: {true_rate:.1%}', transform=ax2.transAxes,
                    verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
        ax2.set_title('Escalation Factor: True vs Estimated')
        ax2.set_xlabel('Years')
        ax2.set_ylabel('Escalation Factor')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        # 3. Premium Factor Comparison
        ax3 = axes[1, 0]
        if 'network_premium' in true_components and 'location_premium' in true_components:
            true_network = true_components['network_premium']
            true_location = true_components['location_premium']
            true_total = true_network * true_location
            
            categories = ['Network\nPremium', 'Location\nPremium', 'Total\nPremium']
            true_values = [true_network, true_location, true_total]
            estimated_values = [true_network, true_location, components.premium_factor]  # We don't separate these
            
            x = np.arange(len(categories))
            width = 0.35
            
            ax3.bar(x - width/2, true_values, width, label='True', color=self.colors[0], alpha=0.7)
            ax3.bar(x + width/2, [true_network, true_location, components.premium_factor], width, 
                   label='Estimated', color=self.colors[1], alpha=0.7)
            
            ax3.set_title('Premium Factors')
            ax3.set_ylabel('Premium Multiplier')
            ax3.set_xticks(x)
            ax3.set_xticklabels(categories)
            ax3.legend()
            ax3.grid(True, alpha=0.3)
            
            # Add error text
            total_error = abs(components.premium_factor - true_total) / true_total * 100
            ax3.text(0.02, 0.98, f'Total Premium Error: {total_error:.1f}%', 
                    transform=ax3.transAxes, verticalalignment='top',
                    bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
        # 4. Component Errors
        ax4 = axes[1, 1]
        error_components = []
        error_labels = []
        
        # Base rent error
        if 'base_rent' in true_components:
            base_error = abs(components.base_rent - true_components['base_rent']) / true_components['base_rent'] * 100
            error_components.append(base_error)
            error_labels.append('Base Rent')
        
        # Market factor error
        if 'market_factor' in true_components:
            true_market = np.array(true_components['market_factor'])
            if len(true_market) == len(components.market_factor):
                market_error = np.mean(np.abs((true_market - components.market_factor) / true_market)) * 100
                error_components.append(market_error)
                error_labels.append('Market Factor')
        
        # Premium error
        if 'network_premium' in true_components and 'location_premium' in true_components:
            true_total = true_components['network_premium'] * true_components['location_premium']
            premium_error = abs(components.premium_factor - true_total) / true_total * 100
            error_components.append(premium_error)
            error_labels.append('Premium Factor')
        
        if error_components:
            bars = ax4.bar(error_labels, error_components, color=self.colors[:len(error_components)], alpha=0.7)
            ax4.set_title('Component Errors (MAPE %)')
            ax4.set_ylabel('Mean Absolute Percentage Error (%)')
            ax4.grid(True, alpha=0.3)
            
            # Add value labels on bars
            for bar, error in zip(bars, error_components):
                height = bar.get_height()
                ax4.text(bar.get_x() + bar.get_width()/2., height + 0.5,
                        f'{error:.1f}%', ha='center', va='bottom')
        
        plt.tight_layout()
        
        if save_path:
            fig.savefig(save_path, dpi=300, bbox_inches='tight')
        
        return fig
    
    def plot_portfolio_summary(
        self, 
        components_list: List[RentComponents],
        true_components_list: Optional[List[Dict[str, Any]]] = None,
        save_path: Optional[str] = None
    ) -> plt.Figure:
        """
        Create summary plots for a portfolio of sites.
        
        Args:
            components_list: List of decomposed components
            true_components_list: List of ground truth components
            save_path: Path to save figure
            
        Returns:
            Matplotlib figure
        """
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        fig.suptitle(f'Portfolio Analysis - {len(components_list)} Sites', fontsize=16)
        
        # Extract portfolio metrics
        reconstruction_errors = [comp.calculate_reconstruction_mape() for comp in components_list]
        base_rents = [comp.base_rent for comp in components_list]
        premium_factors = [comp.premium_factor for comp in components_list]
        escalation_growth = [(comp.escalation_factor[-1] / comp.escalation_factor[0] - 1) 
                           for comp in components_list]
        confidence_scores = [comp.confidence_scores.get('overall_confidence', 0) 
                           for comp in components_list]
        
        # 1. Reconstruction Error Distribution
        ax1 = axes[0, 0]
        ax1.hist(reconstruction_errors, bins=20, color=self.colors[0], alpha=0.7, edgecolor='black')
        ax1.axvline(np.mean(reconstruction_errors), color='red', linestyle='--', 
                   label=f'Mean: {np.mean(reconstruction_errors):.1f}%')
        ax1.set_title('Reconstruction Error Distribution')
        ax1.set_xlabel('MAPE (%)')
        ax1.set_ylabel('Number of Sites')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # 2. Base Rent Distribution
        ax2 = axes[0, 1]
        ax2.hist(base_rents, bins=20, color=self.colors[1], alpha=0.7, edgecolor='black')
        ax2.axvline(np.mean(base_rents), color='red', linestyle='--', 
                   label=f'Mean: ${np.mean(base_rents):.0f}')
        ax2.set_title('Base Rent Distribution')
        ax2.set_xlabel('Base Rent ($)')
        ax2.set_ylabel('Number of Sites')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        # 3. Premium Factor Distribution
        ax3 = axes[0, 2]
        ax3.hist(premium_factors, bins=20, color=self.colors[2], alpha=0.7, edgecolor='black')
        ax3.axvline(np.mean(premium_factors), color='red', linestyle='--', 
                   label=f'Mean: {np.mean(premium_factors):.2f}x')
        ax3.set_title('Premium Factor Distribution')
        ax3.set_xlabel('Premium Factor')
        ax3.set_ylabel('Number of Sites')
        ax3.legend()
        ax3.grid(True, alpha=0.3)
        
        # 4. Escalation Growth vs Reconstruction Error
        ax4 = axes[1, 0]
        scatter = ax4.scatter(escalation_growth, reconstruction_errors, 
                            c=confidence_scores, cmap='viridis', alpha=0.6)
        ax4.set_title('Escalation Growth vs Reconstruction Error')
        ax4.set_xlabel('Total Escalation Growth')
        ax4.set_ylabel('Reconstruction MAPE (%)')
        ax4.grid(True, alpha=0.3)
        plt.colorbar(scatter, ax=ax4, label='Confidence Score')
        
        # 5. Confidence Score Distribution
        ax5 = axes[1, 1]
        ax5.hist(confidence_scores, bins=20, color=self.colors[3], alpha=0.7, edgecolor='black')
        ax5.axvline(np.mean(confidence_scores), color='red', linestyle='--', 
                   label=f'Mean: {np.mean(confidence_scores):.2f}')
        ax5.set_title('Confidence Score Distribution')
        ax5.set_xlabel('Overall Confidence')
        ax5.set_ylabel('Number of Sites')
        ax5.legend()
        ax5.grid(True, alpha=0.3)
        
        # 6. Ground Truth Accuracy (if available)
        ax6 = axes[1, 2]
        if true_components_list:
            # Calculate component accuracies
            market_correlations = []
            premium_errors = []
            
            for comp, true_comp in zip(components_list, true_components_list):
                if 'market_factor' in true_comp:
                    true_market = np.array(true_comp['market_factor'])
                    if len(true_market) == len(comp.market_factor):
                        corr = np.corrcoef(true_market, comp.market_factor)[0, 1]
                        market_correlations.append(corr)
                
                if 'network_premium' in true_comp and 'location_premium' in true_comp:
                    true_premium = true_comp['network_premium'] * true_comp['location_premium']
                    error = abs(comp.premium_factor - true_premium) / true_premium * 100
                    premium_errors.append(error)
            
            if market_correlations and premium_errors:
                ax6.scatter(market_correlations, premium_errors, alpha=0.6, color=self.colors[4])
                ax6.set_title('Market Correlation vs Premium Error')
                ax6.set_xlabel('Market Factor Correlation')
                ax6.set_ylabel('Premium Factor Error (%)')
                ax6.grid(True, alpha=0.3)
            else:
                ax6.text(0.5, 0.5, 'Ground Truth\nNot Available', 
                        horizontalalignment='center', verticalalignment='center',
                        transform=ax6.transAxes, fontsize=12)
                ax6.set_title('Ground Truth Comparison')
        else:
            ax6.text(0.5, 0.5, 'Ground Truth\nNot Available', 
                    horizontalalignment='center', verticalalignment='center',
                    transform=ax6.transAxes, fontsize=12)
            ax6.set_title('Ground Truth Comparison')
        
        plt.tight_layout()
        
        if save_path:
            fig.savefig(save_path, dpi=300, bbox_inches='tight')
        
        return fig


def plot_decomposition_results(
    components: RentComponents,
    true_components: Optional[Dict[str, Any]] = None,
    save_path: Optional[str] = None
) -> plt.Figure:
    """
    Convenience function to plot decomposition results.
    
    Args:
        components: Decomposed components
        true_components: Ground truth components (if available)
        save_path: Path to save figure
        
    Returns:
        Matplotlib figure
    """
    plotter = DecompositionPlotter()
    
    if true_components:
        return plotter.plot_ground_truth_comparison(components, true_components, save_path)
    else:
        return plotter.plot_component_decomposition(components, save_path=save_path)
