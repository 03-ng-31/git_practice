"""
Metrics and evaluation utilities for rent decomposition.
"""
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Any, Tuple
from scipy.stats import pearsonr
from sklearn.metrics import mean_absolute_error, mean_squared_error
from ..decomposer.components import RentComponents


class ValidationMetrics:
    """Calculate validation metrics for rent decomposition."""
    
    @staticmethod
    def mean_absolute_percentage_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
        """Calculate Mean Absolute Percentage Error."""
        return np.mean(np.abs((y_true - y_pred) / y_true)) * 100
    
    @staticmethod
    def symmetric_mean_absolute_percentage_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
        """Calculate Symmetric Mean Absolute Percentage Error."""
        return np.mean(2 * np.abs(y_true - y_pred) / (np.abs(y_true) + np.abs(y_pred))) * 100
    
    @staticmethod
    def normalized_root_mean_square_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
        """Calculate Normalized Root Mean Square Error."""
        rmse = np.sqrt(mean_squared_error(y_true, y_pred))
        return rmse / np.std(y_true)
    
    @staticmethod
    def directional_accuracy(y_true: np.ndarray, y_pred: np.ndarray) -> float:
        """Calculate directional accuracy for time series."""
        if len(y_true) < 2:
            return 0.0
        
        true_direction = np.diff(y_true) > 0
        pred_direction = np.diff(y_pred) > 0
        
        return np.mean(true_direction == pred_direction) * 100
    
    @staticmethod
    def r_squared(y_true: np.ndarray, y_pred: np.ndarray) -> float:
        """Calculate R-squared coefficient of determination."""
        ss_res = np.sum((y_true - y_pred) ** 2)
        ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
        
        if ss_tot == 0:
            return 0.0
        
        return 1 - (ss_res / ss_tot)


def calculate_component_metrics(
    components: RentComponents,
    true_components: Optional[Dict[str, Any]] = None
) -> Dict[str, float]:
    """
    Calculate comprehensive metrics for component decomposition.
    
    Args:
        components: Decomposed rent components
        true_components: Ground truth components (if available)
        
    Returns:
        Dictionary of calculated metrics
    """
    metrics = {}
    
    # 1. Reconstruction Quality Metrics
    reconstruction_mape = ValidationMetrics.mean_absolute_percentage_error(
        components.rent_history, components.reconstructed_rent
    )
    metrics['reconstruction_mape'] = reconstruction_mape
    
    reconstruction_smape = ValidationMetrics.symmetric_mean_absolute_percentage_error(
        components.rent_history, components.reconstructed_rent
    )
    metrics['reconstruction_smape'] = reconstruction_smape
    
    reconstruction_r2 = ValidationMetrics.r_squared(
        components.rent_history, components.reconstructed_rent
    )
    metrics['reconstruction_r2'] = reconstruction_r2
    
    if len(components.rent_history) > 1:
        reconstruction_corr, _ = pearsonr(components.rent_history, components.reconstructed_rent)
        metrics['reconstruction_correlation'] = reconstruction_corr
        
        directional_acc = ValidationMetrics.directional_accuracy(
            components.rent_history, components.reconstructed_rent
        )
        metrics['reconstruction_directional_accuracy'] = directional_acc
    
    # 2. Component Reasonableness Metrics
    # Escalation factor metrics
    escalation_total_growth = components.escalation_factor[-1] / components.escalation_factor[0] - 1
    metrics['escalation_total_growth'] = escalation_total_growth
    
    escalation_monotonic = np.all(np.diff(components.escalation_factor) >= -0.001)
    metrics['escalation_monotonic'] = float(escalation_monotonic)
    
    if components.years > 1:
        avg_escalation_rate = (components.escalation_factor[-1] / components.escalation_factor[0]) ** (1.0 / (components.years - 1)) - 1
        metrics['avg_escalation_rate'] = avg_escalation_rate
    
    # Market factor metrics
    market_volatility = np.std(components.market_factor)
    metrics['market_volatility'] = market_volatility
    
    market_mean = np.mean(components.market_factor)
    metrics['market_mean'] = market_mean
    
    market_bounded = np.all((components.market_factor >= 0.2) & (components.market_factor <= 2.0))
    metrics['market_bounded'] = float(market_bounded)
    
    if components.years > 1:
        market_trend = np.polyfit(range(components.years), components.market_factor, 1)[0]
        metrics['market_trend'] = market_trend
    
    # Premium factor metrics
    metrics['premium_factor'] = components.premium_factor
    premium_reasonable = (0.5 <= components.premium_factor <= 3.0)
    metrics['premium_reasonable'] = float(premium_reasonable)
    
    # Noise metrics
    noise_std = np.std(components.noise)
    noise_mean = np.mean(components.noise)
    noise_to_signal_ratio = noise_std / np.std(components.rent_history)
    
    metrics['noise_std'] = noise_std
    metrics['noise_mean'] = noise_mean
    metrics['noise_to_signal_ratio'] = noise_to_signal_ratio
    metrics['noise_zero_mean'] = float(abs(noise_mean) < 0.1 * noise_std) if noise_std > 0 else 1.0
    
    # 3. Overall Quality Score
    quality_components = [
        min(1.0, max(0.0, (100 - reconstruction_mape) / 100)),  # Reconstruction accuracy (0-1)
        max(0.0, reconstruction_r2),  # R-squared (0-1)
        metrics['escalation_monotonic'],  # Escalation monotonicity (0-1)
        metrics['market_bounded'],  # Market factor reasonableness (0-1)
        metrics['premium_reasonable'],  # Premium factor reasonableness (0-1)
        max(0.0, min(1.0, 1.0 - noise_to_signal_ratio))  # Lower noise is better (0-1)
    ]
    
    metrics['overall_quality_score'] = np.mean(quality_components)
    
    # 4. Ground Truth Comparison (if available)
    if true_components:
        ground_truth_metrics = _calculate_ground_truth_metrics(components, true_components)
        metrics.update(ground_truth_metrics)
        
        # Overall accuracy score (only if ground truth is available)
        accuracy_components = []
        for key in ['base_rent_accurate', 'escalation_rate_accurate', 
                   'market_factor_accurate', 'premium_factor_accurate']:
            if key in metrics:
                accuracy_components.append(metrics[key])
        
        if accuracy_components:
            metrics['overall_accuracy_score'] = np.mean(accuracy_components)
    
    return metrics


def _calculate_ground_truth_metrics(
    components: RentComponents,
    true_components: Dict[str, Any]
) -> Dict[str, float]:
    """Calculate metrics comparing against ground truth."""
    metrics = {}
    
    # Base rent comparison
    if 'base_rent' in true_components:
        true_base = true_components['base_rent']
        base_error = abs(components.base_rent - true_base) / true_base * 100
        metrics['base_rent_mape'] = base_error
        metrics['base_rent_accurate'] = float(base_error < 5.0)  # Within 5%
    
    # Escalation rate comparison
    if 'escalation_rate' in true_components:
        true_rate = true_components['escalation_rate']
        if components.years > 1:
            # Estimate average rate from escalation factor
            est_rate = (components.escalation_factor[-1] / components.escalation_factor[0]) ** (1.0 / (components.years - 1)) - 1
            rate_error = abs(est_rate - true_rate) / max(true_rate, 0.01) * 100
            metrics['escalation_rate_mape'] = rate_error
            metrics['escalation_rate_accurate'] = float(rate_error < 20.0)  # Within 20%
    
    # Market factor comparison
    if 'market_factor' in true_components:
        true_market = np.array(true_components['market_factor'])
        if len(true_market) == len(components.market_factor):
            market_mape = ValidationMetrics.mean_absolute_percentage_error(
                true_market, components.market_factor
            )
            market_corr, _ = pearsonr(true_market, components.market_factor)
            market_r2 = ValidationMetrics.r_squared(true_market, components.market_factor)
            
            metrics['market_factor_mape'] = market_mape
            metrics['market_factor_correlation'] = market_corr
            metrics['market_factor_r2'] = market_r2
            metrics['market_factor_accurate'] = float(market_mape < 15.0 and market_corr > 0.7)
    
    # Premium factor comparison
    if 'total_premium' in true_components:
        true_premium = true_components['total_premium']
        premium_error = abs(components.premium_factor - true_premium) / true_premium * 100
        metrics['premium_factor_mape'] = premium_error
        metrics['premium_factor_accurate'] = float(premium_error < 10.0)  # Within 10%
    
    elif 'network_premium' in true_components and 'location_premium' in true_components:
        true_premium = true_components['network_premium'] * true_components['location_premium']
        premium_error = abs(components.premium_factor - true_premium) / true_premium * 100
        metrics['premium_factor_mape'] = premium_error
        metrics['premium_factor_accurate'] = float(premium_error < 10.0)
    
    return metrics


def calculate_portfolio_metrics(
    components_list: List[RentComponents],
    true_components_list: Optional[List[Dict[str, Any]]] = None
) -> Dict[str, Any]:
    """
    Calculate aggregate metrics for a portfolio of sites.
    
    Args:
        components_list: List of decomposed components
        true_components_list: List of ground truth components
        
    Returns:
        Dictionary of portfolio-level metrics
    """
    portfolio_metrics = {}
    
    # Calculate individual site metrics
    site_metrics = []
    for i, components in enumerate(components_list):
        true_comp = true_components_list[i] if true_components_list and i < len(true_components_list) else None
        metrics = calculate_component_metrics(components, true_comp)
        site_metrics.append(metrics)
    
    # Aggregate metrics across portfolio
    metric_keys = site_metrics[0].keys() if site_metrics else []
    
    for key in metric_keys:
        values = [metrics[key] for metrics in site_metrics if key in metrics and not np.isnan(metrics[key])]
        
        if values:
            portfolio_metrics[f'{key}_mean'] = np.mean(values)
            portfolio_metrics[f'{key}_std'] = np.std(values)
            portfolio_metrics[f'{key}_median'] = np.median(values)
            portfolio_metrics[f'{key}_min'] = np.min(values)
            portfolio_metrics[f'{key}_max'] = np.max(values)
    
    # Success rate metrics
    if site_metrics:
        # Sites with reconstruction MAPE < 15%
        good_reconstruction = sum(1 for m in site_metrics 
                                if m.get('reconstruction_mape', 100) < 15.0)
        portfolio_metrics['sites_good_reconstruction'] = good_reconstruction
        portfolio_metrics['sites_good_reconstruction_pct'] = good_reconstruction / len(site_metrics) * 100
        
        # Sites with high overall quality (> 0.8)
        high_quality = sum(1 for m in site_metrics 
                         if m.get('overall_quality_score', 0) > 0.8)
        portfolio_metrics['sites_high_quality'] = high_quality
        portfolio_metrics['sites_high_quality_pct'] = high_quality / len(site_metrics) * 100
        
        # Sites with reasonable premium factors
        reasonable_premium = sum(1 for m in site_metrics 
                               if m.get('premium_reasonable', 0) > 0.5)
        portfolio_metrics['sites_reasonable_premium'] = reasonable_premium
        portfolio_metrics['sites_reasonable_premium_pct'] = reasonable_premium / len(site_metrics) * 100
    
    # Portfolio summary
    portfolio_metrics['total_sites'] = len(components_list)
    
    return portfolio_metrics


def generate_metrics_summary_table(metrics: Dict[str, float]) -> pd.DataFrame:
    """
    Generate a formatted summary table of metrics.
    
    Args:
        metrics: Dictionary of metrics
        
    Returns:
        Pandas DataFrame with formatted metrics
    """
    summary_data = []
    
    # Group metrics by category
    categories = {
        'Reconstruction Quality': [
            'reconstruction_mape', 'reconstruction_smape', 'reconstruction_r2', 
            'reconstruction_correlation', 'reconstruction_directional_accuracy'
        ],
        'Component Quality': [
            'escalation_total_growth', 'escalation_monotonic', 'avg_escalation_rate',
            'market_volatility', 'market_mean', 'market_bounded', 'market_trend',
            'premium_factor', 'premium_reasonable'
        ],
        'Noise Analysis': [
            'noise_std', 'noise_mean', 'noise_to_signal_ratio', 'noise_zero_mean'
        ],
        'Overall Scores': [
            'overall_quality_score', 'overall_accuracy_score'
        ],
        'Ground Truth Comparison': [
            'base_rent_mape', 'escalation_rate_mape', 'market_factor_mape', 
            'market_factor_correlation', 'premium_factor_mape'
        ]
    }
    
    for category, metric_keys in categories.items():
        for key in metric_keys:
            if key in metrics:
                value = metrics[key]
                
                # Format value based on type
                if 'mape' in key or 'error' in key:
                    formatted_value = f"{value:.2f}%"
                elif 'correlation' in key or 'r2' in key:
                    formatted_value = f"{value:.3f}"
                elif 'score' in key:
                    formatted_value = f"{value:.3f}"
                elif isinstance(value, float):
                    formatted_value = f"{value:.3f}"
                else:
                    formatted_value = str(value)
                
                summary_data.append({
                    'Category': category,
                    'Metric': key.replace('_', ' ').title(),
                    'Value': formatted_value
                })
    
    return pd.DataFrame(summary_data)
