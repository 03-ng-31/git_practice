import unittest
from chatbot.agent import get_response
from chatbot.config import memory

class TestChatbot(unittest.TestCase):
    def test_update_address(self):
        user_input = "i need to update my address"
        response = get_response(user_input, memory)
        self.assertIn("Address updated", response)

if __name__ == "__main__":
    unittest.main()