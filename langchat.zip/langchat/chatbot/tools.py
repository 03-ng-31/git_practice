from langchain.tools import tool
from pydantic import BaseModel, Field

class ChangeEmailInput(BaseModel):
    current_email: str = Field(description="Current email address")
    new_email: str = Field(description="New email address")

@tool("change_email_tool", args_schema=ChangeEmailInput)
def change_email(current_email: str, new_email: str) -> str:
    '''Change the user's email address in the database.'''
    return f"Email changed from {current_email} to {new_email}"

class SubmitInquiryInput(BaseModel):
    inquiry: str = Field(description="User inquiry")

@tool("submit_inquiry_tool", args_schema=SubmitInquiryInput)
def submit_inquiry(inquiry: str) -> str:
    '''Submit the user's inquiry.'''
    return f"Inquiry submitted: {inquiry}"

class UpdateAddressInput(BaseModel):
    street: str = Field(description="Street address")
    city: str = Field(description="City")
    state: str = Field(description="State")
    zip_code: str = Field(description="Zip code")

@tool("update_address_tool", args_schema=UpdateAddressInput)
def update_address(street: str, city: str, state: str, zip_code: str) -> str:
    '''Update the user's address in the database.'''
    return f"Address updated to {street}, {city}, {state}, {zip_code}"