from langchain.agents import AgentExecutor
from langchain.core.runnables import RunnableBranch
from langchain.prompts import ChatPromptTemplate
from chatbot.config import memory
from chatbot.chains import (
    change_email_chain,
    change_email_tool_instance,
    submit_inquiry_chain,
    submit_inquiry_tool_instance,
    update_address_chain,
)
from chatbot.tools import update_address_tool_instance

# Create the classification prompt
classification_prompt = ChatPromptTemplate.from_messages([
    ("system", "classify the user input into either of the three classes only \n"
               "1)inquiry\n2)change email\n3)update address\n"
               "If neither of the above three classes then classify it as others\n"
               "The output should adhere to the labels as mentioned above only\n"
               "If you dont clearly understand, prompt the user to repeat again"),
    ("human", "{question}")
])

# Create the topic classifier chain
topic_classifier_chain = classification_prompt | ChatOpenAI() | OpenAIFunctionsAgentOutputParser()

# Create the routing branch
branch = RunnableBranch(
    (lambda x: "update address" in x['input'].return_values['output'].lower(), lambda x: agent_executor.invoke({"question": x['question']})),
    (lambda x: "change email" in x['input'].return_values['output'].lower(), change_email_chain | change_email_tool_instance),
    (lambda x: "inquiry" in x['input'].return_values['output'].lower(), submit_inquiry_chain | submit_inquiry_tool_instance),
    general_chain
)

# Full chain with topic classifier
full_chain = topic_classifier_chain | branch

# Define function to get response
def get_response(user_input: str, memory) -> str:
    return full_chain.invoke({"question": user_input, "chat_history": memory.chat_memory})
