import os
from dotenv import load_dotenv # type: ignore
import torch # type: ignore
from transformers import AutoModelForCausalLM, AutoTokenizer # type: ignore
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from langchain_core.callbacks import CallbackManagerForLLMRun
from langchain_core.messages import AIMessageChunk, BaseMessage, HumanMessage
from langchain_core.outputs import ChatGeneration, ChatGenerationChunk, ChatResult
from pydantic import PrivateAttr
from typing import List, Optional, Any, Dict, Iterator

# Load environment variables
load_dotenv()

class LLMChatModel(BaseChatModel):
    """
    This class encapsulates a quantized language model for generating responses,
    extending the BaseChatModel from LangChain to integrate with its ecosystem.
    """

    tokenizer: AutoTokenizer = PrivateAttr()
    model: AutoModelForCausalLM = PrivateAttr()
    device: Any = PrivateAttr()

    def __init__(self, model_dir: str, token: str, local_files_only: bool = False, temperature: float = 0.1, max_token_length: int = 200):
        super().__init__()
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(model_dir, local_files_only=local_files_only, token=token)
            self.model = AutoModelForCausalLM.from_pretrained(
                model_dir,
                local_files_only=local_files_only,
                use_cache=True,
                device_map="auto",
                max_length=max_token_length,
                do_sample=True,
                top_p=0.95,
                temperature=temperature,
                top_k=50,
                num_return_sequences=1,
                eos_token_id=self.tokenizer.eos_token_id,
                pad_token_id=self.tokenizer.pad_token_id,
                token=token
            )
            self.model.eval()
            if self.tokenizer.pad_token is None:
                self.tokenizer.pad_token = self.tokenizer.eos_token

            self.device = self.model.device
        except Exception as e:
            raise RuntimeError(f"Failed to load model or tokenizer from {model_dir}: {e}")

    def _generate(self, messages: List[BaseMessage], stop: Optional[List[str]] = None, run_manager: Optional[CallbackManagerForLLMRun] = None, **kwargs: Any) -> ChatResult:
        if not messages or not messages[-1].content:
            raise ValueError("Input messages cannot be empty")

        input_text = messages[-1].content
        try:
            inputs = self.tokenizer(input_text, return_tensors='pt', padding=True, truncation=True, max_length=512)
            inputs = {k: v.to(self.device) for k, v in inputs.items()}
            outputs = self.model.generate(**inputs)
            response_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
            response_text = response_text[len(input_text):].strip()

        except Exception as e:
            raise RuntimeError(f"Failed to generate response: {e}")

        message = AIMessage(content=response_text)
        generation = ChatGeneration(message=message)
        return ChatResult(generations=[generation])

    def _stream(self, messages: List[BaseMessage], stop: Optional[List[str]] = None, run_manager: Optional[CallbackManagerForLLMRun] = None, **kwargs: Any) -> Iterator[ChatGenerationChunk]:
        if not messages or not messages[-1].content:
            raise ValueError("Input messages cannot be empty")

        input_text = messages[-1].content
        try:
            inputs = self.tokenizer(input_text, return_tensors='pt', padding=True, truncation=True, max_length=512)
            inputs = {k: v.to(self.device) for k, v in inputs.items()}
            outputs = self.model.generate(**inputs)
            response_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
            response_text = response_text[len(input_text):].strip()

        except Exception as e:
            raise RuntimeError(f"Failed to generate response: {e}")

        tokens = list(response_text)

        for token in tokens:
            chunk = ChatGenerationChunk(message=AIMessageChunk(content=token))
            if run_manager:
                run_manager.on_llm_new_token(token, chunk=chunk)
            yield chunk

        chunk = ChatGenerationChunk(message=AIMessageChunk(content="", response_metadata={"time_in_sec": 3}))
        if run_manager:
            run_manager.on_llm_new_token("", chunk=chunk)
        yield chunk

    def batch(self, inputs: List[List[BaseMessage]], stop: Optional[List[str]] = None, run_manager: Optional[CallbackManagerForLLMRun] = None, **kwargs: Any) -> List[ChatResult]:
        return [self._generate(messages, stop, run_manager, **kwargs) for messages in inputs]

    @property
    def _llm_type(self) -> str:
        return "quantized-llm-chat-model"

    @property
    def _identifying_params(self) -> Dict[str, Any]:
        return {"model_dir": self.model.name_or_path}

# Define the parameters for the model
model_directory = os.getenv("MODEL_DIRECTORY")
auth_token = os.getenv("AUTH_TOKEN")
local_files_only = False
temperature = 0.1
max_token_length = 1000

# Create an instance of the LLMChatModel class
chat_model = LLMChatModel(
    model_dir=model_directory,
    token=auth_token,
    local_files_only=local_files_only,
    temperature=temperature,
    max_token_length=max_token_length
)