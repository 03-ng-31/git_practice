"""
FastAPI application for Document Comparator.

Endpoints:
  POST /compare          - Upload 2+ PDFs and get comparison report
  GET  /compare/{job_id} - Poll for async comparison results
  GET  /report/{job_id}  - Get HTML report
  GET  /health           - Health check

Run:
  uvicorn api.app:app --reload --port 8000
"""
from __future__ import annotations

import json
import logging
import os
import shutil
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from typing import Optional

import yaml
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Document Comparator API",
    description="Compare PDF document versions and detect text, table, image, and drawing changes.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Configuration ────────────────────────────────────────────────────────

CONFIG_PATH = os.environ.get("DOC_COMPARATOR_CONFIG", "config.yaml")
UPLOAD_DIR = os.environ.get("DOC_COMPARATOR_UPLOADS", "uploads")
OUTPUT_DIR = os.environ.get("DOC_COMPARATOR_OUTPUT", "output")

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

_config: Optional[dict] = None


def get_config() -> dict:
    global _config
    if _config is None:
        if os.path.exists(CONFIG_PATH):
            with open(CONFIG_PATH, "r") as f:
                _config = yaml.safe_load(f)
        else:
            _config = {}
    return _config


# ── Job Management ───────────────────────────────────────────────────────

class JobStatus(BaseModel):
    job_id: str
    status: str  # "pending" | "processing" | "completed" | "failed"
    created_at: str
    completed_at: Optional[str] = None
    version_labels: list[str] = []
    total_changes: int = 0
    changes_by_type: dict = {}
    changes_by_pair: dict = {}
    executive_summary: str = ""
    error: Optional[str] = None
    html_report_url: Optional[str] = None
    json_report_url: Optional[str] = None


# In-memory job store (use Redis/DB for production)
_jobs: dict[str, JobStatus] = {}
_executor = ThreadPoolExecutor(max_workers=2)


def _run_comparison(job_id: str, pdf_paths: list[str], config: dict):
    """Background task: run the full comparison pipeline."""
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent))

    try:
        _jobs[job_id].status = "processing"
        logger.info("Job %s: Starting comparison of %d PDFs", job_id, len(pdf_paths))

        from src.comparators.multi_version import MultiVersionComparator
        from src.agent.graph import AgentOrchestrator
        from src.report.html_generator import HTMLReportGenerator
        from src.report.json_generator import JSONReportGenerator

        # Run comparison
        comparator = MultiVersionComparator(pdf_paths=pdf_paths, config=config)
        report = comparator.run()

        # Run agentic verification
        try:
            agent = AgentOrchestrator(config)
            enriched_diffs, summary = agent.process(report.pair_diffs)
            report.pair_diffs = enriched_diffs
            report.executive_summary = summary
        except Exception as e:
            logger.warning("Agent verification failed (non-fatal): %s", e)

        report.compute_statistics()

        # Generate reports
        job_output = os.path.join(OUTPUT_DIR, job_id)
        os.makedirs(job_output, exist_ok=True)

        html_gen = HTMLReportGenerator(config)
        html_path = html_gen.generate(report, os.path.join(job_output, "report.html"))

        json_gen = JSONReportGenerator(config)
        json_path = json_gen.generate(report, os.path.join(job_output, "changelog.json"))

        # Update job status
        _jobs[job_id].status = "completed"
        _jobs[job_id].completed_at = datetime.now().isoformat()
        _jobs[job_id].version_labels = report.version_labels
        _jobs[job_id].total_changes = report.total_changes
        _jobs[job_id].changes_by_type = report.changes_by_type
        _jobs[job_id].changes_by_pair = report.changes_by_pair
        _jobs[job_id].executive_summary = report.executive_summary
        _jobs[job_id].html_report_url = f"/report/{job_id}/html"
        _jobs[job_id].json_report_url = f"/report/{job_id}/json"

        logger.info("Job %s: Completed. %d changes found.", job_id, report.total_changes)

    except Exception as e:
        logger.error("Job %s: Failed - %s", job_id, e, exc_info=True)
        _jobs[job_id].status = "failed"
        _jobs[job_id].error = str(e)


# ── API Endpoints ────────────────────────────────────────────────────────

@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "service": "document-comparator", "version": "1.0.0"}


@app.post("/compare", response_model=JobStatus)
async def compare_documents(files: list[UploadFile] = File(...)):
    """
    Upload 2 or more PDF files for comparison.
    Files are compared in upload order (first = V1, second = V2, etc.).
    Returns a job_id for polling status.
    """
    if len(files) < 2:
        raise HTTPException(status_code=400, detail="Need at least 2 PDF files to compare.")

    for f in files:
        if not f.filename.lower().endswith(".pdf"):
            raise HTTPException(status_code=400, detail=f"File '{f.filename}' is not a PDF.")

    # Create job
    job_id = str(uuid.uuid4())[:8]
    job_dir = os.path.join(UPLOAD_DIR, job_id)
    os.makedirs(job_dir, exist_ok=True)

    # Save uploaded files
    pdf_paths = []
    for i, f in enumerate(files):
        filename = f"{i:02d}_{f.filename}"
        filepath = os.path.join(job_dir, filename)
        with open(filepath, "wb") as out:
            content = await f.read()
            out.write(content)
        pdf_paths.append(filepath)

    # Create job entry
    _jobs[job_id] = JobStatus(
        job_id=job_id,
        status="pending",
        created_at=datetime.now().isoformat(),
        version_labels=[f.filename for f in files],
    )

    # Submit background task
    config = get_config()
    _executor.submit(_run_comparison, job_id, pdf_paths, config)

    return _jobs[job_id]


@app.get("/compare/{job_id}", response_model=JobStatus)
async def get_comparison_status(job_id: str):
    """Poll for comparison job status and results."""
    if job_id not in _jobs:
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' not found.")
    return _jobs[job_id]


@app.get("/report/{job_id}/html", response_class=HTMLResponse)
async def get_html_report(job_id: str):
    """Get the HTML comparison report."""
    if job_id not in _jobs:
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' not found.")
    if _jobs[job_id].status != "completed":
        raise HTTPException(status_code=409, detail=f"Job is {_jobs[job_id].status}, not completed.")

    html_path = os.path.join(OUTPUT_DIR, job_id, "report.html")
    if not os.path.exists(html_path):
        raise HTTPException(status_code=404, detail="HTML report not found.")

    with open(html_path, "r", encoding="utf-8") as f:
        return HTMLResponse(content=f.read())


@app.get("/report/{job_id}/json")
async def get_json_report(job_id: str):
    """Get the JSON changelog."""
    if job_id not in _jobs:
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' not found.")
    if _jobs[job_id].status != "completed":
        raise HTTPException(status_code=409, detail=f"Job is {_jobs[job_id].status}, not completed.")

    json_path = os.path.join(OUTPUT_DIR, job_id, "changelog.json")
    if not os.path.exists(json_path):
        raise HTTPException(status_code=404, detail="JSON report not found.")

    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return JSONResponse(content=data)


@app.get("/jobs")
async def list_jobs():
    """List all comparison jobs."""
    return {
        "jobs": [
            {
                "job_id": j.job_id,
                "status": j.status,
                "created_at": j.created_at,
                "versions": j.version_labels,
                "total_changes": j.total_changes,
            }
            for j in _jobs.values()
        ]
    }


@app.delete("/jobs/{job_id}")
async def delete_job(job_id: str):
    """Delete a job and its uploaded/output files."""
    if job_id not in _jobs:
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' not found.")

    # Cleanup files
    for directory in [os.path.join(UPLOAD_DIR, job_id), os.path.join(OUTPUT_DIR, job_id)]:
        if os.path.exists(directory):
            shutil.rmtree(directory, ignore_errors=True)

    del _jobs[job_id]
    return {"detail": f"Job '{job_id}' deleted."}
