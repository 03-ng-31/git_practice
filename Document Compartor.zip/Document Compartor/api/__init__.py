# FastAPI application package
