# Document Comparator

A scalable, multi-pipeline document comparison system that detects changes between PDF versions -- including text modifications, table edits, image updates, and engineering drawing dimension changes.

## Architecture

**Hybrid Agentic:** Deterministic pipeline (Layers 0-3) for preprocessing, classification, extraction, and comparison. LangGraph-based agentic orchestrator (Layer 4-5) for intelligent verification, cross-version summarization, and narrative generation.

### Pipeline Layers

| Layer | Purpose | Approach |
|-------|---------|----------|
| 0 | Image Preprocessing | Deskew, denoise, CLAHE, binarization (OpenCV) |
| 1 | Page Classification | 6-signal statistical scorer + region-level hybrid detection |
| 2 | Element Extraction | Docling/Surya OCR, pdfplumber tables, image/drawing crop |
| 3 | Comparison | difflib + semantic diff, SSIM + pHash, table cell-diff, drawing contour |
| 4 | Agentic Verification | LangGraph: triage, VLM verification, drawing analysis, summarization |
| 5 | Report Generation | HTML side-by-side, JSON changelog, version timeline |

## Quick Start

```bash
# Install dependencies (CPU)
pip install -r requirements.txt

# For GPU acceleration
pip install -r requirements-gpu.txt

# Run Jupyter notebooks for exploration
jupyter notebook notebooks/
```

## Multi-Version Comparison

Compares sequential PDF versions (V1->V2, V2->V3, ...) with cumulative changelog:

```python
from src.comparators.multi_version import MultiVersionComparator

comparator = MultiVersionComparator(
    pdf_paths=["v1.pdf", "v2.pdf", "v3.pdf", "v4.pdf"],
    config="config.yaml"
)
report = comparator.run()
```

## Notebooks

| Notebook | Layer | Description |
|----------|-------|-------------|
| 00_image_preprocessing | 0 | Visual before/after for each preprocessing stage |
| 01_page_classification | 1 | 6-signal scoring, region segmentation visualization |
| 02_element_extraction | 2 | Docling, Surya, table extraction, hybrid routing |
| 03_comparison_engine | 3 | Text, table, image, drawing comparison demos |
| 04_agentic_verification | 4 | LangGraph agent graph, VLM verification |
| 05_multi_version_report | 5 | Sequential multi-version pipeline + HTML report |
| 06_end_to_end_demo | E2E | Full pipeline on N versions with profiling |

## REST API (FastAPI)

Start the API server:

```bash
uvicorn api.app:app --reload --port 8000
```

### Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/compare` | Upload 2+ PDFs, returns job_id |
| GET | `/compare/{job_id}` | Poll job status and results |
| GET | `/report/{job_id}/html` | Download HTML report |
| GET | `/report/{job_id}/json` | Download JSON changelog |
| GET | `/jobs` | List all jobs |
| GET | `/health` | Health check |

### Example

```bash
# Upload two PDFs for comparison
curl -X POST http://localhost:8000/compare \
  -F "files=@v1.pdf" \
  -F "files=@v2.pdf"

# Poll status
curl http://localhost:8000/compare/{job_id}

# Get HTML report
curl http://localhost:8000/report/{job_id}/html > report.html
```

## Streamlit UI

Interactive web interface for uploading PDFs and viewing reports:

```bash
streamlit run ui/streamlit_app.py
```

Features:
- Drag-and-drop PDF upload
- Real-time comparison pipeline execution
- Interactive change explorer with expandable sections
- Change statistics dashboard
- Version timeline table
- Download HTML and JSON reports
- API client mode for connecting to the FastAPI backend

## CLI

```bash
python -m src.main v1.pdf v2.pdf v3.pdf --config config.yaml --output output/
```

## Configuration

All parameters are in `config.yaml` -- preprocessing thresholds, model selection, device (CPU/GPU), comparison sensitivity, etc.
