"""
Streamlit UI for Document Comparator.

Interactive interface for uploading PDFs, running comparisons,
and viewing reports with side-by-side visualizations.

Run:
    streamlit run ui/streamlit_app.py
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import time
from pathlib import Path

import streamlit as st

# Ensure project root is on path
sys.path.insert(0, str(Path(__file__).parent.parent))

# ── Page Config ──────────────────────────────────────────────────────────

st.set_page_config(
    page_title="Document Comparator",
    page_icon="📄",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ───────────────────────────────────────────────────────────

st.markdown("""
<style>
    .stApp { max-width: 1400px; margin: 0 auto; }
    .stat-box { background: #f8f9fa; border-radius: 8px; padding: 16px;
                text-align: center; border: 1px solid #dee2e6; }
    .stat-box h2 { margin: 0; font-size: 2rem; }
    .stat-box p { margin: 0; font-size: 0.85rem; color: #6c757d; text-transform: uppercase; }
    .change-added { border-left: 4px solid #28a745; padding-left: 12px; margin: 6px 0; }
    .change-removed { border-left: 4px solid #dc3545; padding-left: 12px; margin: 6px 0; }
    .change-modified { border-left: 4px solid #ffc107; padding-left: 12px; margin: 6px 0; }
</style>
""", unsafe_allow_html=True)

# ── Sidebar ──────────────────────────────────────────────────────────────

st.sidebar.title("Document Comparator")
st.sidebar.markdown("---")

mode = st.sidebar.radio(
    "Mode",
    ["Upload & Compare", "API Client", "About"],
    index=0,
)

st.sidebar.markdown("---")
st.sidebar.markdown(
    "**Comparison Order:**\n"
    "Files are compared sequentially:\n"
    "V1 → V2, V2 → V3, ..."
)


# ── Helper Functions ─────────────────────────────────────────────────────

def load_config():
    """Load config.yaml from project root."""
    import yaml
    config_path = Path(__file__).parent.parent / "config.yaml"
    if config_path.exists():
        with open(config_path, "r") as f:
            return yaml.safe_load(f)
    return {}


def run_comparison(pdf_paths: list[str], config: dict):
    """Run the comparison pipeline."""
    from src.comparators.multi_version import MultiVersionComparator
    from src.agent.graph import AgentOrchestrator
    from src.report.html_generator import HTMLReportGenerator
    from src.report.json_generator import JSONReportGenerator

    # Run comparison
    comparator = MultiVersionComparator(pdf_paths=pdf_paths, config=config)
    report = comparator.run()

    # Agentic verification
    try:
        agent = AgentOrchestrator(config)
        enriched, summary = agent.process(report.pair_diffs)
        report.pair_diffs = enriched
        report.executive_summary = summary
    except Exception as e:
        st.warning(f"Agent verification skipped: {e}")

    report.compute_statistics()
    return report


def render_stat_card(value, label, color="#212529"):
    """Render a stat card."""
    st.markdown(
        f'<div class="stat-box"><h2 style="color:{color}">{value}</h2>'
        f'<p>{label}</p></div>',
        unsafe_allow_html=True,
    )


def display_report(report):
    """Display the full comparison report in Streamlit."""
    from src.models.comparison_ir import ChangeType

    # Summary stats
    st.markdown("### Change Overview")
    cols = st.columns(5)
    with cols[0]:
        render_stat_card(report.total_changes, "Total Changes", "#dc3545")
    with cols[1]:
        render_stat_card(report.changes_by_type.get("text", 0), "Text", "#007bff")
    with cols[2]:
        render_stat_card(report.changes_by_type.get("table", 0), "Table", "#6f42c1")
    with cols[3]:
        render_stat_card(report.changes_by_type.get("image", 0), "Image", "#ffc107")
    with cols[4]:
        render_stat_card(report.changes_by_type.get("drawing", 0), "Drawing", "#fd7e14")

    # Executive summary
    if report.executive_summary:
        st.markdown("### Executive Summary")
        st.info(report.executive_summary)

    # Pairwise diffs
    st.markdown("### Pairwise Comparisons")
    for diff in report.pair_diffs:
        with st.expander(
            f"**{diff.version_label}** — {diff.total_changes} changes",
            expanded=(len(report.pair_diffs) == 1),
        ):
            if diff.summary:
                st.caption(diff.summary)

            # Change counts bar
            counts = diff.change_counts
            count_cols = st.columns(6)
            labels = ["text", "table", "image", "drawing", "pages_added", "pages_removed"]
            for i, label in enumerate(labels):
                with count_cols[i]:
                    st.metric(label.replace("_", " ").title(), counts.get(label, 0))

            # Text changes
            if diff.text_changes:
                st.markdown("#### Text Changes")
                for c in diff.text_changes:
                    icon = {"added": "🟢", "removed": "🔴", "modified": "🟡"}.get(
                        c.change_type.value, "⚪"
                    )
                    with st.container():
                        st.markdown(
                            f"{icon} **{c.change_type.value.upper()}** `{c.element_id}`"
                        )
                        if c.diff_html:
                            st.markdown(c.diff_html, unsafe_allow_html=True)
                        elif c.old_text and c.change_type == ChangeType.REMOVED:
                            st.markdown(f"~~{c.old_text[:200]}~~")
                        elif c.new_text and c.change_type == ChangeType.ADDED:
                            st.markdown(f"*{c.new_text[:200]}*")
                        if c.semantic_similarity > 0:
                            st.caption(f"Semantic similarity: {c.semantic_similarity:.3f}")
                        if c.description:
                            st.caption(c.description)

            # Table changes
            if diff.table_changes:
                st.markdown("#### Table Changes")
                for c in diff.table_changes:
                    st.markdown(f"**{c.change_type.value.upper()}** `{c.element_id}`")
                    tcols = st.columns(3)
                    with tcols[0]:
                        st.metric("Rows Added", len(c.added_rows))
                    with tcols[1]:
                        st.metric("Rows Removed", len(c.removed_rows))
                    with tcols[2]:
                        st.metric("Cells Modified", len(c.modified_cells))
                    if c.description:
                        st.caption(c.description)

            # Image changes
            if diff.image_changes:
                st.markdown("#### Image Changes")
                for c in diff.image_changes:
                    st.markdown(
                        f"**{c.change_type.value.upper()}** `{c.element_id}` — "
                        f"SSIM: {c.ssim_score:.3f}, pHash: {c.phash_distance}"
                    )
                    if c.description:
                        st.caption(c.description)

            # Drawing changes
            if diff.drawing_changes:
                st.markdown("#### Drawing Changes")
                for c in diff.drawing_changes:
                    st.markdown(
                        f"**{c.change_type.value.upper()}** `{c.element_id}` — "
                        f"SSIM: {c.ssim_score:.3f}, Contour: {c.contour_diff_ratio:.1%}"
                    )
                    if c.dimension_changes:
                        for d in c.dimension_changes:
                            st.markdown(
                                f"  - {d.get('label', '?')}: "
                                f"{d.get('old', '?')} → {d.get('new', '?')}"
                            )
                    if c.description:
                        st.caption(c.description)

    # Version timeline
    if report.version_timeline:
        st.markdown("### Version Timeline")
        import pandas as pd
        pair_labels = [d.version_label for d in report.pair_diffs]
        rows = []
        for entry in report.version_timeline[:100]:
            row = {"Element": entry.element_id, "Type": entry.element_type}
            for label in pair_labels:
                row[label] = entry.changes_by_pair.get(label, "-")
            rows.append(row)
        if rows:
            df = pd.DataFrame(rows)
            st.dataframe(df, use_container_width=True, height=400)


# ── Mode: Upload & Compare ───────────────────────────────────────────────

if mode == "Upload & Compare":
    st.title("Document Comparator")
    st.markdown("Upload 2 or more PDF versions for sequential comparison.")

    uploaded_files = st.file_uploader(
        "Upload PDF files (in version order)",
        type=["pdf"],
        accept_multiple_files=True,
    )

    if uploaded_files and len(uploaded_files) >= 2:
        st.success(f"{len(uploaded_files)} PDFs uploaded: {[f.name for f in uploaded_files]}")

        if st.button("Run Comparison", type="primary", use_container_width=True):
            config = load_config()

            # Save to temp directory
            with tempfile.TemporaryDirectory() as tmpdir:
                pdf_paths = []
                for i, f in enumerate(uploaded_files):
                    path = os.path.join(tmpdir, f"{i:02d}_{f.name}")
                    with open(path, "wb") as out:
                        out.write(f.getbuffer())
                    pdf_paths.append(path)

                # Run pipeline
                with st.spinner("Running comparison pipeline..."):
                    progress = st.progress(0, text="Parsing PDFs...")
                    t0 = time.time()

                    try:
                        report = run_comparison(pdf_paths, config)
                        elapsed = time.time() - t0
                        progress.progress(100, text=f"Completed in {elapsed:.1f}s")

                        st.session_state["report"] = report
                        st.session_state["elapsed"] = elapsed

                    except Exception as e:
                        st.error(f"Comparison failed: {e}")
                        st.exception(e)

        # Display results if available
        if "report" in st.session_state:
            report = st.session_state["report"]
            elapsed = st.session_state.get("elapsed", 0)

            st.markdown(f"*Completed in {elapsed:.1f}s*")
            st.markdown("---")
            display_report(report)

            # Download buttons
            st.markdown("---")
            st.markdown("### Download Reports")
            dl_cols = st.columns(2)

            with dl_cols[0]:
                from src.report.html_generator import HTMLReportGenerator
                html_gen = HTMLReportGenerator(load_config())
                html_content = html_gen.render_to_string(report)
                st.download_button(
                    "Download HTML Report",
                    data=html_content,
                    file_name="comparison_report.html",
                    mime="text/html",
                    use_container_width=True,
                )

            with dl_cols[1]:
                from src.report.json_generator import JSONReportGenerator
                json_gen = JSONReportGenerator(load_config())
                # Generate to temp file and read back
                with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
                    json_path = json_gen.generate(report, f.name)
                with open(json_path, "r") as f:
                    json_content = f.read()
                st.download_button(
                    "Download JSON Changelog",
                    data=json_content,
                    file_name="changelog.json",
                    mime="application/json",
                    use_container_width=True,
                )

    elif uploaded_files and len(uploaded_files) < 2:
        st.warning("Please upload at least 2 PDF files.")
    else:
        st.info("Upload 2+ PDF files to get started. Files are compared in upload order.")


# ── Mode: API Client ─────────────────────────────────────────────────────

elif mode == "API Client":
    st.title("API Client")
    st.markdown("Connect to the FastAPI backend for server-side comparison.")

    api_url = st.text_input("API Base URL", value="http://localhost:8000")

    tab_upload, tab_status, tab_jobs = st.tabs(["Submit Job", "Check Status", "List Jobs"])

    with tab_upload:
        api_files = st.file_uploader(
            "Upload PDFs for API comparison",
            type=["pdf"],
            accept_multiple_files=True,
            key="api_upload",
        )

        if api_files and len(api_files) >= 2:
            if st.button("Submit to API"):
                import requests
                files_payload = [
                    ("files", (f.name, f.getbuffer(), "application/pdf"))
                    for f in api_files
                ]
                try:
                    resp = requests.post(f"{api_url}/compare", files=files_payload, timeout=30)
                    if resp.status_code == 200:
                        result = resp.json()
                        st.success(f"Job submitted! ID: **{result['job_id']}**")
                        st.json(result)
                    else:
                        st.error(f"API error: {resp.status_code} - {resp.text}")
                except Exception as e:
                    st.error(f"Connection failed: {e}")

    with tab_status:
        job_id = st.text_input("Job ID")
        if job_id and st.button("Check Status"):
            import requests
            try:
                resp = requests.get(f"{api_url}/compare/{job_id}", timeout=10)
                if resp.status_code == 200:
                    result = resp.json()
                    st.json(result)
                    if result.get("status") == "completed":
                        st.success("Job completed!")
                        if st.button("View HTML Report"):
                            report_resp = requests.get(f"{api_url}/report/{job_id}/html")
                            if report_resp.status_code == 200:
                                st.components.v1.html(report_resp.text, height=800, scrolling=True)
                else:
                    st.error(f"Error: {resp.status_code}")
            except Exception as e:
                st.error(f"Connection failed: {e}")

    with tab_jobs:
        if st.button("Refresh Job List"):
            import requests
            try:
                resp = requests.get(f"{api_url}/jobs", timeout=10)
                if resp.status_code == 200:
                    import pandas as pd
                    jobs = resp.json().get("jobs", [])
                    if jobs:
                        st.dataframe(pd.DataFrame(jobs), use_container_width=True)
                    else:
                        st.info("No jobs found.")
                else:
                    st.error(f"Error: {resp.status_code}")
            except Exception as e:
                st.error(f"Connection failed: {e}")


# ── Mode: About ──────────────────────────────────────────────────────────

elif mode == "About":
    st.title("About Document Comparator")
    st.markdown("""
    ### Architecture

    **Hybrid Agentic Pipeline:**
    - **Layers 0-3** (Deterministic): Preprocessing, Classification, Extraction, Comparison
    - **Layer 4** (Agentic/LangGraph): Triage, VLM Verification, Drawing Analysis, Table Narration
    - **Layer 5**: Report Generation (HTML + JSON)

    ### Features
    - Handles both machine-readable and scanned PDFs
    - 6-signal statistical page classification
    - Region-level hybrid page handling
    - Text diff (structural + semantic)
    - Table cell-level comparison
    - Image comparison (SSIM + perceptual hashing)
    - Engineering drawing analysis (contour + dimension OCR)
    - Sequential multi-version comparison (V1 → V2 → V3 → ...)
    - Cumulative changelog with version timeline

    ### Tech Stack
    PyMuPDF, Docling, Surya, OpenCV, scikit-image, sentence-transformers,
    LangGraph, Ollama, FastAPI, Streamlit
    """)
