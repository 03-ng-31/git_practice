"""
Layer 0: Image Pre-processing Pipeline.
Normalizes and enhances page images before classification, OCR, or comparison.
"""
from __future__ import annotations

import logging
import math
from typing import Optional

import cv2
import numpy as np

logger = logging.getLogger(__name__)


class ImagePreprocessor:
    """
    Six-stage image preprocessing pipeline:
      1. Resolution normalization
      2. Deskew correction
      3. Denoising (Non-Local Means)
      4. Contrast enhancement (CLAHE)
      5. Border / artifact removal
      6. Adaptive binarization (OCR path only)
    """

    def __init__(self, config: dict):
        pre = config.get("preprocessing", {})
        self.target_dpi: int = pre.get("target_dpi", 300)
        self.deskew_threshold_deg: float = pre.get("deskew_threshold_deg", 0.5)
        self.denoise_h: int = pre.get("denoise_h", 10)
        self.denoise_template_window: int = pre.get("denoise_template_window", 7)
        self.denoise_search_window: int = pre.get("denoise_search_window", 21)
        self.clahe_clip: float = pre.get("clahe_clip_limit", 2.0)
        tile = pre.get("clahe_tile_grid", [8, 8])
        self.clahe_tile: tuple[int, int] = (tile[0], tile[1])
        self.binarize_method: str = pre.get("binarize_method", "sauvola")
        self.sauvola_window: int = pre.get("sauvola_window_size", 25)
        self.border_removal: bool = pre.get("border_removal", True)

    # ── Public API ───────────────────────────────────────────────────

    def process(
        self,
        image: np.ndarray,
        source_dpi: Optional[int] = None,
        for_ocr: bool = False,
    ) -> np.ndarray:
        """
        Run the full preprocessing pipeline.

        Args:
            image: Input image (BGR or grayscale numpy array).
            source_dpi: Native DPI of the image. If None, skip resolution step.
            for_ocr: If True, also apply adaptive binarization as the final step.

        Returns:
            Preprocessed image (same channel count unless for_ocr=True -> grayscale).
        """
        steps = []

        # Stage 1: Resolution normalization
        if source_dpi is not None and source_dpi != self.target_dpi:
            image = self.normalize_resolution(image, source_dpi)
            steps.append(f"resolution {source_dpi}->{self.target_dpi}")

        # Stage 2: Deskew
        image, angle = self.deskew(image)
        if abs(angle) > 0.01:
            steps.append(f"deskew {angle:.2f}°")

        # Stage 3: Denoise
        image = self.denoise(image)
        steps.append("denoise")

        # Stage 4: CLAHE
        image = self.enhance_contrast(image)
        steps.append("CLAHE")

        # Stage 5: Border removal
        if self.border_removal:
            image = self.remove_borders(image)
            steps.append("border_removal")

        # Stage 6: Binarize (OCR path only)
        if for_ocr:
            image = self.adaptive_binarize(image)
            steps.append(f"binarize({self.binarize_method})")

        logger.debug("Preprocessing steps: %s", " -> ".join(steps))
        return image

    # ── Stage 1: Resolution ──────────────────────────────────────────

    def normalize_resolution(
        self, image: np.ndarray, source_dpi: int
    ) -> np.ndarray:
        """Scale image so effective DPI matches target_dpi."""
        if source_dpi <= 0:
            return image
        scale = self.target_dpi / source_dpi
        if 0.95 < scale < 1.05:
            return image  # Close enough, skip interpolation noise
        interp = cv2.INTER_CUBIC if scale > 1 else cv2.INTER_AREA
        new_w = int(image.shape[1] * scale)
        new_h = int(image.shape[0] * scale)
        return cv2.resize(image, (new_w, new_h), interpolation=interp)

    # ── Stage 2: Deskew ──────────────────────────────────────────────

    def deskew(self, image: np.ndarray) -> tuple[np.ndarray, float]:
        """
        Detect and correct skew using Hough Line Transform.
        Returns (corrected_image, detected_angle_degrees).
        """
        gray = self._to_gray(image)
        edges = cv2.Canny(gray, 50, 150, apertureSize=3)
        lines = cv2.HoughLinesP(
            edges, 1, np.pi / 180, threshold=100,
            minLineLength=gray.shape[1] // 4,
            maxLineGap=20,
        )

        if lines is None or len(lines) == 0:
            return image, 0.0

        angles = []
        for line in lines:
            x1, y1, x2, y2 = line[0]
            angle = math.degrees(math.atan2(y2 - y1, x2 - x1))
            # Only consider near-horizontal lines (±30°)
            if abs(angle) < 30:
                angles.append(angle)

        if not angles:
            return image, 0.0

        median_angle = float(np.median(angles))
        if abs(median_angle) < self.deskew_threshold_deg:
            return image, median_angle  # Too small to correct

        h, w = image.shape[:2]
        center = (w // 2, h // 2)
        matrix = cv2.getRotationMatrix2D(center, median_angle, 1.0)
        rotated = cv2.warpAffine(
            image, matrix, (w, h),
            flags=cv2.INTER_CUBIC,
            borderMode=cv2.BORDER_REPLICATE,
        )
        return rotated, median_angle

    # ── Stage 3: Denoise ─────────────────────────────────────────────

    def denoise(self, image: np.ndarray) -> np.ndarray:
        """Apply Non-Local Means Denoising."""
        if len(image.shape) == 3 and image.shape[2] == 3:
            return cv2.fastNlMeansDenoisingColored(
                image,
                None,
                h=self.denoise_h,
                hForColorComponents=self.denoise_h,
                templateWindowSize=self.denoise_template_window,
                searchWindowSize=self.denoise_search_window,
            )
        else:
            gray = self._to_gray(image)
            return cv2.fastNlMeansDenoising(
                gray,
                None,
                h=self.denoise_h,
                templateWindowSize=self.denoise_template_window,
                searchWindowSize=self.denoise_search_window,
            )

    # ── Stage 4: CLAHE ───────────────────────────────────────────────

    def enhance_contrast(self, image: np.ndarray) -> np.ndarray:
        """Apply CLAHE (Contrast Limited Adaptive Histogram Equalization)."""
        clahe = cv2.createCLAHE(
            clipLimit=self.clahe_clip,
            tileGridSize=self.clahe_tile,
        )
        if len(image.shape) == 3 and image.shape[2] == 3:
            lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
            l_channel, a, b = cv2.split(lab)
            l_channel = clahe.apply(l_channel)
            lab = cv2.merge([l_channel, a, b])
            return cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
        else:
            gray = self._to_gray(image)
            return clahe.apply(gray)

    # ── Stage 5: Border Removal ──────────────────────────────────────

    def remove_borders(self, image: np.ndarray) -> np.ndarray:
        """
        Remove black scanner borders using contour analysis.
        Only crops if a dominant border is detected.
        """
        gray = self._to_gray(image)
        _, thresh = cv2.threshold(gray, 15, 255, cv2.THRESH_BINARY)

        contours, _ = cv2.findContours(
            thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )
        if not contours:
            return image

        largest = max(contours, key=cv2.contourArea)
        area_ratio = cv2.contourArea(largest) / (gray.shape[0] * gray.shape[1])

        # Only crop if the main content area is 50-98% of the image
        # (too small = probably wrong, too large = no border to remove)
        if 0.50 < area_ratio < 0.98:
            x, y, w, h = cv2.boundingRect(largest)
            # Add a small margin
            margin = 5
            x = max(0, x - margin)
            y = max(0, y - margin)
            w = min(image.shape[1] - x, w + 2 * margin)
            h = min(image.shape[0] - y, h + 2 * margin)
            return image[y : y + h, x : x + w]

        return image

    # ── Stage 6: Binarization ────────────────────────────────────────

    def adaptive_binarize(self, image: np.ndarray) -> np.ndarray:
        """
        Convert to clean binary (black text on white) for OCR.
        Supports Sauvola, adaptive Gaussian, and Otsu methods.
        """
        gray = self._to_gray(image)

        if self.binarize_method == "sauvola":
            return self._sauvola_threshold(gray)
        elif self.binarize_method == "adaptive_gaussian":
            return cv2.adaptiveThreshold(
                gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                cv2.THRESH_BINARY, 31, 10,
            )
        elif self.binarize_method == "otsu":
            _, binary = cv2.threshold(
                gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
            )
            return binary
        else:
            logger.warning("Unknown binarize method '%s', using Otsu", self.binarize_method)
            _, binary = cv2.threshold(
                gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
            )
            return binary

    def _sauvola_threshold(self, gray: np.ndarray) -> np.ndarray:
        """Sauvola local thresholding -- better than Otsu for uneven backgrounds."""
        try:
            from skimage.filters import threshold_sauvola
            thresh = threshold_sauvola(gray, window_size=self.sauvola_window)
            binary = (gray > thresh).astype(np.uint8) * 255
            return binary
        except ImportError:
            logger.warning("scikit-image not available, falling back to adaptive Gaussian")
            return cv2.adaptiveThreshold(
                gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                cv2.THRESH_BINARY, 31, 10,
            )

    # ── Utilities ────────────────────────────────────────────────────

    @staticmethod
    def _to_gray(image: np.ndarray) -> np.ndarray:
        """Convert to grayscale if needed."""
        if len(image.shape) == 2:
            return image
        if image.shape[2] == 4:
            return cv2.cvtColor(image, cv2.COLOR_BGRA2GRAY)
        return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
