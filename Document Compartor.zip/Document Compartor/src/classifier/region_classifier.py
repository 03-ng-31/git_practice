"""
Layer 1 (Region-level): Classifies individual regions on hybrid pages.
Uses layout analysis to segment the page, then checks each region
for native text vs scanned content.
"""
from __future__ import annotations

import logging
from typing import Optional

import numpy as np

from ..models.classification_ir import (
    PageClassification,
    RegionClassification,
    RegionType,
)

logger = logging.getLogger(__name__)


class RegionClassifier:
    """
    For pages classified as 'hybrid', segment into regions and classify each.
    Uses layout analysis (Docling or Surya) + per-region font checking.
    """

    def __init__(self, config: dict):
        self.config = config

    def classify_regions(
        self,
        page,
        page_image: np.ndarray,
        layout_regions: Optional[list] = None,
    ) -> list[RegionClassification]:
        """
        Classify regions on a hybrid page.

        If layout_regions are not pre-computed, uses a simple heuristic
        based on PDF structure (text blocks vs image blocks).

        Args:
            page: PyMuPDF (fitz) Page object.
            page_image: Pre-processed page image as numpy array.
            layout_regions: Pre-computed layout regions from Docling/Surya.

        Returns:
            List of RegionClassification.
        """
        if layout_regions:
            return self._classify_from_layout(page, layout_regions)
        else:
            return self._classify_from_pdf_structure(page)

    def _classify_from_layout(
        self, page, layout_regions: list
    ) -> list[RegionClassification]:
        """Classify regions using pre-computed layout analysis results."""
        regions = []
        for region in layout_regions:
            bbox = region.get("bbox", region.get("bounding_box", (0, 0, 0, 0)))
            label = region.get("label", "unknown")
            region_type, strategy = self._determine_region_type(
                page, bbox, label
            )
            confidence = region.get("confidence", 0.8)
            regions.append(
                RegionClassification(
                    bbox=tuple(bbox),
                    region_type=region_type,
                    confidence=confidence,
                    extraction_strategy=strategy,
                    label=label,
                )
            )
        return regions

    def _classify_from_pdf_structure(self, page) -> list[RegionClassification]:
        """
        Fallback: use PDF structure to identify regions.
        Extract text blocks and image locations from the PDF directly.
        """
        import fitz

        regions = []

        # Get text blocks (type 0 = text, type 1 = image)
        blocks = page.get_text("dict", flags=fitz.TEXT_PRESERVE_WHITESPACE)["blocks"]

        for block in blocks:
            bbox = (block["bbox"][0], block["bbox"][1],
                    block["bbox"][2], block["bbox"][3])

            if block["type"] == 0:  # Text block
                # Check if it has real font info
                has_fonts = False
                text_content = ""
                for line in block.get("lines", []):
                    for span in line.get("spans", []):
                        if span.get("font", ""):
                            has_fonts = True
                        text_content += span.get("text", "")

                if has_fonts and len(text_content.strip()) > 5:
                    region_type = RegionType.NATIVE_TEXT
                    strategy = "direct"
                    confidence = 0.95
                else:
                    region_type = RegionType.SCANNED_TEXT
                    strategy = "ocr"
                    confidence = 0.7

                regions.append(
                    RegionClassification(
                        bbox=bbox,
                        region_type=region_type,
                        confidence=confidence,
                        extraction_strategy=strategy,
                        label="text",
                    )
                )

            elif block["type"] == 1:  # Image block
                # Determine if it's a figure, drawing, or full-page scan
                block_area = abs(bbox[2] - bbox[0]) * abs(bbox[3] - bbox[1])
                page_area = page.rect.width * page.rect.height
                coverage = block_area / page_area if page_area > 0 else 0

                if coverage > 0.8:
                    # Full-page image -- likely a scanned page
                    region_type = RegionType.SCANNED_TEXT
                    strategy = "ocr"
                    label = "full_page_scan"
                else:
                    region_type = RegionType.IMAGE
                    strategy = "visual"
                    label = "image"

                regions.append(
                    RegionClassification(
                        bbox=bbox,
                        region_type=region_type,
                        confidence=0.8,
                        extraction_strategy=strategy,
                        label=label,
                    )
                )

        return regions

    def _determine_region_type(
        self, page, bbox: tuple, label: str
    ) -> tuple[RegionType, str]:
        """
        Given a layout region's label and bbox, determine the RegionType
        and extraction strategy by checking for native text.
        """
        import fitz

        label_lower = label.lower()

        # Image / drawing types -> always visual extraction
        if label_lower in ("figure", "image", "photo", "chart"):
            return RegionType.IMAGE, "visual"
        if label_lower in ("drawing", "diagram", "blueprint", "schematic"):
            return RegionType.DRAWING, "visual"
        if label_lower in ("formula", "equation"):
            return RegionType.FORMULA, "visual"
        if label_lower in ("header", "footer", "page_number"):
            return RegionType.HEADER_FOOTER, "direct"

        # Text and table types -> check for native content
        clip = fitz.Rect(bbox)
        native_text = page.get_text("text", clip=clip).strip()
        text_dict = page.get_text("dict", clip=clip)

        has_fonts = False
        for block in text_dict.get("blocks", []):
            for line in block.get("lines", []):
                for span in line.get("spans", []):
                    if span.get("font", ""):
                        has_fonts = True
                        break

        if label_lower in ("table",):
            if has_fonts and len(native_text) > 10:
                return RegionType.NATIVE_TABLE, "direct"
            else:
                return RegionType.SCANNED_TABLE, "ocr"

        # Default: text region
        if has_fonts and len(native_text) > 5:
            return RegionType.NATIVE_TEXT, "direct"
        else:
            return RegionType.SCANNED_TEXT, "ocr"
