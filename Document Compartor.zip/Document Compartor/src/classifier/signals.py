"""
Layer 1: Individual signal scoring functions for page classification.
Each function returns a float in [0.0, 1.0] where:
  1.0 = strong evidence of machine-readable content
  0.0 = strong evidence of scanned/image-only content
"""
from __future__ import annotations

import logging
import re
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)


def score_font_presence(page) -> float:
    """
    Signal 1: Check for embedded font metadata.
    Machine-readable PDFs always have fonts; scanned PDFs typically do not.
    Weight: 0.30
    """
    try:
        fonts = page.get_fonts(full=True)
        if not fonts:
            return 0.0
        # More fonts = higher confidence it's machine-readable
        return min(1.0, len(fonts) / 3.0)
    except Exception as e:
        logger.debug("Font detection failed: %s", e)
        return 0.5  # Uncertain


def score_text_density(page, min_chars_per_sq_inch: float = 20.0) -> float:
    """
    Signal 2: Text characters per square inch of page area.
    Machine-readable pages have high text density.
    Weight: 0.20
    """
    try:
        text = page.get_text("text").strip()
        char_count = len(text)
        if char_count == 0:
            return 0.0

        rect = page.rect
        # Page dimensions in points; 1 inch = 72 points
        width_in = rect.width / 72.0
        height_in = rect.height / 72.0
        area_sq_in = width_in * height_in

        if area_sq_in <= 0:
            return 0.0

        density = char_count / area_sq_in
        # Normalize: 0 at 0, 1.0 at min_chars_per_sq_inch * 2
        return min(1.0, density / (min_chars_per_sq_inch * 2))
    except Exception as e:
        logger.debug("Text density scoring failed: %s", e)
        return 0.5


def score_image_coverage(page) -> float:
    """
    Signal 3: Fraction of page area covered by images.
    Returns inverted score: high image coverage = low score (likely scanned).
    Weight: 0.15
    """
    try:
        images = page.get_images(full=True)
        if not images:
            return 1.0  # No images = likely machine-readable text

        rect = page.rect
        page_area = rect.width * rect.height
        if page_area <= 0:
            return 0.5

        # Estimate image coverage from image dimensions
        total_image_area = 0.0
        for img_info in images:
            xref = img_info[0]
            try:
                img_rect_list = page.get_image_rects(xref)
                for img_rect in img_rect_list:
                    total_image_area += img_rect.width * img_rect.height
            except Exception:
                # Fallback: use raw pixel dimensions with a discount
                w, h = img_info[2], img_info[3]
                total_image_area += w * h * 0.5

        coverage = min(1.0, total_image_area / page_area)

        # Invert: 0% coverage -> 1.0 (text-only), 100% coverage -> 0.0 (scanned)
        return 1.0 - coverage
    except Exception as e:
        logger.debug("Image coverage scoring failed: %s", e)
        return 0.5


def score_text_encoding_quality(page) -> float:
    """
    Signal 4: Quality of extracted text -- does it look like valid language?
    Garbled OCR text from a scanned PDF disguised as machine-readable will
    have low valid-word ratio.
    Weight: 0.15
    """
    try:
        text = page.get_text("text").strip()
        if len(text) < 10:
            return 0.0  # Too little text to evaluate

        # Tokenize into words (simple whitespace split, strip punctuation)
        words = re.findall(r"[a-zA-Z]{2,}", text)
        if not words:
            # Could be non-Latin script -- check for garbage chars
            garbage_chars = sum(
                1 for c in text
                if c == "\ufffd" or (ord(c) < 32 and c not in "\n\r\t")
            )
            garbage_ratio = garbage_chars / len(text)
            return max(0.0, 1.0 - garbage_ratio * 5)

        # Check word validity using heuristics:
        # - Reasonable length (2-20 chars)
        # - Contains vowels (for Latin scripts)
        # - Not all repeated characters
        vowels = set("aeiouAEIOU")
        valid_count = 0
        for word in words:
            has_vowel = any(c in vowels for c in word)
            reasonable_len = 2 <= len(word) <= 20
            not_garbage = not bool(re.match(r"^(.)\1{3,}$", word))
            if has_vowel and reasonable_len and not_garbage:
                valid_count += 1

        return min(1.0, valid_count / max(1, len(words)))
    except Exception as e:
        logger.debug("Text quality scoring failed: %s", e)
        return 0.5


def score_pdf_operators(page) -> float:
    """
    Signal 5: Ratio of text-rendering vs image-drawing PDF operators.
    Machine-readable pages use Tj/TJ (text show); scanned use Do (image draw).
    Weight: 0.10
    """
    try:
        xref = page.xref
        doc = page.parent

        # Gather content streams
        stream = b""
        contents = page.get_contents()
        if contents:
            for xref_id in contents:
                try:
                    chunk = doc.xref_stream(xref_id)
                    if chunk:
                        stream += chunk
                except Exception:
                    pass

        if not stream:
            return 0.5  # Can't determine

        text_str = stream.decode("latin-1", errors="ignore")

        # Count text operators: Tj, TJ
        text_ops = len(re.findall(r"\b(Tj|TJ)\b", text_str))
        # Count image operators: Do
        image_ops = len(re.findall(r"\bDo\b", text_str))

        total = text_ops + image_ops
        if total == 0:
            return 0.5

        return text_ops / total
    except Exception as e:
        logger.debug("PDF operator scoring failed: %s", e)
        return 0.5


def score_ocr_confidence(page, preprocessor=None) -> float:
    """
    Signal 6: OCR character confidence distribution.
    Machine-readable text re-OCR'd gives confidence >95%.
    Scanned text OCR gives lower, more variable confidence.
    Weight: 0.10

    This signal is expensive (runs OCR), so only used for ambiguous pages.
    """
    try:
        import pytesseract
        from PIL import Image

        # Render page to image at lower DPI for speed
        pix = page.get_pixmap(dpi=150)
        img_data = np.frombuffer(pix.samples, dtype=np.uint8).reshape(
            pix.h, pix.w, pix.n
        )
        if pix.n == 4:
            img_data = img_data[:, :, :3]

        pil_image = Image.fromarray(img_data)

        # Get character-level confidence
        data = pytesseract.image_to_data(
            pil_image, output_type=pytesseract.Output.DICT,
            config="--psm 6",
        )
        confidences = [
            int(c) for c in data["conf"] if str(c).strip() != "-1"
        ]

        if not confidences:
            return 0.5

        mean_conf = float(np.mean(confidences))
        std_conf = float(np.std(confidences))

        # High mean + low std = machine-readable
        mean_score = mean_conf / 100.0
        std_penalty = min(1.0, std_conf / 30.0)
        score = mean_score * (1.0 - 0.5 * std_penalty)

        return max(0.0, min(1.0, score))
    except ImportError:
        logger.debug("pytesseract not available, skipping OCR confidence signal")
        return 0.5
    except Exception as e:
        logger.debug("OCR confidence scoring failed: %s", e)
        return 0.5
