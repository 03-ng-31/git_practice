from .page_classifier import PageClassifier
from .region_classifier import RegionClassifier

__all__ = ["PageClassifier", "RegionClassifier"]
