"""
Layer 1: Multi-signal statistical page classifier.
Determines whether each page is machine-readable, scanned, or hybrid.
"""
from __future__ import annotations

import logging
from typing import Optional

from ..models.classification_ir import (
    PageClassification,
    RegionClassification,
    SignalScores,
)
from .signals import (
    score_font_presence,
    score_image_coverage,
    score_ocr_confidence,
    score_pdf_operators,
    score_text_density,
    score_text_encoding_quality,
)

logger = logging.getLogger(__name__)


class PageClassifier:
    """
    Classifies PDF pages using a weighted composite of 6 independent signals.

    Thresholds (configurable):
      composite > 0.70 -> "machine_readable"
      composite < 0.30 -> "scanned"
      else -> "hybrid" (triggers region-level analysis)
    """

    def __init__(self, config: dict):
        cls_config = config.get("classification", {})
        weights = cls_config.get("signal_weights", {})
        thresholds = cls_config.get("thresholds", {})

        self.weights = {
            "font_presence": weights.get("font_presence", 0.30),
            "text_density": weights.get("text_density", 0.20),
            "image_coverage": weights.get("image_coverage", 0.15),
            "text_quality": weights.get("text_quality", 0.15),
            "operator_ratio": weights.get("operator_ratio", 0.10),
            "ocr_confidence": weights.get("ocr_confidence", 0.10),
        }

        self.thresh_machine = thresholds.get("machine_readable", 0.70)
        self.thresh_scanned = thresholds.get("scanned", 0.30)
        self.min_chars_per_sq_inch = cls_config.get(
            "text_density_min_chars_per_sq_inch", 20
        )

    def classify_page(
        self,
        page,
        run_ocr_signal: bool = False,
        preprocessor=None,
    ) -> PageClassification:
        """
        Classify a single fitz.Page.

        Args:
            page: A PyMuPDF (fitz) Page object.
            run_ocr_signal: If True, compute the expensive OCR confidence signal.
                            Set to True only when other signals are ambiguous.
            preprocessor: Optional ImagePreprocessor instance for OCR signal.

        Returns:
            PageClassification with overall type and signal scores.
        """
        # Compute signals
        signals = SignalScores()
        signals.font_presence = score_font_presence(page)
        signals.text_density = score_text_density(
            page, self.min_chars_per_sq_inch
        )
        signals.image_coverage = score_image_coverage(page)
        signals.text_quality = score_text_encoding_quality(page)
        signals.operator_ratio = score_pdf_operators(page)

        # Quick composite without OCR signal
        quick_composite = self._weighted_score(signals, skip_ocr=True)

        # Only run expensive OCR signal if ambiguous
        if run_ocr_signal or (
            self.thresh_scanned <= quick_composite <= self.thresh_machine
        ):
            signals.ocr_confidence = score_ocr_confidence(page, preprocessor)
        else:
            signals.ocr_confidence = 0.5  # Neutral

        # Full composite
        composite = self._weighted_score(signals, skip_ocr=False)

        # Classify
        if composite > self.thresh_machine:
            overall_type = "machine_readable"
        elif composite < self.thresh_scanned:
            overall_type = "scanned"
        else:
            overall_type = "hybrid"

        return PageClassification(
            page_number=page.number,
            overall_type=overall_type,
            confidence=composite,
            signal_scores=signals,
            regions=[],  # Populated by RegionClassifier if hybrid
            page_width=page.rect.width,
            page_height=page.rect.height,
        )

    def classify_document(
        self,
        doc,
        run_ocr_signal: bool = False,
    ) -> list[PageClassification]:
        """
        Classify all pages in a fitz.Document.

        Args:
            doc: A PyMuPDF (fitz) Document object.
            run_ocr_signal: Whether to compute OCR confidence for ambiguous pages.

        Returns:
            List of PageClassification, one per page.
        """
        classifications = []
        for page in doc:
            cls = self.classify_page(page, run_ocr_signal=run_ocr_signal)
            classifications.append(cls)
            logger.info(cls.summary())
        return classifications

    def _weighted_score(
        self, signals: SignalScores, skip_ocr: bool = False
    ) -> float:
        """Compute weighted composite score from signals."""
        scores = signals.as_dict()
        total = 0.0
        weight_sum = 0.0
        for key, weight in self.weights.items():
            if skip_ocr and key == "ocr_confidence":
                continue
            total += weight * scores[key]
            weight_sum += weight

        return total / weight_sum if weight_sum > 0 else 0.5
