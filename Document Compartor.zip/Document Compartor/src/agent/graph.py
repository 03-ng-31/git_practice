"""
LangGraph Agent Graph: Hybrid agentic orchestrator for Layer 4-5.

Deterministic pipeline (Layers 0-3) feeds raw diffs into this graph.
The graph triages, verifies with VLM, analyzes drawings, narrates tables,
and generates a cross-version executive summary.

Graph topology:
  triage -> [visual_verify, drawing_analyze, table_narrate, aggregate] -> summarize -> END
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Optional

from ..models.comparison_ir import MultiVersionReport, PairwiseDiff
from .nodes.triage import triage_node, ROUTE_PASSTHROUGH
from .nodes.visual_verifier import visual_verification_node
from .nodes.drawing_analyzer import drawing_analysis_node
from .nodes.table_narrator import table_narration_node
from .nodes.summarizer import summarizer_node

logger = logging.getLogger(__name__)


def _aggregate_node(state: dict) -> dict:
    """Collect passthrough changes into verified list."""
    triaged = state.get("triaged", {})
    verified = state.get("verified_changes", [])
    for change in triaged.get(ROUTE_PASSTHROUGH, []):
        if not change.description:
            change.description = f"{change.change_type.value}: {change.element_id}"
        verified.append(change)
    return {**state, "verified_changes": verified}


def _route_after_triage(state: dict) -> list[str]:
    """Determine which nodes to visit after triage."""
    triaged = state.get("triaged", {})
    routes = []
    if triaged.get("visual_verify"):
        routes.append("visual_verify")
    if triaged.get("drawing_analyze"):
        routes.append("drawing_analyze")
    if triaged.get("table_narrate"):
        routes.append("table_narrate")
    routes.append("aggregate")
    return routes


def build_agent_graph():
    """
    Build and compile the LangGraph agent graph.

    Returns a compiled graph that can be invoked with:
        result = graph.invoke(initial_state)
    """
    try:
        from langgraph.graph import StateGraph, END

        # Define graph with dict state
        graph = StateGraph(dict)

        # Add nodes
        graph.add_node("triage", triage_node)
        graph.add_node("visual_verify", visual_verification_node)
        graph.add_node("drawing_analyze", drawing_analysis_node)
        graph.add_node("table_narrate", table_narration_node)
        graph.add_node("aggregate", _aggregate_node)
        graph.add_node("summarize", summarizer_node)

        # Entry point
        graph.set_entry_point("triage")

        # After triage, run verification nodes then aggregate
        # Using sequential edges since conditional fan-out requires specific LangGraph features
        graph.add_edge("triage", "visual_verify")
        graph.add_edge("visual_verify", "drawing_analyze")
        graph.add_edge("drawing_analyze", "table_narrate")
        graph.add_edge("table_narrate", "aggregate")
        graph.add_edge("aggregate", "summarize")
        graph.add_edge("summarize", END)

        compiled = graph.compile()
        logger.info("LangGraph agent compiled successfully.")
        return compiled

    except ImportError:
        logger.warning(
            "langgraph not installed. Using fallback sequential execution."
        )
        return None


class AgentOrchestrator:
    """
    High-level orchestrator that runs the agentic verification pipeline.
    Falls back to sequential execution if LangGraph is not available.
    """

    def __init__(self, config: dict):
        self.config = config
        self._graph = None

    @property
    def graph(self):
        if self._graph is None:
            self._graph = build_agent_graph()
        return self._graph

    def process(
        self,
        pair_diffs: list[PairwiseDiff],
    ) -> tuple[list[PairwiseDiff], str]:
        """
        Run agentic verification and summarization on raw diffs.

        Returns:
            (enriched_diffs, executive_summary)
        """
        initial_state = {
            "config": self.config,
            "raw_diffs": pair_diffs,
            "triaged": {},
            "verified_changes": [],
            "executive_summary": "",
        }

        if self.graph is not None:
            result = self.graph.invoke(initial_state)
        else:
            result = self._fallback_execute(initial_state)

        executive_summary = result.get("executive_summary", "")
        enriched_diffs = result.get("raw_diffs", pair_diffs)

        return enriched_diffs, executive_summary

    def _fallback_execute(self, state: dict) -> dict:
        """Sequential execution without LangGraph."""
        state = triage_node(state)
        state = visual_verification_node(state)
        state = drawing_analysis_node(state)
        state = table_narration_node(state)
        state = _aggregate_node(state)
        state = summarizer_node(state)
        return state
