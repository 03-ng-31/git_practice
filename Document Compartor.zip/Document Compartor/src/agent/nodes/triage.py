"""
Triage Node: Rule-based routing of changes to appropriate verification nodes.
No LLM calls -- pure logic.
"""
from __future__ import annotations

import logging
from typing import Any

from ...models.comparison_ir import (
    ChangeType, DrawingChange, ImageChange, TableChange, TextChange,
)

logger = logging.getLogger(__name__)

ROUTE_PASSTHROUGH = "passthrough"
ROUTE_VISUAL_VERIFY = "visual_verify"
ROUTE_DRAWING_ANALYZE = "drawing_analyze"
ROUTE_TABLE_NARRATE = "table_narrate"
ROUTE_SKIP = "skip"


def triage_single_change(change: Any, config: dict) -> str:
    """Determine how to route a single change."""
    triage_cfg = config.get("agent", {}).get("triage", {})
    skip_threshold = triage_cfg.get("skip_high_confidence_threshold", 0.95)
    always_verify_drawings = triage_cfg.get("always_verify_drawings", True)
    always_verify_ambiguous = triage_cfg.get("always_verify_ambiguous_ssim", True)

    if change.change_type == ChangeType.UNCHANGED:
        return ROUTE_SKIP

    if isinstance(change, DrawingChange) and always_verify_drawings:
        return ROUTE_DRAWING_ANALYZE

    if isinstance(change, ImageChange):
        if change.is_ambiguous and always_verify_ambiguous:
            return ROUTE_VISUAL_VERIFY

    if isinstance(change, TableChange) and change.total_cell_changes > 0:
        return ROUTE_TABLE_NARRATE

    if change.confidence >= skip_threshold:
        return ROUTE_PASSTHROUGH

    if isinstance(change, ImageChange):
        return ROUTE_VISUAL_VERIFY

    return ROUTE_PASSTHROUGH


def triage_node(state: dict) -> dict:
    """
    LangGraph node: Triage all raw changes and sort them by route.
    """
    config = state.get("config", {})
    raw_diffs = state.get("raw_diffs", [])

    routed = {
        ROUTE_PASSTHROUGH: [],
        ROUTE_VISUAL_VERIFY: [],
        ROUTE_DRAWING_ANALYZE: [],
        ROUTE_TABLE_NARRATE: [],
        ROUTE_SKIP: [],
    }

    for diff in raw_diffs:
        for change in diff.all_changes():
            route = triage_single_change(change, config)
            routed[route].append(change)

    total = sum(len(v) for v in routed.values())
    logger.info(
        "Triage: %d changes routed (pass=%d, visual=%d, drawing=%d, table=%d, skip=%d)",
        total,
        len(routed[ROUTE_PASSTHROUGH]),
        len(routed[ROUTE_VISUAL_VERIFY]),
        len(routed[ROUTE_DRAWING_ANALYZE]),
        len(routed[ROUTE_TABLE_NARRATE]),
        len(routed[ROUTE_SKIP]),
    )

    return {**state, "triaged": routed}
