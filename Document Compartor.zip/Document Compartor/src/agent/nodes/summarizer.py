"""
Cross-Version Summary Node: Synthesizes all changes into an executive narrative.
"""
from __future__ import annotations

import logging

from ..llm_provider import LLMProvider
from ...models.comparison_ir import PairwiseDiff

logger = logging.getLogger(__name__)

SUMMARY_PROMPT = """You are a technical document analyst. Generate an executive summary of changes across {n_pairs} sequential document version comparisons.

{pair_summaries}

Provide:
1. A 3-5 sentence executive summary suitable for a project review meeting
2. Highlight the most significant changes
3. Note any trends across versions (e.g., progressive parameter increases, scope additions)"""


def summarizer_node(state: dict) -> dict:
    """LangGraph node: Generate cross-version executive summary."""
    config = state.get("config", {})
    raw_diffs: list[PairwiseDiff] = state.get("raw_diffs", [])
    verified_changes = state.get("verified_changes", [])

    # Build per-pair summaries from all changes
    pair_summaries = []
    for diff in raw_diffs:
        counts = diff.change_counts
        parts = []
        if counts["text"]:
            parts.append(f"{counts['text']} text change(s)")
        if counts["table"]:
            parts.append(f"{counts['table']} table change(s)")
        if counts["image"]:
            parts.append(f"{counts['image']} image change(s)")
        if counts["drawing"]:
            parts.append(f"{counts['drawing']} drawing change(s)")
        if counts["pages_added"]:
            parts.append(f"{counts['pages_added']} page(s) added")
        if counts["pages_removed"]:
            parts.append(f"{counts['pages_removed']} page(s) removed")

        # Add verified descriptions
        pair_details = []
        for change in verified_changes:
            if change.description:
                pair_details.append(f"  - {change.description[:100]}")

        summary_line = f"{diff.version_label}: {', '.join(parts) if parts else 'no changes'}"
        if pair_details:
            summary_line += "\n" + "\n".join(pair_details[:5])
        pair_summaries.append(summary_line)

    summary_text = "\n\n".join(pair_summaries)

    llm = LLMProvider(config)
    if llm.is_ollama_available and raw_diffs:
        prompt = SUMMARY_PROMPT.format(
            n_pairs=len(raw_diffs),
            pair_summaries=summary_text,
        )
        executive_summary = llm.generate_text(prompt).strip()
    else:
        # Generate a rule-based summary
        total = sum(d.total_changes for d in raw_diffs)
        executive_summary = (
            f"Across {len(raw_diffs)} version comparison(s), "
            f"{total} total change(s) were detected. "
            f"{summary_text}"
        )

    # Write summary back to diffs
    for diff in raw_diffs:
        if not diff.summary:
            counts = diff.change_counts
            diff.summary = (
                f"{diff.total_changes} changes: "
                + ", ".join(f"{v} {k}" for k, v in counts.items() if v > 0)
            )

    logger.info("Executive summary generated (%d chars)", len(executive_summary))

    return {
        **state,
        "executive_summary": executive_summary,
        "raw_diffs": raw_diffs,
    }
