"""
Drawing Analysis Node: VLM + OCR analysis for engineering drawings.
Chain-of-thought reasoning for geometry and dimension changes.
"""
from __future__ import annotations

import logging

from ..llm_provider import LLMProvider
from .triage import ROUTE_DRAWING_ANALYZE

logger = logging.getLogger(__name__)

DRAWING_PROMPT = (
    "You are an expert engineering drawing analyst.\n\n"
    "Automated comparison found:\n"
    "- SSIM similarity: {ssim_score:.3f}\n"
    "- Contour difference: {contour_diff:.1%}\n"
    "- Dimension changes: {dim_changes}\n\n"
    "Provide a 2-4 sentence summary of geometric changes, "
    "dimension significance, and whether this is minor or major."
)


def drawing_analysis_node(state: dict) -> dict:
    """LangGraph node: Analyze engineering drawing changes."""
    config = state.get("config", {})
    triaged = state.get("triaged", {})
    drawings = triaged.get(ROUTE_DRAWING_ANALYZE, [])
    if not drawings:
        return state

    llm = LLMProvider(config)
    verified = state.get("verified_changes", [])

    for change in drawings:
        dim_str = _format_dims(change.dimension_changes)

        if llm.is_ollama_available:
            prompt = DRAWING_PROMPT.format(
                ssim_score=change.ssim_score,
                contour_diff=change.contour_diff_ratio,
                dim_changes=dim_str,
            )
            if change.diff_image_path:
                resp = llm.describe_image(prompt, change.diff_image_path)
            else:
                resp = llm.generate_text(prompt)
            change.description = resp.strip()[:500]
        else:
            parts = [f"Drawing change (SSIM={change.ssim_score:.3f})"]
            if change.dimension_changes:
                parts.append(f"Dimensions: {dim_str}")
            if change.contour_diff_ratio > 0.05:
                parts.append(f"Geometry changed {change.contour_diff_ratio:.1%}")
            change.description = ". ".join(parts) + "."

        verified.append(change)
        logger.info("Drawing analyzed %s", change.element_id)

    return {**state, "verified_changes": verified}


def _format_dims(dims: list[dict]) -> str:
    if not dims:
        return "none detected"
    parts = []
    for d in dims[:5]:
        parts.append(f"{d.get('label','?')}: {d.get('old','?')} -> {d.get('new','?')}")
    return ", ".join(parts)
