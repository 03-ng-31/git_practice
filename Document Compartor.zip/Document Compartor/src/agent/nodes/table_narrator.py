"""
Table Narration Node: Converts structured table diffs into natural language.
"""
from __future__ import annotations

import logging

from ..llm_provider import LLMProvider
from .triage import ROUTE_TABLE_NARRATE

logger = logging.getLogger(__name__)

TABLE_NARRATE_PROMPT = """You are a technical document analyst. Describe the following table changes concisely, suitable for an engineering change notice.

Table: {element_id} (Page {page})
Changes:
{change_description}

Provide a brief (1-3 sentence) summary of what changed and its potential impact."""


def table_narration_node(state: dict) -> dict:
    """LangGraph node: Generate natural language descriptions for table changes."""
    config = state.get("config", {})
    triaged = state.get("triaged", {})
    tables = triaged.get(ROUTE_TABLE_NARRATE, [])

    if not tables:
        return state

    llm = LLMProvider(config)
    verified = state.get("verified_changes", [])

    for change in tables:
        change_parts = []
        if change.added_rows:
            change_parts.append(f"- {len(change.added_rows)} row(s) added: {_summarize_rows(change.added_rows)}")
        if change.removed_rows:
            change_parts.append(f"- {len(change.removed_rows)} row(s) removed: {_summarize_rows(change.removed_rows)}")
        if change.modified_cells:
            for cell in change.modified_cells[:10]:
                change_parts.append(
                    f"- Cell [{cell.get('row')}, {cell.get('col')}]: "
                    f"'{cell.get('old')}' -> '{cell.get('new')}'"
                )
        if change.added_columns:
            change_parts.append(f"- Columns added: {', '.join(change.added_columns)}")
        if change.removed_columns:
            change_parts.append(f"- Columns removed: {', '.join(change.removed_columns)}")

        change_desc = "\n".join(change_parts) if change_parts else "No details"

        if llm.is_ollama_available:
            prompt = TABLE_NARRATE_PROMPT.format(
                element_id=change.element_id,
                page=change.page_new or change.page_old or "?",
                change_description=change_desc,
            )
            response = llm.generate_text(prompt)
            change.description = response.strip()[:500]
        else:
            change.description = f"Table updated: {change_desc}"

        verified.append(change)
        logger.info("Table narrated %s: %s", change.element_id, change.description[:80])

    return {**state, "verified_changes": verified}


def _summarize_rows(rows: list[dict], max_show: int = 3) -> str:
    parts = []
    for row in rows[:max_show]:
        parts.append(str({k: v for k, v in list(row.items())[:3]}))
    if len(rows) > max_show:
        parts.append(f"...and {len(rows) - max_show} more")
    return "; ".join(parts)
