"""
Visual Verification Node: Uses VLM to confirm or reject ambiguous image changes.
"""
from __future__ import annotations

import logging

from ..llm_provider import LLMProvider
from .triage import ROUTE_VISUAL_VERIFY

logger = logging.getLogger(__name__)

VISUAL_VERIFY_PROMPT = (
    "You are a technical document analyst comparing two image regions.\n"
    "SSIM similarity: {ssim_score:.3f} (1.0 = identical).\n\n"
    "Determine:\n1. Is there a meaningful visual change? (yes/no)\n"
    "2. If yes, describe concisely.\n3. Confidence: high/medium/low\n\n"
    "Format:\nCHANGED: yes/no\nDESCRIPTION: ...\nCONFIDENCE: ..."
)


def visual_verification_node(state: dict) -> dict:
    """LangGraph node: Verify ambiguous image changes with VLM."""
    config = state.get("config", {})
    triaged = state.get("triaged", {})
    changes = triaged.get(ROUTE_VISUAL_VERIFY, [])
    if not changes:
        return state

    llm = LLMProvider(config)
    verified = state.get("verified_changes", [])

    for change in changes:
        if llm.is_ollama_available and getattr(change, "diff_image_path", None):
            prompt = VISUAL_VERIFY_PROMPT.format(ssim_score=change.ssim_score)
            resp = llm.describe_image(prompt, change.diff_image_path)
            change.description = _parse_response(resp)
        else:
            change.description = (
                f"Image change detected (SSIM={change.ssim_score:.3f}). "
                "VLM verification unavailable."
            )
        verified.append(change)
        logger.info("VLM verified %s: %s", change.element_id, change.description[:80])

    return {**state, "verified_changes": verified}


def _parse_response(response: str) -> str:
    for line in response.split("\n"):
        if line.strip().upper().startswith("DESCRIPTION:"):
            return line.split(":", 1)[1].strip()
    return response[:200] if response else "No description available."
