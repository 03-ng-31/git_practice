"""
LLM Provider: Unified interface for CPU (Ollama) and GPU (transformers/vllm) model access.
Handles lazy loading, fallback, and both text and vision LLM calls.
"""
from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)


class LLMProvider:
    """Unified interface for calling LLMs via Ollama or direct transformers."""

    def __init__(self, config: dict):
        agent_cfg = config.get("agent", {})
        self.device = agent_cfg.get("device", "cpu")
        models = agent_cfg.get("models", {}).get(self.device, {})
        self.text_model_name = models.get("text_llm", "qwen2.5:1.5b")
        self.vlm_model_name = models.get("vlm", "moondream")
        self.ollama_endpoint = agent_cfg.get(
            "ollama_endpoint", "http://localhost:11434"
        )
        self._ollama_available: Optional[bool] = None

    @property
    def is_ollama_available(self) -> bool:
        if self._ollama_available is None:
            self._ollama_available = self._check_ollama()
        return self._ollama_available

    def generate_text(self, prompt: str, model: Optional[str] = None) -> str:
        """Generate text from a prompt using the text LLM."""
        model = model or self.text_model_name
        if self.is_ollama_available:
            return self._call_ollama(prompt, model)
        logger.warning("No LLM available. Returning empty response.")
        return ""

    def describe_image(
        self, prompt: str, image_path: Optional[str] = None, model: Optional[str] = None
    ) -> str:
        """Describe an image using a vision-language model."""
        model = model or self.vlm_model_name
        if self.is_ollama_available:
            return self._call_ollama_vision(prompt, image_path, model)
        logger.warning("No VLM available. Returning empty response.")
        return ""

    def _check_ollama(self) -> bool:
        try:
            import requests
            resp = requests.get(
                f"{self.ollama_endpoint}/api/tags", timeout=5
            )
            if resp.status_code == 200:
                models = [m["name"] for m in resp.json().get("models", [])]
                logger.info("Ollama available. Models: %s", models)
                return True
        except Exception as e:
            logger.debug("Ollama not available: %s", e)
        return False

    def _call_ollama(self, prompt: str, model: str) -> str:
        try:
            import requests
            resp = requests.post(
                f"{self.ollama_endpoint}/api/generate",
                json={"model": model, "prompt": prompt, "stream": False},
                timeout=120,
            )
            if resp.status_code == 200:
                return resp.json().get("response", "")
            logger.warning("Ollama returned %d", resp.status_code)
            return ""
        except Exception as e:
            logger.error("Ollama call failed: %s", e)
            return ""

    def _call_ollama_vision(
        self, prompt: str, image_path: Optional[str], model: str
    ) -> str:
        try:
            import base64
            import requests

            payload: dict = {
                "model": model,
                "prompt": prompt,
                "stream": False,
            }
            if image_path:
                with open(image_path, "rb") as f:
                    b64 = base64.b64encode(f.read()).decode("utf-8")
                payload["images"] = [b64]

            resp = requests.post(
                f"{self.ollama_endpoint}/api/generate",
                json=payload,
                timeout=180,
            )
            if resp.status_code == 200:
                return resp.json().get("response", "")
            return ""
        except Exception as e:
            logger.error("Ollama vision call failed: %s", e)
            return ""
