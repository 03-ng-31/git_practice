"""
Document Comparator - CLI Entry Point.
Compares N PDF versions sequentially and generates a change report.

Usage:
    python -m src.main v1.pdf v2.pdf v3.pdf --config config.yaml --output output/
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
import time
from pathlib import Path

import yaml


def setup_logging(level: str = "INFO"):
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )


def main():
    parser = argparse.ArgumentParser(
        description="Document Comparator - Compare PDF versions and detect changes.",
    )
    parser.add_argument(
        "pdfs",
        nargs="+",
        help="PDF file paths in version order (v1.pdf v2.pdf v3.pdf ...)",
    )
    parser.add_argument(
        "--config", "-c",
        default="config.yaml",
        help="Path to config.yaml (default: config.yaml)",
    )
    parser.add_argument(
        "--output", "-o",
        default="output",
        help="Output directory for reports (default: output/)",
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Logging level (default: INFO)",
    )

    args = parser.parse_args()

    setup_logging(args.log_level)
    logger = logging.getLogger("doc_comparator")

    # Validate inputs
    for pdf_path in args.pdfs:
        if not Path(pdf_path).exists():
            logger.error("PDF not found: %s", pdf_path)
            sys.exit(1)

    if len(args.pdfs) < 2:
        logger.error("Need at least 2 PDF files to compare.")
        sys.exit(1)

    # Load config
    config_path = Path(args.config)
    if config_path.exists():
        with open(config_path, "r") as f:
            config = yaml.safe_load(f)
        logger.info("Loaded config from %s", config_path)
    else:
        logger.warning("Config not found at %s, using defaults", config_path)
        config = {}

    # Run pipeline
    from .comparators.multi_version import MultiVersionComparator

    logger.info("=" * 60)
    logger.info("Document Comparator")
    logger.info("=" * 60)
    logger.info("PDFs: %s", args.pdfs)
    logger.info("Comparison pairs: %d", len(args.pdfs) - 1)

    t_start = time.time()

    comparator = MultiVersionComparator(
        pdf_paths=args.pdfs,
        config=config,
    )
    report = comparator.run()

    elapsed = time.time() - t_start

    # Output results
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    # JSON changelog
    changelog = {
        "versions": report.version_labels,
        "total_changes": report.total_changes,
        "changes_by_type": report.changes_by_type,
        "changes_by_pair": report.changes_by_pair,
        "elapsed_seconds": round(elapsed, 2),
        "pairwise_diffs": [
            {
                "pair": diff.version_label,
                "total_changes": diff.total_changes,
                "change_counts": diff.change_counts,
                "pages_added": diff.pages_added,
                "pages_removed": diff.pages_removed,
            }
            for diff in report.pair_diffs
        ],
        "version_timeline": [
            {
                "element_id": entry.element_id,
                "element_type": entry.element_type,
                "changes": entry.changes_by_pair,
            }
            for entry in report.version_timeline
        ],
    }

    json_path = output_dir / "changelog.json"
    with open(json_path, "w") as f:
        json.dump(changelog, f, indent=2, default=str)

    logger.info("-" * 60)
    logger.info("RESULTS")
    logger.info("-" * 60)
    logger.info("Total changes: %d", report.total_changes)
    logger.info("Changes by type: %s", report.changes_by_type)
    for diff in report.pair_diffs:
        logger.info(
            "  %s: %d changes %s",
            diff.version_label, diff.total_changes, diff.change_counts,
        )
    logger.info("Elapsed: %.2fs", elapsed)
    logger.info("Report saved to: %s", json_path)


if __name__ == "__main__":
    main()
