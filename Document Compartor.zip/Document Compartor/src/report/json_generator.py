"""
Layer 5: JSON Changelog Generator.
Produces a structured JSON changelog from a MultiVersionReport.
"""
from __future__ import annotations

import json
import logging
import os
from datetime import datetime
from typing import Optional

from ..models.comparison_ir import MultiVersionReport

logger = logging.getLogger(__name__)


class JSONReportGenerator:
    """Generates structured JSON changelogs from MultiVersionReport."""

    def __init__(self, config: dict):
        self.output_dir = config.get("report", {}).get("output_dir", "output")

    def generate(
        self,
        report: MultiVersionReport,
        output_path: Optional[str] = None,
    ) -> str:
        """Generate JSON changelog and write to file."""
        if output_path is None:
            os.makedirs(self.output_dir, exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = os.path.join(self.output_dir, f"changelog_{timestamp}.json")

        changelog = {
            "generated_at": datetime.now().isoformat(),
            "versions": report.version_labels,
            "total_changes": report.total_changes,
            "changes_by_type": report.changes_by_type,
            "executive_summary": report.executive_summary,
            "pairwise_diffs": [],
            "version_timeline": [],
        }

        for diff in report.pair_diffs:
            pair_data = {
                "pair": diff.version_label,
                "total_changes": diff.total_changes,
                "change_counts": diff.change_counts,
                "summary": diff.summary,
                "pages_added": diff.pages_added,
                "pages_removed": diff.pages_removed,
                "text_changes": [
                    {
                        "type": c.change_type.value,
                        "element_id": c.element_id,
                        "page_old": c.page_old,
                        "page_new": c.page_new,
                        "old_text": c.old_text[:500] if c.old_text else None,
                        "new_text": c.new_text[:500] if c.new_text else None,
                        "semantic_similarity": round(c.semantic_similarity, 3),
                        "confidence": round(c.confidence, 3),
                        "description": c.description,
                    }
                    for c in diff.text_changes
                ],
                "table_changes": [
                    {
                        "type": c.change_type.value,
                        "element_id": c.element_id,
                        "added_rows": len(c.added_rows),
                        "removed_rows": len(c.removed_rows),
                        "modified_cells": len(c.modified_cells),
                        "description": c.description,
                    }
                    for c in diff.table_changes
                ],
                "image_changes": [
                    {
                        "type": c.change_type.value,
                        "element_id": c.element_id,
                        "ssim_score": round(c.ssim_score, 3),
                        "phash_distance": c.phash_distance,
                        "description": c.description,
                    }
                    for c in diff.image_changes
                ],
                "drawing_changes": [
                    {
                        "type": c.change_type.value,
                        "element_id": c.element_id,
                        "ssim_score": round(c.ssim_score, 3),
                        "contour_diff_ratio": round(c.contour_diff_ratio, 3),
                        "dimension_changes": c.dimension_changes,
                        "description": c.description,
                    }
                    for c in diff.drawing_changes
                ],
            }
            changelog["pairwise_diffs"].append(pair_data)

        for entry in report.version_timeline:
            changelog["version_timeline"].append({
                "element_id": entry.element_id,
                "element_type": entry.element_type,
                "changes": entry.changes_by_pair,
            })

        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(changelog, f, indent=2, default=str, ensure_ascii=False)

        logger.info("JSON changelog generated: %s", output_path)
        return output_path
