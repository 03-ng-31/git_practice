"""
Layer 5: HTML Report Generator using Jinja2 templates.
Produces a self-contained HTML report from a MultiVersionReport.
"""
from __future__ import annotations

import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Optional

from jinja2 import Environment, FileSystemLoader

from ..models.comparison_ir import MultiVersionReport

logger = logging.getLogger(__name__)


class HTMLReportGenerator:
    """Generates HTML comparison reports from MultiVersionReport."""

    def __init__(self, config: dict):
        report_cfg = config.get("report", {})
        self.output_dir = report_cfg.get("output_dir", "output")

        # Resolve template directory
        template_dir = str(Path(__file__).parent / "templates")
        self.env = Environment(
            loader=FileSystemLoader(template_dir),
            autoescape=False,
        )
        self.template_name = "report.html"

    def generate(
        self,
        report: MultiVersionReport,
        output_path: Optional[str] = None,
    ) -> str:
        """
        Generate HTML report and write to file.

        Args:
            report: MultiVersionReport with all comparison data.
            output_path: Output file path. Defaults to output_dir/report_<ts>.html.

        Returns:
            Path to generated HTML file.
        """
        if output_path is None:
            os.makedirs(self.output_dir, exist_ok=True)
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = os.path.join(self.output_dir, f"report_{ts}.html")

        pair_labels = [d.version_label for d in report.pair_diffs]

        context = {
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "version_labels": report.version_labels,
            "total_changes": report.total_changes,
            "changes_by_type": report.changes_by_type,
            "changes_by_pair": report.changes_by_pair,
            "executive_summary": report.executive_summary,
            "pair_diffs": report.pair_diffs,
            "pair_labels": pair_labels,
            "version_timeline": report.version_timeline,
        }

        template = self.env.get_template(self.template_name)
        html = template.render(**context)

        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)

        logger.info("HTML report generated: %s", output_path)
        return output_path

    def render_to_string(self, report: MultiVersionReport) -> str:
        """Render HTML report to string (for serving via API)."""
        pair_labels = [d.version_label for d in report.pair_diffs]
        context = {
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "version_labels": report.version_labels,
            "total_changes": report.total_changes,
            "changes_by_type": report.changes_by_type,
            "changes_by_pair": report.changes_by_pair,
            "executive_summary": report.executive_summary,
            "pair_diffs": report.pair_diffs,
            "pair_labels": pair_labels,
            "version_timeline": report.version_timeline,
        }
        template = self.env.get_template(self.template_name)
        return template.render(**context)
