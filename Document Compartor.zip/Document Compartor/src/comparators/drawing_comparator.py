"""
Layer 3: Engineering drawing comparison engine.
Visual overlay diff, dimension OCR, structural contour comparison.
"""
from __future__ import annotations

import logging
import os
import re
from typing import Optional

import cv2
import numpy as np

from ..models.comparison_ir import ChangeType, DrawingChange

logger = logging.getLogger(__name__)


class DrawingComparator:
    """Compares engineering drawings between two document versions."""

    def __init__(self, config: dict):
        draw_config = config.get("comparison", {}).get("drawing", {})
        self.feature_detector = draw_config.get("feature_detector", "ORB")
        self.min_match_count = draw_config.get("min_match_count", 10)

    def compare_drawings(
        self,
        old_image: np.ndarray,
        new_image: np.ndarray,
        element_id: str = "",
        page_old: Optional[int] = None,
        page_new: Optional[int] = None,
        output_dir: Optional[str] = None,
    ) -> DrawingChange:
        """Compare two engineering drawings."""
        aligned_old, aligned_new = self._align_drawings(old_image, new_image)
        ssim_score = self._compute_ssim(aligned_old, aligned_new)
        contour_ratio = self._contour_diff(aligned_old, aligned_new)
        dimension_changes = self._compare_dimensions(aligned_old, aligned_new)

        diff_path = None
        if output_dir:
            diff_path = self._save_drawing_diff(
                aligned_old, aligned_new, element_id, output_dir
            )

        has_changes = ssim_score < 0.95 or contour_ratio > 0.05 or dimension_changes
        change_type = ChangeType.MODIFIED if has_changes else ChangeType.UNCHANGED

        return DrawingChange(
            change_type=change_type,
            page_old=page_old,
            page_new=page_new,
            element_id=element_id,
            ssim_score=ssim_score,
            contour_diff_ratio=contour_ratio,
            dimension_changes=dimension_changes,
            diff_image_path=diff_path,
            confidence=0.75,
        )

    def _align_drawings(self, old_img, new_img):
        """Align using feature matching + homography."""
        gray_old = cv2.cvtColor(old_img, cv2.COLOR_BGR2GRAY)
        gray_new = cv2.cvtColor(new_img, cv2.COLOR_BGR2GRAY)

        if self.feature_detector == "SIFT":
            detector = cv2.SIFT_create()
            matcher = cv2.BFMatcher(cv2.NORM_L2)
        else:
            detector = cv2.ORB_create(nfeatures=2000)
            matcher = cv2.BFMatcher(cv2.NORM_HAMMING)

        kp1, des1 = detector.detectAndCompute(gray_old, None)
        kp2, des2 = detector.detectAndCompute(gray_new, None)

        if des1 is None or des2 is None or len(kp1) < 4 or len(kp2) < 4:
            return self._simple_resize(old_img, new_img)

        try:
            matches = matcher.knnMatch(des1, des2, k=2)
        except Exception:
            return self._simple_resize(old_img, new_img)

        good = []
        for pair in matches:
            if len(pair) == 2:
                m, n = pair
                if m.distance < 0.75 * n.distance:
                    good.append(m)

        if len(good) < self.min_match_count:
            return self._simple_resize(old_img, new_img)

        src = np.float32([kp1[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
        dst = np.float32([kp2[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)
        H, _ = cv2.findHomography(src, dst, cv2.RANSAC, 5.0)
        if H is None:
            return self._simple_resize(old_img, new_img)

        h, w = new_img.shape[:2]
        aligned = cv2.warpPerspective(old_img, H, (w, h))
        return aligned, new_img

    def _contour_diff(self, old_img, new_img) -> float:
        """Compare edge maps to detect geometry changes."""
        edges_old = cv2.Canny(cv2.cvtColor(old_img, cv2.COLOR_BGR2GRAY), 50, 150)
        edges_new = cv2.Canny(cv2.cvtColor(new_img, cv2.COLOR_BGR2GRAY), 50, 150)
        diff_edges = cv2.bitwise_xor(edges_old, edges_new)
        total = max(np.count_nonzero(edges_old) + np.count_nonzero(edges_new), 1)
        return np.count_nonzero(diff_edges) / total

    def _compare_dimensions(self, old_img, new_img) -> list[dict]:
        """Extract and compare dimension annotations via OCR."""
        old_dims = self._extract_dimensions(old_img)
        new_dims = self._extract_dimensions(new_img)
        changes = []
        for label in set(old_dims) | set(new_dims):
            ov = old_dims.get(label)
            nv = new_dims.get(label)
            if ov != nv:
                changes.append({"label": label, "old": ov, "new": nv})
        return changes

    def _extract_dimensions(self, image) -> dict:
        """OCR dimension text from drawing image."""
        try:
            import pytesseract
            from PIL import Image
            pil = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
            text = pytesseract.image_to_string(pil, config="--psm 6")
            dims = {}
            for i, (val, unit) in enumerate(
                re.findall(r"(\d+\.?\d*)\s*(mm|cm|m|in|inch|ft)?", text, re.I)
            ):
                dims[f"dim_{i}"] = f"{val} {unit}".strip()
            return dims
        except Exception:
            return {}

    def _compute_ssim(self, img1, img2) -> float:
        try:
            from skimage.metrics import structural_similarity
            g1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
            g2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
            score, _ = structural_similarity(g1, g2, full=True)
            return float(score)
        except Exception:
            return 0.0

    def _save_drawing_diff(self, old_img, new_img, element_id, output_dir) -> str:
        os.makedirs(output_dir, exist_ok=True)
        g_old = cv2.cvtColor(old_img, cv2.COLOR_BGR2GRAY)
        g_new = cv2.cvtColor(new_img, cv2.COLOR_BGR2GRAY)
        diff = np.zeros((*g_old.shape, 3), dtype=np.uint8)
        diff[:, :, 0] = g_old
        diff[:, :, 1] = g_new
        diff[:, :, 2] = np.minimum(g_old, g_new)
        fp = os.path.join(output_dir, f"drawing_diff_{element_id}.png")
        cv2.imwrite(fp, diff)
        return fp

    @staticmethod
    def _simple_resize(img1, img2):
        h = max(img1.shape[0], img2.shape[0])
        w = max(img1.shape[1], img2.shape[1])
        return (
            cv2.resize(img1, (w, h), interpolation=cv2.INTER_AREA),
            cv2.resize(img2, (w, h), interpolation=cv2.INTER_AREA),
        )
