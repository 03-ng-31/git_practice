"""
Layer 3: Text comparison engine.
Two-tier approach: structural diff (difflib) + semantic diff (sentence-transformers).
"""
from __future__ import annotations

import difflib
import logging
from typing import Optional

from ..models.comparison_ir import ChangeType, TextChange

logger = logging.getLogger(__name__)


class TextComparator:
    """Compares text elements between two document versions."""

    def __init__(self, config: dict):
        text_config = config.get("comparison", {}).get("text", {})
        self.semantic_model_name = text_config.get(
            "semantic_model", "all-MiniLM-L6-v2"
        )
        self.semantic_threshold = text_config.get(
            "semantic_similarity_threshold", 0.85
        )
        self._model = None

    @property
    def semantic_model(self):
        """Lazy-load the sentence transformer model."""
        if self._model is None:
            try:
                from sentence_transformers import SentenceTransformer
                logger.info("Loading semantic model: %s", self.semantic_model_name)
                self._model = SentenceTransformer(self.semantic_model_name)
            except ImportError:
                logger.warning(
                    "sentence-transformers not installed. "
                    "Semantic diff will be unavailable."
                )
        return self._model

    def compare_text_blocks(
        self,
        old_texts: list[tuple[str, str]],
        new_texts: list[tuple[str, str]],
    ) -> list[TextChange]:
        """
        Compare aligned text blocks between old and new versions.

        Args:
            old_texts: List of (element_id, text_content) from old version.
            new_texts: List of (element_id, text_content) from new version.

        Returns:
            List of TextChange objects.
        """
        changes = []

        old_map = {eid: text for eid, text in old_texts}
        new_map = {eid: text for eid, text in new_texts}

        all_ids = set(old_map.keys()) | set(new_map.keys())

        for eid in sorted(all_ids):
            old_text = old_map.get(eid)
            new_text = new_map.get(eid)

            if old_text is None:
                changes.append(TextChange(
                    change_type=ChangeType.ADDED,
                    page_old=None,
                    page_new=self._page_from_id(eid),
                    element_id=eid,
                    new_text=new_text or "",
                    confidence=0.95,
                ))
            elif new_text is None:
                changes.append(TextChange(
                    change_type=ChangeType.REMOVED,
                    page_old=self._page_from_id(eid),
                    page_new=None,
                    element_id=eid,
                    old_text=old_text,
                    confidence=0.95,
                ))
            elif old_text.strip() != new_text.strip():
                diff_html = self._generate_diff_html(old_text, new_text)
                semantic_sim = self._semantic_similarity(old_text, new_text)

                changes.append(TextChange(
                    change_type=ChangeType.MODIFIED,
                    page_old=self._page_from_id(eid),
                    page_new=self._page_from_id(eid),
                    element_id=eid,
                    old_text=old_text,
                    new_text=new_text,
                    diff_html=diff_html,
                    semantic_similarity=semantic_sim,
                    confidence=0.90,
                ))

        return changes

    def compare_full_text(self, old_text: str, new_text: str) -> dict:
        """
        Compare full document text (fallback mode).
        Returns a dict with unified diff and change statistics.
        """
        old_lines = old_text.splitlines(keepends=True)
        new_lines = new_text.splitlines(keepends=True)

        diff = list(difflib.unified_diff(
            old_lines, new_lines,
            fromfile="old", tofile="new",
            lineterm="",
        ))

        added = sum(1 for l in diff if l.startswith("+") and not l.startswith("+++"))
        removed = sum(1 for l in diff if l.startswith("-") and not l.startswith("---"))

        ratio = difflib.SequenceMatcher(None, old_text, new_text).ratio()

        return {
            "unified_diff": "".join(diff),
            "lines_added": added,
            "lines_removed": removed,
            "similarity_ratio": ratio,
        }

    def _generate_diff_html(self, old_text: str, new_text: str) -> str:
        """Generate HTML inline diff showing additions and deletions."""
        old_words = old_text.split()
        new_words = new_text.split()

        matcher = difflib.SequenceMatcher(None, old_words, new_words)
        html_parts = []

        for op, i1, i2, j1, j2 in matcher.get_opcodes():
            if op == "equal":
                html_parts.append(" ".join(old_words[i1:i2]))
            elif op == "replace":
                old_chunk = " ".join(old_words[i1:i2])
                new_chunk = " ".join(new_words[j1:j2])
                html_parts.append(
                    f'<del style="background:#fdd">{old_chunk}</del> '
                    f'<ins style="background:#dfd">{new_chunk}</ins>'
                )
            elif op == "delete":
                html_parts.append(
                    f'<del style="background:#fdd">{" ".join(old_words[i1:i2])}</del>'
                )
            elif op == "insert":
                html_parts.append(
                    f'<ins style="background:#dfd">{" ".join(new_words[j1:j2])}</ins>'
                )

        return " ".join(html_parts)

    def _semantic_similarity(self, text1: str, text2: str) -> float:
        """Compute cosine similarity between two text strings."""
        model = self.semantic_model
        if model is None:
            return 0.0
        try:
            embeddings = model.encode([text1, text2])
            from numpy import dot
            from numpy.linalg import norm
            cos_sim = dot(embeddings[0], embeddings[1]) / (
                norm(embeddings[0]) * norm(embeddings[1])
            )
            return float(cos_sim)
        except Exception as e:
            logger.debug("Semantic similarity failed: %s", e)
            return 0.0

    @staticmethod
    def _page_from_id(element_id: str) -> Optional[int]:
        """Extract page number from element_id like 'p3_text_100_200'."""
        try:
            if element_id.startswith("p"):
                return int(element_id.split("_")[0][1:])
        except (ValueError, IndexError):
            pass
        return None
