"""
Layer 3: Image and figure comparison engine.
Uses perceptual hashing (pHash), SSIM, and pixel-level diff.
"""
from __future__ import annotations

import logging
import os
from typing import Optional

import cv2
import numpy as np

from ..models.comparison_ir import ChangeType, ImageChange

logger = logging.getLogger(__name__)


class ImageComparator:
    """Compares image elements between two document versions."""

    def __init__(self, config: dict):
        img_config = config.get("comparison", {}).get("image", {})
        self.phash_threshold = img_config.get("phash_identical_threshold", 5)
        self.ssim_change_threshold = img_config.get("ssim_change_threshold", 0.95)
        self.ssim_ambiguous_low = img_config.get("ssim_ambiguous_low", 0.70)

    def compare_images(
        self,
        old_image: np.ndarray,
        new_image: np.ndarray,
        element_id: str = "",
        page_old: Optional[int] = None,
        page_new: Optional[int] = None,
        output_dir: Optional[str] = None,
    ) -> ImageChange:
        """
        Compare two images using pHash + SSIM + pixel diff.
        """
        old_resized, new_resized = self._normalize_sizes(old_image, new_image)

        phash_dist = self._phash_distance(old_resized, new_resized)
        ssim_score = self._compute_ssim(old_resized, new_resized)

        diff_path = None
        if output_dir and ssim_score < self.ssim_change_threshold:
            diff_path = self._save_diff_overlay(
                old_resized, new_resized, element_id, output_dir
            )

        if phash_dist <= self.phash_threshold and ssim_score >= self.ssim_change_threshold:
            change_type = ChangeType.UNCHANGED
        else:
            change_type = ChangeType.MODIFIED

        if ssim_score >= self.ssim_change_threshold:
            confidence = 0.95
        elif ssim_score <= self.ssim_ambiguous_low:
            confidence = 0.90
        else:
            confidence = 0.60

        return ImageChange(
            change_type=change_type,
            page_old=page_old,
            page_new=page_new,
            element_id=element_id,
            ssim_score=ssim_score,
            phash_distance=phash_dist,
            diff_image_path=diff_path,
            confidence=confidence,
        )

    def _phash_distance(self, img1: np.ndarray, img2: np.ndarray) -> int:
        """Compute perceptual hash Hamming distance."""
        try:
            import imagehash
            from PIL import Image
            pil1 = Image.fromarray(cv2.cvtColor(img1, cv2.COLOR_BGR2RGB))
            pil2 = Image.fromarray(cv2.cvtColor(img2, cv2.COLOR_BGR2RGB))
            hash1 = imagehash.phash(pil1)
            hash2 = imagehash.phash(pil2)
            return hash1 - hash2
        except ImportError:
            logger.warning("imagehash not installed, skipping pHash")
            return 99
        except Exception as e:
            logger.debug("pHash failed: %s", e)
            return 99

    def _compute_ssim(self, img1: np.ndarray, img2: np.ndarray) -> float:
        """Compute Structural Similarity Index."""
        try:
            from skimage.metrics import structural_similarity
            gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
            gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
            score, _ = structural_similarity(gray1, gray2, full=True)
            return float(score)
        except ImportError:
            logger.warning("scikit-image not available, using basic comparison")
            diff = cv2.absdiff(img1, img2)
            return 1.0 - (np.mean(diff) / 255.0)
        except Exception as e:
            logger.debug("SSIM failed: %s", e)
            return 0.0

    def _save_diff_overlay(
        self, old_img, new_img, element_id, output_dir
    ) -> str:
        """Create and save a red/green diff overlay image."""
        os.makedirs(output_dir, exist_ok=True)
        diff = cv2.absdiff(old_img, new_img)
        gray_diff = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)
        _, mask = cv2.threshold(gray_diff, 30, 255, cv2.THRESH_BINARY)
        overlay = old_img.copy()
        red_mask = np.zeros_like(old_img)
        red_mask[:, :, 2] = mask
        overlay = cv2.addWeighted(overlay, 0.7, red_mask, 0.3, 0)
        filepath = os.path.join(output_dir, f"diff_{element_id}.png")
        cv2.imwrite(filepath, overlay)
        return filepath

    @staticmethod
    def _normalize_sizes(img1, img2):
        """Resize both images to the same dimensions."""
        h = max(img1.shape[0], img2.shape[0])
        w = max(img1.shape[1], img2.shape[1])
        if img1.shape[:2] != (h, w):
            img1 = cv2.resize(img1, (w, h), interpolation=cv2.INTER_AREA)
        if img2.shape[:2] != (h, w):
            img2 = cv2.resize(img2, (w, h), interpolation=cv2.INTER_AREA)
        return img1, img2
