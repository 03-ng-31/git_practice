"""
Layer 3: Page alignment between two document versions.
Matches pages from old to new, detecting insertions/deletions.
"""
from __future__ import annotations

import logging
from typing import Optional

from ..models.document_ir import ParsedDocument

logger = logging.getLogger(__name__)


class PageAligner:
    """Aligns pages between two document versions for comparison."""

    def __init__(self, config: dict):
        pa_config = config.get("comparison", {}).get("page_alignment", {})
        self.method = pa_config.get("method", "sequential")
        self.similarity_threshold = pa_config.get("similarity_threshold", 0.80)

    def align(
        self,
        old_doc: ParsedDocument,
        new_doc: ParsedDocument,
    ) -> list[tuple[Optional[int], Optional[int]]]:
        """
        Align pages between old and new documents.
        Returns list of (old_page_num, new_page_num) tuples.
        None = page added or removed.
        """
        if self.method == "similarity":
            return self._align_by_similarity(old_doc, new_doc)
        return self._align_sequential(old_doc, new_doc)

    def _align_sequential(self, old_doc, new_doc):
        alignment = []
        max_pages = max(old_doc.page_count, new_doc.page_count)
        for i in range(max_pages):
            old_p = i if i < old_doc.page_count else None
            new_p = i if i < new_doc.page_count else None
            alignment.append((old_p, new_p))
        return alignment

    def _align_by_similarity(self, old_doc, new_doc):
        from difflib import SequenceMatcher

        old_texts = [p.full_text for p in old_doc.pages]
        new_texts = [p.full_text for p in new_doc.pages]

        sim = []
        for i, ot in enumerate(old_texts):
            for j, nt in enumerate(new_texts):
                ratio = SequenceMatcher(None, ot, nt).quick_ratio()
                sim.append((ratio, i, j))
        sim.sort(reverse=True)

        alignment = []
        used_old, used_new = set(), set()

        for score, i, j in sim:
            if i in used_old or j in used_new:
                continue
            if score >= self.similarity_threshold:
                alignment.append((i, j))
                used_old.add(i)
                used_new.add(j)

        for i in range(len(old_texts)):
            if i not in used_old:
                alignment.append((i, None))
        for j in range(len(new_texts)):
            if j not in used_new:
                alignment.append((None, j))

        alignment.sort(key=lambda x: (
            x[0] if x[0] is not None else float("inf"),
            x[1] if x[1] is not None else float("inf"),
        ))
        return alignment
