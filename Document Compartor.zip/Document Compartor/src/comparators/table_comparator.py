"""
Layer 3: Table comparison engine.
Cell-level diff between pandas DataFrames, with column alignment.
"""
from __future__ import annotations

import logging
from typing import Optional

import pandas as pd

from ..models.comparison_ir import ChangeType, TableChange

logger = logging.getLogger(__name__)


class TableComparator:
    """Compares table elements (as DataFrames) between two document versions."""

    def __init__(self, config: dict):
        self.config = config

    def compare_tables(
        self,
        old_df: pd.DataFrame,
        new_df: pd.DataFrame,
        element_id: str = "",
        table_index: int = 0,
        page_old: Optional[int] = None,
        page_new: Optional[int] = None,
    ) -> TableChange:
        """
        Compare two tables at the cell level.
        """
        old_df, new_df = self._align_columns(old_df, new_df)

        old_cols = set(old_df.columns)
        new_cols = set(new_df.columns)
        added_cols = list(new_cols - old_cols)
        removed_cols = list(old_cols - new_cols)

        common_cols = list(old_cols & new_cols)
        if not common_cols:
            return TableChange(
                change_type=ChangeType.MODIFIED,
                page_old=page_old,
                page_new=page_new,
                element_id=element_id,
                table_index=table_index,
                added_columns=added_cols,
                removed_columns=removed_cols,
                confidence=0.70,
            )

        old_common = old_df[common_cols].reset_index(drop=True)
        new_common = new_df[common_cols].reset_index(drop=True)

        added_rows, removed_rows, modified_cells = self._diff_rows(
            old_common, new_common
        )

        has_changes = (
            added_rows or removed_rows or modified_cells
            or added_cols or removed_cols
        )
        change_type = ChangeType.MODIFIED if has_changes else ChangeType.UNCHANGED

        return TableChange(
            change_type=change_type,
            page_old=page_old,
            page_new=page_new,
            element_id=element_id,
            table_index=table_index,
            added_rows=added_rows,
            removed_rows=removed_rows,
            modified_cells=modified_cells,
            added_columns=added_cols,
            removed_columns=removed_cols,
            confidence=0.85,
        )

    def _align_columns(self, old_df, new_df):
        """Align columns between two DataFrames by normalized name."""
        def normalize_col(col):
            return str(col).strip().lower()

        old_norm = {normalize_col(c): c for c in old_df.columns}
        new_norm = {normalize_col(c): c for c in new_df.columns}

        rename_map = {}
        for norm_name, new_col in new_norm.items():
            if norm_name in old_norm and old_norm[norm_name] != new_col:
                rename_map[new_col] = old_norm[norm_name]

        if rename_map:
            new_df = new_df.rename(columns=rename_map)
        return old_df, new_df

    def _diff_rows(self, old_df, new_df):
        """Compare rows cell-by-cell."""
        added_rows = []
        removed_rows = []
        modified_cells = []

        old_str = old_df.astype(str)
        new_str = new_df.astype(str)
        max_rows = max(len(old_str), len(new_str))

        for i in range(max_rows):
            if i >= len(old_str):
                added_rows.append(new_df.iloc[i].to_dict())
            elif i >= len(new_str):
                removed_rows.append(old_df.iloc[i].to_dict())
            else:
                for col in old_str.columns:
                    old_val = old_str.iloc[i][col]
                    new_val = new_str.iloc[i][col]
                    if old_val != new_val:
                        modified_cells.append({
                            "row": i,
                            "col": col,
                            "old": old_df.iloc[i][col],
                            "new": new_df.iloc[i][col],
                        })

        return added_rows, removed_rows, modified_cells
