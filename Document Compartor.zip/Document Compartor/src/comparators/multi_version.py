"""
Multi-version sequential comparator orchestrator.
Compares V1->V2, V2->V3, ... and produces a cumulative report.
"""
from __future__ import annotations

import concurrent.futures
import hashlib
import logging
import os
import pickle
from itertools import pairwise
from pathlib import Path
from typing import Optional

import yaml

from ..models.comparison_ir import (
    MultiVersionReport,
    PairwiseDiff,
    VersionTimelineEntry,
)
from ..models.document_ir import ParsedDocument

logger = logging.getLogger(__name__)


class MultiVersionComparator:
    """
    Orchestrates sequential comparison across N document versions.

    Key optimization: each PDF is parsed once through Layers 0-2,
    cached to disk, and reused across pairwise comparisons.
    """

    def __init__(
        self,
        pdf_paths: list[str],
        config: Optional[dict] = None,
        config_path: Optional[str] = None,
    ):
        if config is None and config_path:
            with open(config_path, "r") as f:
                config = yaml.safe_load(f)
        self.config = config or {}
        self.pdf_paths = pdf_paths
        self.max_workers = self.config.get("general", {}).get("max_workers", 4)
        self.cache_dir = self.config.get("general", {}).get(
            "cache_dir", ".cache/parsed"
        )
        self.parsed_cache: dict[str, ParsedDocument] = {}

    def run(self) -> MultiVersionReport:
        """
        Execute the full multi-version comparison pipeline.

        1. Parse all versions (parallelizable)
        2. Sequential pairwise comparison
        3. Build cumulative report

        Returns:
            MultiVersionReport with all pair diffs and summary.
        """
        # Step 1: Parse all versions
        logger.info(
            "Parsing %d PDF versions with %d workers...",
            len(self.pdf_paths), self.max_workers,
        )
        self._parse_all_versions()

        # Step 2: Sequential pairwise comparison
        logger.info("Running sequential pairwise comparisons...")
        pair_diffs = []
        for old_path, new_path in pairwise(self.pdf_paths):
            old_doc = self.parsed_cache[old_path]
            new_doc = self.parsed_cache[new_path]
            diff = self._compare_pair(old_doc, new_doc)
            diff.version_old = old_path
            diff.version_new = new_path
            diff.version_label = f"{Path(old_path).stem} -> {Path(new_path).stem}"
            pair_diffs.append(diff)
            logger.info(
                "  %s: %d changes", diff.version_label, diff.total_changes
            )

        # Step 3: Build report
        report = MultiVersionReport(
            version_paths=self.pdf_paths,
            version_labels=[Path(p).stem for p in self.pdf_paths],
            pair_diffs=pair_diffs,
        )
        report.version_timeline = self._build_timeline(pair_diffs)
        report.compute_statistics()

        logger.info(
            "Multi-version comparison complete: %d total changes across %d pairs",
            report.total_changes, len(pair_diffs),
        )
        return report

    # ── Parsing ──────────────────────────────────────────────────────

    def _parse_all_versions(self) -> None:
        """Parse all PDF versions, using cache and parallelism."""
        paths_to_parse = [
            p for p in self.pdf_paths if p not in self.parsed_cache
        ]

        if not paths_to_parse:
            return

        # Check disk cache
        uncached = []
        for path in paths_to_parse:
            cached = self._load_from_cache(path)
            if cached is not None:
                self.parsed_cache[path] = cached
                logger.info("  Loaded from cache: %s", path)
            else:
                uncached.append(path)

        if not uncached:
            return

        # Parse uncached in parallel
        with concurrent.futures.ProcessPoolExecutor(
            max_workers=min(self.max_workers, len(uncached))
        ) as executor:
            futures = {
                executor.submit(self._parse_single, path): path
                for path in uncached
            }
            for future in concurrent.futures.as_completed(futures):
                path = futures[future]
                try:
                    doc = future.result()
                    self.parsed_cache[path] = doc
                    self._save_to_cache(path, doc)
                    logger.info("  Parsed: %s (%s)", path, doc.summary())
                except Exception as e:
                    logger.error("  Failed to parse %s: %s", path, e)
                    raise

    def _parse_single(self, pdf_path: str) -> ParsedDocument:
        """
        Parse a single PDF through Layers 0-2.
        This is a placeholder -- the actual implementation will use
        the full preprocessing + classification + extraction pipeline.
        """
        # Import here to avoid issues with multiprocessing
        import fitz

        from ..preprocessing.image_preprocessor import ImagePreprocessor
        from ..classifier.page_classifier import PageClassifier
        from ..models.document_ir import PageData, DocumentElement
        from ..models.classification_ir import RegionType

        preprocessor = ImagePreprocessor(self.config)
        classifier = PageClassifier(self.config)

        doc = fitz.open(pdf_path)
        parsed = ParsedDocument(
            source_path=pdf_path,
            version_label=Path(pdf_path).stem,
            total_pages=doc.page_count,
        )

        full_text_parts = []

        for page in doc:
            # Classify
            classification = classifier.classify_page(page)

            # Extract text (basic -- will be enhanced with Docling/Surya)
            text = page.get_text("text").strip()
            full_text_parts.append(text)

            page_data = PageData(
                page_number=page.number,
                classification=classification,
                width=page.rect.width,
                height=page.rect.height,
            )

            # Add text element
            if text:
                page_data.elements.append(DocumentElement(
                    element_type="text",
                    page_number=page.number,
                    bounding_box=(0, 0, page.rect.width, page.rect.height),
                    content=text,
                    region_type=RegionType.NATIVE_TEXT,
                    extraction_strategy="direct",
                    confidence=classification.confidence,
                    reading_order=0,
                ))

            parsed.pages.append(page_data)

        parsed.raw_full_text = "\n\n".join(full_text_parts)
        doc.close()
        return parsed

    # ── Comparison ───────────────────────────────────────────────────

    def _compare_pair(
        self, old_doc: ParsedDocument, new_doc: ParsedDocument
    ) -> PairwiseDiff:
        """Compare two parsed documents."""
        from .page_aligner import PageAligner
        from .text_comparator import TextComparator

        aligner = PageAligner(self.config)
        text_comp = TextComparator(self.config)

        alignment = aligner.align(old_doc, new_doc)

        diff = PairwiseDiff()
        diff.page_alignment = alignment

        # Compare aligned pages
        for old_page_num, new_page_num in alignment:
            if old_page_num is None:
                diff.pages_added.append(new_page_num)
                continue
            if new_page_num is None:
                diff.pages_removed.append(old_page_num)
                continue

            old_page = old_doc.get_page(old_page_num)
            new_page = new_doc.get_page(new_page_num)
            if old_page is None or new_page is None:
                continue

            # Text comparison
            old_texts = [
                (el.element_id, el.content)
                for el in old_page.text_elements
                if isinstance(el.content, str)
            ]
            new_texts = [
                (el.element_id, el.content)
                for el in new_page.text_elements
                if isinstance(el.content, str)
            ]
            text_changes = text_comp.compare_text_blocks(old_texts, new_texts)
            diff.text_changes.extend(text_changes)

            # Image comparison would go here
            # Table comparison would go here
            # Drawing comparison would go here

        return diff

    # ── Caching ──────────────────────────────────────────────────────

    def _cache_key(self, pdf_path: str) -> str:
        """Generate cache key from file content hash."""
        hasher = hashlib.md5()
        with open(pdf_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                hasher.update(chunk)
        return hasher.hexdigest()

    def _cache_path(self, pdf_path: str) -> str:
        key = self._cache_key(pdf_path)
        return os.path.join(self.cache_dir, f"{key}.pkl")

    def _load_from_cache(self, pdf_path: str) -> Optional[ParsedDocument]:
        try:
            cache_file = self._cache_path(pdf_path)
            if os.path.exists(cache_file):
                with open(cache_file, "rb") as f:
                    return pickle.load(f)
        except Exception as e:
            logger.debug("Cache load failed for %s: %s", pdf_path, e)
        return None

    def _save_to_cache(self, pdf_path: str, doc: ParsedDocument) -> None:
        try:
            os.makedirs(self.cache_dir, exist_ok=True)
            cache_file = self._cache_path(pdf_path)
            with open(cache_file, "wb") as f:
                pickle.dump(doc, f)
        except Exception as e:
            logger.debug("Cache save failed for %s: %s", pdf_path, e)

    # ── Timeline ─────────────────────────────────────────────────────

    def _build_timeline(
        self, pair_diffs: list[PairwiseDiff]
    ) -> list[VersionTimelineEntry]:
        """Build element-level version timeline from all pair diffs."""
        timeline_map: dict[str, VersionTimelineEntry] = {}

        for diff in pair_diffs:
            for change in diff.all_changes():
                eid = change.element_id
                if eid not in timeline_map:
                    timeline_map[eid] = VersionTimelineEntry(
                        element_id=eid,
                        element_type=getattr(change, "element_type", "unknown"),
                    )
                description = change.description or change.change_type.value
                timeline_map[eid].changes_by_pair[diff.version_label] = description

        return list(timeline_map.values())
