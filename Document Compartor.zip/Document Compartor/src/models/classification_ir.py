"""
Intermediate Representation for page and region classification.
Layer 1 outputs these dataclasses.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class RegionType(Enum):
    """Type of content region on a page."""
    NATIVE_TEXT = "native_text"
    SCANNED_TEXT = "scanned_text"
    NATIVE_TABLE = "native_table"
    SCANNED_TABLE = "scanned_table"
    IMAGE = "image"
    DRAWING = "drawing"
    FORMULA = "formula"
    HEADER_FOOTER = "header_footer"
    UNKNOWN = "unknown"


@dataclass
class RegionClassification:
    """Classification result for a single region on a page."""
    bbox: tuple[float, float, float, float]  # (x0, y0, x1, y1)
    region_type: RegionType
    confidence: float  # 0.0 to 1.0
    extraction_strategy: str  # "direct" | "ocr" | "visual"
    label: str = ""  # Original label from layout analysis

    @property
    def area(self) -> float:
        x0, y0, x1, y1 = self.bbox
        return abs(x1 - x0) * abs(y1 - y0)


@dataclass
class SignalScores:
    """Individual signal scores from statistical classification."""
    font_presence: float = 0.0
    text_density: float = 0.0
    image_coverage: float = 0.0
    text_quality: float = 0.0
    operator_ratio: float = 0.0
    ocr_confidence: float = 0.0

    def as_dict(self) -> dict[str, float]:
        return {
            "font_presence": self.font_presence,
            "text_density": self.text_density,
            "image_coverage": self.image_coverage,
            "text_quality": self.text_quality,
            "operator_ratio": self.operator_ratio,
            "ocr_confidence": self.ocr_confidence,
        }


@dataclass
class PageClassification:
    """Classification result for a single page."""
    page_number: int
    overall_type: str  # "machine_readable" | "scanned" | "hybrid"
    confidence: float  # Composite score 0.0 to 1.0
    signal_scores: SignalScores = field(default_factory=SignalScores)
    regions: list[RegionClassification] = field(default_factory=list)
    page_width: float = 0.0
    page_height: float = 0.0

    @property
    def is_hybrid(self) -> bool:
        return self.overall_type == "hybrid"

    @property
    def is_scanned(self) -> bool:
        return self.overall_type == "scanned"

    @property
    def is_machine_readable(self) -> bool:
        return self.overall_type == "machine_readable"

    def summary(self) -> str:
        region_counts = {}
        for r in self.regions:
            key = r.region_type.value
            region_counts[key] = region_counts.get(key, 0) + 1
        return (
            f"Page {self.page_number}: {self.overall_type} "
            f"(confidence={self.confidence:.2f}, regions={region_counts})"
        )
