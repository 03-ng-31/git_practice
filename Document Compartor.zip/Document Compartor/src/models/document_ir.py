"""
Intermediate Representation for parsed documents.
Layer 2 outputs these dataclasses. Used by Layer 3+ for comparison.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional, Union

import numpy as np

from .classification_ir import PageClassification, RegionType


@dataclass
class DocumentElement:
    """A single extracted element from a document page."""
    element_type: str  # "text" | "table" | "image" | "drawing" | "formula"
    page_number: int
    bounding_box: tuple[float, float, float, float]  # (x0, y0, x1, y1)
    content: Any  # str | pd.DataFrame | np.ndarray (image) | Path (to cached image)
    region_type: RegionType
    extraction_strategy: str  # "direct" | "ocr" | "visual"
    confidence: float = 1.0  # Extraction confidence (0.0-1.0)
    reading_order: int = 0  # Position in reading order
    metadata: dict = field(default_factory=dict)
    # metadata can include: caption, font_info, ocr_language, table_headers, etc.

    @property
    def element_id(self) -> str:
        """Unique identifier for this element within the document."""
        x0, y0, x1, y1 = self.bounding_box
        return f"p{self.page_number}_{self.element_type}_{int(x0)}_{int(y0)}"

    @property
    def is_text(self) -> bool:
        return self.element_type == "text"

    @property
    def is_table(self) -> bool:
        return self.element_type == "table"

    @property
    def is_image(self) -> bool:
        return self.element_type == "image"

    @property
    def is_drawing(self) -> bool:
        return self.element_type == "drawing"

    @property
    def area(self) -> float:
        x0, y0, x1, y1 = self.bounding_box
        return abs(x1 - x0) * abs(y1 - y0)


@dataclass
class PageData:
    """All extracted elements and metadata for a single page."""
    page_number: int
    elements: list[DocumentElement] = field(default_factory=list)
    classification: Optional[PageClassification] = None
    page_image_path: Optional[str] = None  # Path to pre-processed page image on disk
    raw_image_path: Optional[str] = None  # Path to original unprocessed image
    width: float = 0.0
    height: float = 0.0

    @property
    def text_elements(self) -> list[DocumentElement]:
        return [e for e in self.elements if e.is_text]

    @property
    def table_elements(self) -> list[DocumentElement]:
        return [e for e in self.elements if e.is_table]

    @property
    def image_elements(self) -> list[DocumentElement]:
        return [e for e in self.elements if e.is_image]

    @property
    def drawing_elements(self) -> list[DocumentElement]:
        return [e for e in self.elements if e.is_drawing]

    @property
    def full_text(self) -> str:
        """Concatenate all text elements in reading order."""
        sorted_els = sorted(self.text_elements, key=lambda e: e.reading_order)
        return "\n\n".join(
            e.content for e in sorted_els if isinstance(e.content, str)
        )


@dataclass
class ParsedDocument:
    """
    Complete parsed representation of a single PDF document.
    This is the output of Layers 0-2 and the input to Layer 3.
    """
    source_path: str  # Original PDF file path
    version_label: str = ""  # User-friendly version label (e.g., "V1", "V2")
    pages: list[PageData] = field(default_factory=list)
    total_pages: int = 0
    raw_full_text: str = ""  # Full document text for fallback comparison

    # Metadata
    metadata: dict = field(default_factory=dict)
    # metadata can include: title, author, creation_date, producer, etc.

    @property
    def page_count(self) -> int:
        return len(self.pages)

    def get_page(self, page_number: int) -> Optional[PageData]:
        """Get page by 0-indexed page number."""
        for page in self.pages:
            if page.page_number == page_number:
                return page
        return None

    def all_elements(self, element_type: Optional[str] = None) -> list[DocumentElement]:
        """Get all elements across all pages, optionally filtered by type."""
        elements = []
        for page in self.pages:
            for el in page.elements:
                if element_type is None or el.element_type == element_type:
                    elements.append(el)
        return elements

    def summary(self) -> str:
        type_counts: dict[str, int] = {}
        for el in self.all_elements():
            type_counts[el.element_type] = type_counts.get(el.element_type, 0) + 1
        return (
            f"ParsedDocument('{self.source_path}', "
            f"pages={self.page_count}, elements={type_counts})"
        )
