from .document_ir import DocumentElement, ParsedDocument
from .classification_ir import PageClassification, RegionClassification, RegionType
from .comparison_ir import (
    TextChange, TableChange, ImageChange, DrawingChange,
    PairwiseDiff, MultiVersionReport
)

__all__ = [
    "DocumentElement", "ParsedDocument",
    "PageClassification", "RegionClassification", "RegionType",
    "TextChange", "TableChange", "ImageChange", "DrawingChange",
    "PairwiseDiff", "MultiVersionReport",
]
