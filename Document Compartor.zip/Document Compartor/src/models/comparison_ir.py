"""
Intermediate Representation for comparison results.
Layer 3 outputs these, Layer 4 (agent) enriches them, Layer 5 renders them.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class ChangeType(Enum):
    ADDED = "added"
    REMOVED = "removed"
    MODIFIED = "modified"
    UNCHANGED = "unchanged"


# ── Individual Change Types ──────────────────────────────────────────────


@dataclass
class TextChange:
    """A change in a text element between two document versions."""
    change_type: ChangeType
    page_old: Optional[int]  # None if added
    page_new: Optional[int]  # None if removed
    element_id: str
    old_text: str = ""
    new_text: str = ""
    diff_html: str = ""  # HTML-formatted inline diff
    semantic_similarity: float = 0.0  # 0.0 = completely different, 1.0 = identical
    confidence: float = 1.0
    description: str = ""  # LLM-generated description (filled by agent)

    @property
    def is_semantic_only(self) -> bool:
        """Text changed but meaning stayed the same (paraphrase)."""
        return (
            self.change_type == ChangeType.MODIFIED
            and self.semantic_similarity > 0.85
        )


@dataclass
class TableChange:
    """A change in a table element between two document versions."""
    change_type: ChangeType
    page_old: Optional[int]
    page_new: Optional[int]
    element_id: str
    table_index: int = 0  # Index among tables on the page
    added_rows: list[dict] = field(default_factory=list)
    removed_rows: list[dict] = field(default_factory=list)
    modified_cells: list[dict] = field(default_factory=list)
    # Each modified_cell: {"row": int, "col": str, "old": val, "new": val}
    added_columns: list[str] = field(default_factory=list)
    removed_columns: list[str] = field(default_factory=list)
    confidence: float = 1.0
    description: str = ""

    @property
    def total_cell_changes(self) -> int:
        return len(self.added_rows) + len(self.removed_rows) + len(self.modified_cells)


@dataclass
class ImageChange:
    """A change in an image/figure between two document versions."""
    change_type: ChangeType
    page_old: Optional[int]
    page_new: Optional[int]
    element_id: str
    ssim_score: float = 0.0  # Structural similarity (1.0 = identical)
    phash_distance: int = 0  # Hamming distance (0 = identical)
    diff_image_path: Optional[str] = None  # Path to visual diff overlay
    old_image_path: Optional[str] = None
    new_image_path: Optional[str] = None
    confidence: float = 1.0
    description: str = ""

    @property
    def is_ambiguous(self) -> bool:
        """SSIM in the uncertain range -- needs LLM verification."""
        return 0.70 <= self.ssim_score <= 0.95


@dataclass
class DrawingChange:
    """A change in an engineering drawing between two document versions."""
    change_type: ChangeType
    page_old: Optional[int]
    page_new: Optional[int]
    element_id: str
    ssim_score: float = 0.0
    contour_diff_ratio: float = 0.0  # Fraction of contour area that changed
    dimension_changes: list[dict] = field(default_factory=list)
    # Each: {"label": "width", "old": "25.4 mm", "new": "30.0 mm"}
    geometry_changes: list[str] = field(default_factory=list)
    # e.g., ["bolt pattern modified", "fillet radius increased"]
    diff_image_path: Optional[str] = None
    old_image_path: Optional[str] = None
    new_image_path: Optional[str] = None
    confidence: float = 1.0
    description: str = ""


# ── Aggregated Comparison Results ────────────────────────────────────────


@dataclass
class PairwiseDiff:
    """Complete comparison result between two consecutive document versions."""
    version_old: str  # File path or label
    version_new: str
    version_label: str = ""  # e.g., "V1 -> V2"

    text_changes: list[TextChange] = field(default_factory=list)
    table_changes: list[TableChange] = field(default_factory=list)
    image_changes: list[ImageChange] = field(default_factory=list)
    drawing_changes: list[DrawingChange] = field(default_factory=list)

    # Page-level info
    pages_added: list[int] = field(default_factory=list)
    pages_removed: list[int] = field(default_factory=list)
    page_alignment: list[tuple[Optional[int], Optional[int]]] = field(
        default_factory=list
    )
    # Each tuple: (old_page_num, new_page_num), None means added/removed

    confidence: float = 1.0
    summary: str = ""  # LLM-generated summary (filled by agent)

    @property
    def total_changes(self) -> int:
        return (
            len(self.text_changes)
            + len(self.table_changes)
            + len(self.image_changes)
            + len(self.drawing_changes)
        )

    @property
    def change_counts(self) -> dict[str, int]:
        return {
            "text": len(self.text_changes),
            "table": len(self.table_changes),
            "image": len(self.image_changes),
            "drawing": len(self.drawing_changes),
            "pages_added": len(self.pages_added),
            "pages_removed": len(self.pages_removed),
        }

    def all_changes(self) -> list:
        """Return all changes as a flat list."""
        return (
            self.text_changes
            + self.table_changes
            + self.image_changes
            + self.drawing_changes
        )


@dataclass
class VersionTimelineEntry:
    """Tracks how a single element evolved across all versions."""
    element_id: str
    element_type: str
    changes_by_pair: dict[str, str] = field(default_factory=dict)
    # key: "V1 -> V2", value: "modified: pressure 150->200 PSI"


@dataclass
class MultiVersionReport:
    """
    Complete report across N sequential document versions.
    This is the final output of the entire pipeline.
    """
    version_paths: list[str] = field(default_factory=list)
    version_labels: list[str] = field(default_factory=list)

    pair_diffs: list[PairwiseDiff] = field(default_factory=list)
    version_timeline: list[VersionTimelineEntry] = field(default_factory=list)

    # Aggregated statistics
    total_changes: int = 0
    changes_by_type: dict[str, int] = field(default_factory=dict)
    changes_by_pair: dict[str, int] = field(default_factory=dict)

    # LLM-generated
    executive_summary: str = ""

    def compute_statistics(self) -> None:
        """Recompute aggregate statistics from pair diffs."""
        self.total_changes = sum(d.total_changes for d in self.pair_diffs)
        self.changes_by_type = {"text": 0, "table": 0, "image": 0, "drawing": 0}
        self.changes_by_pair = {}
        for diff in self.pair_diffs:
            counts = diff.change_counts
            for key in ["text", "table", "image", "drawing"]:
                self.changes_by_type[key] += counts.get(key, 0)
            self.changes_by_pair[diff.version_label] = diff.total_changes
