import fitz
import pytesseract
import cv2
import numpy as np
from io import BytesIO
from PIL import Image
import PyPDF2
from app.preprocessor import pre_process_img
from app.template_matching import template_matching
from app.form_handlers import process_w9_form, process_eft_form

def ocr_redact_and_rebuild(input_pdf_path, output_pdf_path):
    # Load PDF and convert first page to image
    pil_image = convert_first_page_to_image(input_pdf_path)
    cv2_image = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)

    # Optional: Template matching for ROI (skipped for simplicity)
    processed_img = pre_process_img(cv2_image)

    # Perform OCR
    ocr_text = pytesseract.image_to_string(processed_img)
    form_type = identify_form_type(ocr_text)

    # Redact logic placeholder
    # You could enhance this with OCR box grouping + confidence scoring
    # For now, we simply replace the first page

    redacted_pil = Image.fromarray(cv2.cvtColor(processed_img, cv2.COLOR_BGR2RGB))
    pdf_bytes = BytesIO()
    redacted_pil.save(pdf_bytes, format="PDF")
    pdf_bytes.seek(0)

    redacted_reader = PyPDF2.PdfReader(pdf_bytes)
    first_page = redacted_reader.pages[0]

    writer = PyPDF2.PdfWriter()
    writer.add_page(first_page)

    reader = PyPDF2.PdfReader(input_pdf_path)
    for i in range(1, len(reader.pages)):
        writer.add_page(reader.pages[i])

    with open(output_pdf_path, "wb") as f:
        writer.write(f)

def convert_first_page_to_image(pdf_path):
    from pdf2image import convert_from_path
    return convert_from_path(pdf_path, first_page=1, last_page=1)[0]

def identify_form_type(text):
    lower = text.lower()
    if "w-9" in lower:
        process_w9_form(text, None)
        return "W-9"
    elif "eft" in lower:
        process_eft_form(text, None)
        return "EFT"
    else:
        return "Unknown"