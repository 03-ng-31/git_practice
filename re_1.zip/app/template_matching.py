import cv2
import numpy as np

def template_matching(template, target, method=cv2.TM_CCOEFF_NORMED):
    tH, tW = template.shape[:2]
    best_match = {'value': -1, 'loc': None, 'scale': 1.0}
    for scale in np.linspace(0.5, 1.5, 21):
        resized = cv2.resize(target, None, fx=scale, fy=scale)
        h, w = resized.shape[:2]
        if h < tH or w < tW:
            continue
        result = cv2.matchTemplate(resized, template, method)
        _, max_val, _, max_loc = cv2.minMaxLoc(result)
        if max_val > best_match['value']:
            best_match = {'value': max_val, 'loc': max_loc, 'scale': scale}
    return best_match