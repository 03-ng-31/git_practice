import shutil
import logging
from app.ocr_redactor import ocr_redact_and_rebuild

def process_non_ocr_route(input_path, output_path):
    logging.info("Processing document using non-OCR route.")
    try:
        shutil.copy(input_path, output_path)
        logging.info("Non-OCR processing complete. Saved to: %s", output_path)
    except Exception as e:
        logging.error("Error during non-OCR processing: %s", e)
        raise

def process_ocr_route(input_path, output_path):
    ocr_redact_and_rebuild(input_path, output_path)