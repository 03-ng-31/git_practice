import streamlit as st
import tempfile
import os
from app.orchestrator import orchestrate_processing

st.set_page_config(page_title="Redaction", layout="centered")
st.title("🔒 Redaction - PDF OCR Processor")

uploaded_file = st.file_uploader("📎 Upload a PDF file to redact sensitive fields", type=["pdf"])

if uploaded_file:
    with tempfile.TemporaryDirectory() as tmpdir:
        input_path = os.path.join(tmpdir, uploaded_file.name)
        output_path = os.path.join(tmpdir, f"processed_{uploaded_file.name}")
        with open(input_path, "wb") as f:
            f.write(uploaded_file.read())

        with st.spinner("🔍 Running OCR and Redaction..."):
            orchestrate_processing(input_path, output_path)

        with open(output_path, "rb") as f:
            st.success("✅ Redaction complete! Download your file:")
            st.download_button(label="📥 Download Redacted PDF", data=f, file_name=os.path.basename(output_path), mime="application/pdf")