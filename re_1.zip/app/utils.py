import os
import shutil
import logging

def upload_to_output_dir(output_file, upload_dir='processed_files'):
    os.makedirs(upload_dir, exist_ok=True)
    destination = os.path.join(upload_dir, os.path.basename(output_file))
    try:
        shutil.copy(output_file, destination)
        logging.info(f"Uploaded file saved to {destination}")
    except Exception as e:
        logging.error(f"Failed to upload file: {e}")
        raise
    return destination