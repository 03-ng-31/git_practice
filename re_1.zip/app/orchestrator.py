import fitz
from app.processor import process_ocr_route, process_non_ocr_route

def orchestrate_processing(input_pdf_path, output_pdf_path):
    doc = fitz.open(input_pdf_path)
    first_page = doc[0]
    text = first_page.get_text().strip()
    images = first_page.get_images(full=True)

    if text and not images:
        return process_non_ocr_route(input_pdf_path, output_pdf_path)
    else:
        return process_ocr_route(input_pdf_path, output_pdf_path)