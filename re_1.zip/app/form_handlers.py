import logging
from PIL import Image

def process_w9_form(ocr_text: str, image: Image.Image) -> dict:
    logging.info("Processing W-9 form: extracting and redacting SSN or EIN if detected.")
    # Placeholder logic for extracting EIN
    extracted_info = {
        "EIN_found": "yes" if "employer identification number" in ocr_text.lower() else "no",
        "ocr_text": ocr_text[:200]  # Show first 200 chars
    }
    return {"status": "W-9 processed", "data": extracted_info}

def process_eft_form(ocr_text: str, image: Image.Image) -> dict:
    logging.info("Processing EFT form: extracting account and routing numbers.")
    extracted_info = {
        "Routing_detected": "yes" if "routing" in ocr_text.lower() else "no",
        "ocr_text": ocr_text[:200]
    }
    return {"status": "EFT processed", "data": extracted_info}