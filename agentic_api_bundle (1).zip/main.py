
from agents.orchestrator import AgentOrchestrator

if __name__ == "__main__":
    # Sample test inputs
    doc_id = "example_run"
    pdf_path = "example_lease.pdf"  # Change to actual test path

    filters = {
        "Module Name": "Real Estate",
        "Territory": "South",
        "Owner": "Crown",
        "Market": "South East",
        "Contract Type": "Lease",
        "SubMarket": "Florida",
        "Document Type": "Lease",
        "Local Market": "Tampa",
        "Facility Type": "Easement"
    }

    fields = [
        {"name": "Commencement Date", "description": "Start date of lease"},
        {"name": "Site ID", "description": "Site identifier"},
        {"name": "Owner Name", "description": "Legal owner"}
    ]

    pipeline = AgentOrchestrator(doc_id)
    result = pipeline.run(pdf_path, filters, fields)
    print(result)
