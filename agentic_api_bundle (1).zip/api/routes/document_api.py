
from flask import Blueprint, request, jsonify
import os
import uuid
from agents.orchestrator import AgentOrchestrator

document_bp = Blueprint("document_api", __name__)

@document_bp.route("/health", methods=["GET"])
def health_check():
    return jsonify({"status": "ok"}), 200

@document_bp.route("/process", methods=["POST"])
def process_document():
    if "file" not in request.files:
        return jsonify({"error": "Missing file"}), 400

    file = request.files["file"]
    filters = request.form.get("filters")
    fields = request.form.get("fields")

    try:
        filters = eval(filters)
        fields = eval(fields)
    except Exception as e:
        return jsonify({"error": f"Invalid JSON input: {e}"}), 400

    doc_id = str(uuid.uuid4())
    filepath = f"uploads/{doc_id}.pdf"
    os.makedirs("uploads", exist_ok=True)
    file.save(filepath)

    pipeline = AgentOrchestrator(doc_id)
    result = pipeline.run(filepath, filters, fields)

    return jsonify(result)
