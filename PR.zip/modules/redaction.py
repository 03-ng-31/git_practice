import cv2
import re

def group_digit_boxes(ocr_data, conf_threshold=30, y_tolerance=10, x_tolerance=10):
    groups = []
    indices = []
    for i, text in enumerate(ocr_data['text']):
        text = text.strip()
        try:
            conf = float(ocr_data['conf'][i])
        except:
            conf = 0
        if conf > conf_threshold and re.search(r'\d', text):
            indices.append(i)
    indices = sorted(indices, key=lambda i: (ocr_data['top'][i], ocr_data['left'][i]))
    for i in indices:
        if not groups:
            groups.append([i])
        else:
            added = False
            for group in groups:
                last_idx = group[-1]
                if (abs(ocr_data['top'][i] - ocr_data['top'][last_idx]) < y_tolerance and 
                    (ocr_data['left'][i] - (ocr_data['left'][last_idx] + ocr_data['width'][last_idx]) < x_tolerance)):
                    group.append(i)
                    added = True
                    break
            if not added:
                groups.append([i])
    return groups

def get_union_box(ocr_data, indices):
    x_vals = [ocr_data['left'][i] for i in indices]
    y_vals = [ocr_data['top'][i] for i in indices]
    widths = [ocr_data['width'][i] for i in indices]
    heights = [ocr_data['height'][i] for i in indices]
    union_x = min(x_vals)
    union_y = min(y_vals)
    union_x2 = max([x + w for x, w in zip(x_vals, widths)])
    union_y2 = max([y + h for y, h in zip(y_vals, heights)])
    return union_x, union_y, union_x2 - union_x, union_y2 - union_y

def redact_ein_candidates_dynamic(image, ocr_data, x_offset, y_offset, background_color, 
                                   expected_digits=9, extra_margin=4, conf_threshold=30, y_tolerance=10, x_tolerance=10):
    result_img = image.copy()
    groups = group_digit_boxes(ocr_data, conf_threshold=conf_threshold, y_tolerance=y_tolerance, x_tolerance=x_tolerance)
    
    for group in groups:
        group = sorted(group, key=lambda i: ocr_data['left'][i])
        combined_text = "".join([ocr_data['text'][i].strip() for i in group])
        digits_only = re.sub(r'\D', '', combined_text)
        actual_count = len(digits_only)
        union_x, union_y, union_w, union_h = get_union_box(ocr_data, group)
        if actual_count < expected_digits and actual_count > 0:
            average_digit_width = union_w / actual_count
            new_width = average_digit_width * expected_digits
            new_union_x = union_x - int((new_width - union_w) / 2)
        else:
            new_width = union_w
            new_union_x = union_x
        abs_x = x_offset + new_union_x
        abs_y = y_offset + union_y - extra_margin
        abs_h = union_h + 2 * extra_margin
        cv2.rectangle(result_img, (abs_x, abs_y), (abs_x + int(new_width), abs_y + abs_h), background_color, -1)
    return result_img, groups