import cv2

def pre_process_img(img):
    gray_img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    enhanced = clahe.apply(gray_img)
    adaptive_thresh = cv2.adaptiveThreshold(
        enhanced, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 15, 8)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))
    opened = cv2.morphologyEx(adaptive_thresh, cv2.MORPH_OPEN, kernel)
    horizontal_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (35, 1))
    vertical_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 35))
    horizontal_lines = cv2.morphologyEx(opened, cv2.MORPH_OPEN, horizontal_kernel)
    vertical_lines = cv2.morphologyEx(opened, cv2.MORPH_OPEN, vertical_kernel)
    lines = cv2.add(horizontal_lines, vertical_lines)
    no_lines = cv2.subtract(opened, lines)
    final_processed = cv2.bitwise_not(no_lines)
    return final_processed