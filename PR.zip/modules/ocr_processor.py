import pytesseract

def perform_ocr(img):
    return pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT)