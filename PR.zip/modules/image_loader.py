import cv2

def load_image(image_path, mode=cv2.IMREAD_GRAYSCALE):
    """Load an image from a given path with error handling."""
    image = cv2.imread(image_path, mode)
    if image is None:
        raise FileNotFoundError(f"Cannot load image at {image_path}")
    return image