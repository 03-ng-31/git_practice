import cv2
import matplotlib.pyplot as plt

from modules.image_loader import load_image
from modules.template_matching import template_matching
from modules.preprocessing import pre_process_img
from modules.ocr_processor import perform_ocr
from modules.redaction import redact_ein_candidates_dynamic, group_digit_boxes, get_union_box

def main():
    template_path = "data/roi_blank.png"
    target_path = "data/typed_document.jpg"
    
    template = load_image(template_path)
    target = load_image(target_path)
    target_color = cv2.cvtColor(target, cv2.COLOR_GRAY2BGR)
    
    match_result = template_matching(template, target)
    x = int(match_result['loc'][0] / match_result['scale'])
    y = int(match_result['loc'][1] / match_result['scale'])
    tH, tW = template.shape[:2]
    tH, tW = int(tH / match_result['scale']), int(tW / match_result['scale'])
    roi = target_color[y:y+tH, x:x+tW]
    
    processed_roi = pre_process_img(roi)
    ocr_data = perform_ocr(processed_roi)
    
    roi_area = target_color[y:y+tH, x:x+tW]
    background_color = cv2.mean(roi_area)[:3]
    background_color = tuple(map(int, background_color))
    
    redacted_img, groups = redact_ein_candidates_dynamic(
        target_color.copy(), ocr_data, x, y, background_color
    )
    
    plt.figure(figsize=(12, 10))
    plt.imshow(cv2.cvtColor(redacted_img, cv2.COLOR_BGR2RGB))
    plt.title("Redacted Image")
    plt.axis("off")
    plt.show()

if __name__ == "__main__":
    main()