import streamlit as st
import cv2
import numpy as np

from modules.template_matching import template_matching
from modules.preprocessing import pre_process_img
from modules.ocr_processor import perform_ocr
from modules.redaction import redact_ein_candidates_dynamic

def process_template_matching(template_bytes, target_bytes):
    template_array = np.frombuffer(template_bytes.read(), np.uint8)
    template_img = cv2.imdecode(template_array, cv2.IMREAD_GRAYSCALE)
    target_array = np.frombuffer(target_bytes.read(), np.uint8)
    target_img = cv2.imdecode(target_array, cv2.IMREAD_GRAYSCALE)
    target_color = cv2.cvtColor(target_img, cv2.COLOR_GRAY2BGR)
    match_result = template_matching(template_img, target_img)
    x = int(match_result['loc'][0] / match_result['scale'])
    y = int(match_result['loc'][1] / match_result['scale'])
    tH, tW = template_img.shape[:2]
    tH, tW = int(tH / match_result['scale']), int(tW / match_result['scale'])
    roi = target_color[y:y+tH, x:x+tW]
    target_with_roi = target_color.copy()
    cv2.rectangle(target_with_roi, (x, y), (x+tW, y+tH), (0, 255, 0), 2)
    return template_img, target_img, target_color, target_with_roi, match_result, (x, y, tH, tW)

def perform_redaction(x, y, tH, tW, target_color):
    roi = target_color[y:y+tH, x:x+tW]
    processed_roi = pre_process_img(roi)
    ocr_data = perform_ocr(processed_roi)
    roi_area = target_color[y:y+tH, x:x+tW]
    background_color = cv2.mean(roi_area)[:3]
    background_color = tuple(map(int, background_color))
    redacted_img, _ = redact_ein_candidates_dynamic(
        target_color.copy(), ocr_data, x, y, background_color
    )
    return redacted_img

def main():
    st.title("EIN Redaction Demo")
    st.write("Upload a template ROI image and a target document image.")
    template_file = st.file_uploader("Upload Template ROI Image", type=["png", "jpg", "jpeg"])
    target_file = st.file_uploader("Upload Target Document Image", type=["png", "jpg", "jpeg"])

    if template_file and target_file:
        template_img, target_img, target_color, target_with_roi, match_result, roi_params = process_template_matching(template_file, target_file)
        x, y, tH, tW = roi_params

        st.subheader("Region of Interest (ROI) Detection")
        st.image(cv2.cvtColor(target_with_roi, cv2.COLOR_BGR2RGB), caption="Target Image with ROI Highlighted", use_column_width=True)
        st.write(f"Template Matching Confidence: {match_result['value']:.4f}")

        if st.button("Perform Redaction"):
            redacted_img = perform_redaction(x, y, tH, tW, target_color)
            st.subheader("Redacted Target Image")
            st.image(cv2.cvtColor(redacted_img, cv2.COLOR_BGR2RGB), caption="Redacted Image", use_column_width=True)

if __name__ == "__main__":
    main()