import streamlit as st
import pandas as pd
import numpy as np
import joblib
import os
from sklearn.preprocessing import MinMaxScaler, OneHotEncoder
import sklearn
import plotly.graph_objects as go
# Streamlit app
st.title("IOP Priority Scoring")

# Function to perform inference using the provided inference pipeline


# Function to create a gauge chart
def create_gauge_chart(value):
    fig = go.Figure(go.Indicator(
        mode = "gauge+number",
        value = value,
        title = {'text': "Normalized Score"},
        gauge = {
            'axis': {'range': [None, 1000]},
            'bar': {'color': "darkblue"},
            'steps': [
                {'range': [0, 200], 'color': "lightgray"},
                {'range': [200, 400], 'color': "gray"},
                {'range': [400, 600], 'color': "yellow"},
                {'range': [600, 800], 'color': "orange"},
                {'range': [800, 1000], 'color': "red"}],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': value}}))

    return fig
def inference_pipeline(new_data, load_path):
    # Ensure compatible sklearn version
    required_sklearn_version = '1.5.0'  # Update this to the version used during model training
    if sklearn.__version__ != required_sklearn_version:
        raise ValueError(f"Incompatible scikit-learn version. Expected {required_sklearn_version}, but got {sklearn.__version__}. Please install the correct version.")
    
    # Load the model and scalers
    clf = joblib.load(os.path.join(load_path, 'clf.pkl'))
    scaler = joblib.load(os.path.join(load_path, 'scaler.pkl'))
    label_encoders = joblib.load(os.path.join(load_path, 'label_encoders.pkl'))
    ohe = joblib.load(os.path.join(load_path, 'one_hot_encoder.pkl'))
    feature_importances = pd.read_csv(os.path.join(load_path, 'feature_importances.csv'))
    min_max_scores = np.load(os.path.join(load_path, 'min_max_scores.npz'))
    min_score = min_max_scores['min_score']
    max_score = min_max_scores['max_score']
    
    # Load nominal features
    with open(os.path.join(load_path, 'nominal_features.txt'), 'r') as f:
        nominal_features = f.read().splitlines()

    # Load columns for reindexing
    with open(os.path.join(load_path, 'dummy_columns.txt'), 'r') as f:
        dummy_columns = f.read().splitlines()

    with open(os.path.join(load_path, 'features_normalize.txt'), 'r') as f:
        features_normalize = f.read().splitlines()

    # Pre-process the new data
    new_df = pd.DataFrame(new_data)
    
    # Handle categorical features
    for col in label_encoders.keys():
        le = label_encoders[col]
        new_df[col + '_Encoded'] = le.transform(new_df[col])
        new_df.drop(col, axis=1, inplace=True)
    
    # Validate categorical features before one-hot encoding
    for col in nominal_features:
        if not set(new_df[col]).issubset(set(ohe.categories_[nominal_features.index(col)])):
            raise ValueError(f"Invalid value in column {col}. Expected values are: {ohe.categories_[nominal_features.index(col)]}")

    # One-Hot Encoding for nominal variables
    ohe_features = ohe.transform(new_df[nominal_features])
    ohe_feature_names = ohe.get_feature_names_out(nominal_features)
    new_df_ohe = pd.DataFrame(ohe_features, columns=ohe_feature_names)
    new_df = pd.concat([new_df.drop(nominal_features, axis=1), new_df_ohe], axis=1)

    # Reindex the new DataFrame to ensure it has the same columns as the training data
    new_df = new_df.reindex(columns=dummy_columns, fill_value=0)
    
    # Normalize the new data
    new_df[features_normalize] = scaler.transform(new_df[features_normalize])

    # Predict the impact level
    y_prob_new = clf.predict_proba(new_df)
    y_class = clf.predict(new_df)
    highest_probabilities_new = np.max(y_prob_new, axis=1)
    
    # Calculate the total score based on feature importance and feature points
    def calculate_total_score(row, feature_importances):
        total_score = 0
        for feature, importance in zip(feature_importances['Feature'], feature_importances['Importance']):
            total_score += row[feature] * importance
        return total_score

    new_df['Total_Score'] = new_df.apply(calculate_total_score, axis=1, feature_importances=feature_importances)
    
    # Calculate the weighted score by multiplying the total score by the highest probability
    new_df['Weighted_Score'] = new_df['Total_Score'] * highest_probabilities_new
    new_df['predicted_class'] = y_class
    new_df['predicted_prob'] = highest_probabilities_new
    
    # Normalize the score to the range [100-1000]
    min_range = 100
    max_range = 1000

    new_df['Normalized_Score'] = min_range + ((new_df['Weighted_Score'] - min_score) / (max_score - min_score)) * (max_range - min_range)

    return new_df[['Total_Score', 'predicted_prob', 'Weighted_Score', 'Normalized_Score', 'predicted_class']]

# Define the min and max values for each attribute
min_max_values = {
    'Existing_Customers': (1000, 5000),
    'Revenue_Loss_Per_Hour_USD': (100.0, 10000.0),
    'Combined_Signal_Strength_dBm': (-100.0, -50.0),
    'Combined_Coverage_Area_sqkm': (5.0, 50.0),
    'Combined_Packet_Loss_Percentage': (0.0, 5.0),
    'Combined_Max_Connections': (500, 5000),
    'Infrastructure_Capacity_Mbps': (50.0, 1000.0),
    'Signal_Strength_dBm': (-100.0, -50.0),
    'Coverage_Area_sqkm': (5.0, 50.0),
    'Latency_ms': (5.0, 100.0),
    'Packet_Loss_Percentage': (0.0, 5.0),
    'Max_Connections': (500, 5000),
    'SLA_Hours': (1, 24),
    'Outage_Duration_Hours': (0.5, 24.0)
}

# User inputs
attributes = {
    'Existing_Customers': st.number_input(f'Existing Customers (min: {min_max_values["Existing_Customers"][0]}, max: {min_max_values["Existing_Customers"][1]})', 
                                          min_value=min_max_values['Existing_Customers'][0], max_value=min_max_values['Existing_Customers'][1]),
    'Revenue_Loss_Per_Hour_USD': st.number_input(f'Revenue Loss Per Hour (USD) (min: {min_max_values["Revenue_Loss_Per_Hour_USD"][0]}, max: {min_max_values["Revenue_Loss_Per_Hour_USD"][1]})', 
                                                 min_value=min_max_values['Revenue_Loss_Per_Hour_USD'][0], max_value=min_max_values['Revenue_Loss_Per_Hour_USD'][1]),
    'Combined_Signal_Strength_dBm': st.number_input(f'Combined Signal Strength (dBm) (min: {min_max_values["Combined_Signal_Strength_dBm"][0]}, max: {min_max_values["Combined_Signal_Strength_dBm"][1]})', 
                                                    min_value=min_max_values['Combined_Signal_Strength_dBm'][0], max_value=min_max_values['Combined_Signal_Strength_dBm'][1]),
    'Combined_Coverage_Area_sqkm': st.number_input(f'Combined Coverage Area (sqkm) (min: {min_max_values["Combined_Coverage_Area_sqkm"][0]}, max: {min_max_values["Combined_Coverage_Area_sqkm"][1]})', 
                                                   min_value=min_max_values['Combined_Coverage_Area_sqkm'][0], max_value=min_max_values['Combined_Coverage_Area_sqkm'][1]),
    'Combined_Packet_Loss_Percentage': st.number_input(f'Combined Packet Loss Percentage (min: {min_max_values["Combined_Packet_Loss_Percentage"][0]}, max: {min_max_values["Combined_Packet_Loss_Percentage"][1]})', 
                                                       min_value=min_max_values['Combined_Packet_Loss_Percentage'][0], max_value=min_max_values['Combined_Packet_Loss_Percentage'][1]),
    'Combined_Max_Connections': st.number_input(f'Combined Max Connections (min: {min_max_values["Combined_Max_Connections"][0]}, max: {min_max_values["Combined_Max_Connections"][1]})', 
                                                min_value=min_max_values['Combined_Max_Connections'][0], max_value=min_max_values['Combined_Max_Connections'][1]),
    'Infrastructure_Capacity_Mbps': st.number_input(f'Infrastructure Capacity (Mbps) (min: {min_max_values["Infrastructure_Capacity_Mbps"][0]}, max: {min_max_values["Infrastructure_Capacity_Mbps"][1]})', 
                                                    min_value=min_max_values['Infrastructure_Capacity_Mbps'][0], max_value=min_max_values['Infrastructure_Capacity_Mbps'][1]),
    'Signal_Strength_dBm': st.number_input(f'Signal Strength (dBm) (min: {min_max_values["Signal_Strength_dBm"][0]}, max: {min_max_values["Signal_Strength_dBm"][1]})', 
                                           min_value=min_max_values['Signal_Strength_dBm'][0], max_value=min_max_values['Signal_Strength_dBm'][1]),
    'Coverage_Area_sqkm': st.number_input(f'Coverage Area (sqkm) (min: {min_max_values["Coverage_Area_sqkm"][0]}, max: {min_max_values["Coverage_Area_sqkm"][1]})', 
                                          min_value=min_max_values['Coverage_Area_sqkm'][0], max_value=min_max_values['Coverage_Area_sqkm'][1]),
    'Latency_ms': st.number_input(f'Latency (ms) (min: {min_max_values["Latency_ms"][0]}, max: {min_max_values["Latency_ms"][1]})', 
                                  min_value=min_max_values['Latency_ms'][0], max_value=min_max_values['Latency_ms'][1]),
    'Packet_Loss_Percentage': st.number_input(f'Packet Loss Percentage (min: {min_max_values["Packet_Loss_Percentage"][0]}, max: {min_max_values["Packet_Loss_Percentage"][1]})', 
                                              min_value=min_max_values['Packet_Loss_Percentage'][0], max_value=min_max_values['Packet_Loss_Percentage'][1]),
    'Max_Connections': st.number_input(f'Max Connections (min: {min_max_values["Max_Connections"][0]}, max: {min_max_values["Max_Connections"][1]})', 
                                       min_value=min_max_values['Max_Connections'][0], max_value=min_max_values['Max_Connections'][1]),
    'SLA_Hours': st.number_input(f'SLA Hours (min: {min_max_values["SLA_Hours"][0]}, max: {min_max_values["SLA_Hours"][1]})', 
                                 min_value=min_max_values['SLA_Hours'][0], max_value=min_max_values['SLA_Hours'][1]),
    'Operational_Status': st.selectbox('Operational Status', ['Operational', 'Maintenance', 'Outage']),
    'Backup_Available_Quantitative': st.number_input('Backup Available (Quantitative)', min_value=0, max_value=2),
    'Outage_Type': st.selectbox('Outage Type', ['Man-made', 'Natural Disaster', 'Infrastructure Deficit']),
    'Outage_Cause': st.selectbox('Outage Cause', ['Vandalism', 'Equipment Failure', 'Human Error', 'Storm', 'Earthquake', 'Flood', 'Power Outage', 'Network Equipment Failure', 'Backhaul Link Failure']),
    'Outage_Duration_Hours': st.number_input(f'Outage Duration (Hours) (min: {min_max_values["Outage_Duration_Hours"][0]}, max: {min_max_values["Outage_Duration_Hours"][1]})', 
                                             min_value=min_max_values['Outage_Duration_Hours'][0], max_value=min_max_values['Outage_Duration_Hours'][1]),
    'Day_of_Week': st.selectbox('Day of Week', ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']),
    'Hour_of_Day': st.number_input('Hour of Day', min_value=0, max_value=23),
    'Month': st.selectbox('Month', [str(i) for i in range(1,13)]),
    'Season': st.selectbox('Season', ['1', '2', '3', '4']),  # 1: Winter, 2: Spring, 3: Summer, 4: Fall
    'Is_Work_Hours': st.selectbox('Is Work Hours', [0, 1]),
    'Is_Weekend': st.selectbox('Is Weekend', [0, 1])
}


# Add a submit button
if st.button('Submit'):
    # Check if all inputs are provided
    if all(value is not None for value in attributes.values()):
        # Convert user inputs to DataFrame
        input_data = pd.DataFrame([attributes])

        # Perform inference
        load_path = 'C:/Users/hp/Desktop/IOP'  # Change this to your actual path
        scores = inference_pipeline(input_data, load_path)
        input_data.to_csv(os.path.join(load_path, 'user_input_data.csv'), index=False)

        # Display scores
        st.subheader("Priority Scores")
        st.write(scores)
        
         # Display score meter
        normalized_score = scores['Normalized_Score'].iloc[0]
        st.metric(label="Normalized Score", value=normalized_score, delta=None)

        # Speedometer gauge
        fig = create_gauge_chart(normalized_score)
        st.plotly_chart(fig)
        
         # Display top 5 features
        feature_importances = pd.read_csv(os.path.join(load_path, 'feature_importances.csv'))
        st.subheader("Top 5 Features and Their Importance")
        top_5_features = feature_importances.nlargest(5, 'Importance')
        st.write(top_5_features)

        # Plot top 5 features
        fig_features = go.Figure([go.Bar(
            x=top_5_features['Importance'],
            y=top_5_features['Feature'],
            orientation='h'
        )])
        fig_features.update_layout(title_text='Top 5 Features by Importance', xaxis_title='Importance', yaxis_title='Feature')
        st.plotly_chart(fig_features)
    else:
        st.error("Please provide values for all inputs.")