import streamlit as st
import tempfile
import os
from app.orchestrator import orchestrate_processing

st.title("🛡️ Redaction - PDF OCR Redactor")

uploaded_file = st.file_uploader("Upload a PDF file", type=["pdf"])

if uploaded_file:
    with tempfile.TemporaryDirectory() as tmpdir:
        input_path = os.path.join(tmpdir, uploaded_file.name)
        output_path = os.path.join(tmpdir, f"processed_{uploaded_file.name}")
        with open(input_path, "wb") as f:
            f.write(uploaded_file.read())

        with st.spinner("Processing PDF..."):
            orchestrate_processing(input_path, output_path)

        with open(output_path, "rb") as f:
            st.success("Redaction complete. Download your file below.")
            st.download_button(label="Download Redacted PDF", data=f, file_name=os.path.basename(output_path), mime="application/pdf")