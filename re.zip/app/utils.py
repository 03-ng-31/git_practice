import os
import shutil

def upload_to_output_dir(output_file, upload_dir='processed_files'):
    os.makedirs(upload_dir, exist_ok=True)
    final_path = os.path.join(upload_dir, os.path.basename(output_file))
    shutil.copy(output_file, final_path)
    return final_path