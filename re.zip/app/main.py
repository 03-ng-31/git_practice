from flask import Flask, request, send_file, jsonify
import os
from werkzeug.utils import secure_filename
import tempfile
from app.orchestrator import orchestrate_processing

app = Flask(__name__)

@app.route('/process', methods=['POST'])
def process_endpoint():
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    filename = secure_filename(file.filename)
    with tempfile.TemporaryDirectory() as tmpdir:
        input_path = os.path.join(tmpdir, filename)
        output_path = os.path.join(tmpdir, f"processed_{filename}")
        file.save(input_path)
        orchestrate_processing(input_path, output_path)
        return send_file(output_path, as_attachment=True)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)