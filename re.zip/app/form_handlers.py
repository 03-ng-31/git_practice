import logging
from PIL import Image

def process_w9_form(ocr_text: str, image: Image.Image) -> dict:
    logging.info("Processing W-9 form via specialized OCR module.")
    result = {"status": "W-9 processed", "data": ocr_text}
    return result

def process_eft_form(ocr_text: str, image: Image.Image) -> dict:
    logging.info("Processing EFT form via specialized OCR module.")
    result = {"status": "EFT processed", "data": ocr_text}
    return result