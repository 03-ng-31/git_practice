# Low-Level Design (LLD) -- Phase 1: Cell Tower Rent Intelligence

## 1. Repository Structure

```
pj_feb/
├── analytical_phase/                    # ← Phase 1 deliverables
│   ├── phase1_rent_intelligence.ipynb   # Main analytical notebook (54 cells)
│   ├── ARCHITECTURE_HLD.md             # High-level design document
│   └── ARCHITECTURE_LLD.md             # This document
│
├── data/
│   └── synthetic/
│       └── synthetic_5k_sites.parquet   # 5,000 sites × 71 columns (896 KB)
│
├── simulations/
│   └── sim_00_data_generator.ipynb      # Generates the synthetic dataset
│
├── scripts/
│   └── ingest_data.py                   # Haversine function (line 916), data pipeline
│
├── notebooks/                           # Pre-existing analysis notebooks (00-09)
│
└── requirements.txt                     # Python dependencies
```

---

## 2. Data Schema

### 2.1 Source File

| Attribute | Value |
|-----------|-------|
| Path | `data/synthetic/synthetic_5k_sites.parquet` |
| Format | Apache Parquet (Snappy compression via PyArrow) |
| Rows | 5,000 |
| Columns | 71 |
| Size on disk | 896 KB |
| Primary key | `site_id` (format: `SIM_NNNNN`) |
| Coordinate system | WGS-84 (lat/lon in decimal degrees) |

### 2.2 Column Inventory by Domain

#### Identity / Location (5 columns)

| Column | Dtype | Range / Values | Nullable |
|--------|-------|---------------|----------|
| `site_id` | str | `SIM_00000` to `SIM_04999` | No |
| `lat` | float64 | 25.33 to 48.31 | No |
| `lon` | float64 | -123.44 to -67.06 | No |
| `state` | str | 24 distinct (AL, AZ, CA, ...) | No |
| `metro_region` | str | 30 distinct (Dallas, Rural Kansas, ...) | No |

#### Property Characteristics (12 columns)

| Column | Dtype | Range / Values | Nullable |
|--------|-------|---------------|----------|
| `property_type` | str | commercial, rooftop, vacant_land, residential, government, agricultural, industrial | No |
| `structure_type` | str | monopole, lattice, guyed, rooftop, concealed_stealth | No |
| `tower_height_ft` | float64 | 0.0 to ~400 | No |
| `building_height_ft` | float64 | 0.0 to ~200 | No |
| `lease_area_sqft` | float64 | ~50 to ~100,000 | No |
| `parcel_acreage` | float64 | ~0.001 to ~50 | No |
| `construction_year` | int64 | 1985 to 2023 | No |
| `construction_age` | int64 | 3 to 41 | No |
| `site_access_ordinal` | int64 | 1 (unimproved) to 4 (elevator) | No |
| `has_building` | int64 | 0 or 1 | No |
| `is_ground_tower` | int64 | 0 or 1 | No |
| `has_parcel` | int64 | 0 or 1 | No |

#### Zoning / Regulatory (6 columns)

| Column | Dtype | Range / Values | Nullable |
|--------|-------|---------------|----------|
| `zoning_district_type` | str | residential, commercial, industrial, agricultural, mixed_use | No |
| `permit_approval_difficulty` | int64 | 1 to 5 | No |
| `wrluri_index` | float64 | ~-3.0 to ~4.0 (standardised) | No |
| `colocation_required` | int64 | 0 or 1 | No |
| `height_restriction_ft` | int64 | 100, 120, 150, 200, 300, 999 | No |
| `has_zoning_data` | int64 | 0 or 1 | No |

#### Market / Demographics (16 columns)

| Column | Dtype | Range / Values | Nullable |
|--------|-------|---------------|----------|
| `census_population_density` | float64 | 5 to ~50,000 (per sq km) | No |
| `census_population_3km` | int64 | ~1 to ~1,500,000 | No |
| `census_median_income` | float64 | 20,000 to ~250,000 | No |
| `census_median_home_value` | float64 | 50,000 to ~2,500,000 | No |
| `census_median_rent` | float64 | ~150 to ~7,500 | No |
| `census_vacancy_rate` | float64 | 0.01 to 0.40 | No |
| `urban_rural_class` | int64 | 1 (rural) to 4 (urban core) | No |
| `underlying_land_value_psf` | float64 | 0.10 to ~500 ($/sqft) | No |
| `hud_safmr` | float64 | ~100 to ~8,000 | No |
| `property_tax_rate` | float64 | 0.005 to 0.030 | No |
| `topography_class` | int64 | 1 (flat) to 3 (mountainous) | No |
| `terrain_elevation_variance_m` | float64 | ~0 to ~200 | No |
| `poi_density_1km` | int64 | 0 to ~5,000 | No |
| `building_density_500m` | int64 | 0 to ~10,000 | No |
| `distance_to_highway_km` | float64 | ~0.01 to ~80 | No |
| `ground_elevation_ft` | float64 | 100 to 8,000 | No |
| `unemployment_rate_local` | float64 | 0.02 to 0.15 | No |

#### Competition / Supply (7 columns)

| Column | Dtype | Range / Values | Nullable |
|--------|-------|---------------|----------|
| `fcc_tower_count_5km` | int64 | 0 to ~40 | No |
| `fcc_tower_density_sqkm` | float64 | 0 to ~0.5 | No |
| `competitor_tower_distance_km` | float64 | 0.1 to ~50 | No |
| `tower_per_capita` | float64 | 0 to ~50 | No |
| `scarcity_index` | float64 | 0 to 1 | No |
| `landlord_concentration` | int64 | 1 to ~30 | No |
| `composite_hazard_score` | float64 | 0 to ~0.8 | No |

#### Network Parameters (13 columns)

| Column | Dtype | Range / Values | Nullable |
|--------|-------|---------------|----------|
| `tenant_count` | int64 | 1 to 5 | No |
| `primary_technology` | int64 | 1 (2G) to 5 (5G_mmW) | No |
| `coverage_critical` | int64 | 0 or 1 | No |
| `capacity_utilization_pct` | float64 | 5.0 to 99.0 | No |
| `high_traffic` | int64 | 0 or 1 | No |
| `backhaul_type` | int64 | 1 (satellite) to 4 (fiber) | No |
| `has_fiber_connection` | int64 | 0 or 1 | No |
| `network_substitutability_score` | float64 | 0 to 1 | No |
| `search_ring_alternative_count` | int64 | 0 to ~15 | No |
| `inter_site_distance_km` | float64 | 0.2 to ~30 | No |
| `antenna_count` | int64 | 3 to 30 | No |
| `structure_capacity_remaining` | float64 | 0 to 1 | No |
| `site_priority_tier` | int64 | 1 (critical) to 3 (fungible) | No |

#### Lease / Contract (7 columns)

| Column | Dtype | Range / Values | Nullable |
|--------|-------|---------------|----------|
| `lease_age_years` | float64 | 2.0 to 25.0 | No |
| `remaining_term_years` | float64 | 0.0 to ~28.0 | No |
| `escalation_type` | str | fixed_3pct, fixed_2pct, cpi_linked, flat | No |
| `escalation_rate` | float64 | 0.0, 0.02, 0.025, 0.03 | No |
| `cumulative_escalation_factor` | float64 | 1.0 to ~2.1 | No |
| `amendment_count` | int64 | 0 or 1 | No |
| `de_escalated_base_rent` | float64 | ~50 to ~8,000 | No |

#### Rent & Ground Truth (4 columns)

| Column | Dtype | Range / Values | Nullable |
|--------|-------|---------------|----------|
| `current_monthly_rent` | float64 | 151 to 6,343 | No |
| `true_fmv` | float64 | 200 to 8,000 | No |
| `true_deviation_pct` | float64 | ~-0.8 to ~3.0 | No |
| `true_class` | str | OVERPAYING, AT_MARKET, UNDERPAYING | No |

### 2.3 Derived Columns (computed at runtime)

The notebook adds the following columns to the master DataFrame during
execution. Total column count after enrichment: ~95.

| Column | Source Step | Formula | Dtype |
|--------|-----------|---------|-------|
| `submarket` | 1a | Copy of `metro_region` | str |
| `escalation_drift_ratio` | 1c | `cumulative_escalation_factor / (1.025)^lease_age_years` | float64 |
| `rent_vintage_gap` | 1c | `current_monthly_rent - de_escalated_base_rent` | float64 |
| `rent_vintage_gap_pct` | 1c | `rent_vintage_gap / current_monthly_rent * 100` | float64 |
| `term_urgency_score` | 1c | `1 / max(remaining_term_years, 0.5)` | float64 |
| `amendment_adjusted_flag` | 1c | `1 if amendment_count > 0 else 0` | int64 |
| `technology_label` | 1c | Map: {1:'2G', 2:'3G', 3:'4G', 4:'5G_sub6', 5:'5G_mmW'} | str |
| `sub_median` | 4a | `groupby('submarket').median()` | float64 |
| `sub_mean` | 4a | `groupby('submarket').mean()` | float64 |
| `sub_std` | 4a | `groupby('submarket').std()` | float64 |
| `sub_p25` | 4a | `groupby('submarket').quantile(0.25)` | float64 |
| `sub_p75` | 4a | `groupby('submarket').quantile(0.75)` | float64 |
| `sub_iqr` | 4a | `sub_p75 - sub_p25` | float64 |
| `rent_z_score` | 4b | `(rent - sub_mean) / sub_std` | float64 |
| `rent_percentile_rank` | 4b | `groupby('submarket').rank(pct=True) * 100` | float64 |
| `deviation_from_median_pct` | 4b | `(rent - sub_median) / sub_median * 100` | float64 |
| `peer_comparison_index` | 6b | `rent / median_of_same_property_type_in_submarket` | float64 |
| `infrastructure_value_score` | 6b | `(tenant_count * antenna_count) / rent` | float64 |
| `lease_efficiency_ratio` | 6b | `de_escalated_base_rent / hud_safmr` | float64 |
| `contractual_risk_score` | 6b | `escalation_drift_ratio * lease_age / remaining_term` | float64 |
| `lease_age_bin` | 6c | `pd.cut(lease_age, bins=[0,5,10,15,20,30])` | category |
| `iqr_flag` | 7a | 1 if outside Tukey fences, 0 otherwise | int64 |
| `zscore_flag` | 7b | `1 if abs(z_score) > 2.0` | int64 |
| `mad_z` | 7c | `abs(rent - median) / (MAD * 1.4826)` | float64 |
| `mad_flag` | 7c | `1 if mad_z > 3.0` | int64 |
| `*_pctile` (7 cols) | 7d | Percentile rank per submarket for 7 fields | float64 |
| `market_score` | 7d | Mean of 5 economic percentile ranks | float64 |
| `multi_factor_flag` | 7d | Conjunction of 3 conditions | int64 |
| `contractual_anomaly_flag` | 7d | Conjunction of 4 conditions | int64 |
| `anomaly_severity` | 7e | Sum of 5 flag columns (0-5) | int64 |
| `anomaly_tier` | 7e | CRITICAL/WARNING/WATCH/NORMAL | category |

---

## 3. Module-Level Design

### 3.1 Notebook Cell Map

The notebook contains 54 cells organised into 8 logical steps. Below is the
authoritative cell index with purpose and I/O contracts.

| Cell | Step | Type | Purpose | Input | Output |
|------|------|------|---------|-------|--------|
| 0 | -- | md | Title and table of contents | -- | -- |
| 1 | 1 | code | Imports, constants, paths | -- | `PROJECT_ROOT`, `PARQUET_PATH`, `CPI_AVG_ANNUAL` |
| 2 | 1 | md | Step 1 header | -- | -- |
| 3 | 1 | code | Load parquet (or run generator) | Parquet file | `df` (5000 × 71) |
| 4 | 1a | code | Build geographic hierarchy | `df` | `df['submarket']`, `hierarchy` table |
| 5 | 1b | code | Validate lat/lon and rent | `df` | Print validation stats |
| 6 | 1c | code | Derive contractual metrics | `df` | `df` + 6 new columns |
| 7 | 2 | md | Step 2 header | -- | -- |
| 8 | 2 | code | `plot_submarket_map()` function + demo | `df`, `DEMO_SUBMARKET` | Plotly figure |
| 9 | 3 | md | Step 3 header | -- | -- |
| 10 | 3 | code | `haversine_miles()`, `find_sites_in_rings()`, `make_ring_polygon()` | -- | Function definitions |
| 11 | 3 | code | Demo: Dallas search ring with overlays | `df`, `CENTER_LAT/LON` | `ring_df_in`, Plotly figure |
| 12 | 4 | md | Step 4 header | -- | -- |
| 13 | 4a | code | Submarket aggregates, merge to df | `df` | `submarket_stats`, `df` + 6 stat cols |
| 14 | 4c | code | Ring-level aggregation table | `ring_df_in` | `ring_stats` table |
| 15 | 4d | code | Ring rent histogram | `ring_df_in` | Plotly figure |
| 16 | 4e | code | Ranked deviation table (top 20) | `ring_df_in` | `ranked` DataFrame |
| 17 | 5 | md | Step 5 header | -- | -- |
| 18 | 5 | code | `pctile_rank_cols()` helper | -- | Function definition |
| 19 | 5a | md | Macro header | -- | -- |
| 20 | 5a | code | Macro-economic grouped bar | `ring_df_in` | Plotly figure |
| 21 | 5b | md | Micro header | -- | -- |
| 22 | 5b | code | Micro-economic radar chart | `ring_df_in`, `df` | Plotly figure |
| 23 | 5c | md | Zoning header | -- | -- |
| 24 | 5c | code | Zoning stacked bar + rent table | `ring_df_in` | Plotly figure, table |
| 25 | 5d | md | Technology header | -- | -- |
| 26 | 5d | code | Technology pie + bar | `ring_df_in` | Plotly figure, table |
| 27 | 5e | md | Competition header | -- | -- |
| 28 | 5e | code | Scarcity scatter + summary | `ring_df_in` | Plotly figure, table |
| 29 | 5f | md | Contractual header | -- | -- |
| 30 | 5f | code | Escalation type box plot | `ring_df_in` | Plotly figure, table |
| 31 | 5f | code | Lease age vs drift scatter | `ring_df_in` | Plotly figure |
| 32 | 5f | code | Rent decomposition stacked bar | `ring_df_in` | Plotly figure |
| 33 | 5f | code | Lease age x escalation heatmap | `ring_df_in` | Plotly figure |
| 34 | 5f | code | Remaining term timeline | `ring_df_in` | Plotly figure |
| 35 | 6 | md | Step 6 header | -- | -- |
| 36 | 6a | code | `compute_portfolio_kpis()` function | -- | Function definition |
| 37 | 6a | code | Portfolio KPI comparison table | `df`, `DEMO_SUBMARKET` | `kpi_compare` table |
| 38 | 6b | code | Site-level KPIs + top 10 | `df` | `df` + 4 new cols, table |
| 39 | 6c | code | Trend KPIs (gradient, premium, vintage) | `df`, `ring_df_in` | Printed summaries |
| 40 | 7 | md | Step 7 header | -- | -- |
| 41 | 7a | code | IQR flag computation | `df` | `df['iqr_flag']` |
| 42 | 7b | code | Z-score flag computation | `df` | `df['zscore_flag']` |
| 43 | 7c | code | MAD flag computation | `df` | `df['mad_z']`, `df['mad_flag']` |
| 44 | 7d-i | code | Multi-factor flag | `df` | `df['multi_factor_flag']`, `df['market_score']` |
| 45 | 7d-ii | code | Contractual anomaly flag | `df` | `df['contractual_anomaly_flag']` |
| 46 | 7e | code | Severity and tier computation | `df` | `df['anomaly_severity']`, `df['anomaly_tier']` |
| 47 | 7e | code | Full anomaly summary table | `df` | `anomaly_table` DataFrame |
| 48 | 7e | code | Tier breakdown by submarket | `df` | `tier_by_sub` table |
| 49 | 7e | code | National anomaly severity map | `df` | Plotly figure |
| 50 | 8 | md | Step 8 header | -- | -- |
| 51 | 8a | code | Cross-submarket KPI matrix | `df` | `kpi_matrix` table |
| 52 | 8b | code | Renegotiation priority top 25 | `df` | `renego_list` table |
| 53 | 8c | code | Executive summary (printed report) | `df` | Text output |

---

## 4. Function Specifications

### 4.1 `haversine_miles(lat1, lon1, lat2, lon2)`

| Attribute | Detail |
|-----------|--------|
| Purpose | Compute great-circle distance between two WGS-84 points |
| Algorithm | Haversine formula |
| Input | Four arrays (or scalars) of decimal degrees |
| Output | Array (or scalar) of distances in miles |
| Vectorised | Yes (NumPy) |
| Constant | Earth radius = 3958.8 miles |
| Complexity | O(N) where N = number of points |

### 4.2 `find_sites_in_rings(df, center_lat, center_lon, radii_miles=(5,10,15))`

| Attribute | Detail |
|-----------|--------|
| Purpose | Tag every site with distance from center and ring band label |
| Input | Full DataFrame, center coordinates, tuple of radii |
| Output | Copy of DataFrame with `distance_mi` (float) and `ring_band` (str) columns |
| Ring bands | `0-5 mi`, `5-10 mi`, `10-15 mi`, `Outside` |
| Implementation | Calls `haversine_miles()`, then `np.select()` for band labeling |
| Complexity | O(N) |

### 4.3 `make_ring_polygon(center_lat, center_lon, radius_mi, n_points=72)`

| Attribute | Detail |
|-----------|--------|
| Purpose | Generate lat/lon polygon vertices for a circle overlay |
| Algorithm | Destination-point formula (angular distance on sphere) |
| Input | Center coords, radius in miles, point count |
| Output | Tuple of (lats_list, lons_list) -- closed polygon (first == last) |
| Usage | Passed to `go.Scattermapbox()` for circle rendering |

### 4.4 `plot_submarket_map(df, submarket, color_col='current_monthly_rent')`

| Attribute | Detail |
|-----------|--------|
| Purpose | Render all sites in a submarket on an interactive map |
| Marker size | Proportional to `tenant_count` |
| Color scale | `RdYlGn_r` (red = high rent, green = low) |
| Tooltip | site_id, rent, property_type, technology, tenants, lease_age, escalation |
| Map style | `carto-positron` (light basemap) |
| Auto-center | Median lat/lon of submarket sites |
| Auto-zoom | 8 |

### 4.5 `pctile_rank_cols(data, cols)`

| Attribute | Detail |
|-----------|--------|
| Purpose | Convert raw values to 0-100 percentile ranks |
| Input | DataFrame, list of column names |
| Output | New DataFrame with same index, columns ranked |
| Method | `Series.rank(pct=True) * 100` |
| Usage | Radar charts (5b), multi-factor anomaly (7d) |

### 4.6 `compute_portfolio_kpis(data, submarket_name='Portfolio')`

| Attribute | Detail |
|-----------|--------|
| Purpose | Compute 13 portfolio-level KPIs for a group of sites |
| Input | Filtered DataFrame (one submarket or all), label string |
| Output | Named `pd.Series` with 13 entries |
| KPIs | See HLD Section 6 for full list |

### 4.7 `compute_iqr_flag(group)`

| Attribute | Detail |
|-----------|--------|
| Purpose | Flag sites outside Tukey's fences within a submarket |
| Input | Grouped DataFrame (one submarket) |
| Output | Series of 0/1 integers |
| Threshold | Q1 - 1.5*IQR, Q3 + 1.5*IQR |

### 4.8 `compute_mad_z(group)`

| Attribute | Detail |
|-----------|--------|
| Purpose | Compute MAD-normalised z-scores within a submarket |
| Input | Grouped DataFrame (one submarket) |
| Output | Series of float MAD z-scores |
| Scaling | `MAD * 1.4826` for consistency with Gaussian std |
| Guard | `max(mad_scaled, 1e-6)` to avoid division by zero |

---

## 5. Anomaly Detection -- Algorithmic Pseudocode

### 5.1 IQR Fence Method

```
FOR each submarket S in df:
    rents = df[df.submarket == S]['current_monthly_rent']
    Q1 = percentile(rents, 25)
    Q3 = percentile(rents, 75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    FOR each site i in S:
        iqr_flag[i] = 1 IF (rent[i] < lower OR rent[i] > upper) ELSE 0
```

### 5.2 Z-Score Method

```
FOR each submarket S in df:
    mu = mean(rents in S)
    sigma = std(rents in S)
    FOR each site i in S:
        z_score[i] = (rent[i] - mu) / sigma
        zscore_flag[i] = 1 IF abs(z_score[i]) > 2.0 ELSE 0
```

### 5.3 MAD Method

```
FOR each submarket S in df:
    med = median(rents in S)
    MAD = median( |rent_i - med| for all i in S )
    MAD_scaled = MAD * 1.4826
    FOR each site i in S:
        mad_z[i] = |rent[i] - med| / max(MAD_scaled, 1e-6)
        mad_flag[i] = 1 IF mad_z[i] > 3.0 ELSE 0
```

### 5.4 Multi-Factor Anomaly

```
FOR each submarket S in df:
    FOR each column C in {land_value, income, pop_density, home_value, safmr,
                          rent, escalation_factor}:
        C_pctile[i] = percentile_rank(C[i] within S) * 100

    market_score[i] = mean(land_pctile, income_pctile, pop_pctile,
                           home_pctile, safmr_pctile)

    multi_factor_flag[i] = 1 IF ALL(
        rent_pctile[i] >= 75,
        market_score[i] <= 40,
        escalation_pctile[i] >= 60
    ) ELSE 0

    contractual_anomaly_flag[i] = 1 IF ALL(
        rent_pctile[i] >= 75,
        escalation_type[i] IN {fixed_3pct, fixed_2pct},
        lease_age_years[i] >= 15,
        amendment_count[i] == 0
    ) ELSE 0
```

### 5.5 Severity Aggregation

```
flags = [iqr_flag, zscore_flag, mad_flag, multi_factor_flag,
         contractual_anomaly_flag]

anomaly_severity[i] = SUM(flags for site i)     // range 0-5

anomaly_tier[i] = CASE
    WHEN anomaly_severity[i] >= 3 THEN 'CRITICAL'
    WHEN anomaly_severity[i] >= 2 THEN 'WARNING'
    WHEN anomaly_severity[i] >= 1 THEN 'WATCH'
    ELSE 'NORMAL'
```

---

## 6. KPI Computation Detail

### 6.1 Portfolio-Level KPIs (13)

| # | KPI | Pandas Implementation |
|---|-----|-----------------------|
| 1 | Median Monthly Rent | `data['current_monthly_rent'].median()` |
| 2 | Rent Dispersion IQR | `data['current_monthly_rent'].quantile(0.75) - data['current_monthly_rent'].quantile(0.25)` |
| 3 | Overpayment Exposure Rate | `(data['current_monthly_rent'] > p75).mean() * 100` |
| 4 | Rent-to-Land-Value Ratio | `(data['current_monthly_rent'] / data['underlying_land_value_psf'].clip(0.01)).median()` |
| 5 | Escalation Drift Index | `data['escalation_drift_ratio'].median()` |
| 6 | Technology Premium | `median_rent(5G) / median_rent(4G)` |
| 7 | Competitive Pressure | `data['scarcity_index'].median() * data['landlord_concentration'].median()` |
| 8 | Weighted Avg Lease Age | `np.average(data['lease_age_years'], weights=data['current_monthly_rent'])` |
| 9 | Near-Expiry Exposure | `(data['remaining_term_years'] < 3).mean() * 100` |
| 10 | Fixed-Escalator Dominance | `data['escalation_type'].isin(['fixed_3pct','fixed_2pct']).mean() * 100` |
| 11 | Amendment Coverage Rate | `(data['amendment_count'] > 0).mean() * 100` |
| 12 | Vintage Gap Ratio | `data['rent_vintage_gap_pct'].median()` |
| 13 | Portfolio Escalation Overshoot | `data['cumulative_escalation_factor'].median() - 1` |

### 6.2 Site-Level KPIs (10)

| # | KPI | Pandas Implementation |
|---|-----|-----------------------|
| 1 | Rent Z-Score | `(rent - sub_mean) / sub_std` |
| 2 | Rent Percentile Rank | `groupby('submarket')['rent'].rank(pct=True) * 100` |
| 3 | Peer Comparison Index | `rent / groupby(['submarket','property_type'])['rent'].transform('median')` |
| 4 | Infrastructure Value Score | `(tenant_count * antenna_count) / rent` |
| 5 | Lease Efficiency Ratio | `de_escalated_base_rent / hud_safmr` |
| 6 | Escalation Drift Ratio | `cumulative_escalation_factor / (1.025)^lease_age_years` |
| 7 | Rent Vintage Gap % | `(rent - de_escalated_base_rent) / rent * 100` |
| 8 | Term Urgency Score | `1 / max(remaining_term_years, 0.5)` |
| 9 | Contractual Risk Score | `escalation_drift_ratio * lease_age_years / max(remaining_term, 0.5)` |
| 10 | Anomaly Flag | `1 if anomaly_severity >= 2` |

---

## 7. Visualisation Inventory

The notebook produces 14 interactive Plotly figures and 10+ tabular outputs.

| # | Cell | Chart Type | Library | Data Scope |
|---|------|-----------|---------|------------|
| 1 | 8 | Scatter mapbox | plotly.express | Submarket (all sites) |
| 2 | 11 | Scatter mapbox + polygon rings | plotly.graph_objects | Search ring (3 bands) |
| 3 | 15 | Histogram | plotly.express | Ring sites rent distribution |
| 4 | 20 | Grouped bar | plotly.express | Macro factors by ring band |
| 5 | 22 | Radar / polar | plotly.graph_objects | Micro-economic profile |
| 6 | 24 | Stacked bar | plotly.express | Zoning distribution |
| 7 | 26 | Pie + bar subplot | plotly.graph_objects | Technology mix + rent |
| 8 | 28 | Scatter (sized) | plotly.express | Scarcity vs rent |
| 9 | 30 | Box plot | plotly.express | Rent by escalation type |
| 10 | 31 | Scatter (sized) | plotly.express | Lease age vs drift |
| 11 | 32 | Stacked horizontal bar | plotly.graph_objects | Base rent + escalation gap |
| 12 | 33 | Heatmap (annotated) | plotly.express | Lease age x escalation |
| 13 | 34 | Bar (color-coded) | plotly.express | Remaining term timeline |
| 14 | 49 | Scatter mapbox | plotly.express | National anomaly map |

---

## 8. Configuration & Constants

| Constant | Value | Location | Purpose |
|----------|-------|----------|---------|
| `CPI_AVG_ANNUAL` | 0.025 | Cell 1 | Average annual CPI for drift ratio calculation |
| `MILES_TO_KM` | 1.60934 | Cell 1 | Unit conversion (not currently used; haversine is miles-native) |
| `DEMO_SUBMARKET` | `'Dallas'` | Cell 8 | Default submarket for demonstration |
| `CENTER_LAT` / `CENTER_LON` | Median of Dallas sites | Cell 11 | Default search ring center |
| IQR multiplier | 1.5 | Cell 41 | Tukey fence width |
| Z-score threshold | 2.0 | Cell 42 | Parametric anomaly cutoff |
| MAD scaling factor | 1.4826 | Cell 43 | Gaussian-consistent MAD scaling |
| MAD threshold | 3.0 | Cell 43 | Robust anomaly cutoff |
| Multi-factor: rent pctile | >= 75 | Cell 44 | Top-quartile rent filter |
| Multi-factor: market score | <= 40 | Cell 44 | Weak economic justification |
| Multi-factor: escalation pctile | >= 60 | Cell 44 | Above-median escalation |
| Contractual: lease age | >= 15 | Cell 45 | Long enough for drift to compound |
| Severity: CRITICAL | >= 3 flags | Cell 46 | Highest urgency |
| Severity: WARNING | >= 2 flags | Cell 46 | Review within quarter |
| Severity: WATCH | 1 flag | Cell 46 | Monitor, low priority |

---

## 9. Execution Profile

| Metric | Observed Value |
|--------|---------------|
| Total cells | 54 |
| Code cells | 39 |
| Markdown cells | 15 |
| Execution time (end-to-end) | ~10 seconds |
| Peak memory | ~50 MB |
| Output notebook size | ~760 KB |
| Plotly figures rendered | 14 |
| Tables displayed | 10+ |
| Anomalies detected | 676 sites (13.5%) |
| CRITICAL tier | 13 sites (0.3%) |
| WARNING tier | 197 sites (3.9%) |

---

## 10. Dependency Matrix

| Package | Version Constraint | Used By |
|---------|--------------------|---------|
| numpy | any (tested 1.24+) | Vectorised math, haversine, ring computation |
| pandas | any (tested 2.0+) | DataFrame operations, groupby, merge |
| scipy | any (tested 1.11+) | `stats` module (imported but lightly used) |
| plotly | >= 5.0 | All 14 interactive visualisations |
| pyarrow | any | Parquet file reading |
| jupyter | any | Notebook execution environment |
| math | stdlib | `make_ring_polygon()` trigonometry |
| pathlib | stdlib | File path resolution |
| warnings | stdlib | Suppress deprecation warnings |

No additional packages beyond those in the project `requirements.txt` are required.

---

## 11. Testing and Validation

### 11.1 Execution Verification

The notebook was executed end-to-end via `jupyter nbconvert --execute` with
zero errors. Key validation checkpoints:

| Checkpoint | Expected | Observed |
|------------|----------|----------|
| Parquet loaded | 5000 rows × 71 cols | 5000 rows × 71 cols |
| Missing coordinates | 0 | 0 |
| Missing rent values | 0 | 0 |
| Submarkets created | 30 | 30 |
| States mapped | 24 | 24 |
| Dallas ring (0-5 mi) | > 0 sites | 24 sites |
| Dallas ring (5-10 mi) | > 0 sites | 44 sites |
| Dallas ring (10-15 mi) | > 0 sites | 80 sites |
| IQR flags | > 0, < 10% | 110 (2.2%) |
| Z-score flags | > 0, < 10% | 214 (4.3%) |
| MAD flags | > 0, < 5% | 87 (1.7%) |
| Multi-factor flags | > 0, < 5% | 56 (1.1%) |
| Contractual flags | > 0, < 15% | 434 (8.7%) |
| CRITICAL tier | > 0, < 1% | 13 (0.3%) |
| Total flagged | > 0 | 676 (13.5%) |

### 11.2 Known Limitations

| Limitation | Impact | Mitigation |
|------------|--------|------------|
| Synthetic data only | Patterns may not match production | Design is data-agnostic; swap parquet path for production |
| Single CPI constant (2.5%) | Ignores year-to-year CPI variation | Acceptable for Phase 1; Phase 2 can use FRED CPI series |
| No interactive submarket selector | User must edit `DEMO_SUBMARKET` variable | Phase 2 Streamlit app will add dropdowns |
| Macro factors limited to unemployment | FRED fields not in synthetic data | Production data will have CPI, treasury, mortgage, HPI |
| No persistence of anomaly results | Recomputed on each run | Phase 2 can export to parquet/CSV |
