# High-Level Design (HLD) -- Phase 1: Cell Tower Rent Intelligence

## 1. Executive Overview

### 1.1 Business Context

Verizon manages a national portfolio of cell tower lease agreements. Over
decades, contractual escalation clauses, origination noise, and lack of
systematic market benchmarking have caused rents to drift away from fair
market value. The business needs an analytical platform that makes visible
what is being paid, how it compares to peers, and where the highest-risk
overpayments exist -- all without relying on machine learning so that outputs
are fully transparent and auditable.

### 1.2 Solution Summary

Phase 1 delivers a **pure descriptive-analytics layer** (no ML) that:

1. Overlays every cell site on an interactive geographic map per submarket.
2. Lets users draw search rings (5 / 10 / 15 miles) around any coordinate and
   instantly see peer comparisons.
3. Compares each site across six factor dimensions -- macro-economic,
   micro-economic, zoning, technology, competition, and contractual.
4. Computes 29 business KPIs at portfolio, site, and trend levels.
5. Runs five statistical anomaly-detection methods and produces a severity-tiered
   anomaly table (CRITICAL / WARNING / WATCH / NORMAL).
6. Delivers an executive summary with renegotiation priority ranking and
   annualised savings potential.

### 1.3 Design Principles

| Principle | Rationale |
|-----------|-----------|
| No ML in Phase 1 | Full transparency; outputs are explainable to non-technical stakeholders |
| Descriptive statistics only | IQR, Z-score, MAD, percentile ranks -- industry-standard, auditable |
| Open-source stack | Python, Pandas, Plotly, Jupyter -- no vendor lock-in |
| Single-notebook delivery | Self-contained; no external services, databases, or deployment infra |
| Submarket-relative metrics | All comparisons are within-submarket to avoid cross-market distortion |

---

## 2. Scope

### 2.1 In Scope (Phase 1)

- Static analytical notebook with interactive Plotly charts
- Data: 5,000 synthetic sites with 71 features (extendable to production data)
- Geographic hierarchy: State > Submarket (metro_region) > Site
- Radius-based search ring analysis
- Six-dimensional factor comparison
- 29 business KPIs
- Five-method anomaly detection with severity tiering
- Executive summary and renegotiation priority list

### 2.2 Out of Scope (deferred to Phase 2)

- ML-based FMV prediction
- Real-time data ingestion
- Deployed web application (Streamlit / Dash)
- User authentication and role-based access
- Automated alerting and scheduling
- Integration with lease management systems

---

## 3. Solution Architecture

### 3.1 Logical Architecture

```
+-------------------------------------------------------------------+
|                        PRESENTATION LAYER                         |
|                                                                   |
|   Jupyter Notebook  (phase1_rent_intelligence.ipynb)              |
|   ├── Plotly Mapbox           (interactive maps)                  |
|   ├── Plotly Charts           (bar, scatter, radar, heatmap)      |
|   ├── Pandas DataFrames       (tables)                            |
|   └── Print Statements        (executive summary)                 |
+-------------------------------------------------------------------+
                               |
+-------------------------------------------------------------------+
|                       COMPUTATION LAYER                           |
|                                                                   |
|   ┌─────────────┐  ┌──────────────┐  ┌──────────────────┐        |
|   │ Search Ring │  │ Aggregation  │  │ Anomaly          │        |
|   │ Engine      │  │ Engine       │  │ Detection Engine │        |
|   │             │  │              │  │                  │        |
|   │ haversine() │  │ groupby()    │  │ IQR fences       │        |
|   │ ring bands  │  │ z-score      │  │ Z-score          │        |
|   │ circle geo  │  │ percentile   │  │ MAD              │        |
|   └─────────────┘  │ deviation    │  │ Multi-factor     │        |
|                     └──────────────┘  │ Contractual      │        |
|   ┌─────────────┐  ┌──────────────┐  └──────────────────┘        |
|   │ Factor      │  │ KPI          │                               |
|   │ Comparison  │  │ Engine       │                               |
|   │             │  │              │                               |
|   │ 6 panels   │  │ 13 portfolio │                               |
|   │ pctile rank │  │ 10 site      │                               |
|   │ radar chart │  │  6 trend     │                               |
|   └─────────────┘  └──────────────┘                               |
+-------------------------------------------------------------------+
                               |
+-------------------------------------------------------------------+
|                          DATA LAYER                               |
|                                                                   |
|   Source:  data/synthetic/synthetic_5k_sites.parquet              |
|   Format:  Apache Parquet (columnar, compressed)                  |
|   Records: 5,000 sites × 71 features                             |
|   Size:    ~900 KB                                                |
|                                                                   |
|   In-memory: single Pandas DataFrame (~10 MB with derived cols)  |
+-------------------------------------------------------------------+
```

### 3.2 Component Architecture

```mermaid
flowchart LR
    subgraph DataLayer ["Data Layer"]
        Parquet["Parquet File<br/>5K sites × 71 cols"]
    end

    subgraph PrepLayer ["Preparation Layer"]
        Load["Load + Validate"]
        Hierarchy["Build State/Submarket/Site<br/>Hierarchy"]
        Derive["Derive Contractual<br/>Metrics (6 new cols)"]
        Load --> Hierarchy --> Derive
    end

    subgraph ComputeLayer ["Computation Layer"]
        SearchRing["Search Ring<br/>Engine"]
        Aggregation["Aggregation<br/>Engine"]
        Factors["Factor Comparison<br/>Engine (6 panels)"]
        KPIs["KPI Engine<br/>(29 KPIs)"]
        Anomaly["Anomaly Detection<br/>Engine (5 methods)"]
    end

    subgraph PresentationLayer ["Presentation Layer"]
        Maps["Interactive Maps<br/>(Plotly Mapbox)"]
        Charts["Factor Charts<br/>(bar/radar/heatmap)"]
        Tables["Ranked Tables<br/>(DataFrames)"]
        Summary["Executive Summary<br/>(text + gauges)"]
    end

    Parquet --> Load
    Derive --> SearchRing
    Derive --> Aggregation
    Derive --> Factors
    Derive --> KPIs
    Derive --> Anomaly

    SearchRing --> Maps
    Aggregation --> Maps
    Aggregation --> Tables
    Factors --> Charts
    KPIs --> Tables
    KPIs --> Summary
    Anomaly --> Tables
    Anomaly --> Maps
    Anomaly --> Summary
```

### 3.3 Data Flow

```mermaid
flowchart TB
    subgraph ingestion ["1. Data Ingestion"]
        Raw["Parquet File"] -->|"pd.read_parquet()"| DF["Master DataFrame<br/>5000 rows × 71 cols"]
    end

    subgraph enrichment ["2. In-Memory Enrichment"]
        DF --> Hierarchy["Add: submarket col<br/>(= metro_region)"]
        Hierarchy --> Contract["Add: escalation_drift_ratio,<br/>rent_vintage_gap,<br/>rent_vintage_gap_pct,<br/>term_urgency_score,<br/>amendment_adjusted_flag,<br/>technology_label"]
        Contract --> SubStats["Add: sub_median, sub_mean,<br/>sub_std, sub_p25,<br/>sub_p75, sub_iqr<br/>(via groupby merge)"]
        SubStats --> SiteMetrics["Add: rent_z_score,<br/>rent_percentile_rank,<br/>deviation_from_median_pct"]
    end

    subgraph compute ["3. Analytical Computation"]
        SiteMetrics --> Ring["Search Ring:<br/>+ distance_mi, ring_band"]
        SiteMetrics --> SiteKPIs["Site KPIs:<br/>+ peer_comparison_index,<br/>infrastructure_value_score,<br/>lease_efficiency_ratio,<br/>contractual_risk_score"]
        SiteMetrics --> AnomalyFlags["Anomaly Flags:<br/>+ iqr_flag, zscore_flag,<br/>mad_flag, mad_z,<br/>multi_factor_flag,<br/>contractual_anomaly_flag,<br/>market_score,<br/>anomaly_severity,<br/>anomaly_tier"]
    end

    subgraph output ["4. Output Artefacts"]
        Ring --> MapViz["Map Visualisations"]
        SiteKPIs --> KPITable["KPI Scorecard Tables"]
        AnomalyFlags --> AnomalyTable["Anomaly Summary Table"]
        AnomalyFlags --> AnomalyMap["Anomaly Map"]
        AnomalyFlags --> ExecSummary["Executive Summary"]
    end
```

---

## 4. Geographic Hierarchy

```
National Portfolio
 └── State (24 states)
      └── Submarket / Metro Region (30 submarkets)
           └── Individual Site (site_id + lat/lon)

Example:
 TX
  ├── Dallas      (248 sites)
  ├── Houston     (250 sites)
  ├── Austin      (150 sites)
  └── San Antonio (150 sites)
```

All statistical comparisons (z-score, percentile, IQR, MAD) are computed
**within submarket** to ensure sites are compared only against geographic
peers.

---

## 5. Six Factor Dimensions

| # | Dimension | Key Fields | Chart Type |
|---|-----------|-----------|------------|
| 5a | Macro-Economic | unemployment_rate_local | Grouped bar |
| 5b | Micro-Economic | census_median_income, census_median_home_value, census_population_density, underlying_land_value_psf, hud_safmr, property_tax_rate | Radar / spider |
| 5c | Zoning / Regulatory | zoning_district_type, permit_approval_difficulty, wrluri_index, colocation_required, height_restriction_ft | Stacked bar |
| 5d | Technology / Network | primary_technology, antenna_count, tenant_count, capacity_utilization_pct, backhaul_type, has_fiber_connection, coverage_critical | Pie + bar |
| 5e | Competitive Landscape | fcc_tower_count_5km, fcc_tower_density_sqkm, competitor_tower_distance_km, scarcity_index, landlord_concentration, search_ring_alternative_count | Scatter + bubble |
| 5f | Contractual / Lease | lease_age_years, remaining_term_years, escalation_type, escalation_rate, cumulative_escalation_factor, amendment_count, de_escalated_base_rent | Box + heatmap + waterfall + timeline |

---

## 6. Anomaly Detection Strategy

Five independent statistical methods; no ML. A site's severity = count of
flags triggered.

| Method | Algorithm | Threshold | Type |
|--------|-----------|-----------|------|
| 7a. IQR Fences | Tukey's box-plot rule | outside Q1-1.5*IQR or Q3+1.5*IQR | Non-parametric |
| 7b. Z-Score | Standard deviation from mean | abs(z) > 2.0 | Parametric |
| 7c. MAD | Median Absolute Deviation | mad_z > 3.0 | Robust non-parametric |
| 7d-i. Multi-Factor | Percentile-rank cross-check | rent >= p75 AND market_score <= 40 AND escalation >= p60 | Rule-based |
| 7d-ii. Contractual | Lease-profile pattern match | rent >= p75 AND fixed_escalation AND age >= 15 AND no_amendment | Rule-based |

**Severity tiers:**

| Tier | Flags Triggered | Action |
|------|-----------------|--------|
| CRITICAL | >= 3 | Immediate investigation, renegotiation queue |
| WARNING | 2 | Review within quarter |
| WATCH | 1 | Monitor, low priority |
| NORMAL | 0 | No action needed |

---

## 7. Technology Stack

| Component | Technology | Purpose |
|-----------|-----------|---------|
| Runtime | Python 3.11 | Core language |
| Data manipulation | Pandas, NumPy | DataFrame operations, vectorised math |
| Statistical | SciPy | Distribution functions |
| Visualisation | Plotly (mapbox, express, graph_objects) | Interactive charts and maps |
| Geospatial | Haversine (custom function) | Distance calculations |
| File format | Apache Parquet (PyArrow) | Columnar data storage |
| Notebook | Jupyter | Interactive execution environment |

---

## 8. Non-Functional Requirements

| Attribute | Target | Notes |
|-----------|--------|-------|
| Data volume | 5,000 sites (Phase 1); scales to 50K+ | In-memory Pandas; vectorised operations |
| Execution time | < 30 seconds end-to-end | Verified: notebook executes in ~10s |
| Portability | Any machine with Python 3.9+ | No external services or databases |
| Reproducibility | Deterministic outputs | Seed-controlled synthetic data |
| Maintainability | Single notebook, clear section structure | Markdown section headers, documented functions |

---

## 9. Future Evolution (Phase 2 Preview)

| Capability | Phase 1 (Current) | Phase 2 (Planned) |
|------------|-------------------|-------------------|
| FMV estimation | Descriptive stats only | XGBoost + QRF ensemble |
| Data source | Synthetic 5K sites | Production Verizon data |
| Delivery | Jupyter notebook | Streamlit / Dash web app |
| Anomaly detection | Statistical (5 methods) | ML anomaly models (Isolation Forest, LOF) |
| Forecasting | None | 10-year FMV and rent projections |
| Alerting | None | Automated anomaly notifications |
| Access control | Local file | Role-based access |
