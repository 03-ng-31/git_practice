#!/usr/bin/env python3
"""
Automated data ingestion pipeline for Cell-Site FMV enrichment.
Fetches from Census, FRED, BLS, FCC, HUD, FEMA, FHFA, TIGER/Line, OpenCelliD
via APIs or bulk download (no manual download).
Run on-demand or on a schedule (cron / Task Scheduler).

Usage:
  python scripts/ingest_data.py                    # run all enabled sources
  python scripts/ingest_data.py --sources fred,census_acs  # run selected
  python scripts/ingest_data.py --build-unified   # after ingest, build unified table
"""

from __future__ import annotations

import argparse
import os
import sys
import zipfile
import io
from datetime import datetime
from pathlib import Path

# Project root = parent of scripts/
PROJECT_ROOT = Path(__file__).resolve().parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

# Load .env before any API keys are used
_env_file = PROJECT_ROOT / ".env"
if _env_file.is_file():
    try:
        from dotenv import load_dotenv
        load_dotenv(_env_file)
    except ImportError:
        pass

import requests
import pandas as pd
import yaml

# Optional deps (fail gracefully per source)
try:
    from fredapi import Fred
except ImportError:
    Fred = None

try:
    import geopandas as gpd
    from shapely.geometry import Point
except ImportError:
    gpd = None


# US MCC/MNC -> Carrier Name mapping
# Source: ITU / FCC assignments for MCC 310-316 (major US carriers)
US_CARRIER_MAP = {
    # MCC 310
    (310, 12): "Verizon", (310, 13): "MobileTel", (310, 16): "Cricket (AT&T)",
    (310, 17): "North Sight Comm", (310, 20): "Union Telephone",
    (310, 26): "T-Mobile", (310, 30): "AT&T", (310, 34): "Airpeak",
    (310, 38): "AT&T", (310, 40): "Conestoga", (310, 46): "SIMMETRY",
    (310, 50): "ACS Wireless",
    (310, 53): "West Virginia Wireless",
    (310, 54): "Alltel (AT&T)", (310, 60): "Consolidated Comm",
    (310, 66): "U.S. Cellular", (310, 70): "AT&T",
    (310, 80): "Corr Wireless", (310, 90): "AT&T",
    (310, 100): "Plateau Wireless", (310, 110): "PTI Pacifica",
    (310, 120): "Sprint (T-Mobile)", (310, 130): "Carolina West",
    (310, 140): "GTA Wireless", (310, 150): "AT&T",
    (310, 160): "T-Mobile", (310, 170): "AT&T",
    (310, 180): "West Central Wireless", (310, 190): "Alaska Wireless",
    (310, 200): "T-Mobile", (310, 210): "T-Mobile",
    (310, 220): "T-Mobile", (310, 230): "T-Mobile",
    (310, 240): "T-Mobile", (310, 250): "T-Mobile",
    (310, 260): "T-Mobile", (310, 270): "T-Mobile",
    (310, 280): "AT&T", (310, 290): "T-Mobile",
    (310, 300): "iSmart Mobile", (310, 310): "T-Mobile",
    (310, 311): "Farmers Wireless",
    (310, 320): "Smith Bagley (CellularOne)", (310, 330): "T-Mobile",
    (310, 340): "Westlink", (310, 350): "Carolina Phone",
    (310, 370): "Docomo Pacific",
    (310, 380): "AT&T", (310, 390): "TX-11 Acquisition",
    (310, 400): "iConnect / Wave Runner",
    (310, 410): "AT&T", (310, 420): "Cincinnati Bell",
    (310, 430): "GCI Communication", (310, 440): "Cellular South",
    (310, 450): "Viaero", (310, 460): "NewCore",
    (310, 470): "nTelos (Shenandoah)", (310, 480): "iConnect",
    (310, 490): "T-Mobile", (310, 500): "PSC Wireless",
    (310, 510): "Airtel", (310, 520): "VeriSign",
    (310, 530): "Iowa Wireless (T-Mobile)", (310, 540): "Oklahoma Western",
    (310, 560): "AT&T", (310, 570): "Cellular One",
    (310, 580): "Inland Cellular", (310, 590): "Verizon",
    (310, 600): "Cellcom", (310, 610): "Epic Touch",
    (310, 620): "Coleman County Telecom", (310, 630): "AmeriLink PCS",
    (310, 640): "Airadigm", (310, 650): "Jasper Technologies",
    (310, 660): "T-Mobile", (310, 670): "AT&T",
    (310, 680): "AT&T", (310, 690): "Conestoga",
    (310, 700): "Cross Valiant", (310, 710): "Arctic Slope Telephone",
    (310, 730): "U.S. Cellular", (310, 740): "Viaero",
    (310, 750): "Appalachian Wireless", (310, 760): "Panhandle Telecom",
    (310, 770): "Iowa Wireless", (310, 780): "Airlink PCS",
    (310, 790): "PinPoint", (310, 800): "T-Mobile",
    (310, 830): "Caprock Cellular", (310, 840): "Telecom North America",
    (310, 850): "Aeris Comm", (310, 870): "PACE",
    (310, 880): "DTC Wireless", (310, 890): "Rural Cellular",
    (310, 900): "Mid-Rivers Wireless", (310, 910): "First Cellular",
    (310, 950): "AT&T", (310, 960): "Plateau",
    (310, 970): "Globalstar", (310, 980): "AT&T",
    (310, 990): "AT&T",
    # MCC 311
    (311, 10): "Chariton Valley", (311, 12): "Verizon",
    (311, 20): "Missouri RSA 5 Partnership",
    (311, 30): "Indigo Wireless", (311, 40): "Commnet",
    (311, 50): "Wilkes Cellular", (311, 60): "Farmers Cellular",
    (311, 70): "Easterbrooke Cellular", (311, 80): "Pine Cellular",
    (311, 90): "Long Lines Wireless", (311, 100): "High Plains Wireless",
    (311, 110): "C Spire (Cellular South)", (311, 120): "Choice Wireless",
    (311, 130): "Cell One Amarillo", (311, 140): "Teleguam",
    (311, 150): "Wilkes Cellular", (311, 160): "Endless Mountains",
    (311, 170): "Broadpoint", (311, 180): "Cingular (AT&T)",
    (311, 190): "AT&T", (311, 200): "T-Mobile",
    (311, 210): "Emery Telcom", (311, 220): "U.S. Cellular",
    (311, 230): "C Spire", (311, 240): "Cordova Wireless",
    (311, 250): "iConnect", (311, 270): "Verizon",
    (311, 271): "Verizon", (311, 272): "Verizon",
    (311, 273): "Verizon", (311, 274): "Verizon",
    (311, 275): "Verizon", (311, 276): "Verizon",
    (311, 277): "Verizon", (311, 278): "Verizon",
    (311, 279): "Verizon", (311, 280): "Verizon",
    (311, 281): "Verizon", (311, 282): "Verizon",
    (311, 283): "Verizon", (311, 284): "Verizon",
    (311, 285): "Verizon", (311, 286): "Verizon",
    (311, 287): "Verizon", (311, 288): "Verizon",
    (311, 289): "Verizon",
    (311, 290): "PinPoint", (311, 300): "Nexus Communications",
    (311, 310): "Leaco Rural Telephone", (311, 320): "Commnet Midwest",
    (311, 330): "Bug Tussel Wireless", (311, 340): "Illinois Valley Cellular",
    (311, 350): "Sagebrush Cellular", (311, 360): "Stelera Wireless",
    (311, 370): "GCI Communication", (311, 380): "New Dimension Wireless",
    (311, 390): "Verizon", (311, 410): "Iowa RSA 2",
    (311, 420): "NorthwestCell", (311, 430): "RSA 1 Limited Partnership",
    (311, 440): "Bluegrass Cellular",
    (311, 470): "Vitelcom", (311, 480): "Verizon",
    (311, 481): "Verizon", (311, 482): "Verizon",
    (311, 483): "Verizon", (311, 484): "Verizon",
    (311, 485): "Verizon", (311, 486): "Verizon",
    (311, 487): "Verizon", (311, 488): "Verizon",
    (311, 489): "Verizon",
    (311, 490): "Sprint (T-Mobile)", (311, 530): "NewCore",
    (311, 580): "U.S. Cellular", (311, 590): "Verizon",
    (311, 740): "Viaero", (311, 870): "PACE",
    (311, 880): "DTC Wireless", (311, 882): "Verizon",
    (311, 950): "ETC",
    # MCC 312
    (312, 90): "AT&T", (312, 120): "Appalachian Wireless",
    (312, 130): "Sprint (T-Mobile)", (312, 150): "NorthStar",
    (312, 160): "Mobi", (312, 170): "Sprint (T-Mobile)",
    (312, 190): "Sprint (T-Mobile)", (312, 250): "i CAN_NB",
    (312, 260): "NewCore", (312, 270): "Cellular Network Partnership",
    (312, 280): "Verizon", (312, 330): "Nemont Telephone",
    (312, 420): "Nex-Tech Wireless", (312, 530): "Sprint (T-Mobile)",
    (312, 570): "Blue Wireless",
    # MCC 313 / 316 (less common)
    (313, 100): "FirstNet (AT&T)",
    (316, 10): "Nextel (T-Mobile)", (316, 11): "Southern Linc",
}


def _resolve_carrier_name(mcc: int, mnc: int) -> str:
    """Look up carrier name from MCC/MNC pair. Falls back to 'Unknown ({mcc}/{mnc})'."""
    name = US_CARRIER_MAP.get((mcc, mnc))
    if name:
        return name
    # Normalize to top-4 by known MNC ranges
    if mnc in range(270, 290) or mnc in range(480, 490) or mnc in (12, 390, 590):
        return "Verizon"
    return f"MCC{mcc}/MNC{mnc}"


def load_config() -> dict:
    cfg_path = PROJECT_ROOT / "configs" / "ingestion_config.yaml"
    if not cfg_path.is_file():
        return {"paths": {"data_root": "data", "raw_dir": "data/raw", "processed_dir": "data/processed"}}
    with open(cfg_path) as f:
        return yaml.safe_load(f) or {}


def get_paths(cfg: dict) -> dict:
    root = cfg.get("paths", {})
    data_root = PROJECT_ROOT / root.get("data_root", "data")
    return {
        "data_root": data_root,
        "raw": data_root / "raw",
        "processed": data_root / "processed",
        "unified": data_root / "unified",
    }


def ensure_dirs(paths: dict) -> None:
    for k, v in paths.items():
        if isinstance(v, Path):
            v.mkdir(parents=True, exist_ok=True)


# ---------- Census ACS ----------
def ingest_census_acs(cfg: dict, paths: dict) -> None:
    api_key = os.environ.get("CENSUS_API_KEY", "")
    year = cfg.get("census_acs", {}).get("year", "2022")
    dataset = cfg.get("census_acs", {}).get("dataset", "acs5")
    variables = cfg.get("census_acs", {}).get("variables", ["B01003_001E", "B19013_001E", "B25077_001E", "B25064_001E"])
    var_str = ",".join(variables + ["NAME"])
    base = f"https://api.census.gov/data/{year}/acs/{dataset}"
    out_path = paths["processed"] / "acs_tract.parquet"

    if out_path.is_file():
        print(f"Census ACS: already cached at {out_path}, skipping API fetch")
        return

    all_rows = []
    cols = None
    # State FIPS 01-56 (US states + DC)
    for state_fips in [f"{i:02d}" for i in range(1, 57)]:
        if state_fips in ("02", "03", "15", "72", "78"): continue  # AK, HI, PR, VI
        params = {"get": var_str, "for": "tract:*", "in": f"state:{state_fips}"}
        if api_key:
            params["key"] = api_key
        try:
            r = requests.get(base, params=params, timeout=60)
            r.raise_for_status()
            data = r.json()
            if len(data) <= 1:
                continue
            if cols is None:
                cols = data[0]
            all_rows.extend(data[1:])
        except Exception as e:
            print(f"Census ACS state {state_fips}: {e}")
            continue

    if not all_rows or cols is None:
        print("Census ACS: no data")
        return
    df = pd.DataFrame(all_rows, columns=cols)
    df["tract_fips"] = df["state"] + df["county"] + df["tract"]
    for c in variables:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    df.to_parquet(out_path, index=False)
    print(f"Census ACS: wrote {len(df)} tracts -> {out_path}")


# ---------- FRED ----------
def ingest_fred(cfg: dict, paths: dict) -> None:
    if Fred is None:
        print("FRED: pip install fredapi and set FRED_API_KEY")
        return
    api_key = os.environ.get("FRED_API_KEY", "")
    if not api_key:
        print("FRED: set FRED_API_KEY in .env")
        return
    series_map = cfg.get("fred", {}).get("series", {"CPIAUCSL": "cpi_all_urban", "DGS10": "treasury_10yr_yield"})
    start = cfg.get("fred", {}).get("start_date", "2020-01-01")
    out_path = paths["processed"] / "fred_macro.parquet"

    if out_path.is_file():
        print(f"FRED: already cached at {out_path}, skipping API fetch")
        return

    fred = Fred(api_key=api_key)
    records = []
    for series_id, name in series_map.items():
        try:
            s = fred.get_series(series_id, observation_start=start)
            for dt, val in s.items():
                records.append({"date": dt.strftime("%Y-%m-%d") if hasattr(dt, "strftime") else str(dt), "series_id": series_id, "name": name, "value": val})
        except Exception as e:
            print(f"FRED {series_id}: {e}")
    if not records:
        print("FRED: no data")
        return
    df = pd.DataFrame(records)
    df.to_parquet(out_path, index=False)
    print(f"FRED: wrote {len(df)} rows -> {out_path}")


# ---------- BLS LAUS (state-level to avoid needing county list) ----------
def ingest_bls(cfg: dict, paths: dict) -> None:
    out_path = paths["processed"] / "bls_laus.parquet"
    if out_path.is_file():
        print(f"BLS State: already cached at {out_path}, skipping API fetch")
        return

    # State-level unemployment: LASST + state FIPS + 000000000003 (rate)
    states = cfg.get("bls", {}).get("states", [])
    if not states:
        states = [f"{i:02d}" for i in range(1, 57) if i not in (2, 3, 15, 72, 78)]
    series_ids = [f"LASST{s}000000000003" for s in states]
    url = "https://api.bls.gov/publicAPI/v2/timeseries/data/"
    payload = {"seriesid": series_ids[:50], "startyear": "2022", "endyear": str(datetime.now().year)}
    if os.environ.get("BLS_API_KEY"):
        payload["registrationkey"] = os.environ.get("BLS_API_KEY")

    records = []
    for i in range(0, len(series_ids), 50):
        chunk = series_ids[i : i + 50]
        payload["seriesid"] = chunk
        try:
            r = requests.post(url, json=payload, timeout=30)
            j = r.json()
            if j.get("status") != "REQUEST_SUCCEEDED":
                print("BLS:", j.get("message", j))
                continue
            for s in j.get("Results", {}).get("series", []):
                sid = s.get("seriesID", "")
                state_fips = sid[5:7] if len(sid) >= 7 else ""
                for d in s.get("data", []):
                    records.append({"state_fips": state_fips, "year": d.get("year"), "period": d.get("period"), "unemployment_rate": d.get("value")})
        except Exception as e:
            print(f"BLS: {e}")
    if not records:
        print("BLS: no data")
        return
    df = pd.DataFrame(records)
    df.to_parquet(out_path, index=False)
    print(f"BLS: wrote {len(df)} rows -> {out_path}")


# ---------- BLS LAUS County-Level ----------
def ingest_bls_county(cfg: dict, paths: dict) -> None:
    """Fetch county-level monthly unemployment from BLS LAUS.
    Series format: LAUCN{5-digit county FIPS}0000000003 (unemployment rate)."""
    import time as _time

    out_path = paths["processed"] / "bls_laus_county.parquet"
    if out_path.is_file():
        print(f"BLS County: already cached at {out_path}, skipping API fetch")
        return

    bls_cfg = cfg.get("bls_county", {})
    start_year = bls_cfg.get("start_year", "2020")
    end_year = str(datetime.now().year)

    # Build county FIPS list from Census ACS county data if available,
    # otherwise generate standard FIPS codes
    county_fips_list = []
    acs_county_path = paths.get("data_root", Path("data")) / "census_county_demographics_2010_2024.csv"
    processed_county = paths["processed"] / "acs_tract.parquet"

    if acs_county_path.is_file():
        df_counties = pd.read_csv(acs_county_path, dtype=str, usecols=["state", "county"])
        df_counties = df_counties.drop_duplicates()
        county_fips_list = (df_counties["state"] + df_counties["county"]).unique().tolist()
    elif processed_county.is_file():
        df_acs = pd.read_parquet(processed_county, columns=["tract_fips"])
        # Extract 5-digit county FIPS from 11-digit tract FIPS
        county_fips_list = df_acs["tract_fips"].str[:5].dropna().unique().tolist()
    else:
        # Generate all county-like FIPS (state 01-56 x county 001-999, then filter to real ones)
        skip_state = {"03", "07", "14", "43", "52"}
        state_fips_list = [f"{i:02d}" for i in range(1, 57) if f"{i:02d}" not in skip_state]
        # Use a representative set -- we'll get back only real ones from BLS
        for st in state_fips_list:
            for cty in range(1, 200, 2):  # odd FIPS only (most real counties)
                county_fips_list.append(f"{st}{cty:03d}")

    series_ids = [f"LAUCN{fips}0000000003" for fips in county_fips_list]
    print(f"BLS County: {len(series_ids)} county series to fetch (years {start_year}-{end_year})")

    url = "https://api.bls.gov/publicAPI/v2/timeseries/data/"
    base_payload = {"startyear": start_year, "endyear": end_year}
    if os.environ.get("BLS_API_KEY"):
        base_payload["registrationkey"] = os.environ["BLS_API_KEY"]

    records = []
    chunk_size = 50  # BLS limit per request
    for i in range(0, len(series_ids), chunk_size):
        chunk = series_ids[i: i + chunk_size]
        payload = {**base_payload, "seriesid": chunk}
        try:
            r = requests.post(url, json=payload, timeout=60)
            j = r.json()
            if j.get("status") != "REQUEST_SUCCEEDED":
                msg = j.get("message", [""])[0] if isinstance(j.get("message"), list) else j.get("message", "")
                if "threshold" in str(msg).lower() or "limit" in str(msg).lower():
                    print(f"  BLS County: rate limit hit at chunk {i//chunk_size}, pausing 10s...")
                    _time.sleep(10)
                    continue
                continue
            for s in j.get("Results", {}).get("series", []):
                sid = s.get("seriesID", "")
                county_fips = sid[5:10] if len(sid) >= 10 else ""
                for d in s.get("data", []):
                    records.append({
                        "county_fips": county_fips,
                        "year": d.get("year"),
                        "period": d.get("period"),
                        "unemployment_rate": pd.to_numeric(d.get("value"), errors="coerce"),
                    })
        except Exception as e:
            print(f"  BLS County chunk {i//chunk_size}: {e}")

        if (i // chunk_size) % 10 == 9:
            _time.sleep(1)  # rate limit courtesy

    if not records:
        print("BLS County: no data")
        return

    df = pd.DataFrame(records)
    df["state_fips"] = df["county_fips"].str[:2]
    df.to_parquet(out_path, index=False)
    print(f"BLS County: wrote {len(df)} rows ({df['county_fips'].nunique()} counties) -> {out_path}")


# ---------- FHFA HPI Granular (ZIP + Tract) ----------
def ingest_fhfa_hpi_granular(cfg: dict, paths: dict) -> None:
    """Download FHFA House Price Index at ZIP and Tract level.
    These are bulk CSV/Excel downloads from FHFA -- no API key needed."""
    fhfa_cfg = cfg.get("fhfa_hpi_granular", {})
    raw_dir = paths["raw"] / "fhfa"
    raw_dir.mkdir(parents=True, exist_ok=True)

    # --- ZIP-level HPI ---
    zip_url = fhfa_cfg.get(
        "zip_url",
        "https://www.fhfa.gov/HPI_master.csv",
    )
    try:
        print("  FHFA: downloading master HPI CSV...")
        r = requests.get(zip_url, timeout=120)
        r.raise_for_status()
        from io import StringIO
        df_master = pd.read_csv(StringIO(r.text))
        print(f"  FHFA: loaded master HPI with {len(df_master)} rows, columns: {list(df_master.columns)}")

        # Filter to ZIP5 level rows (level = "ZIP5" or similar)
        level_col = None
        for col in df_master.columns:
            if "level" in col.lower() or "frequency" in col.lower():
                level_col = col
                break

        if level_col:
            zip_levels = [v for v in df_master[level_col].unique() if "zip" in str(v).lower() or "ZIP" in str(v)]
            if zip_levels:
                df_zip = df_master[df_master[level_col].isin(zip_levels)].copy()
                zip_out = paths["processed"] / "fhfa_hpi_zip.parquet"
                df_zip.to_parquet(zip_out, index=False)
                print(f"  FHFA ZIP: wrote {len(df_zip)} rows -> {zip_out}")

            # Filter to tract level
            tract_levels = [v for v in df_master[level_col].unique() if "tract" in str(v).lower()]
            if tract_levels:
                df_tract = df_master[df_master[level_col].isin(tract_levels)].copy()
                tract_out = paths["processed"] / "fhfa_hpi_tract.parquet"
                df_tract.to_parquet(tract_out, index=False)
                print(f"  FHFA Tract: wrote {len(df_tract)} rows -> {tract_out}")
        else:
            # Save the full master file and let downstream filter
            master_out = paths["processed"] / "fhfa_hpi_master.parquet"
            df_master.to_parquet(master_out, index=False)
            print(f"  FHFA: wrote full master {len(df_master)} rows -> {master_out}")

    except Exception as e:
        print(f"  FHFA granular: {e}")

    # --- Try dedicated ZIP-level file as fallback ---
    zip5_url = fhfa_cfg.get(
        "zip5_url",
        "https://www.fhfa.gov/DataTools/Downloads/Documents/HPI/HPI_AT_BDL_ZIP5.xlsx",
    )
    zip_out = paths["processed"] / "fhfa_hpi_zip.parquet"
    if not zip_out.is_file():
        try:
            print("  FHFA: trying ZIP5 Excel download...")
            r = requests.get(zip5_url, timeout=120)
            r.raise_for_status()
            df_zip = pd.read_excel(io.BytesIO(r.content))
            df_zip.to_parquet(zip_out, index=False)
            print(f"  FHFA ZIP5: wrote {len(df_zip)} rows -> {zip_out}")
        except Exception as e:
            print(f"  FHFA ZIP5 fallback: {e}")

    # --- Try dedicated tract-level file ---
    tract_url = fhfa_cfg.get(
        "tract_url",
        "https://www.fhfa.gov/DataTools/Downloads/Documents/HPI/HPI_AT_BDL_tract.csv",
    )
    tract_out = paths["processed"] / "fhfa_hpi_tract.parquet"
    if not tract_out.is_file():
        try:
            print("  FHFA: trying tract-level CSV download...")
            r = requests.get(tract_url, timeout=120)
            r.raise_for_status()
            from io import StringIO
            df_tract = pd.read_csv(StringIO(r.text))
            df_tract.to_parquet(tract_out, index=False)
            print(f"  FHFA Tract: wrote {len(df_tract)} rows -> {tract_out}")
        except Exception as e:
            print(f"  FHFA Tract fallback: {e}")


# ---------- Census ACS Block Group (latest year) ----------
def ingest_acs_blockgroup(cfg: dict, paths: dict) -> None:
    """Fetch Census ACS block-group-level data for the latest year only.
    Block group is the finest ACS geography (~220k block groups nationwide)."""
    import time as _time

    api_key = os.environ.get("CENSUS_API_KEY", "")
    bg_cfg = cfg.get("acs_blockgroup", {})
    year = bg_cfg.get("year", cfg.get("census_acs", {}).get("year", "2024"))
    dataset = bg_cfg.get("dataset", "acs5")
    variables = bg_cfg.get("variables", cfg.get("census_acs", {}).get("variables", [
        "B01003_001E", "B19013_001E", "B25077_001E", "B25064_001E",
    ]))
    var_str = ",".join(variables + ["NAME"])
    base = f"https://api.census.gov/data/{year}/acs/{dataset}"
    out_path = paths["processed"] / f"acs_blockgroup_{year}.parquet"

    if out_path.is_file():
        print(f"ACS Block Group: already cached at {out_path}, skipping API fetch")
        return

    skip_fips = {"03", "07", "14", "43", "52"}
    state_fips_list = [f"{i:02d}" for i in range(1, 57) if f"{i:02d}" not in skip_fips]
    state_fips_list.append("72")

    all_rows = []
    cols = None
    print(f"ACS Block Group: fetching {len(state_fips_list)} states for year {year}...")

    for idx, st in enumerate(state_fips_list):
        params = {
            "get": var_str,
            "for": "block group:*",
            "in": f"state:{st}",
        }
        if api_key:
            params["key"] = api_key
        try:
            r = requests.get(base, params=params, timeout=120)
            r.raise_for_status()
            data = r.json()
            if len(data) > 1:
                if cols is None:
                    cols = data[0]
                all_rows.extend(data[1:])
        except Exception as e:
            print(f"  ACS BG state {st}: {e}")
            continue

        if (idx + 1) % 10 == 0:
            print(f"  Loaded {idx + 1}/{len(state_fips_list)} states ({len(all_rows):,} BGs so far)")
            _time.sleep(0.3)

    if not all_rows or cols is None:
        print("ACS Block Group: no data")
        return

    df = pd.DataFrame(all_rows, columns=cols)
    # Build block group FIPS: state(2) + county(3) + tract(6) + block group(1) = 12 digits
    bg_col = "block group" if "block group" in df.columns else df.columns[-1]
    df["bg_fips"] = df["state"] + df["county"] + df["tract"] + df[bg_col]
    df["tract_fips"] = df["state"] + df["county"] + df["tract"]
    df["county_fips"] = df["state"] + df["county"]
    for c in variables:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    df.to_parquet(out_path, index=False)
    print(f"ACS Block Group: wrote {len(df):,} block groups -> {out_path}")


# ---------- OpenCelliD Tract Aggregation ----------
def aggregate_opencellid_to_tract(cfg: dict, paths: dict) -> None:
    """Aggregate point-level OpenCelliD towers to tract-level metrics using
    TIGER/Line spatial join.  Computes tower_count, tower_density, carrier_count,
    pct_5g, and tower_growth_18mo per tract."""
    if gpd is None:
        print("OpenCelliD Agg: pip install geopandas")
        return

    towers_path = paths["processed"] / "opencellid_us.parquet"
    tracts_path = paths["processed"] / "tiger_tracts.parquet"
    out_path = paths["processed"] / "opencellid_tract_agg.parquet"

    if out_path.is_file():
        print(f"OpenCelliD Agg: already cached at {out_path}, skipping")
        return

    if not towers_path.is_file():
        print("OpenCelliD Agg: run opencellid_bulk first")
        return
    if not tracts_path.is_file():
        print("OpenCelliD Agg: run tiger_tracts first")
        return

    print("  OpenCelliD Agg: loading towers and tracts...")
    df_towers = pd.read_parquet(towers_path)
    tracts = gpd.read_parquet(tracts_path)

    # Rename lon column if needed
    if "lng" in df_towers.columns and "lon" not in df_towers.columns:
        df_towers.rename(columns={"lng": "lon"}, inplace=True)

    # Resolve carrier names if not already present
    if "carrier_name" not in df_towers.columns:
        print("  OpenCelliD Agg: mapping carrier names from MCC/MNC codes...")
        df_towers["carrier_name"] = df_towers.apply(
            lambda r: _resolve_carrier_name(int(r["mcc"]), int(r["net"]))
            if pd.notna(r.get("mcc")) and pd.notna(r.get("net")) else "Unknown",
            axis=1,
        )

    # Create GeoDataFrame from towers
    towers_gdf = gpd.GeoDataFrame(
        df_towers,
        geometry=gpd.points_from_xy(df_towers["lon"], df_towers["lat"]),
        crs="EPSG:4326",
    )

    print(f"  OpenCelliD Agg: spatial join {len(towers_gdf):,} towers to {len(tracts):,} tracts...")
    joined = gpd.sjoin(
        towers_gdf,
        tracts[["GEOID", "ALAND", "geometry"]],
        how="left",
        predicate="within",
    )

    # Aggregate per tract
    print("  OpenCelliD Agg: computing tract-level metrics...")

    # Parse created timestamp for temporal metrics
    if "created" in joined.columns:
        joined["created_ts"] = pd.to_numeric(joined["created"], errors="coerce")
        cutoff_18mo = datetime.now().timestamp() - (18 * 30 * 24 * 3600)
        joined["is_new_18mo"] = joined["created_ts"] > cutoff_18mo
    else:
        joined["is_new_18mo"] = False

    agg = joined.dropna(subset=["GEOID"]).groupby("GEOID").agg(
        tower_count=("GEOID", "size"),
        carrier_count=("net", "nunique"),
        carrier_names=("carrier_name", lambda x: "|".join(sorted(x.dropna().unique()))),
        dominant_carrier=("carrier_name", lambda x: x.value_counts().index[0] if len(x) > 0 else "Unknown"),
        radio_types=("radio", "nunique"),
        pct_lte=("radio", lambda x: (x == "LTE").sum() / len(x) if len(x) > 0 else 0),
        pct_5g_nr=("radio", lambda x: (x == "NR").sum() / len(x) if len(x) > 0 else 0),
        pct_gsm=("radio", lambda x: (x == "GSM").sum() / len(x) if len(x) > 0 else 0),
        avg_range=("range", "mean"),
        new_towers_18mo=("is_new_18mo", "sum"),
        aland=("ALAND", "first"),
    ).reset_index()

    # Compute density (towers per sq km)
    agg["aland"] = pd.to_numeric(agg["aland"], errors="coerce")
    agg["tract_area_sqkm"] = agg["aland"] / 1e6  # ALAND is in sq meters
    agg["tower_density_sqkm"] = agg["tower_count"] / agg["tract_area_sqkm"].replace(0, float("nan"))
    agg["tower_growth_18mo"] = agg["new_towers_18mo"] / agg["tower_count"].replace(0, float("nan"))

    # Count of distinct named carriers (excluding MCC/MNC fallbacks)
    agg["named_carrier_count"] = agg["carrier_names"].apply(
        lambda s: len([c for c in s.split("|") if c and not c.startswith("MCC")]) if pd.notna(s) else 0
    )

    agg.rename(columns={"GEOID": "tract_fips"}, inplace=True)
    agg.drop(columns=["aland"], inplace=True, errors="ignore")
    agg.to_parquet(out_path, index=False)
    print(f"OpenCelliD Agg: wrote {len(agg):,} tract aggregates -> {out_path}")
    print(f"  Tracts with towers: {(agg['tower_count'] > 0).sum():,}")
    print(f"  Avg towers/tract: {agg['tower_count'].mean():.1f}")
    print(f"  Avg 5G NR %: {agg['pct_5g_nr'].mean()*100:.1f}%")
    print(f"  Top dominant carriers: {agg['dominant_carrier'].value_counts().head(5).to_dict()}")


# ---------- Temporal Trend Features ----------
def compute_temporal_features(cfg: dict, paths: dict) -> None:
    """Compute temporal trend features (growth rates) from multi-year Census ACS
    tract data.  Outputs 1yr, 3yr, 5yr growth rates for population, income,
    home value, and rent per tract."""
    trends_out = paths["processed"] / "temporal_trends_tract.parquet"
    if trends_out.is_file():
        print(f"Temporal Features: already cached at {trends_out}, skipping")
        return

    # Try to load the all-US tract data
    tract_path = paths.get("data_root", Path("data")) / "census_tract_all_us_demographics_2010_2024.parquet"
    if not tract_path.is_file():
        # Fallback to processed ACS
        tract_path = paths["processed"] / "acs_tract.parquet"
    if not tract_path.is_file():
        print("Temporal Features: no tract data found")
        return

    print("  Temporal: loading tract data...")
    df = pd.read_parquet(tract_path)

    # Need tract_fips and year columns
    if "tract_fips" not in df.columns:
        if "state" in df.columns and "county" in df.columns and "tract" in df.columns:
            df["tract_fips"] = df["state"].astype(str) + df["county"].astype(str) + df["tract"].astype(str)
        else:
            print("Temporal Features: cannot build tract_fips")
            return

    if "year" not in df.columns:
        print("Temporal Features: no year column -- need multi-year data")
        return

    latest_year = int(df["year"].max())
    metrics = {
        "population": "population",
        "median_income": "median_income",
        "median_home_value": "median_home_value",
        "median_rent": "median_rent",
    }

    # Find which columns actually exist
    available_metrics = {k: v for k, v in metrics.items() if v in df.columns}
    if not available_metrics:
        # Try ACS variable names
        acs_map = {
            "B01003_001E": "population",
            "B19013_001E": "median_income",
            "B25077_001E": "median_home_value",
            "B25064_001E": "median_rent",
        }
        for acs_var, name in acs_map.items():
            if acs_var in df.columns:
                df.rename(columns={acs_var: name}, inplace=True)
                available_metrics[name] = name
    if not available_metrics:
        print("Temporal Features: no recognized metric columns")
        return

    print(f"  Temporal: computing growth rates for {list(available_metrics.keys())} ...")
    print(f"  Latest year: {latest_year}, computing 1yr/3yr/5yr windows")

    # Pivot: one row per tract, columns for each year's metric
    windows = {"1yr": 1, "3yr": 3, "5yr": 5}
    trend_frames = []

    for window_name, years_back in windows.items():
        compare_year = latest_year - years_back
        df_latest = df[df["year"] == latest_year].set_index("tract_fips")
        df_compare = df[df["year"] == compare_year].set_index("tract_fips")

        if len(df_compare) == 0:
            print(f"  Temporal: no data for year {compare_year}, skipping {window_name}")
            continue

        for metric_name, col_name in available_metrics.items():
            if col_name not in df_latest.columns or col_name not in df_compare.columns:
                continue
            latest_vals = pd.to_numeric(df_latest[col_name], errors="coerce")
            compare_vals = pd.to_numeric(df_compare[col_name], errors="coerce")
            # Filter out sentinel values (Census uses -666666666 for missing)
            latest_vals = latest_vals[latest_vals > 0]
            compare_vals = compare_vals[compare_vals > 0]
            growth = (latest_vals - compare_vals.reindex(latest_vals.index)) / compare_vals.reindex(latest_vals.index)
            growth_col = f"{metric_name}_growth_{window_name}"
            trend_frames.append(growth.rename(growth_col))

    if not trend_frames:
        print("Temporal Features: no trend data computed")
        return

    df_trends = pd.concat(trend_frames, axis=1)
    df_trends.index.name = "tract_fips"
    df_trends = df_trends.reset_index()

    # Clean: cap extreme values (>500% growth or <-90% decline are likely data artifacts)
    numeric_cols = [c for c in df_trends.columns if c != "tract_fips"]
    for col in numeric_cols:
        df_trends[col] = df_trends[col].clip(-0.9, 5.0)

    df_trends.to_parquet(trends_out, index=False)
    print(f"Temporal Features: wrote {len(df_trends):,} tracts x {len(numeric_cols)} features -> {trends_out}")
    print(f"  Features: {numeric_cols}")


# ---------- Housing Market Indicator Variables ----------
def compute_housing_indicators(cfg: dict, paths: dict) -> None:
    """Compute FMV indicator variables from HUD SAFMR, FHFA HPI, and Wharton WRLURI.
    Outputs state-level composite features joinable to the spine via state_fips/state_abbr."""
    import numpy as _np

    out_path = paths["processed"] / "housing_market_composites.parquet"
    if out_path.is_file():
        print(f"Housing Indicators: already cached at {out_path}, skipping")
        return

    FIPS_TO_ABBR_LOCAL = {
        "01": "AL", "02": "AK", "04": "AZ", "05": "AR", "06": "CA",
        "08": "CO", "09": "CT", "10": "DE", "11": "DC", "12": "FL",
        "13": "GA", "15": "HI", "16": "ID", "17": "IL", "18": "IN",
        "19": "IA", "20": "KS", "21": "KY", "22": "LA", "23": "ME",
        "24": "MD", "25": "MA", "26": "MI", "27": "MN", "28": "MS",
        "29": "MO", "30": "MT", "31": "NE", "32": "NV", "33": "NH",
        "34": "NJ", "35": "NM", "36": "NY", "37": "NC", "38": "ND",
        "39": "OH", "40": "OK", "41": "OR", "42": "PA", "44": "RI",
        "45": "SC", "46": "SD", "47": "TN", "48": "TX", "49": "UT",
        "50": "VT", "51": "VA", "53": "WA", "54": "WV", "55": "WI",
        "56": "WY",
    }
    ABBR_TO_FIPS_LOCAL = {v: k for k, v in FIPS_TO_ABBR_LOCAL.items()}

    frames = {}

    # 1. HUD SAFMR -- aggregate ZIP-level rents to state
    safmr_path = paths["processed"] / "hud_safmr.parquet"
    if safmr_path.is_file():
        hud = pd.read_parquet(safmr_path)
        # Detect rent columns
        rent_cols = [c for c in hud.columns if "BR" in c.upper() or "safmr" in c.lower()]
        two_br = next((c for c in hud.columns if "2" in c and ("BR" in c.upper() or "safmr" in c.lower())), None)
        state_col = next((c for c in hud.columns if c.upper() == "STATE"), None)
        zip_col = next((c for c in hud.columns if c.lower() in ("zcta", "zip_code")), None)

        if two_br:
            hud[two_br] = pd.to_numeric(hud[two_br], errors="coerce")
            hud["log_safmr_2br"] = _np.log1p(hud[two_br].clip(lower=1))
            if state_col:
                safmr_state = hud.groupby(state_col).agg(
                    safmr_2br_median=(two_br, "median"),
                    safmr_zip_count=(two_br, "count"),
                ).reset_index().rename(columns={state_col: "state_fips"})
                safmr_state["state_abbr"] = safmr_state["state_fips"].astype(str).str.zfill(2).map(FIPS_TO_ABBR_LOCAL)
                frames["safmr"] = safmr_state
                print(f"  Housing: HUD SAFMR aggregated to {len(safmr_state)} states")

    # 2. FHFA HPI -- state-level appreciation rates
    hpi_path = paths["processed"] / "fhfa_hpi.parquet"
    hpi_master = paths["processed"] / "fhfa_hpi_master.parquet"
    for hp in [hpi_path, hpi_master]:
        if hp.is_file():
            try:
                hpi = pd.read_parquet(hp)
                # Try to extract state-level HPI and compute appreciation
                yr_col = next((c for c in hpi.columns if c.lower() in ("yr", "year")), None)
                hpi_col = next((c for c in hpi.columns if "hpi" in c.lower() or "index" in c.lower()), None)
                place_col = next((c for c in hpi.columns if "place" in c.lower() or "state" in c.lower()), None)
                if yr_col and hpi_col and place_col:
                    hpi[yr_col] = pd.to_numeric(hpi[yr_col], errors="coerce")
                    hpi[hpi_col] = pd.to_numeric(hpi[hpi_col], errors="coerce")
                    max_yr = int(hpi[yr_col].max())
                    # Compute appreciation per state
                    rates = []
                    for state in hpi[place_col].unique():
                        sd = hpi[hpi[place_col] == state].set_index(yr_col)[hpi_col]
                        rec = {"state_name": state, "hpi_latest": sd.get(max_yr)}
                        for label, yb in [("1yr", 1), ("3yr", 3), ("5yr", 5)]:
                            cy = max_yr - yb
                            if cy in sd.index and max_yr in sd.index and sd[cy] > 0:
                                rec[f"hpi_appreciation_{label}"] = round((sd[max_yr] - sd[cy]) / sd[cy], 4)
                        rates.append(rec)
                    if rates:
                        frames["hpi"] = pd.DataFrame(rates)
                        print(f"  Housing: FHFA HPI appreciation computed for {len(rates)} states")
                    break
            except Exception as e:
                print(f"  Housing: HPI parse error - {e}")

    # 3. Wharton WRLURI
    wrluri_path = paths["processed"] / "wrluri.parquet"
    if wrluri_path.is_file():
        try:
            wrluri = pd.read_parquet(wrluri_path)
            wrluri_col = next((c for c in wrluri.columns if "WRLURI" in c.upper()), None)
            state_col = next((c for c in wrluri.columns if "state" in c.lower()), None)
            if wrluri_col and state_col:
                wrluri[wrluri_col] = pd.to_numeric(wrluri[wrluri_col], errors="coerce")
                vals = wrluri[wrluri_col].dropna()
                wmin, wmax = vals.quantile(0.01), vals.quantile(0.99)
                wrluri["permit_difficulty_score"] = ((wrluri[wrluri_col] - wmin) / (wmax - wmin) * 10).clip(0, 10)
                w_state = wrluri.groupby(state_col).agg(
                    permit_difficulty_mean=("permit_difficulty_score", "mean"),
                    wrluri_raw_mean=(wrluri_col, "mean"),
                ).reset_index().rename(columns={state_col: "state_name"})
                w_state["wrluri_scarcity_boost"] = w_state["permit_difficulty_mean"] * 0.15
                frames["wrluri"] = w_state
                print(f"  Housing: WRLURI aggregated to {len(w_state)} states")
        except Exception as e:
            print(f"  Housing: WRLURI parse error - {e}")

    if not frames:
        print("Housing Indicators: no component data available")
        return

    # Combine all state-level frames
    df = pd.DataFrame({"state_abbr": list(ABBR_TO_FIPS_LOCAL.values())})
    df["state_fips"] = df["state_abbr"].map(ABBR_TO_FIPS_LOCAL)
    for label, frame in frames.items():
        if "state_abbr" in frame.columns:
            df = df.merge(frame, on="state_abbr", how="left")
        elif "state_fips" in frame.columns:
            df = df.merge(frame, on="state_fips", how="left")

    # Derived composites
    if "safmr_2br_median" in df.columns:
        df["log_land_value_proxy"] = _np.log1p(df["safmr_2br_median"].fillna(0) * 12)

    df.to_parquet(out_path, index=False)
    feature_cols = [c for c in df.columns if c not in ("state_abbr", "state_fips")]
    print(f"Housing Indicators: wrote {len(df)} states x {len(feature_cols)} features -> {out_path}")


# ================================================================
# SITE-LEVEL GEOSPATIAL FEATURES
# Query federal APIs per site lat/lon (not state centroids)
# ================================================================

import math as _math


def _haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Haversine distance in km between two WGS84 points."""
    R = 6371.0
    dlat = _math.radians(lat2 - lat1)
    dlon = _math.radians(lon2 - lon1)
    a = _math.sin(dlat / 2) ** 2 + _math.cos(_math.radians(lat1)) * _math.cos(_math.radians(lat2)) * _math.sin(dlon / 2) ** 2
    return R * 2 * _math.atan2(_math.sqrt(a), _math.sqrt(1 - a))


def _load_spine(paths: dict) -> pd.DataFrame | None:
    """Load the site spine (or synthetic data) with lat/lon."""
    spine_path = paths["processed"] / "spine_sites.parquet"
    if spine_path.is_file():
        return pd.read_parquet(spine_path)
    syn = paths["data_root"].parent / "data" / "synthetic" / "synthetic_5k_sites.parquet"
    if syn.is_file():
        return pd.read_parquet(syn)
    # Try from project root
    syn2 = PROJECT_ROOT / "data" / "synthetic" / "synthetic_5k_sites.parquet"
    if syn2.is_file():
        return pd.read_parquet(syn2)
    return None


# ---------- USGS 3DEP Site-Level Elevation ----------
def ingest_usgs_elevation_sites(cfg: dict, paths: dict) -> None:
    """Query USGS EPQS for ground elevation at each site lat/lon.
    Also computes terrain variance from 4 offset points (~5 km) and
    derives topography_class."""
    import time as _time

    spine = _load_spine(paths)
    if spine is None or "latitude" not in spine.columns:
        print("USGS Elevation: no spine with lat/lon")
        return

    out_path = paths["processed"] / "usgs_elevation_sites.parquet"
    geo_cfg = cfg.get("geospatial_sites", {})
    use_variance = geo_cfg.get("terrain_variance", True)

    # Resume support: if file exists, load and skip already-queried sites
    if out_path.is_file():
        existing = pd.read_parquet(out_path)
        done_ids = set(existing["site_id"].values) if "site_id" in existing.columns else set()
        print(f"  USGS Elevation: resuming ({len(done_ids)} already done)")
    else:
        existing = None
        done_ids = set()

    EPQS_URL = "https://epqs.nationalmap.gov/v1/json"
    OFFSETS = [(0.045, 0), (-0.045, 0), (0, 0.055), (0, -0.055)]  # ~5 km

    def _get_elev(lat, lon, retries=3):
        for attempt in range(retries):
            try:
                r = requests.get(EPQS_URL, params={
                    "x": lon, "y": lat, "wkid": 4326, "units": "Feet", "includeDate": "false"
                }, timeout=15)
                r.raise_for_status()
                val = r.json().get("value")
                if val is not None and val != -1000000:
                    return float(val)
                return None
            except Exception:
                if attempt < retries - 1:
                    _time.sleep(1)
        return None

    id_col = "site_id" if "site_id" in spine.columns else spine.columns[0]
    records = []
    total = len(spine)
    skipped = 0

    print(f"  USGS Elevation: querying {total} sites...")
    for idx, row in spine.iterrows():
        sid = row.get(id_col, idx)
        if sid in done_ids:
            skipped += 1
            continue

        lat, lon = row["latitude"], row["longitude"]
        elev = _get_elev(lat, lon)

        variance = None
        topo_class = "Unknown"
        if use_variance and elev is not None:
            offsets = [elev]
            for dlat, dlon in OFFSETS:
                e = _get_elev(lat + dlat, lon + dlon)
                if e is not None:
                    offsets.append(e)
                _time.sleep(0.1)
            if len(offsets) >= 3:
                import numpy as _np
                variance = float(_np.std(offsets))
                if variance < 50:
                    topo_class = "Flat"
                elif variance < 200:
                    topo_class = "Rolling"
                elif variance < 500:
                    topo_class = "Hilly"
                else:
                    topo_class = "Mountainous"

        records.append({
            "site_id": sid,
            "ground_elevation_ft": elev,
            "terrain_variance_ft": round(variance, 1) if variance else None,
            "topography_class": topo_class,
        })

        done_count = len(records) + skipped
        if done_count % 100 == 0:
            print(f"    ... {done_count}/{total} sites")
        _time.sleep(0.12)

    if not records and existing is not None:
        print(f"  USGS Elevation: all {len(done_ids)} sites already done")
        return

    df_new = pd.DataFrame(records)
    if existing is not None and len(existing) > 0:
        df_all = pd.concat([existing, df_new], ignore_index=True).drop_duplicates("site_id", keep="last")
    else:
        df_all = df_new
    df_all.to_parquet(out_path, index=False)
    print(f"USGS Elevation: wrote {len(df_all)} sites -> {out_path}")


# ---------- USGS NLCD Site-Level Land Cover ----------
def ingest_nlcd_landcover_sites(cfg: dict, paths: dict) -> None:
    """Query MRLC WMS for NLCD land cover code at each site lat/lon."""
    import time as _time

    spine = _load_spine(paths)
    if spine is None or "latitude" not in spine.columns:
        print("NLCD: no spine with lat/lon")
        return

    out_path = paths["processed"] / "nlcd_landcover_sites.parquet"

    # Resume
    if out_path.is_file():
        existing = pd.read_parquet(out_path)
        done_ids = set(existing["site_id"].values) if "site_id" in existing.columns else set()
    else:
        existing = None
        done_ids = set()

    NLCD_LEGEND = {
        11: "Open Water", 12: "Perennial Ice/Snow",
        21: "Developed, Open Space", 22: "Developed, Low Intensity",
        23: "Developed, Medium Intensity", 24: "Developed, High Intensity",
        31: "Barren Land",
        41: "Deciduous Forest", 42: "Evergreen Forest", 43: "Mixed Forest",
        51: "Dwarf Scrub", 52: "Shrub/Scrub",
        71: "Grassland/Herbaceous", 72: "Sedge/Herbaceous", 73: "Lichens", 74: "Moss",
        81: "Pasture/Hay", 82: "Cultivated Crops",
        90: "Woody Wetlands", 95: "Emergent Herbaceous Wetlands",
    }
    MRLC_URL = "https://www.mrlc.gov/geoserver/mrlc_display/wms"

    def _get_nlcd(lat, lon, retries=2):
        delta = 0.005
        params = {
            "SERVICE": "WMS", "VERSION": "1.1.1", "REQUEST": "GetFeatureInfo",
            "LAYERS": "NLCD_2021_Land_Cover_L48",
            "QUERY_LAYERS": "NLCD_2021_Land_Cover_L48",
            "INFO_FORMAT": "application/json", "SRS": "EPSG:4326",
            "BBOX": f"{lon - delta},{lat - delta},{lon + delta},{lat + delta}",
            "WIDTH": 3, "HEIGHT": 3, "X": 1, "Y": 1,
        }
        for attempt in range(retries):
            try:
                r = requests.get(MRLC_URL, params=params, timeout=15)
                r.raise_for_status()
                feats = r.json().get("features", [])
                if feats:
                    code = feats[0].get("properties", {}).get("PALETTE_INDEX")
                    if code is not None:
                        return int(code)
            except Exception:
                if attempt < retries - 1:
                    _time.sleep(1)
        return None

    id_col = "site_id" if "site_id" in spine.columns else spine.columns[0]
    records = []
    total = len(spine)

    print(f"  NLCD: querying {total} sites...")
    for idx, row in spine.iterrows():
        sid = row.get(id_col, idx)
        if sid in done_ids:
            continue
        code = _get_nlcd(row["latitude"], row["longitude"])
        label = NLCD_LEGEND.get(code, "Unknown") if code else "No Data"

        # Derived features
        is_developed = 1 if code and 21 <= code <= 24 else 0
        dev_intensity = (code - 20) if code and 21 <= code <= 24 else 0  # 1-4 scale

        records.append({
            "site_id": sid,
            "nlcd_code": code,
            "nlcd_label": label,
            "nlcd_is_developed": is_developed,
            "nlcd_development_intensity": dev_intensity,
        })
        if len(records) % 200 == 0:
            print(f"    ... {len(records) + len(done_ids)}/{total}")
        _time.sleep(0.15)

    if not records and existing is not None:
        print(f"  NLCD: all sites already done")
        return

    df_new = pd.DataFrame(records)
    if existing is not None and len(existing) > 0:
        df_all = pd.concat([existing, df_new], ignore_index=True).drop_duplicates("site_id", keep="last")
    else:
        df_all = df_new
    df_all.to_parquet(out_path, index=False)
    print(f"NLCD: wrote {len(df_all)} sites -> {out_path}")


# ---------- FEMA NFHL Site-Level Flood Zones ----------
def ingest_fema_flood_sites(cfg: dict, paths: dict) -> None:
    """Query FEMA NFHL for flood zone at each site lat/lon."""
    import time as _time

    spine = _load_spine(paths)
    if spine is None or "latitude" not in spine.columns:
        print("FEMA Sites: no spine with lat/lon")
        return

    out_path = paths["processed"] / "fema_flood_sites.parquet"

    if out_path.is_file():
        existing = pd.read_parquet(out_path)
        done_ids = set(existing["site_id"].values) if "site_id" in existing.columns else set()
    else:
        existing = None
        done_ids = set()

    FEMA_URL = "https://hazards.fema.gov/arcgis/rest/services/public/NFHL/MapServer/28/query"

    def _flood_risk_score(zone: str) -> int | None:
        if not zone or zone in ("ERROR", "NO DATA"):
            return None
        zu = zone.strip().upper()
        if zu.startswith("A") or zu.startswith("V"):
            return 3  # high risk
        if zu == "B" or "500" in zu:
            return 2  # moderate
        return 1  # minimal

    def _get_flood(lat, lon, retries=2):
        params = {
            "geometry": f"{lon},{lat}",
            "geometryType": "esriGeometryPoint",
            "spatialRel": "esriSpatialRelIntersects",
            "outFields": "FLD_ZONE,ZONE_SUBTY,SFHA_TF",
            "returnGeometry": "false", "f": "json", "inSR": 4326,
        }
        for attempt in range(retries):
            try:
                r = requests.get(FEMA_URL, params=params, timeout=20)
                r.raise_for_status()
                feats = r.json().get("features", [])
                if feats:
                    a = feats[0].get("attributes", {})
                    return a.get("FLD_ZONE", ""), a.get("ZONE_SUBTY", ""), a.get("SFHA_TF", "")
                return "NO DATA", "", ""
            except Exception:
                if attempt < retries - 1:
                    _time.sleep(1)
        return "ERROR", "", ""

    id_col = "site_id" if "site_id" in spine.columns else spine.columns[0]
    records = []
    total = len(spine)

    print(f"  FEMA Flood: querying {total} sites...")
    for idx, row in spine.iterrows():
        sid = row.get(id_col, idx)
        if sid in done_ids:
            continue
        zone, subtype, sfha = _get_flood(row["latitude"], row["longitude"])
        score = _flood_risk_score(zone)

        records.append({
            "site_id": sid,
            "fema_flood_zone": zone,
            "fema_zone_subtype": subtype,
            "fema_sfha": sfha,
            "flood_risk_score": score,
            "is_sfha": 1 if str(sfha).upper() == "T" else 0,
        })
        if len(records) % 200 == 0:
            print(f"    ... {len(records) + len(done_ids)}/{total}")
        _time.sleep(0.25)

    if not records and existing is not None:
        print(f"  FEMA Flood: all sites already done")
        return

    df_new = pd.DataFrame(records)
    if existing is not None and len(existing) > 0:
        df_all = pd.concat([existing, df_new], ignore_index=True).drop_duplicates("site_id", keep="last")
    else:
        df_all = df_new
    df_all.to_parquet(out_path, index=False)
    print(f"FEMA Flood: wrote {len(df_all)} sites -> {out_path}")


# ---------- TIGER Highway Proximity Site-Level ----------
def ingest_tiger_highway_sites(cfg: dict, paths: dict) -> None:
    """Query TIGERweb for distance to nearest primary highway per site."""
    import time as _time

    spine = _load_spine(paths)
    if spine is None or "latitude" not in spine.columns:
        print("TIGER Highway: no spine with lat/lon")
        return

    out_path = paths["processed"] / "tiger_highway_sites.parquet"

    if out_path.is_file():
        existing = pd.read_parquet(out_path)
        done_ids = set(existing["site_id"].values) if "site_id" in existing.columns else set()
    else:
        existing = None
        done_ids = set()

    TIGER_URL = "https://tigerweb.geo.census.gov/arcgis/rest/services/TIGERweb/Transportation/MapServer/2/query"

    def _nearest_highway(lat, lon, bbox_size=0.2, retries=2):
        envelope = f"{lon - bbox_size},{lat - bbox_size},{lon + bbox_size},{lat + bbox_size}"
        params = {
            "geometry": envelope, "geometryType": "esriGeometryEnvelope",
            "spatialRel": "esriSpatialRelIntersects",
            "outFields": "FULLNAME,MTFCC", "returnGeometry": "true",
            "f": "json", "inSR": 4326, "outSR": 4326, "resultRecordCount": 30,
        }
        for attempt in range(retries):
            try:
                r = requests.get(TIGER_URL, params=params, timeout=30)
                r.raise_for_status()
                feats = r.json().get("features", [])
                if not feats:
                    return None, None
                min_dist = float("inf")
                nearest = ""
                for feat in feats:
                    name = feat.get("attributes", {}).get("FULLNAME", "")
                    for path in feat.get("geometry", {}).get("paths", []):
                        for vx in path:
                            d = _haversine(lat, lon, vx[1], vx[0])
                            if d < min_dist:
                                min_dist = d
                                nearest = name
                return round(min_dist, 2), nearest
            except Exception:
                if attempt < retries - 1:
                    _time.sleep(2)
        return None, None

    id_col = "site_id" if "site_id" in spine.columns else spine.columns[0]
    records = []
    total = len(spine)

    print(f"  TIGER Highway: querying {total} sites...")
    for idx, row in spine.iterrows():
        sid = row.get(id_col, idx)
        if sid in done_ids:
            continue
        dist, name = _nearest_highway(row["latitude"], row["longitude"])
        if dist is None:
            # Retry with larger bbox
            dist, name = _nearest_highway(row["latitude"], row["longitude"], bbox_size=0.5)

        records.append({
            "site_id": sid,
            "distance_to_highway_km": dist,
            "nearest_highway_name": name or "",
        })
        if len(records) % 100 == 0:
            print(f"    ... {len(records) + len(done_ids)}/{total}")
        _time.sleep(0.4)

    if not records and existing is not None:
        print(f"  TIGER Highway: all sites already done")
        return

    df_new = pd.DataFrame(records)
    if existing is not None and len(existing) > 0:
        df_all = pd.concat([existing, df_new], ignore_index=True).drop_duplicates("site_id", keep="last")
    else:
        df_all = df_new
    df_all.to_parquet(out_path, index=False)
    print(f"TIGER Highway: wrote {len(df_all)} sites -> {out_path}")


# ---------- Geospatial Composite Features ----------
def compute_geospatial_composites(cfg: dict, paths: dict) -> None:
    """Combine elevation, NLCD, FEMA flood, and highway distance into
    composite indicator features for FMV modeling."""
    out_path = paths["processed"] / "geospatial_composites_sites.parquet"

    # Load all component tables
    elev_path = paths["processed"] / "usgs_elevation_sites.parquet"
    nlcd_path = paths["processed"] / "nlcd_landcover_sites.parquet"
    fema_path = paths["processed"] / "fema_flood_sites.parquet"
    hwy_path = paths["processed"] / "tiger_highway_sites.parquet"

    dfs = {}
    for label, p in [("elevation", elev_path), ("nlcd", nlcd_path), ("fema", fema_path), ("highway", hwy_path)]:
        if p.is_file():
            dfs[label] = pd.read_parquet(p)
            print(f"  Composites: loaded {label} ({len(dfs[label])} sites)")
        else:
            print(f"  Composites: {label} not found at {p}")

    if not dfs:
        print("Geospatial Composites: no component data available")
        return

    # Start with whichever has the most sites
    base_key = max(dfs, key=lambda k: len(dfs[k]))
    df = dfs[base_key][["site_id"]].copy()

    # Merge all components
    for label, component in dfs.items():
        cols = [c for c in component.columns if c != "site_id"]
        df = df.merge(component[["site_id"] + cols], on="site_id", how="left")

    # --- Derived composite features ---

    # 1. composite_hazard_score (0-10 scale):
    #    flood risk (0-3) + terrain difficulty (0-3) + development incompatibility (0-4)
    df["_flood"] = df.get("flood_risk_score", pd.Series(dtype=float)).fillna(1).clip(1, 3)
    df["_terrain"] = pd.cut(
        df.get("terrain_variance_ft", pd.Series(dtype=float)).fillna(0),
        bins=[-1, 50, 200, 500, float("inf")],
        labels=[0, 1, 2, 3],
    ).astype(float).fillna(0)
    df["_dev_risk"] = df.get("nlcd_development_intensity", pd.Series(dtype=float)).fillna(0)
    df["composite_hazard_score"] = (df["_flood"] + df["_terrain"] + df["_dev_risk"]).clip(0, 10)

    # 2. site_accessibility_score (0-10): closer to highway + more developed = more accessible
    hwy_dist = df.get("distance_to_highway_km", pd.Series(dtype=float)).fillna(50)
    df["_hwy_score"] = (10 - hwy_dist.clip(0, 50) / 5).clip(0, 10)
    df["_dev_score"] = df.get("nlcd_development_intensity", pd.Series(dtype=float)).fillna(0) * 2.5
    df["site_accessibility_score"] = ((df["_hwy_score"] + df["_dev_score"]) / 2).clip(0, 10)

    # 3. buildability_index (0-10): how easy it is to build a tower here
    #    high = easy (flat, developed, no flood, near highway)
    #    low = hard (mountainous, undeveloped, flood zone, remote)
    df["buildability_index"] = (
        (3 - df["_terrain"])  # flat = 3, mountainous = 0
        + df.get("nlcd_is_developed", pd.Series(dtype=float)).fillna(0) * 2  # developed = +2
        + (3 - df["_flood"].clip(1, 3)) * 1  # no flood = +2, high flood = 0
        + df["_hwy_score"] / 5  # near highway = +2
    ).clip(0, 10)

    # 4. scarcity_proxy: inverse of buildability -- harder to build = more scarce = higher FMV
    df["scarcity_proxy"] = (10 - df["buildability_index"]).clip(0, 10)

    # 5. elevation_category for one-hot or ordinal use
    df["elevation_category"] = pd.cut(
        df.get("ground_elevation_ft", pd.Series(dtype=float)).fillna(0),
        bins=[-1000, 100, 500, 2000, 5000, 15000],
        labels=["coastal", "lowland", "midland", "highland", "mountain"],
    )

    # Drop temp columns
    drop_cols = [c for c in df.columns if c.startswith("_")]
    df.drop(columns=drop_cols, inplace=True)

    df.to_parquet(out_path, index=False)
    composite_cols = [c for c in df.columns if c not in ("site_id",)]
    print(f"Geospatial Composites: wrote {len(df)} sites x {len(composite_cols)} features -> {out_path}")
    print(f"  Features: {composite_cols}")


# ---------- FCC ASR bulk download ----------
def ingest_fcc_asr(cfg: dict, paths: dict) -> None:
    out_processed = paths["processed"] / "fcc_asr.parquet"
    if out_processed.is_file():
        print(f"FCC ASR: already cached at {out_processed}, skipping download")
        return

    base_url = cfg.get("fcc_asr", {}).get("base_url", "https://data.fcc.gov/download/pub/uls/complete")
    files = cfg.get("fcc_asr", {}).get("files", ["r_tower.zip"])
    raw_dir = paths["raw"] / "fcc"
    raw_dir.mkdir(parents=True, exist_ok=True)

    for fname in files:
        url = f"{base_url}/{fname}"
        try:
            r = requests.get(url, stream=True, timeout=120)
            r.raise_for_status()
            out_zip = raw_dir / fname
            with open(out_zip, "wb") as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)
            print(f"FCC ASR: downloaded -> {out_zip}")
        except Exception as e:
            print(f"FCC ASR {fname}: {e}")

    # Optional: parse r_tower.zip EN.dat into a simple table (FCC format is pipe-delimited; layout in FCC docs)
    r_tower = raw_dir / "r_tower.zip"
    if r_tower.is_file():
        try:
            with zipfile.ZipFile(r_tower) as z:
                for name in z.namelist():
                    if "EN" in name and (name.endswith(".dat") or name.endswith(".txt")):
                        with z.open(name) as f:
                            lines = f.read().decode("utf-8", errors="ignore").strip().split("\n")
                        if not lines:
                            continue
                        # Assume first line is header or first record; FCC EN format is pipe-delimited
                        rows = [ln.split("|") for ln in lines[:50000] if ln]
                        if rows:
                            df = pd.DataFrame(rows[1:], columns=rows[0] if len(rows[0]) == len(rows[1]) else None)
                            if df is not None and len(df.columns) > 3:
                                out_processed = paths["processed"] / "fcc_asr.parquet"
                                df.to_parquet(out_processed, index=False)
                                print(f"FCC ASR: parsed {len(df)} rows -> {out_processed}")
                        break
        except Exception as e:
            print(f"FCC ASR parse: {e}")


# ---------- HUD SAFMR (ArcGIS) ----------
def ingest_hud_safmr(cfg: dict, paths: dict) -> None:
    out_path = paths["processed"] / "hud_safmr.parquet"
    if out_path.is_file():
        print(f"HUD SAFMR: already cached at {out_path}, skipping API fetch")
        return

    base = "https://services.arcgis.com/VTyQ9soqVukalItT/arcgis/rest/services/HUD_PDR_Small_Area_Fair_Market_Rents/FeatureServer/1/query"
    params = {"where": "1=1", "outFields": "ZCTA,STATE,BR0,BR1,BR2,BR3,BR4", "returnGeometry": "false", "f": "json", "resultRecordCount": 1000}
    all_records = []
    offset = 0
    while True:
        params["resultOffset"] = offset
        try:
            r = requests.get(base, params=params, timeout=60)
            j = r.json()
            if "error" in j:
                print("HUD SAFMR:", j["error"])
                return
            feats = j.get("features", [])
            if not feats:
                break
            for f in feats:
                a = f.get("attributes", {})
                a["zip_code"] = a.get("ZCTA")
                all_records.append(a)
            offset += len(feats)
            if len(feats) < 1000:
                break
        except Exception as e:
            print(f"HUD SAFMR: {e}")
            break
    if not all_records:
        print("HUD SAFMR: no data")
        return
    df = pd.DataFrame(all_records)
    df.to_parquet(out_path, index=False)
    print(f"HUD SAFMR: wrote {len(df)} rows -> {out_path}")


# ---------- FEMA NFHL (ArcGIS) ----------
def ingest_fema_flood(cfg: dict, paths: dict) -> None:
    out_path = paths["processed"] / "fema_flood.parquet"
    if out_path.is_file():
        print(f"FEMA Flood: already cached at {out_path}, skipping API fetch")
        return

    # Query a subset (e.g. limit) to avoid huge response; full nation would need tiling
    base = "https://hazards.fema.gov/arcgis/rest/services/public/NFHL/MapServer/28/query"
    params = {"where": "1=1", "outFields": "FLD_ZONE,ZONE_SUBTY,OBJECTID", "returnGeometry": "false", "f": "json", "resultRecordCount": 50000}
    try:
        r = requests.get(base, params=params, timeout=120)
        j = r.json()
        if "error" in j:
            print("FEMA:", j.get("error"))
            return
        feats = j.get("features", [])
        records = [f.get("attributes", {}) for f in feats]
        if not records:
            print("FEMA: no features (try different layer or bbox)")
            return
        df = pd.DataFrame(records)
        df.to_parquet(out_path, index=False)
        print(f"FEMA: wrote {len(df)} rows -> {out_path}")
    except Exception as e:
        print(f"FEMA: {e}")


# ---------- FHFA HPI (bulk CSV download) ----------
def ingest_fhfa_hpi(cfg: dict, paths: dict) -> None:
    url = cfg.get("fhfa_hpi", {}).get("base_url", "")
    if not url:
        print("FHFA: set fhfa_hpi.base_url in ingestion_config.yaml (see FHFA website)")
        return
    raw_dir = paths["raw"] / "fhfa"
    raw_dir.mkdir(parents=True, exist_ok=True)
    try:
        r = requests.get(url, timeout=120)
        r.raise_for_status()
        z = zipfile.ZipFile(io.BytesIO(r.content))
        for name in z.namelist():
            if name.endswith(".csv"):
                df = pd.read_csv(z.open(name), nrows=50000)
                out_path = paths["processed"] / "fhfa_hpi.parquet"
                df.to_parquet(out_path, index=False)
                print(f"FHFA: wrote {len(df)} rows -> {out_path}")
                break
    except Exception as e:
        print(f"FHFA: {e}")


# ---------- TIGER/Line Tract Shapefiles ----------
def ingest_tiger_tracts(cfg: dict, paths: dict) -> None:
    """Download Census TIGER/Line tract shapefiles for all US states and merge
    into a single GeoParquet file.  This replaces the per-point Census Geocoder
    API with an offline spatial join (gpd.sjoin)."""
    if gpd is None:
        print("TIGER: pip install geopandas shapely pyogrio")
        return

    tiger_cfg = cfg.get("tiger_tracts", {})
    tiger_year = tiger_cfg.get("year", "2024")
    base_url = tiger_cfg.get(
        "base_url",
        f"https://www2.census.gov/geo/tiger/TIGER{tiger_year}/TRACT",
    )
    raw_dir = paths["raw"] / "tiger"
    raw_dir.mkdir(parents=True, exist_ok=True)
    out_path = paths["processed"] / "tiger_tracts.parquet"

    # All US state FIPS (including AK=02, HI=15, DC=11, PR=72)
    skip_fips = {"03", "07", "14", "43", "52"}
    state_fips_list = [f"{i:02d}" for i in range(1, 57) if f"{i:02d}" not in skip_fips]
    state_fips_list.append("72")  # Puerto Rico

    all_gdfs = []
    for st in state_fips_list:
        fname = f"tl_{tiger_year}_{st}_tract.zip"
        local_zip = raw_dir / fname
        url = f"{base_url}/{fname}"

        # Download if not cached
        if not local_zip.is_file():
            try:
                print(f"  TIGER: downloading {fname} ...")
                r = requests.get(url, stream=True, timeout=120)
                r.raise_for_status()
                with open(local_zip, "wb") as f:
                    for chunk in r.iter_content(chunk_size=65536):
                        f.write(chunk)
            except Exception as e:
                print(f"  TIGER state {st}: download error - {e}")
                continue

        # Read shapefile from zip
        try:
            gdf = gpd.read_file(f"zip://{local_zip}")
            # Keep only essential columns
            keep_cols = ["STATEFP", "COUNTYFP", "TRACTCE", "GEOID", "NAMELSAD",
                         "ALAND", "AWATER", "INTPTLAT", "INTPTLON", "geometry"]
            keep_cols = [c for c in keep_cols if c in gdf.columns]
            gdf = gdf[keep_cols]
            all_gdfs.append(gdf)
        except Exception as e:
            print(f"  TIGER state {st}: read error - {e}")
            continue

    if not all_gdfs:
        print("TIGER: no data")
        return

    tracts = pd.concat(all_gdfs, ignore_index=True)
    tracts = gpd.GeoDataFrame(tracts, geometry="geometry", crs="EPSG:4326")
    tracts.to_parquet(out_path, index=False)
    print(f"TIGER: wrote {len(tracts)} tract polygons -> {out_path}")


# ---------- OpenCelliD Bulk Download ----------
def ingest_opencellid_bulk(cfg: dict, paths: dict) -> None:
    """Download the full OpenCelliD cell-tower database and filter to US towers
    (MCC 310-316).  Replaces per-bbox API calls with a single bulk file."""
    api_key = os.environ.get("OPENCELLID_API_KEY", "")
    if not api_key:
        print("OpenCelliD: set OPENCELLID_API_KEY in .env")
        return

    oci_cfg = cfg.get("opencellid_bulk", {})
    us_mcc_codes = oci_cfg.get("us_mcc_codes", [310, 311, 312, 313, 316])
    raw_dir = paths["raw"] / "opencellid"
    raw_dir.mkdir(parents=True, exist_ok=True)
    gz_path = raw_dir / "cell_towers.csv.gz"
    out_path = paths["processed"] / "opencellid_us.parquet"

    if out_path.is_file():
        print(f"OpenCelliD: already cached at {out_path}, skipping download/parse")
        return

    # Download bulk file if not cached
    if not gz_path.is_file():
        url = f"https://opencellid.org/ocid/downloads?token={api_key}&type=full&file=cell_towers.csv.gz"
        print("  OpenCelliD: downloading bulk file (~500 MB, this will take a while)...")
        try:
            r = requests.get(url, stream=True, timeout=600)
            r.raise_for_status()
            with open(gz_path, "wb") as f:
                for chunk in r.iter_content(chunk_size=262144):
                    f.write(chunk)
            size_mb = gz_path.stat().st_size / 1024 / 1024
            print(f"  OpenCelliD: downloaded {size_mb:.0f} MB -> {gz_path}")
        except Exception as e:
            print(f"  OpenCelliD: download error - {e}")
            if gz_path.is_file():
                gz_path.unlink()
            return
    else:
        size_mb = gz_path.stat().st_size / 1024 / 1024
        print(f"  OpenCelliD: using cached bulk file ({size_mb:.0f} MB)")

    # Read and filter to US towers
    print("  OpenCelliD: reading and filtering to US (MCC in", us_mcc_codes, ")...")
    try:
        usecols = ["radio", "mcc", "net", "area", "cell", "lon", "lat",
                    "range", "samples", "changeable", "created", "updated"]
        chunks = pd.read_csv(
            gz_path, compression="gzip", usecols=usecols,
            dtype={"mcc": "Int64", "net": "Int64", "area": "Int64", "cell": "Int64"},
            chunksize=500_000,
        )
        us_frames = []
        total_read = 0
        for chunk in chunks:
            total_read += len(chunk)
            us_chunk = chunk[chunk["mcc"].isin(us_mcc_codes)]
            if len(us_chunk) > 0:
                us_frames.append(us_chunk)
            if total_read % 2_000_000 == 0:
                print(f"    ... processed {total_read:,} rows")

        if not us_frames:
            print("  OpenCelliD: no US towers found")
            return

        df_us = pd.concat(us_frames, ignore_index=True)

        # Map MCC/MNC to carrier names
        print("  OpenCelliD: mapping carrier names from MCC/MNC codes...")
        df_us["carrier_name"] = df_us.apply(
            lambda r: _resolve_carrier_name(int(r["mcc"]), int(r["net"]))
            if pd.notna(r["mcc"]) and pd.notna(r["net"]) else "Unknown",
            axis=1,
        )
        print(f"  Top carriers: {df_us['carrier_name'].value_counts().head(10).to_dict()}")

        df_us.to_parquet(out_path, index=False)
        print(f"OpenCelliD: wrote {len(df_us):,} US towers -> {out_path}")
        print(f"  Radio breakdown: {df_us['radio'].value_counts().to_dict()}")
    except Exception as e:
        print(f"  OpenCelliD: parse error - {e}")


# ---------- FMV Proxy / Derived Features ----------
def compute_fmv_proxy_features(cfg: dict, paths: dict) -> None:
    """Compute derived proxy features for FMV prediction from existing data.

    Produces two output files:
      1. fmv_proxy_tract.parquet  -- tract-level derived features
      2. fmv_proxy_sites.parquet  -- site-level derived features (asset class, etc.)

    Tract-level features:
      - vacancy_rate, income_to_rent_ratio, home_value_to_income_ratio
      - carrier_monopoly_flag, tech_upgrade_score
      - rural_flag, population_density
      - CAGR (10yr compound annual growth for home value and income)
      - volatility (std dev of year-over-year changes)
      - trend_acceleration (1yr growth vs 3yr growth)

    Site-level features:
      - asset_class (derived from NLCD code)
    """
    import numpy as _np

    tract_out = paths["processed"] / "fmv_proxy_tract.parquet"
    site_out = paths["processed"] / "fmv_proxy_sites.parquet"

    if tract_out.is_file() and site_out.is_file():
        print(f"FMV Proxy Features: already cached, skipping")
        return

    # ================================================================
    # TRACT-LEVEL PROXY FEATURES
    # ================================================================
    tract_frames = []

    # --- 1. Ratios from Census ACS (latest year block-group or tract) ---
    acs_bg_glob = list(paths["processed"].glob("acs_blockgroup_*.parquet"))
    acs_tract_path = paths["processed"] / "acs_tract.parquet"
    multi_year_path = paths.get("data_root", Path("data")) / "census_tract_all_us_demographics_2010_2024.parquet"

    # Try block-group first (finer), then tract
    acs_df = None
    if acs_bg_glob:
        acs_df = pd.read_parquet(sorted(acs_bg_glob)[-1])
        print(f"  FMV Proxy: loaded block-group data ({len(acs_df):,} rows)")
    elif acs_tract_path.is_file():
        acs_df = pd.read_parquet(acs_tract_path)
        print(f"  FMV Proxy: loaded tract data ({len(acs_df):,} rows)")

    # Standardize column names (ACS variable codes -> friendly names)
    ACS_RENAME = {
        "B01003_001E": "population", "B19013_001E": "median_income",
        "B25077_001E": "median_home_value", "B25064_001E": "median_rent",
        "B25002_001E": "total_housing_units", "B25002_003E": "vacant_units",
    }
    if acs_df is not None:
        for old, new in ACS_RENAME.items():
            if old in acs_df.columns and new not in acs_df.columns:
                acs_df.rename(columns={old: new}, inplace=True)

        # Ensure tract_fips exists
        if "tract_fips" not in acs_df.columns:
            if "state" in acs_df.columns and "county" in acs_df.columns and "tract" in acs_df.columns:
                acs_df["tract_fips"] = acs_df["state"].astype(str) + acs_df["county"].astype(str) + acs_df["tract"].astype(str)

        # Aggregate block groups to tract if needed
        if "bg_fips" in acs_df.columns and "tract_fips" in acs_df.columns:
            numeric_cols = ["population", "median_income", "median_home_value",
                            "median_rent", "total_housing_units", "vacant_units"]
            available_num = [c for c in numeric_cols if c in acs_df.columns]
            for c in available_num:
                acs_df[c] = pd.to_numeric(acs_df[c], errors="coerce")
            # For medians, take the population-weighted mean across block groups;
            # for totals, sum them
            sum_cols = [c for c in ["population", "total_housing_units", "vacant_units"] if c in available_num]
            median_cols = [c for c in ["median_income", "median_home_value", "median_rent"] if c in available_num]

            agg_dict = {}
            for c in sum_cols:
                agg_dict[c] = (c, "sum")
            for c in median_cols:
                agg_dict[c] = (c, "median")
            tract_agg = acs_df.groupby("tract_fips").agg(**agg_dict).reset_index()
        else:
            tract_agg = acs_df.copy()
            if "tract_fips" in tract_agg.columns:
                tract_agg = tract_agg.drop_duplicates("tract_fips")

        if "tract_fips" in tract_agg.columns:
            # Ensure numeric
            for c in ["population", "median_income", "median_home_value",
                       "median_rent", "total_housing_units", "vacant_units"]:
                if c in tract_agg.columns:
                    tract_agg[c] = pd.to_numeric(tract_agg[c], errors="coerce")

            ratios = tract_agg[["tract_fips"]].copy()

            # Vacancy rate
            if "total_housing_units" in tract_agg.columns and "vacant_units" in tract_agg.columns:
                ratios["vacancy_rate"] = (
                    tract_agg["vacant_units"] / tract_agg["total_housing_units"].replace(0, _np.nan)
                ).clip(0, 1)

            # Income-to-rent ratio (annual income / annual rent)
            if "median_income" in tract_agg.columns and "median_rent" in tract_agg.columns:
                annual_rent = tract_agg["median_rent"].clip(lower=1) * 12
                ratios["income_to_rent_ratio"] = (
                    tract_agg["median_income"].clip(lower=0) / annual_rent
                ).clip(0, 50)

            # Home-value-to-income ratio (market heat indicator)
            if "median_home_value" in tract_agg.columns and "median_income" in tract_agg.columns:
                ratios["home_value_to_income_ratio"] = (
                    tract_agg["median_home_value"].clip(lower=0)
                    / tract_agg["median_income"].clip(lower=1)
                ).clip(0, 50)

            # Population density (per sq km) -- need TIGER tract area
            tiger_path = paths["processed"] / "tiger_tracts.parquet"
            if tiger_path.is_file():
                try:
                    tiger = pd.read_parquet(tiger_path, columns=["GEOID", "ALAND"])
                    tiger["ALAND"] = pd.to_numeric(tiger["ALAND"], errors="coerce")
                    tiger["tract_area_sqkm"] = tiger["ALAND"] / 1e6
                    tiger.rename(columns={"GEOID": "tract_fips"}, inplace=True)
                    ratios = ratios.merge(tiger[["tract_fips", "tract_area_sqkm"]], on="tract_fips", how="left")
                    if "population" in tract_agg.columns:
                        pop_series = tract_agg.set_index("tract_fips")["population"].reindex(ratios["tract_fips"])
                        ratios["population_density_sqkm"] = (
                            pop_series.values / ratios["tract_area_sqkm"].replace(0, _np.nan)
                        )
                    # Rural flag: < 100 people per sq km
                    if "population_density_sqkm" in ratios.columns:
                        ratios["rural_flag"] = (ratios["population_density_sqkm"] < 100).astype(int)
                except Exception as e:
                    print(f"  FMV Proxy: TIGER area merge failed: {e}")

            tract_frames.append(ratios)
            print(f"  FMV Proxy: computed ACS ratio features for {len(ratios):,} tracts")

    # --- 2. OpenCelliD-derived features ---
    oci_path = paths["processed"] / "opencellid_tract_agg.parquet"
    if oci_path.is_file():
        oci = pd.read_parquet(oci_path)
        oci_derived = oci[["tract_fips"]].copy()

        # Carrier monopoly flag: only 1 named carrier in the tract
        if "named_carrier_count" in oci.columns:
            oci_derived["carrier_monopoly_flag"] = (oci["named_carrier_count"] <= 1).astype(int)
        elif "carrier_count" in oci.columns:
            oci_derived["carrier_monopoly_flag"] = (oci["carrier_count"] <= 1).astype(int)

        # Tech upgrade score: 5G penetration x deployment velocity
        if "pct_5g_nr" in oci.columns and "tower_growth_18mo" in oci.columns:
            oci_derived["tech_upgrade_score"] = (
                oci["pct_5g_nr"].fillna(0) * 5  # 0-5 scale for 5G
                + oci["tower_growth_18mo"].fillna(0).clip(0, 1) * 5  # 0-5 scale for growth
            ).clip(0, 10)

        # Co-location potential: high tower count + multiple carriers
        if "tower_count" in oci.columns and "carrier_count" in oci.columns:
            oci_derived["colocation_potential"] = (
                _np.log1p(oci["tower_count"]) * oci["carrier_count"].clip(1, 10) / 10
            ).clip(0, 10)

        tract_frames.append(oci_derived)
        print(f"  FMV Proxy: computed OpenCelliD-derived features for {len(oci_derived):,} tracts")

    # --- 3. Temporal derived features: CAGR, volatility, trend acceleration ---
    if multi_year_path.is_file():
        df_multi = pd.read_parquet(multi_year_path)
        # Standardize column names
        for old, new in ACS_RENAME.items():
            if old in df_multi.columns and new not in df_multi.columns:
                df_multi.rename(columns={old: new}, inplace=True)
        if "tract_fips" not in df_multi.columns:
            if "state" in df_multi.columns and "county" in df_multi.columns and "tract" in df_multi.columns:
                df_multi["tract_fips"] = df_multi["state"].astype(str) + df_multi["county"].astype(str) + df_multi["tract"].astype(str)

        if "year" in df_multi.columns and "tract_fips" in df_multi.columns:
            df_multi["year"] = pd.to_numeric(df_multi["year"], errors="coerce")
            latest_yr = int(df_multi["year"].max())
            earliest_yr = int(df_multi["year"].min())
            n_years = latest_yr - earliest_yr

            temporal_derived = []

            for metric in ["median_home_value", "median_income"]:
                if metric not in df_multi.columns:
                    continue
                df_multi[metric] = pd.to_numeric(df_multi[metric], errors="coerce")

                # Pivot: rows=tract_fips, columns=year, values=metric
                pivot = df_multi[df_multi[metric] > 0].pivot_table(
                    index="tract_fips", columns="year", values=metric, aggfunc="first"
                )
                if pivot.empty:
                    continue

                # CAGR over full period
                if latest_yr in pivot.columns and earliest_yr in pivot.columns and n_years > 0:
                    start_val = pivot[earliest_yr].replace(0, _np.nan)
                    end_val = pivot[latest_yr].replace(0, _np.nan)
                    valid = (start_val > 0) & (end_val > 0)
                    cagr = pd.Series(_np.nan, index=pivot.index)
                    cagr[valid] = (end_val[valid] / start_val[valid]) ** (1.0 / n_years) - 1
                    cagr = cagr.clip(-0.3, 0.5)
                    temporal_derived.append(cagr.rename(f"{metric}_cagr_{n_years}yr"))

                # Volatility: std of year-over-year percent changes
                yoy = pivot.pct_change(axis=1)
                vol = yoy.std(axis=1).clip(0, 2)
                temporal_derived.append(vol.rename(f"{metric}_volatility"))

                # Trend acceleration: 1yr growth minus 3yr annualized growth
                trends_path = paths["processed"] / "temporal_trends_tract.parquet"
                if trends_path.is_file():
                    trends = pd.read_parquet(trends_path)
                    g1 = f"{metric.replace('median_', '')}_growth_1yr"
                    g3 = f"{metric.replace('median_', '')}_growth_3yr"
                    if g1 in trends.columns and g3 in trends.columns:
                        accel = (trends.set_index("tract_fips")[g1]
                                 - trends.set_index("tract_fips")[g3] / 3)
                        accel = accel.clip(-1, 1)
                        temporal_derived.append(accel.rename(f"{metric}_trend_acceleration"))

            if temporal_derived:
                df_temporal = pd.concat(temporal_derived, axis=1)
                df_temporal.index.name = "tract_fips"
                df_temporal = df_temporal.reset_index()
                tract_frames.append(df_temporal)
                print(f"  FMV Proxy: computed temporal derived features "
                      f"({len([c for c in df_temporal.columns if c != 'tract_fips'])} features, "
                      f"{len(df_temporal):,} tracts)")

    # --- Combine all tract-level proxy features ---
    if tract_frames:
        df_tract = tract_frames[0]
        for frame in tract_frames[1:]:
            df_tract = df_tract.merge(frame, on="tract_fips", how="outer")
        feature_cols = [c for c in df_tract.columns if c != "tract_fips"]
        df_tract.to_parquet(tract_out, index=False)
        print(f"  FMV Proxy Tract: wrote {len(df_tract):,} tracts x {len(feature_cols)} features -> {tract_out}")
        print(f"  Features: {feature_cols}")
    else:
        print("  FMV Proxy Tract: no input data available")

    # ================================================================
    # SITE-LEVEL PROXY FEATURES (asset_class from NLCD)
    # ================================================================
    nlcd_path = paths["processed"] / "nlcd_landcover_sites.parquet"
    if nlcd_path.is_file():
        nlcd = pd.read_parquet(nlcd_path)
        sites = nlcd[["site_id"]].copy()

        nlcd_code = nlcd.get("nlcd_code", pd.Series(dtype=float))

        # Asset class mapping from NLCD
        def _nlcd_to_asset_class(code):
            if pd.isna(code):
                return "Unknown"
            code = int(code)
            if code == 24:
                return "Commercial/Industrial"
            if code == 23:
                return "Mixed Commercial/Residential"
            if code == 22:
                return "Residential"
            if code == 21:
                return "Developed Open Space"
            if code == 31:
                return "Vacant/Barren Land"
            if code in (81, 82):
                return "Agricultural"
            if code in (41, 42, 43):
                return "Forested"
            if code in (90, 95):
                return "Wetland"
            if code == 11:
                return "Water"
            if code in (51, 52, 71):
                return "Scrub/Grassland"
            return "Other"

        sites["asset_class"] = nlcd_code.map(_nlcd_to_asset_class)

        # Numeric asset class ordinal (higher = more developed = typically higher FMV)
        ASSET_ORDINAL = {
            "Water": 0, "Wetland": 1, "Forested": 2, "Scrub/Grassland": 2,
            "Agricultural": 3, "Vacant/Barren Land": 4,
            "Developed Open Space": 5, "Residential": 6,
            "Mixed Commercial/Residential": 7, "Commercial/Industrial": 8,
            "Other": 3, "Unknown": 3,
        }
        sites["asset_class_ordinal"] = sites["asset_class"].map(ASSET_ORDINAL).fillna(3).astype(int)

        # Rooftop flag: codes 22-24 are structures likely with rooftops
        sites["is_rooftop_candidate"] = nlcd_code.apply(
            lambda c: 1 if pd.notna(c) and 22 <= int(c) <= 24 else 0
        )

        # Greenfield flag: undeveloped land where new towers could be erected
        sites["is_greenfield"] = nlcd_code.apply(
            lambda c: 1 if pd.notna(c) and int(c) in (21, 31, 52, 71, 81, 82) else 0
        )

        sites.to_parquet(site_out, index=False)
        site_cols = [c for c in sites.columns if c != "site_id"]
        print(f"  FMV Proxy Sites: wrote {len(sites):,} sites x {len(site_cols)} features -> {site_out}")
        print(f"  Asset class distribution: {sites['asset_class'].value_counts().to_dict()}")
    else:
        # Create a minimal file so caching works
        pd.DataFrame(columns=["site_id", "asset_class"]).to_parquet(site_out, index=False)
        print("  FMV Proxy Sites: NLCD data not available, wrote empty file")


# ---------- Build unified table ----------
def build_unified(cfg: dict, paths: dict) -> None:
    spine_path = paths["processed"] / "spine_sites.parquet"
    if not spine_path.is_file():
        # Fallback: use synthetic if present
        syn = PROJECT_ROOT / "data" / "synthetic" / "synthetic_5k_sites.parquet"
        if syn.is_file():
            spine = pd.read_parquet(syn)
            if "tract_fips" not in spine.columns and "latitude" in spine.columns:
                spine["tract_fips"] = ""
                spine["county_fips"] = ""
                spine["zip_code"] = ""
            spine.to_parquet(spine_path, index=False)
            print(f"Spine: copied synthetic -> {spine_path}")
        else:
            print("Unified: no spine_sites.parquet or synthetic_5k_sites.parquet; skipping join")
            return
    else:
        spine = pd.read_parquet(spine_path)

    out_path = Path(cfg.get("paths", {}).get("unified_file", "data/unified/sites_enriched.parquet"))
    if not str(out_path).startswith("data"):
        out_path = paths["unified"] / "sites_enriched.parquet"
    else:
        out_path = PROJECT_ROOT / out_path
    out_path.parent.mkdir(parents=True, exist_ok=True)

    df = spine.copy()

    # --- Spatial join: fill tract_fips from TIGER shapefiles if missing ---
    tiger_path = paths["processed"] / "tiger_tracts.parquet"
    needs_spatial = (
        "latitude" in df.columns
        and "longitude" in df.columns
        and tiger_path.is_file()
        and gpd is not None
    )
    has_tract_fips = "tract_fips" in df.columns and df["tract_fips"].notna().any() and (df["tract_fips"] != "").any()

    if needs_spatial and not has_tract_fips:
        print("  Unified: running TIGER spatial join to assign tract_fips ...")
        tracts = gpd.read_parquet(tiger_path)
        sites_gdf = gpd.GeoDataFrame(
            df,
            geometry=gpd.points_from_xy(df["longitude"], df["latitude"]),
            crs="EPSG:4326",
        )
        joined = gpd.sjoin(sites_gdf, tracts[["STATEFP", "COUNTYFP", "TRACTCE", "GEOID", "geometry"]],
                           how="left", predicate="within")
        df["tract_fips"] = joined["GEOID"].values
        df["state_fips"] = joined["STATEFP"].values
        df["county_fips"] = (joined["STATEFP"].fillna("") + joined["COUNTYFP"].fillna("")).values
        # Drop geometry column added by sjoin
        if "geometry" in df.columns:
            df = df.drop(columns=["geometry"])
        print(f"  Unified: spatial join matched {df['tract_fips'].notna().sum()}/{len(df)} sites")
    elif needs_spatial and has_tract_fips:
        # Fill only rows with missing tract_fips
        missing_mask = df["tract_fips"].isna() | (df["tract_fips"] == "")
        if missing_mask.any():
            print(f"  Unified: spatial join for {missing_mask.sum()} sites missing tract_fips ...")
            tracts = gpd.read_parquet(tiger_path)
            missing_df = df.loc[missing_mask].copy()
            missing_gdf = gpd.GeoDataFrame(
                missing_df,
                geometry=gpd.points_from_xy(missing_df["longitude"], missing_df["latitude"]),
                crs="EPSG:4326",
            )
            joined = gpd.sjoin(missing_gdf, tracts[["STATEFP", "COUNTYFP", "TRACTCE", "GEOID", "geometry"]],
                               how="left", predicate="within")
            df.loc[missing_mask, "tract_fips"] = joined["GEOID"].values
            if "state_fips" in df.columns:
                df.loc[missing_mask, "state_fips"] = joined["STATEFP"].values
            if "county_fips" in df.columns:
                df.loc[missing_mask, "county_fips"] = (joined["STATEFP"].fillna("") + joined["COUNTYFP"].fillna("")).values
            print(f"  Unified: filled {joined['GEOID'].notna().sum()} missing tract_fips via spatial join")

    # ACS
    acs_path = paths["processed"] / "acs_tract.parquet"
    if acs_path.is_file() and "tract_fips" in df.columns:
        acs = pd.read_parquet(acs_path)
        tract_cols = [c for c in acs.columns if c not in ("state", "county", "tract", "NAME") and c != "tract_fips"]
        acs["tract_fips"] = acs.get("state", "").astype(str) + acs.get("county", "").astype(str) + acs.get("tract", "").astype(str)
        df = df.merge(acs[["tract_fips"] + tract_cols].drop_duplicates("tract_fips"), on="tract_fips", how="left", suffixes=("", "_acs"))

    # FRED latest (broadcast to all rows)
    fred_path = paths["processed"] / "fred_macro.parquet"
    if fred_path.is_file():
        fred = pd.read_parquet(fred_path)
        fred_latest = fred.loc[fred.groupby("name")["date"].idxmax()].set_index("name")["value"]
        for name, val in fred_latest.items():
            df[name] = val

    # HUD SAFMR
    hud_path = paths["processed"] / "hud_safmr.parquet"
    if hud_path.is_file() and "zip_code" in df.columns:
        hud = pd.read_parquet(hud_path)
        hud["zip_code"] = hud.get("ZCTA", hud.get("zip_code", "")).astype(str)
        df["zip_code"] = df["zip_code"].astype(str)
        df = df.merge(hud.drop_duplicates("zip_code"), on="zip_code", how="left")

    # BLS state-level (from pipeline)
    bls_path = paths["processed"] / "bls_laus.parquet"
    if bls_path.is_file() and "state_fips" in df.columns:
        bls = pd.read_parquet(bls_path)
        bls_latest = bls.sort_values(["year", "period"], ascending=[False, False]).drop_duplicates("state_fips", keep="first") if "year" in bls.columns else bls
        if "unemployment_rate" in bls_latest.columns:
            bls_latest = bls_latest.rename(columns={"unemployment_rate": "state_unemployment_rate"})
            df = df.merge(bls_latest[["state_fips", "state_unemployment_rate"]].drop_duplicates("state_fips"), on="state_fips", how="left")

    # BLS county-level unemployment
    bls_county_path = paths["processed"] / "bls_laus_county.parquet"
    if bls_county_path.is_file() and "county_fips" in df.columns:
        bls_cty = pd.read_parquet(bls_county_path)
        bls_cty_latest = bls_cty.sort_values(["year", "period"], ascending=[False, False]).drop_duplicates("county_fips", keep="first")
        if "unemployment_rate" in bls_cty_latest.columns:
            bls_cty_latest = bls_cty_latest.rename(columns={"unemployment_rate": "county_unemployment_rate"})
            df = df.merge(bls_cty_latest[["county_fips", "county_unemployment_rate"]].drop_duplicates("county_fips"), on="county_fips", how="left")
            print(f"  Unified: joined county unemployment for {df['county_unemployment_rate'].notna().sum()}/{len(df)} sites")

    # FHFA HPI at tract level
    fhfa_tract_path = paths["processed"] / "fhfa_hpi_tract.parquet"
    if fhfa_tract_path.is_file() and "tract_fips" in df.columns:
        fhfa_tract = pd.read_parquet(fhfa_tract_path)
        # Find the geography/FIPS column and HPI column
        fips_col = next((c for c in fhfa_tract.columns if "fips" in c.lower() or "tract" in c.lower() or "place_id" in c.lower()), None)
        hpi_col = next((c for c in fhfa_tract.columns if "hpi" in c.lower() or "index" in c.lower()), None)
        if fips_col and hpi_col:
            fhfa_tract[fips_col] = fhfa_tract[fips_col].astype(str).str.zfill(11)
            fhfa_latest = fhfa_tract.sort_values(fhfa_tract.columns[fhfa_tract.columns.str.contains("year|yr|period|date", case=False)].tolist()[-1:] or ["index"],
                                                  ascending=False).drop_duplicates(fips_col, keep="first") if len(fhfa_tract) > 0 else fhfa_tract
            fhfa_latest = fhfa_latest.rename(columns={fips_col: "tract_fips", hpi_col: "fhfa_hpi_tract"})
            df = df.merge(fhfa_latest[["tract_fips", "fhfa_hpi_tract"]].drop_duplicates("tract_fips"), on="tract_fips", how="left")
            print(f"  Unified: joined FHFA tract HPI for {df['fhfa_hpi_tract'].notna().sum()}/{len(df)} sites")

    # FHFA HPI at ZIP level
    fhfa_zip_path = paths["processed"] / "fhfa_hpi_zip.parquet"
    if fhfa_zip_path.is_file() and "zip_code" in df.columns:
        fhfa_zip = pd.read_parquet(fhfa_zip_path)
        fips_col = next((c for c in fhfa_zip.columns if "zip" in c.lower() or "place_id" in c.lower()), None)
        hpi_col = next((c for c in fhfa_zip.columns if "hpi" in c.lower() or "index" in c.lower()), None)
        if fips_col and hpi_col:
            fhfa_zip[fips_col] = fhfa_zip[fips_col].astype(str).str.zfill(5)
            fhfa_z_latest = fhfa_zip.drop_duplicates(fips_col, keep="last")
            fhfa_z_latest = fhfa_z_latest.rename(columns={fips_col: "zip_code", hpi_col: "fhfa_hpi_zip"})
            df["zip_code"] = df["zip_code"].astype(str).str.zfill(5)
            df = df.merge(fhfa_z_latest[["zip_code", "fhfa_hpi_zip"]].drop_duplicates("zip_code"), on="zip_code", how="left")
            print(f"  Unified: joined FHFA ZIP HPI for {df['fhfa_hpi_zip'].notna().sum()}/{len(df)} sites")

    # OpenCelliD tract aggregates
    oci_agg_path = paths["processed"] / "opencellid_tract_agg.parquet"
    if oci_agg_path.is_file() and "tract_fips" in df.columns:
        oci_agg = pd.read_parquet(oci_agg_path)
        oci_cols = [c for c in oci_agg.columns if c != "tract_fips"]
        df = df.merge(oci_agg.drop_duplicates("tract_fips"), on="tract_fips", how="left", suffixes=("", "_oci"))
        print(f"  Unified: joined OpenCelliD tract agg ({len(oci_cols)} cols) for {df['tower_count'].notna().sum() if 'tower_count' in df.columns else 0}/{len(df)} sites")

    # Temporal trend features
    trends_path = paths["processed"] / "temporal_trends_tract.parquet"
    if trends_path.is_file() and "tract_fips" in df.columns:
        trends = pd.read_parquet(trends_path)
        trend_cols = [c for c in trends.columns if c != "tract_fips"]
        df = df.merge(trends.drop_duplicates("tract_fips"), on="tract_fips", how="left", suffixes=("", "_trend"))
        print(f"  Unified: joined {len(trend_cols)} temporal features for {df[trend_cols[0]].notna().sum() if trend_cols else 0}/{len(df)} sites")

    # Housing market composites (state-level)
    housing_path = paths["processed"] / "housing_market_composites.parquet"
    if housing_path.is_file() and "state_fips" in df.columns:
        housing = pd.read_parquet(housing_path)
        if "state_fips" in housing.columns:
            h_cols = [c for c in housing.columns if c not in ("state_fips", "state_abbr")]
            df = df.merge(housing[["state_fips"] + h_cols].drop_duplicates("state_fips"), on="state_fips", how="left", suffixes=("", "_housing"))
            print(f"  Unified: joined {len(h_cols)} housing market features")
        elif "state_abbr" in housing.columns and "state_abbr" in df.columns:
            h_cols = [c for c in housing.columns if c not in ("state_fips", "state_abbr")]
            df = df.merge(housing[["state_abbr"] + h_cols].drop_duplicates("state_abbr"), on="state_abbr", how="left", suffixes=("", "_housing"))
            print(f"  Unified: joined {len(h_cols)} housing market features")

    # HUD SAFMR enhanced (ZIP-level)
    safmr_enhanced_path = paths["processed"] / "hud_safmr_indicators.parquet"
    if safmr_enhanced_path.is_file() and "zip_code" in df.columns:
        safmr_e = pd.read_parquet(safmr_enhanced_path)
        zip_col = next((c for c in safmr_e.columns if c.lower() in ("zcta", "zip_code")), None)
        if zip_col:
            safmr_e[zip_col] = safmr_e[zip_col].astype(str).str.zfill(5)
            safmr_cols = [c for c in ["log_safmr_2br", "safmr_2br_national_pctile", "rent_tier"] if c in safmr_e.columns]
            if safmr_cols:
                safmr_e = safmr_e.rename(columns={zip_col: "zip_code"})
                df["zip_code"] = df["zip_code"].astype(str).str.zfill(5)
                df = df.merge(safmr_e[["zip_code"] + safmr_cols].drop_duplicates("zip_code"), on="zip_code", how="left", suffixes=("", "_safmr"))
                print(f"  Unified: joined {len(safmr_cols)} SAFMR ZIP features")

    # --- Site-level geospatial features ---
    id_col = "site_id" if "site_id" in df.columns else None

    # Geospatial composites (includes elevation, NLCD, FEMA, highway + derived features)
    composites_path = paths["processed"] / "geospatial_composites_sites.parquet"
    if composites_path.is_file() and id_col:
        geo_comp = pd.read_parquet(composites_path)
        geo_cols = [c for c in geo_comp.columns if c != "site_id"]
        df = df.merge(geo_comp.drop_duplicates("site_id"), on="site_id", how="left", suffixes=("", "_geo"))
        matched = df[geo_cols[0]].notna().sum() if geo_cols else 0
        print(f"  Unified: joined {len(geo_cols)} geospatial features for {matched}/{len(df)} sites")
    else:
        # Try joining individual component files
        for label, fname in [
            ("elevation", "usgs_elevation_sites.parquet"),
            ("nlcd", "nlcd_landcover_sites.parquet"),
            ("fema_flood", "fema_flood_sites.parquet"),
            ("highway", "tiger_highway_sites.parquet"),
        ]:
            fpath = paths["processed"] / fname
            if fpath.is_file() and id_col:
                comp = pd.read_parquet(fpath)
                cols = [c for c in comp.columns if c != "site_id"]
                df = df.merge(comp.drop_duplicates("site_id"), on="site_id", how="left", suffixes=("", f"_{label}"))
                print(f"  Unified: joined {label} ({len(cols)} cols)")

    # --- FMV Proxy Features (tract-level) ---
    proxy_tract_path = paths["processed"] / "fmv_proxy_tract.parquet"
    if proxy_tract_path.is_file() and "tract_fips" in df.columns:
        proxy_tract = pd.read_parquet(proxy_tract_path)
        proxy_cols = [c for c in proxy_tract.columns if c != "tract_fips"]
        df = df.merge(proxy_tract.drop_duplicates("tract_fips"), on="tract_fips", how="left", suffixes=("", "_proxy"))
        print(f"  Unified: joined {len(proxy_cols)} FMV proxy tract features")

    # --- FMV Proxy Features (site-level: asset_class, etc.) ---
    proxy_site_path = paths["processed"] / "fmv_proxy_sites.parquet"
    if proxy_site_path.is_file() and id_col:
        proxy_site = pd.read_parquet(proxy_site_path)
        if len(proxy_site) > 0:
            proxy_s_cols = [c for c in proxy_site.columns if c != "site_id"]
            df = df.merge(proxy_site.drop_duplicates("site_id"), on="site_id", how="left", suffixes=("", "_asset"))
            print(f"  Unified: joined {len(proxy_s_cols)} FMV proxy site features (asset_class, etc.)")

    df.to_parquet(out_path, index=False)
    print(f"Unified: wrote {len(df)} rows x {len(df.columns)} cols -> {out_path}")


# ---------- Main ----------
def main() -> None:
    parser = argparse.ArgumentParser(description="Ingest enrichment data (no manual download)")
    parser.add_argument("--sources", type=str, default="", help="Comma-separated sources (see ALL_SOURCES in code)")
    parser.add_argument("--build-unified", action="store_true", help="After ingest, build data/unified/sites_enriched.parquet")
    args = parser.parse_args()

    cfg = load_config()
    paths = get_paths(cfg)
    ensure_dirs(paths)
    # Normalize paths that might be "data/raw" -> data_root/raw
    if "raw" not in paths or not str(paths["raw"]).endswith("raw"):
        paths["raw"] = paths["data_root"] / "raw"
        paths["processed"] = paths["data_root"] / "processed"
        paths["unified"] = paths["data_root"] / "unified"
    paths["raw"].mkdir(parents=True, exist_ok=True)
    paths["processed"].mkdir(parents=True, exist_ok=True)
    paths["unified"].mkdir(parents=True, exist_ok=True)

    enabled = cfg.get("sources", {})
    want = set(args.sources.split(",")) if args.sources else set(enabled.keys())

    ALL_SOURCES = (
        "census_acs", "fred", "bls", "bls_county", "fcc_asr", "hud_safmr",
        "fema_flood", "fhfa_hpi", "fhfa_hpi_granular", "tiger_tracts",
        "opencellid_bulk", "acs_blockgroup", "opencellid_tract_agg",
        "temporal_features",
        "housing_indicators",
        "fmv_proxy_features",
        "usgs_elevation_sites", "nlcd_landcover_sites",
        "fema_flood_sites", "tiger_highway_sites",
        "geospatial_composites",
    )

    run = []
    if want:
        run = [s for s in ALL_SOURCES if s in want]
    else:
        for s in ALL_SOURCES:
            if enabled.get(s, True):
                run.append(s)

    runners = {
        "census_acs": ingest_census_acs,
        "fred": ingest_fred,
        "bls": ingest_bls,
        "bls_county": ingest_bls_county,
        "fcc_asr": ingest_fcc_asr,
        "hud_safmr": ingest_hud_safmr,
        "fema_flood": ingest_fema_flood,
        "fhfa_hpi": ingest_fhfa_hpi,
        "fhfa_hpi_granular": ingest_fhfa_hpi_granular,
        "tiger_tracts": ingest_tiger_tracts,
        "opencellid_bulk": ingest_opencellid_bulk,
        "acs_blockgroup": ingest_acs_blockgroup,
        "opencellid_tract_agg": aggregate_opencellid_to_tract,
        "temporal_features": compute_temporal_features,
        "housing_indicators": compute_housing_indicators,
        "fmv_proxy_features": compute_fmv_proxy_features,
        "usgs_elevation_sites": ingest_usgs_elevation_sites,
        "nlcd_landcover_sites": ingest_nlcd_landcover_sites,
        "fema_flood_sites": ingest_fema_flood_sites,
        "tiger_highway_sites": ingest_tiger_highway_sites,
        "geospatial_composites": compute_geospatial_composites,
    }
    for name in run:
        print(f"--- {name} ---")
        try:
            runners[name](cfg, paths)
        except Exception as e:
            print(f"{name} failed: {e}")

    if args.build_unified:
        print("--- build_unified ---")
        try:
            build_unified(cfg, paths)
        except Exception as e:
            print(f"build_unified failed: {e}")


if __name__ == "__main__":
    main()
