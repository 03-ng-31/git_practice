import pandas as pd

asr = pd.read_parquet('data/processed/fcc_asr.parquet')
uls = pd.read_parquet('data/processed/fcc_uls_cell.parquet')

uls_with_tower = uls[
    uls['tower_registration_number'].notna() &
    (uls['tower_registration_number'].str.strip() != '')
].copy()
print(f'ULS with tower_registration_number: {len(uls_with_tower):,}')

coloc_counts = uls_with_tower.groupby('tower_registration_number').agg(
    uls_license_count=('unique_system_identifier', 'nunique'),
    unique_call_signs=('call_sign', 'nunique'),
).reset_index()
print(f'Unique towers in ULS: {len(coloc_counts):,}')

coloc_df = asr.merge(
    coloc_counts,
    left_on='registration_number',
    right_on='tower_registration_number',
    how='left',
)
coloc_df.drop(columns=['tower_registration_number'], errors='ignore', inplace=True)
coloc_df['uls_license_count'] = coloc_df['uls_license_count'].fillna(0).astype(int)
coloc_df['unique_call_signs'] = coloc_df['unique_call_signs'].fillna(0).astype(int)

matched = (coloc_df['uls_license_count'] > 0).sum()
total = len(coloc_df)
print(f'\nCo-location summary ({total:,} ASR towers):')
print(f'  Matched to ULS:              {matched:,} ({matched/total*100:.1f}%)')
print(f'  Towers with 0 ULS licenses:  {(coloc_df["uls_license_count"] == 0).sum():,}')
print(f'  Towers with 1 license:       {(coloc_df["uls_license_count"] == 1).sum():,}')
print(f'  Towers with 2+ licenses:     {(coloc_df["uls_license_count"] >= 2).sum():,}')
print(f'  Towers with 3+ licenses:     {(coloc_df["uls_license_count"] >= 3).sum():,}')
print(f'  Max licenses on one tower:   {coloc_df["uls_license_count"].max()}')
print('\nColumns:', list(coloc_df.columns))
print('Shape:', coloc_df.shape)
