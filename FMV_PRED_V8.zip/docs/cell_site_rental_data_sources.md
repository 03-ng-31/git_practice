# Cell Site Rental Value Prediction — Data Sources & Implementation Plan

**Objective:** Predict rental value for cell sites (existing or upcoming) using Verizon rent data as the primary target, supplemented by alternate carrier benchmarks where available.

---

## 1. What You Have

| Source | What It Provides | Geography | Use for Model |
|--------|------------------|-----------|---------------|
| **Verizon rent data** | Your internal lease payments (target variable) | Site-level (lat/lon or address) | Primary target; join to tract via geocoding |
| **Census ACS** | 28 raw + 8 derived (population, income, housing, education, labor) | State, County, Tract, ZCTA, Block Group | Demographics, market size, income |
| **OpenCelliD** | Tower count, carrier count (MNC), radio tech (LTE/5G), density | Tract (via spatial join) | Competition, coverage gap proxy |
| **TIGER/Line** | Tract boundaries, area (ALAND) | Tract | Spatial join, density denominator |
| **BLS LAUS** | County unemployment | County | Economic activity |
| **FHFA HPI** | Home price index, appreciation rates | ZIP, Tract | Area appreciation proxy |
| **FRED** | National macro, state unemployment | National, State | Macro context |

---

## 2. Alternate Carrier Rent Data — Reliable Sources

### A. Free / Public

| Source | What It Provides | Reliability | How to Pull |
|--------|------------------|-------------|-------------|
| **U.S. Cell Tower Lease Rent Rates Index** | State + city-level low/high monthly rent ranges (USD) | Benchmark only; not site-specific | **CSV download:** [celltowerleaseexperts.com](https://www.celltowerleaseexperts.com/datasets/US-Cell-Tower-Lease-Rent-Rates-Index.csv) or [celltowerai.com](https://www.celltowerai.com/dataset-files/us-cell-tower-leaes-rent-rates-index.csv) |
| **FCC ULS (Universal Licensing System)** | Tower/antenna registrations, lease records | Official but incomplete (no rooftop, no rent amounts) | **Bulk download:** `https://data.fcc.gov/download/pub/uls/complete/` — files: `a_tower.zip`, `a_lease.zip` (pipe-delimited) |
| **FCC ASR (Antenna Structure Registration)** | Tower locations, heights, registration IDs | Official; towers only (no buildings) | State GIS portals (e.g., Arkansas), or FCC ULS |

**Limitations:**
- FCC data has **no rent amounts** — only registration/lease existence.
- Cell Tower Lease Rent Index is **city/state benchmarks**, not carrier-specific or site-level.
- Carriers (Verizon, AT&T, T-Mobile) **do not disclose site-level rents** publicly.

### B. Commercial (Paid)

| Source | What It Provides | Notes |
|--------|------------------|-------|
| **Steel in the Air** | 285k+ locations, 10k+ leases with rates | Consulting engagement only; not sold as dataset |
| **Tower Maps** | Tower locations, height, zoning | No tenant/rent info (carriers keep confidential) |

### C. SEC Filings (Aggregate Only)

- **10-K filings** (Verizon, AT&T, T-Mobile, Crown Castle): Aggregate lease expense, not site-level.
- Useful for sanity-checking totals, not for training.

---

## 3. Recommended Data Pulls for Your Pipeline

### Already in Notebook (Keep)

- Census ACS (2015–2024 for cell-site focus)
- OpenCelliD (tower count, carrier count, LTE/5G %, density)
- TIGER, BLS, FHFA, FRED

### Add to Notebook

| Data | Source | Purpose |
|------|--------|---------|
| **Cell Tower Lease Rent Index** | CSV from celltowerleaseexperts.com or celltowerai.com | Benchmark target for city/state; validate model outputs |
| **Coverage gap proxy** | Derived from OpenCelliD | Tracts with low tower density relative to population = opportunity |
| **Carrier-specific flags** | OpenCelliD `mcc`+`net` (MNC) | Verizon/AT&T/T-Mobile presence per tract |
| **Time window** | Restrict Census to 2015–2024 | Cell-site-relevant period |

### Optional (If You Want More)

| Data | Source | Effort |
|------|--------|--------|
| FCC ULS `a_lease` | FCC bulk download | Parse pipe-delimited; join to towers; no rent $ |
| FCC ULS `a_tower` | FCC bulk download | Additional tower locations (overlaps OpenCelliD) |

---

## 4. OpenCelliD → Carrier Mapping (US)

Use `mcc` + `net` (MNC) to flag carrier presence:

| Carrier | MCC | MNC (examples) |
|---------|-----|----------------|
| Verizon | 311 | 480, 110, 270–289, 390, 481–489 |
| AT&T | 310 | 410, 280; 311: 180 |
| T-Mobile | 310 | 260, 120; 311: 490 |
| Sprint (legacy) | 310 | 120 (now T-Mobile) |

**Derived features:**
- `has_verizon`, `has_att`, `has_tmobile` (boolean per tract)
- `carrier_count` (already in `oci_agg`)
- `verizon_tower_pct`, `att_tower_pct`, `tmobile_tower_pct`

---

## 5. Coverage Gap Proxy

**Formula:** Tracts with **high population** but **low tower density** = underserved = higher rent potential.

```
coverage_gap_score = population / (tower_count + 1)   # higher = more gap
# or
coverage_gap_score = population_density / (tower_density_sqkm + 0.01)
```

Tracts with 0 towers get `tower_count=0` → high gap score. Normalize (e.g., percentile) for modeling.

---

## 6. Implementation Checklist

- [x] **Time window:** `years = range(2015, 2025)` in Census cells
- [x] **Coverage gap:** `coverage_gap_score` in oci_agg (NB06 Section 13)
- [x] **Population per tower:** `population_per_tower` in oci_agg
- [x] **Carrier flags:** `has_verizon`, `has_att`, `has_tmobile` in oci_agg
- [x] **5G penetration:** `pct_5g_nr` in oci_agg
- [x] **Renter concentration:** `renter_concentration` in compute_fmv_derived (NB06)
- [x] **Population & income growth:** `*_growth_5yr` in temporal trends (NB06 Section 14)
- [x] **Compound hazard:** `compound_hazard_score` in NB07 combined geo
- [x] **High-demand corridor:** `high_demand_corridor_score` in NB07
- [x] **FHFA HPI appreciation:** `hpi_appreciation_5yr` in NB08
- [ ] **Cell Tower Lease Index:** Add cell to download CSV for benchmark
- [ ] **Verizon target:** Geocode rent data to tract_fips; join to feature matrix

---

## 7. File References

| Resource | URL |
|----------|-----|
| Cell Tower Lease Rent Index CSV | https://www.celltowerleaseexperts.com/datasets/US-Cell-Tower-Lease-Rent-Rates-Index.csv |
| Cell Tower AI CSV | https://www.celltowerai.com/dataset-files/us-cell-tower-leaes-rent-rates-index.csv |
| FCC ULS Complete | https://data.fcc.gov/download/pub/uls/complete/ |
| FCC ULS Docs | https://www.fcc.gov/wireless/data/public-access-files-database-downloads |
| OpenCelliD Bulk | https://opencellid.org/ocid/downloads (token required) |
