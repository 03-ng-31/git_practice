# Feature Engineering — Data Sources (No Hardcoding)

All URLs and configuration live in `configs/data_sources.yaml`. Load with:
```python
import yaml
with open("configs/data_sources.yaml") as f:
    SOURCES = yaml.safe_load(f)
```

---

## Mandatory Features — Data Sources

### High Impact, Low Effort

| Feature | Source | Notebook | URL / Config Key |
|---------|--------|----------|-------------------|
| **Coverage gap score** | OpenCelliD + Census | NB06 | `population / (tower_count + 1)` from oci_agg |
| **Compound hazard** | FEMA × USGS 3DEP | NB07 | `flood_risk_score × (terrain_variance_ft/100)` |
| **High-demand corridor** | NLCD × TIGER | NB07 | `nlcd_is_developed × (10 - distance_to_highway_km/5)` |
| **Population per tower** | OpenCelliD + Census | NB06 | `population / tower_count` in oci_agg |
| **Renter concentration** | Census ACS | NB06 | `renter_occupied / (owner + renter)` in compute_fmv_derived |

### Medium Effort, Strong Signal

| Feature | Source | Notebook | URL / Config Key |
|---------|--------|----------|-------------------|
| **Distance to nearest interstate** | TIGER Layer 2, filter RTTYP='I' | NB07 | `tiger.transportation_base` + `tiger.interstates_filter` |
| **Land cover diversity** | NLCD WMS, buffer sampling | NB07 | `usgs.mrlc_wms_url` + `usgs.nlcd_layers` |
| **Developed % in buffer** | NLCD WMS, multiple points | NB07 | Same as above |
| **Population & income growth (5yr)** | Census ACS panel | NB06 | Section 14 temporal trends |
| **5G penetration** | OpenCelliD `radio` field | NB06 | `pct_5g_nr` in oci_agg |
| **Carrier flags** | OpenCelliD MCC+MNC | NB06 | `has_verizon`, `has_att`, `has_tmobile` in oci_agg |

---

## Optional Features — If Data Available

| Feature | Source | URL (from config) |
|---------|--------|-------------------|
| **Distance to airport** | DoT / FAA | `airports.dot_csv` or `airports.faa_arcgis` |
| **Coastal proximity** | Census TIGER Coastline | `coastline.census_shapefile` |
| **FHFA HPI appreciation** | FHFA HPI time series | `fhfa.state_quarterly` — compute 5yr growth |
| **NLCD multi-year change** | MRLC NLCD 2016, 2019, 2021 | `usgs.nlcd_layers` — compare vintages |

---

## API Endpoints (configs/data_sources.yaml)

- **Census CenPop**: State centroids (2020)
- **USGS 3DEP**: `epqs.nationalmap.gov/v1/json`
- **USGS NLCD**: `mrlc.gov/geoserver/mrlc_display/wms` — layers: 2016, 2019, 2021
- **FEMA NFHL**: `hazards.fema.gov` (primary + alternate)
- **TIGER Transportation**: Layer 2 = Primary Roads; filter `RTTYP='I'` for interstates
- **FHFA HPI**: State quarterly CSV, master monthly
- **Airports**: DoT CSV or FAA ArcGIS
- **Coastline**: Census TIGER 2024 COASTLINE

---

## Notebook Mapping

| Notebook | Features Added |
|----------|----------------|
| **06** | renter_concentration, population_per_tower, coverage_gap_score, 5G (pct_5g_nr), carrier flags, population/income growth 5yr |
| **07** | compound_hazard_score, high_demand_corridor_score, distance_to_nearest_interstate_km, optional: NLCD multi-year, airport, coastal |
| **08** | hpi_appreciation_5yr, config loading |
