#!/usr/bin/env python3
"""
Automated data ingestion pipeline for Cell-Site FMV enrichment.
Fetches from Census, FRED, BLS, FCC, HUD, FEMA, FHFA via APIs or bulk download
(no manual download). Run on-demand or on a schedule (cron / Task Scheduler).

Usage:
  python scripts/ingest_data.py                    # run all enabled sources
  python scripts/ingest_data.py --sources fred,census_acs  # run selected
  python scripts/ingest_data.py --build-unified   # after ingest, build unified table
"""

from __future__ import annotations

import argparse
import os
import sys
import zipfile
import io
from datetime import datetime
from pathlib import Path

# Project root = parent of scripts/
PROJECT_ROOT = Path(__file__).resolve().parent.parent
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

# Load .env before any API keys are used
_env_file = PROJECT_ROOT / ".env"
if _env_file.is_file():
    try:
        from dotenv import load_dotenv
        load_dotenv(_env_file)
    except ImportError:
        pass

import requests
import pandas as pd
import yaml

# Optional deps (fail gracefully per source)
try:
    from fredapi import Fred
except ImportError:
    Fred = None


def load_config() -> dict:
    cfg_path = PROJECT_ROOT / "configs" / "ingestion_config.yaml"
    if not cfg_path.is_file():
        return {"paths": {"data_root": "data", "raw_dir": "data/raw", "processed_dir": "data/processed"}}
    with open(cfg_path) as f:
        return yaml.safe_load(f) or {}


def get_paths(cfg: dict) -> dict:
    root = cfg.get("paths", {})
    data_root = PROJECT_ROOT / root.get("data_root", "data")
    return {
        "data_root": data_root,
        "raw": data_root / "raw",
        "processed": data_root / "processed",
        "unified": data_root / "unified",
    }


def ensure_dirs(paths: dict) -> None:
    for k, v in paths.items():
        if isinstance(v, Path):
            v.mkdir(parents=True, exist_ok=True)


# ---------- Census ACS ----------
def ingest_census_acs(cfg: dict, paths: dict) -> None:
    api_key = os.environ.get("CENSUS_API_KEY", "")
    year = cfg.get("census_acs", {}).get("year", "2022")
    dataset = cfg.get("census_acs", {}).get("dataset", "acs5")
    variables = cfg.get("census_acs", {}).get("variables", ["B01003_001E", "B19013_001E", "B25077_001E", "B25064_001E"])
    var_str = ",".join(variables + ["NAME"])
    base = f"https://api.census.gov/data/{year}/acs/{dataset}"
    out_path = paths["processed"] / "acs_tract.parquet"

    all_rows = []
    cols = None
    # State FIPS 01-56 (US states + DC)
    for state_fips in [f"{i:02d}" for i in range(1, 57)]:
        if state_fips in ("02", "03", "15", "72", "78"): continue  # AK, HI, PR, VI
        params = {"get": var_str, "for": "tract:*", "in": f"state:{state_fips}"}
        if api_key:
            params["key"] = api_key
        try:
            r = requests.get(base, params=params, timeout=60)
            r.raise_for_status()
            data = r.json()
            if len(data) <= 1:
                continue
            if cols is None:
                cols = data[0]
            all_rows.extend(data[1:])
        except Exception as e:
            print(f"Census ACS state {state_fips}: {e}")
            continue

    if not all_rows or cols is None:
        print("Census ACS: no data")
        return
    df = pd.DataFrame(all_rows, columns=cols)
    df["tract_fips"] = df["state"] + df["county"] + df["tract"]
    for c in variables:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    df.to_parquet(out_path, index=False)
    print(f"Census ACS: wrote {len(df)} tracts -> {out_path}")


# ---------- FRED ----------
def ingest_fred(cfg: dict, paths: dict) -> None:
    if Fred is None:
        print("FRED: pip install fredapi and set FRED_API_KEY")
        return
    api_key = os.environ.get("FRED_API_KEY", "")
    if not api_key:
        print("FRED: set FRED_API_KEY in .env")
        return
    series_map = cfg.get("fred", {}).get("series", {"CPIAUCSL": "cpi_all_urban", "DGS10": "treasury_10yr_yield"})
    start = cfg.get("fred", {}).get("start_date", "2020-01-01")
    out_path = paths["processed"] / "fred_macro.parquet"

    fred = Fred(api_key=api_key)
    records = []
    for series_id, name in series_map.items():
        try:
            s = fred.get_series(series_id, observation_start=start)
            for dt, val in s.items():
                records.append({"date": dt.strftime("%Y-%m-%d") if hasattr(dt, "strftime") else str(dt), "series_id": series_id, "name": name, "value": val})
        except Exception as e:
            print(f"FRED {series_id}: {e}")
    if not records:
        print("FRED: no data")
        return
    df = pd.DataFrame(records)
    df.to_parquet(out_path, index=False)
    print(f"FRED: wrote {len(df)} rows -> {out_path}")


# ---------- BLS LAUS (state-level to avoid needing county list) ----------
def ingest_bls(cfg: dict, paths: dict) -> None:
    # State-level unemployment: LASST + state FIPS + 000000000003 (rate)
    states = cfg.get("bls", {}).get("states", [])
    if not states:
        states = [f"{i:02d}" for i in range(1, 57) if i not in (2, 3, 15, 72, 78)]
    series_ids = [f"LASST{s}000000000003" for s in states]
    url = "https://api.bls.gov/publicAPI/v2/timeseries/data/"
    payload = {"seriesid": series_ids[:50], "startyear": "2022", "endyear": str(datetime.now().year)}
    if os.environ.get("BLS_API_KEY"):
        payload["registrationkey"] = os.environ.get("BLS_API_KEY")

    records = []
    for i in range(0, len(series_ids), 50):
        chunk = series_ids[i : i + 50]
        payload["seriesid"] = chunk
        try:
            r = requests.post(url, json=payload, timeout=30)
            j = r.json()
            if j.get("status") != "REQUEST_SUCCEEDED":
                print("BLS:", j.get("message", j))
                continue
            for s in j.get("Results", {}).get("series", []):
                sid = s.get("seriesID", "")
                state_fips = sid[5:7] if len(sid) >= 7 else ""
                for d in s.get("data", []):
                    records.append({"state_fips": state_fips, "year": d.get("year"), "period": d.get("period"), "unemployment_rate": d.get("value")})
        except Exception as e:
            print(f"BLS: {e}")
    if not records:
        print("BLS: no data")
        return
    df = pd.DataFrame(records)
    out_path = paths["processed"] / "bls_laus.parquet"
    df.to_parquet(out_path, index=False)
    print(f"BLS: wrote {len(df)} rows -> {out_path}")


# ---------- FCC ASR bulk download ----------
def ingest_fcc_asr(cfg: dict, paths: dict) -> None:
    base_url = cfg.get("fcc_asr", {}).get("base_url", "https://data.fcc.gov/download/pub/uls/complete")
    files = cfg.get("fcc_asr", {}).get("files", ["r_tower.zip"])
    raw_dir = paths["raw"] / "fcc"
    raw_dir.mkdir(parents=True, exist_ok=True)

    for fname in files:
        url = f"{base_url}/{fname}"
        try:
            r = requests.get(url, stream=True, timeout=120)
            r.raise_for_status()
            out_zip = raw_dir / fname
            with open(out_zip, "wb") as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)
            print(f"FCC ASR: downloaded -> {out_zip}")
        except Exception as e:
            print(f"FCC ASR {fname}: {e}")

    # Optional: parse r_tower.zip EN.dat into a simple table (FCC format is pipe-delimited; layout in FCC docs)
    r_tower = raw_dir / "r_tower.zip"
    if r_tower.is_file():
        try:
            with zipfile.ZipFile(r_tower) as z:
                for name in z.namelist():
                    if "EN" in name and (name.endswith(".dat") or name.endswith(".txt")):
                        with z.open(name) as f:
                            lines = f.read().decode("utf-8", errors="ignore").strip().split("\n")
                        if not lines:
                            continue
                        # Assume first line is header or first record; FCC EN format is pipe-delimited
                        rows = [ln.split("|") for ln in lines[:50000] if ln]
                        if rows:
                            df = pd.DataFrame(rows[1:], columns=rows[0] if len(rows[0]) == len(rows[1]) else None)
                            if df is not None and len(df.columns) > 3:
                                out_processed = paths["processed"] / "fcc_asr.parquet"
                                df.to_parquet(out_processed, index=False)
                                print(f"FCC ASR: parsed {len(df)} rows -> {out_processed}")
                        break
        except Exception as e:
            print(f"FCC ASR parse: {e}")


# ---------- HUD SAFMR (ArcGIS) ----------
def ingest_hud_safmr(cfg: dict, paths: dict) -> None:
    base = "https://services.arcgis.com/VTyQ9soqVukalItT/arcgis/rest/services/HUD_PDR_Small_Area_Fair_Market_Rents/FeatureServer/1/query"
    params = {"where": "1=1", "outFields": "ZCTA,STATE,BR0,BR1,BR2,BR3,BR4", "returnGeometry": "false", "f": "json", "resultRecordCount": 1000}
    all_records = []
    offset = 0
    while True:
        params["resultOffset"] = offset
        try:
            r = requests.get(base, params=params, timeout=60)
            j = r.json()
            if "error" in j:
                print("HUD SAFMR:", j["error"])
                return
            feats = j.get("features", [])
            if not feats:
                break
            for f in feats:
                a = f.get("attributes", {})
                a["zip_code"] = a.get("ZCTA")
                all_records.append(a)
            offset += len(feats)
            if len(feats) < 1000:
                break
        except Exception as e:
            print(f"HUD SAFMR: {e}")
            break
    if not all_records:
        print("HUD SAFMR: no data")
        return
    df = pd.DataFrame(all_records)
    out_path = paths["processed"] / "hud_safmr.parquet"
    df.to_parquet(out_path, index=False)
    print(f"HUD SAFMR: wrote {len(df)} rows -> {out_path}")


# ---------- FEMA NFHL (ArcGIS) ----------
def ingest_fema_flood(cfg: dict, paths: dict) -> None:
    # Query a subset (e.g. limit) to avoid huge response; full nation would need tiling
    base = "https://hazards.fema.gov/arcgis/rest/services/public/NFHL/MapServer/28/query"
    params = {"where": "1=1", "outFields": "FLD_ZONE,ZONE_SUBTY,OBJECTID", "returnGeometry": "false", "f": "json", "resultRecordCount": 50000}
    try:
        r = requests.get(base, params=params, timeout=120)
        j = r.json()
        if "error" in j:
            print("FEMA:", j.get("error"))
            return
        feats = j.get("features", [])
        records = [f.get("attributes", {}) for f in feats]
        if not records:
            print("FEMA: no features (try different layer or bbox)")
            return
        df = pd.DataFrame(records)
        out_path = paths["processed"] / "fema_flood.parquet"
        df.to_parquet(out_path, index=False)
        print(f"FEMA: wrote {len(df)} rows -> {out_path}")
    except Exception as e:
        print(f"FEMA: {e}")


# ---------- FHFA HPI (bulk CSV download) ----------
def ingest_fhfa_hpi(cfg: dict, paths: dict) -> None:
    url = cfg.get("fhfa_hpi", {}).get("base_url", "")
    if not url:
        print("FHFA: set fhfa_hpi.base_url in ingestion_config.yaml (see FHFA website)")
        return
    raw_dir = paths["raw"] / "fhfa"
    raw_dir.mkdir(parents=True, exist_ok=True)
    try:
        r = requests.get(url, timeout=120)
        r.raise_for_status()
        z = zipfile.ZipFile(io.BytesIO(r.content))
        for name in z.namelist():
            if name.endswith(".csv"):
                df = pd.read_csv(z.open(name), nrows=50000)
                out_path = paths["processed"] / "fhfa_hpi.parquet"
                df.to_parquet(out_path, index=False)
                print(f"FHFA: wrote {len(df)} rows -> {out_path}")
                break
    except Exception as e:
        print(f"FHFA: {e}")


# ---------- Build unified table ----------
def build_unified(cfg: dict, paths: dict) -> None:
    spine_path = paths["processed"] / "spine_sites.parquet"
    if not spine_path.is_file():
        # Fallback: use synthetic if present
        syn = PROJECT_ROOT / "data" / "synthetic" / "synthetic_5k_sites.parquet"
        if syn.is_file():
            spine = pd.read_parquet(syn)
            if "tract_fips" not in spine.columns and "latitude" in spine.columns:
                spine["tract_fips"] = ""
                spine["county_fips"] = ""
                spine["zip_code"] = ""
            spine.to_parquet(spine_path, index=False)
            print(f"Spine: copied synthetic -> {spine_path}")
        else:
            print("Unified: no spine_sites.parquet or synthetic_5k_sites.parquet; skipping join")
            return
    else:
        spine = pd.read_parquet(spine_path)

    out_path = Path(cfg.get("paths", {}).get("unified_file", "data/unified/sites_enriched.parquet"))
    if not str(out_path).startswith("data"):
        out_path = paths["unified"] / "sites_enriched.parquet"
    else:
        out_path = PROJECT_ROOT / out_path
    out_path.parent.mkdir(parents=True, exist_ok=True)

    df = spine.copy()
    # ACS
    acs_path = paths["processed"] / "acs_tract.parquet"
    if acs_path.is_file() and "tract_fips" in df.columns:
        acs = pd.read_parquet(acs_path)
        tract_cols = [c for c in acs.columns if c not in ("state", "county", "tract", "NAME") and c != "tract_fips"]
        acs["tract_fips"] = acs.get("state", "").astype(str) + acs.get("county", "").astype(str) + acs.get("tract", "").astype(str)
        df = df.merge(acs[["tract_fips"] + tract_cols].drop_duplicates("tract_fips"), on="tract_fips", how="left", suffixes=("", "_acs"))

    # FRED latest (broadcast to all rows)
    fred_path = paths["processed"] / "fred_macro.parquet"
    if fred_path.is_file():
        fred = pd.read_parquet(fred_path)
        fred_latest = fred.loc[fred.groupby("name")["date"].idxmax()].set_index("name")["value"]
        for name, val in fred_latest.items():
            df[name] = val

    # HUD SAFMR
    hud_path = paths["processed"] / "hud_safmr.parquet"
    if hud_path.is_file() and "zip_code" in df.columns:
        hud = pd.read_parquet(hud_path)
        hud["zip_code"] = hud.get("ZCTA", hud.get("zip_code", "")).astype(str)
        df["zip_code"] = df["zip_code"].astype(str)
        df = df.merge(hud.drop_duplicates("zip_code"), on="zip_code", how="left")

    # BLS (state-level from pipeline)
    bls_path = paths["processed"] / "bls_laus.parquet"
    if bls_path.is_file() and "state_fips" in df.columns:
        bls = pd.read_parquet(bls_path)
        bls_latest = bls.sort_values(["year", "period"], ascending=[False, False]).drop_duplicates("state_fips", keep="first") if "year" in bls.columns else bls
        if "unemployment_rate" in bls_latest.columns:
            df = df.merge(bls_latest[["state_fips", "unemployment_rate"]].drop_duplicates("state_fips"), on="state_fips", how="left")

    df.to_parquet(out_path, index=False)
    print(f"Unified: wrote {len(df)} rows -> {out_path}")


# ---------- Main ----------
def main() -> None:
    parser = argparse.ArgumentParser(description="Ingest enrichment data (no manual download)")
    parser.add_argument("--sources", type=str, default="", help="Comma-separated: census_acs,fred,bls,fcc_asr,hud_safmr,fema_flood,fhfa_hpi")
    parser.add_argument("--build-unified", action="store_true", help="After ingest, build data/unified/sites_enriched.parquet")
    args = parser.parse_args()

    cfg = load_config()
    paths = get_paths(cfg)
    ensure_dirs(paths)
    # Normalize paths that might be "data/raw" -> data_root/raw
    if "raw" not in paths or not str(paths["raw"]).endswith("raw"):
        paths["raw"] = paths["data_root"] / "raw"
        paths["processed"] = paths["data_root"] / "processed"
        paths["unified"] = paths["data_root"] / "unified"
    paths["raw"].mkdir(parents=True, exist_ok=True)
    paths["processed"].mkdir(parents=True, exist_ok=True)
    paths["unified"].mkdir(parents=True, exist_ok=True)

    enabled = cfg.get("sources", {})
    want = set(args.sources.split(",")) if args.sources else set(enabled.keys())

    run = []
    if want:
        run = [s for s in ("census_acs", "fred", "bls", "fcc_asr", "hud_safmr", "fema_flood", "fhfa_hpi") if s in want]
    else:
        for s in ("census_acs", "fred", "bls", "fcc_asr", "hud_safmr", "fema_flood", "fhfa_hpi"):
            if enabled.get(s, True):
                run.append(s)

    runners = {
        "census_acs": ingest_census_acs,
        "fred": ingest_fred,
        "bls": ingest_bls,
        "fcc_asr": ingest_fcc_asr,
        "hud_safmr": ingest_hud_safmr,
        "fema_flood": ingest_fema_flood,
        "fhfa_hpi": ingest_fhfa_hpi,
    }
    for name in run:
        print(f"--- {name} ---")
        try:
            runners[name](cfg, paths)
        except Exception as e:
            print(f"{name} failed: {e}")

    if args.build_unified:
        print("--- build_unified ---")
        try:
            build_unified(cfg, paths)
        except Exception as e:
            print(f"build_unified failed: {e}")


if __name__ == "__main__":
    main()
