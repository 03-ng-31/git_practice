
from tools.json_validator import validate_json_output
import json

class ValidationAgent:
    def __init__(self, retries: int = 1):
        self.retries = retries

    def validate(self, raw_output: str) -> tuple:
        for _ in range(self.retries):
            try:
                data = json.loads(raw_output)
                return validate_json_output(data)
            except:
                continue
        return None, "Validation failed"
