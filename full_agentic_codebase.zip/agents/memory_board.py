
import os
import json
from datetime import datetime

class AgentMemoryBoard:
    def __init__(self, doc_id: str, memory_dir: str = "memory"):
        os.makedirs(memory_dir, exist_ok=True)
        self.path = os.path.join(memory_dir, f"{doc_id}.json")
        self._memory = self._load()
        if "_meta" not in self._memory:
            self._memory["_meta"] = {"created": datetime.utcnow().isoformat(), "log": []}

    def _load(self):
        if os.path.exists(self.path):
            with open(self.path, "r") as f:
                return json.load(f)
        return {}

    def save(self):
        with open(self.path, "w") as f:
            json.dump(self._memory, f, indent=2)

    def update(self, key: str, value, retries: int = 0, runtime: float = 0.0):
        self._memory[key] = value
        self._memory["_meta"]["log"].append({
            "step": key,
            "timestamp": datetime.utcnow().isoformat(),
            "retries": retries,
            "runtime": runtime
        })
        self.save()

    def get(self, key: str):
        return self._memory.get(key)

    def get_all(self):
        return self._memory
