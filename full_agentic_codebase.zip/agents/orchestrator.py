
from agents.planner_agent import PlannerAgent
from agents.agent_registry import AGENT_REGISTRY
from agents.memory_board import AgentMemoryBoard
import time

class AgentOrchestrator:
    def __init__(self, doc_id: str):
        self.memory = AgentMemoryBoard(doc_id)
        self.planner = PlannerAgent()

    def run(self, pdf_path, filters, fields):
        plan = self.planner.generate_plan(filters, fields)
        for agent_name in plan:
            agent = AGENT_REGISTRY.get(agent_name)
            if not agent:
                raise ValueError(f"Unknown agent: {agent_name}")

            t0 = time.time()
            if agent_name == "DocumentParserAgent":
                output = agent.parse(pdf_path)
            elif agent_name == "PromptBuilderAgent":
                output = agent.run(filters, fields)
            elif agent_name == "ExtractionAgent":
                prompt = self.memory.get("prompt")
                text = self.memory.get("parsed")["text"]
                output = agent.run(prompt, text)
            elif agent_name == "ValidationAgent":
                raw = self.memory.get("extracted")
                validated, error = agent.validate(raw)
                if error:
                    self.memory.update("error", error)
                    return {"error": error, "raw": raw}
                output = validated.dict()
            else:
                output = None

            self.memory.update(agent_name.lower(), output, runtime=time.time() - t0)

        return self.memory.get_all()
