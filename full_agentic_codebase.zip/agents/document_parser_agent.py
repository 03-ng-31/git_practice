
from tools.ocr import extract_text_from_pdf

class DocumentParserAgent:
    def parse(self, pdf_path: str) -> dict:
        return extract_text_from_pdf(pdf_path)
