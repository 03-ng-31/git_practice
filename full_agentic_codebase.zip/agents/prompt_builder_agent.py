
from langchain.chains import LLMChain
from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate

class PromptBuilderAgent:
    def __init__(self, retries: int = 2):
        self.retries = retries
        self.chain = LLMChain(
            llm=OpenAI(model="gpt-4"),
            prompt=PromptTemplate.from_template("Given filters: {filters} and fields: {fields}, generate a JSON-extractable prompt.")
        )

    def run(self, filters: dict, fields: list) -> str:
        for attempt in range(self.retries):
            try:
                return self.chain.run({"filters": str(filters), "fields": str(fields)})
            except Exception:
                if attempt == self.retries - 1:
                    raise RuntimeError("PromptBuilder failed after retries")
