
from langchain.llms import OpenAI

class ExtractionAgent:
    def __init__(self, retries: int = 2):
        self.retries = retries
        self.llm = OpenAI(model="gpt-4")

    def run(self, prompt: str, doc_text: str) -> str:
        full_input = f"{prompt}\n\n### DOCUMENT CONTENT\n{doc_text}"
        for _ in range(self.retries):
            try:
                return self.llm.invoke(full_input)
            except Exception:
                continue
        raise RuntimeError("Extraction failed")
