
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.llms import OpenAI

class PlannerAgent:
    def __init__(self):
        prompt = PromptTemplate.from_template("""
You are a planner for an AI document analysis pipeline. Based on the user-defined fields and document filters, list the ordered steps using the following agents:
- DocumentParserAgent
- PromptBuilderAgent
- ExtractionAgent
- ValidationAgent
""")
        self.chain = LLMChain(prompt=prompt, llm=OpenAI(model="gpt-4"))

    def generate_plan(self, filters: dict, fields: list) -> list:
        response = self.chain.run(filters=filters, fields=fields)
        return [line.strip() for line in response.split("\n") if line.strip()]
