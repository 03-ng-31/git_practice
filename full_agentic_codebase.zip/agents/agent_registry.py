
from agents.prompt_builder_agent import PromptBuilderAgent
from agents.document_parser_agent import DocumentParserAgent
from agents.extraction_agent import ExtractionAgent
from agents.validation_agent import ValidationAgent

AGENT_REGISTRY = {
    "DocumentParserAgent": DocumentParserAgent(),
    "PromptBuilderAgent": PromptBuilderAgent(),
    "ExtractionAgent": ExtractionAgent(),
    "ValidationAgent": ValidationAgent(),
}
