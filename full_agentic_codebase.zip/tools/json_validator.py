
from pydantic import BaseModel, Field, ValidationError
from typing import Optional, Dict

class FieldExtraction(BaseModel):
    value: Optional[str]
    reasoning: str
    confidence: float = Field(..., ge=0.0, le=1.0)

class ExtractionSchema(BaseModel):
    __root__: Dict[str, FieldExtraction]

def validate_json_output(data: dict):
    try:
        validated = ExtractionSchema.parse_obj(data)
        return validated, None
    except ValidationError as ve:
        return None, str(ve)
