
import fitz  # PyMuPDF
from pdf2image import convert_from_path
import pytesseract

def extract_text_from_pdf(pdf_path: str) -> dict:
    try:
        doc = fitz.open(pdf_path)
        text = "\n\n".join([page.get_text() for page in doc])
        return {"text": text, "is_ocr": False}
    except Exception:
        images = convert_from_path(pdf_path)
        text = " ".join([pytesseract.image_to_string(img) for img in images])
        return {"text": text, "is_ocr": True}
